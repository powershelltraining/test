using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace AmazonFBAManager.Data;

/// <summary>
/// SQL Server connection factory
/// </summary>
public interface IConnectionFactory
{
    IDbConnection Create();
    Task<IDbConnection> CreateAsync();
}

public class SqlConnectionFactory : IConnectionFactory
{
    private readonly string _connectionString;

    public SqlConnectionFactory(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
    }

    public SqlConnectionFactory(string connectionString)
    {
        _connectionString = connectionString;
    }

    public IDbConnection Create()
    {
        return new SqlConnection(_connectionString);
    }

    public Task<IDbConnection> CreateAsync()
    {
        var connection = new SqlConnection(_connectionString);
        return Task.FromResult<IDbConnection>(connection);
    }
}

/// <summary>
/// Configuration extensions for dependency injection
/// </summary>
public static class DataExtensions
{
    public static IServiceCollection AddDataServices(this IServiceCollection services, string connectionString)
    {
        services.AddSingleton<IConnectionFactory>(new SqlConnectionFactory(connectionString));
        return services;
    }
}