using Dapper;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;
using AmazonFBAManager.Data;

namespace AmazonFBAManager.Data.Repositories;

/// <summary>
/// Case Management Repository
/// </summary>
public class CaseRepository : ICaseRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public CaseRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<CaseDto>> GetCasesAsync(int sellerAccountId, string? status = null, int page = 1, int pageSize = 20)
    {
        using var conn = _connectionFactory.Create();
        var offset = (page - 1) * pageSize;
        return await conn.QueryAsync<CaseDto>(@"
            SELECT c.CaseId, c.SellerAccountId, c.AmazonCaseId, c.CaseType, c.CaseCategory, c.Status, c.Priority,
                   c.OpenedDate, c.ResolvedDate, c.ResolvedAmount, c.Subject, c.Description,
                   c.AssignedUserId, u.Username AS AssignedUsername,
                   c.EscalationLevel, c.POARequired
            FROM dbo.Cases c
            LEFT JOIN dbo.Users u ON c.AssignedUserId = u.UserId
            WHERE c.SellerAccountId = @SellerAccountId
                AND (@Status IS NULL OR c.Status = @Status)
            ORDER BY c.OpenedDate DESC
            OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY",
            new { SellerAccountId = sellerAccountId, Status = status, Offset = offset, PageSize = pageSize });
    }

    public async Task<CaseDto?> GetCaseByIdAsync(int caseId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<CaseDto>(@"
            SELECT c.CaseId, c.SellerAccountId, c.AmazonCaseId, c.CaseType, c.CaseCategory, c.Status, c.Priority,
                   c.OpenedDate, c.ResolvedDate, c.ResolvedAmount, c.Subject, c.Description,
                   c.AssignedUserId, u.Username AS AssignedUsername,
                   c.EscalationLevel, c.POARequired
            FROM dbo.Cases c
            LEFT JOIN dbo.Users u ON c.AssignedUserId = u.UserId
            WHERE c.CaseId = @CaseId",
            new { CaseId = caseId });
    }

    public async Task<int> CreateCaseAsync(CaseCreateDto caseDto)
    {
        using var conn = _connectionFactory.Create();
        return await conn.ExecuteScalarAsync<int>(@"
            INSERT INTO dbo.Cases (SellerAccountId, CaseType, Subject, Description, Priority, Status, LinkedCaseId, AssignedUserId)
            VALUES (@SellerAccountId, @CaseType, @Subject, @Description, @Priority, 'Open', @LinkedAuditId, @AssignedUserId);
            SELECT SCOPE_IDENTITY();",
            new { caseDto.SellerAccountId, caseDto.CaseType, caseDto.Subject, caseDto.Description,
                caseDto.Priority, caseDto.LinkedAuditId, caseDto.AssignedUserId });
    }

    public async Task UpdateCaseAsync(CaseDto caseDto)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.Cases
            SET Status = @Status, Priority = @Priority, Subject = @Subject, Description = @Description,
                AssignedUserId = @AssignedUserId, ModifiedDate = GETDATE()
            WHERE CaseId = @CaseId",
            caseDto);
    }

    public async Task ResolveCaseAsync(int caseId, decimal? resolvedAmount = null, string? resolutionNote = null)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.Cases
            SET Status = 'Resolved', ResolvedDate = GETDATE(), ResolvedAmount = @ResolvedAmount, ModifiedDate = GETDATE()
            WHERE CaseId = @CaseId",
            new { CaseId = caseId, ResolvedAmount = resolvedAmount });

        if (!string.IsNullOrEmpty(resolutionNote))
        {
            await conn.ExecuteAsync(@"
                INSERT INTO dbo.CaseNotes (CaseId, UserId, NoteDate, NoteText, IsInternal)
                VALUES (@CaseId, NULL, GETDATE(), 'RESOLUTION: ' + @NoteText, 1)",
                new { CaseId = caseId, NoteText = resolutionNote });
        }
    }

    public async Task EscalateCaseAsync(int caseId, int userId, string escalationReason)
    {
        using var conn = _connectionFactory.Create();
        var currentLevel = await conn.ExecuteScalarAsync<int?>(@"
            SELECT EscalationLevel FROM dbo.Cases WHERE CaseId = @CaseId");
        var newLevel = (currentLevel ?? 0) + 1;

        await conn.ExecuteAsync(@"
            UPDATE dbo.Cases SET EscalationLevel = @EscalationLevel, Status = CASE WHEN @EscalationLevel >= 2 THEN 'Escalated' ELSE Status END, ModifiedDate = GETDATE()
            WHERE CaseId = @CaseId",
            new { CaseId = caseId, EscalationLevel = newLevel });

        await conn.ExecuteAsync(@"
            INSERT INTO dbo.CaseNotes (CaseId, UserId, NoteDate, NoteText, IsInternal)
            VALUES (@CaseId, @UserId, GETDATE(), 'ESCALATION: ' + @EscalationReason + ' (Level: ' + CAST(@EscalationLevel AS VARCHAR) + ')', 1)",
            new { CaseId = caseId, UserId = userId, EscalationReason = escalationReason, EscalationLevel = newLevel });
    }

    public async Task<IEnumerable<CaseNoteDto>> GetCaseNotesAsync(int caseId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<CaseNoteDto>(@"
            SELECT n.NoteId, n.CaseId, n.UserId, u.Username, n.NoteDate, n.NoteText, n.IsInternal
            FROM dbo.CaseNotes n
            LEFT JOIN dbo.Users u ON n.UserId = u.UserId
            WHERE n.CaseId = @CaseId
            ORDER BY n.NoteDate DESC",
            new { CaseId = caseId });
    }

    public async Task AddCaseNoteAsync(int caseId, int userId, string noteText, bool isInternal = true)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            INSERT INTO dbo.CaseNotes (CaseId, UserId, NoteDate, NoteText, IsInternal)
            VALUES (@CaseId, @UserId, GETDATE(), @NoteText, @IsInternal)",
            new { CaseId = caseId, UserId = userId, NoteText = noteText, IsInternal = isInternal });
    }

    public async Task<IEnumerable<CaseAgingReportDto>> GetCaseAgingReportAsync(int sellerAccountId, int slaDays = 14)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<CaseAgingReportDto>(@"
            EXEC dbo.usp_Case_GetAgingReport @SellerAccountId, @SLADays",
            new { SellerAccountId = sellerAccountId, SLADays = slaDays });
    }

    public async Task<IEnumerable<SuppressedListingDto>> GetListingSuppressedFixesAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<SuppressedListingDto>(@"
            EXEC dbo.usp_Case_GetListingSuppressedFixes @SellerAccountId",
            new { SellerAccountId = sellerAccountId });
    }
}

/// <summary>
/// Reimbursement Repository
/// </summary>
public class ReimbursementRepository : IReimbursementRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public ReimbursementRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<ReimbursementAuditDto>> AuditLostDamagedInventoryAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<ReimbursementAuditDto>(@"
            EXEC dbo.usp_Reimbursement_AuditLostDamagedInventory @SellerAccountId, @DateFrom, @DateTo",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }

    public async Task<IEnumerable<ReturnlessRefundAuditDto>> AuditReturnlessRefundsAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<ReturnlessRefundAuditDto>(@"
            EXEC dbo.usp_Reimbursement_AuditReturnlessRefunds @SellerAccountId, @DateFrom, @DateTo",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }

    public async Task<IEnumerable<FeeOverchargeDto>> DetectFeeOverchargesAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<FeeOverchargeDto>(@"
            EXEC dbo.usp_Reimbursement_DetectFeeOvercharges @SellerAccountId, @DateFrom, @DateTo",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }

    public async Task<IEnumerable<ReimbursementChecklistItemDto>> GetMonthlyChecklistAsync(int sellerAccountId, int month, int year)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<ReimbursementChecklistItemDto>(@"
            EXEC dbo.usp_Reimbursement_MonthlyChecklist @SellerAccountId, @Month, @Year",
            new { SellerAccountId = sellerAccountId, Month = month, Year = year });
    }

    public async Task<ReimbursementKPIDashboardDto> GetKPIDashboardAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstAsync<ReimbursementKPIDashboardDto>(@"
            EXEC dbo.usp_Reimbursement_GetKPIDashboard @SellerAccountId, @DateFrom, @DateTo",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }

    public async Task<IEnumerable<COGSImpactDto>> CalculateCOGSImpactAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<COGSImpactDto>(@"
            EXEC dbo.usp_Reimbursement_CalculateCOGSImpact @SellerAccountId",
            new { SellerAccountId = sellerAccountId });
    }

    public async Task<IEnumerable<ReimbursementAuditDto>> GetPendingAuditsAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<ReimbursementAuditDto>(@"
            SELECT p.SKU, p.ASIN, p.ProductTitle, p.COGS AS CostBasis, ra.QtyExpected, ra.QtyAmazonReported,
                   ra.QtyVariance, ra.ClaimableAmount, ra.CostBasis, ra.Status, ra.AuditId
            FROM dbo.ReimbursementAudit ra
            JOIN dbo.Products p ON ra.ProductId = p.ProductId
            WHERE ra.SellerAccountId = @SellerAccountId AND ra.Status = 'Pending'
            ORDER BY ra.ClaimableAmount DESC",
            new { SellerAccountId = sellerAccountId });
    }

    public async Task UpdateAuditStatusAsync(long auditId, string status)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.ReimbursementAudit SET Status = @Status WHERE AuditId = @AuditId",
            new { AuditId = auditId, Status = status });
    }

    public async Task LinkAuditToCaseAsync(long auditId, int caseId)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.ReimbursementAudit SET LinkedCaseId = @CaseId WHERE AuditId = @AuditId",
            new { AuditId = auditId, CaseId = caseId });
    }
}

/// <summary>
/// Sales Repository
/// </summary>
public class SalesRepository : ISalesRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public SalesRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<SalesOrderDto>> GetSalesOrdersAsync(int sellerAccountId, DateTime? dateFrom = null, DateTime? dateTo = null, int page = 1, int pageSize = 20)
    {
        using var conn = _connectionFactory.Create();
        var offset = (page - 1) * pageSize;
        return await conn.QueryAsync<SalesOrderDto>(@"
            SELECT OrderId, SellerAccountId, AmazonOrderId, OrderDate, ShipDate, FulfillmentChannel, OrderStatus, TotalAmount, Currency
            FROM dbo.SalesOrders
            WHERE SellerAccountId = @SellerAccountId
                AND (@DateFrom IS NULL OR OrderDate >= @DateFrom)
                AND (@DateTo IS NULL OR OrderDate <= @DateTo)
            ORDER BY OrderDate DESC
            OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo, Offset = offset, PageSize = pageSize });
    }

    public async Task<SalesOrderDto?> GetSalesOrderByIdAsync(long orderId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<SalesOrderDto>(@"
            SELECT OrderId, SellerAccountId, AmazonOrderId, OrderDate, ShipDate, FulfillmentChannel, OrderStatus, TotalAmount, Currency
            FROM dbo.SalesOrders WHERE OrderId = @OrderId",
            new { OrderId = orderId });
    }

    public async Task<SalesOrderDto?> GetSalesOrderByAmazonIdAsync(int sellerAccountId, string amazonOrderId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<SalesOrderDto>(@"
            SELECT OrderId, SellerAccountId, AmazonOrderId, OrderDate, ShipDate, FulfillmentChannel, OrderStatus, TotalAmount, Currency
            FROM dbo.SalesOrders
            WHERE SellerAccountId = @SellerAccountId AND AmazonOrderId = @AmazonOrderId",
            new { SellerAccountId = sellerAccountId, AmazonOrderId = amazonOrderId });
    }

    public async Task<int> ImportSalesOrdersAsync(int sellerAccountId, long importId, IEnumerable<SalesOrderDto> orders)
    {
        using var conn = _connectionFactory.Create();
        var count = 0;
        foreach (var order in orders)
        {
            var existing = await conn.QueryFirstOrDefaultAsync<long>(@"
                SELECT OrderId FROM dbo.SalesOrders WHERE AmazonOrderId = @AmazonOrderId",
                new { order.AmazonOrderId });

            if (existing == 0)
            {
                await conn.ExecuteAsync(@"
                    INSERT INTO dbo.SalesOrders (SellerAccountId, AmazonOrderId, OrderDate, ShipDate, FulfillmentChannel, OrderStatus, TotalAmount, Currency)
                    VALUES (@SellerAccountId, @AmazonOrderId, @OrderDate, @ShipDate, @FulfillmentChannel, @OrderStatus, @TotalAmount, @Currency)",
                    new { sellerAccountId, order.AmazonOrderId, order.OrderDate, order.ShipDate,
                        order.FulfillmentChannel, order.OrderStatus, order.TotalAmount, order.Currency });
                count++;
            }
        }
        return count;
    }

    public async Task<IEnumerable<SalesOrderItemDto>> GetSalesOrderItemsAsync(long orderId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<SalesOrderItemDto>(@"
            SELECT OrderItemId, OrderId, ProductId, ASIN, SKU, QtySold, ItemPrice, PromotionDiscount, ShippingPrice, GiftWrapPrice
            FROM dbo.SalesOrderItems WHERE OrderId = @OrderId",
            new { OrderId = orderId });
    }

    public async Task<IEnumerable<ProfitLossBySKUDto>> GetProfitLossBySKUAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo, string groupBy = "SKU")
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<ProfitLossBySKUDto>(@"
            EXEC dbo.usp_Reports_ProfitLossBySKU @SellerAccountId, @DateFrom, @DateTo, @GroupBy",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo, GroupBy = groupBy });
    }

    public async Task<IEnumerable<SalesVelocityDto>> GetSalesVelocityAsync(int sellerAccountId, string? asin = null, int periods = 12)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<SalesVelocityDto>(@"
            EXEC dbo.usp_Reports_SalesVelocity @SellerAccountId, @ASIN, @Periods",
            new { SellerAccountId = sellerAccountId, ASIN = asin, Periods = periods });
    }

    public async Task<IEnumerable<MultiAccountSummaryDto>> GetMultiAccountSummaryAsync(int userId, DateTime dateFrom, DateTime dateTo)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<MultiAccountSummaryDto>(@"
            EXEC dbo.usp_Reports_MultiAccountSummary @UserId, @DateFrom, @DateTo",
            new { UserId = userId, DateFrom = dateFrom, DateTo = dateTo });
    }

    public async Task<DashboardSummaryDto> GetDashboardSummaryAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();

        var revenue = await conn.ExecuteScalarAsync<decimal?>(@"
            SELECT SUM(TotalAmount) FROM dbo.SalesOrders
            WHERE SellerAccountId = @SellerAccountId AND OrderDate >= CAST(GETDATE() AS DATE)",
            new { SellerAccountId = sellerAccountId }) ?? 0;

        var units = await conn.ExecuteScalarAsync<int?>(@"
            SELECT SUM(soi.QtySold) FROM dbo.SalesOrderItems soi
            JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
            WHERE so.SellerAccountId = @SellerAccountId AND so.OrderDate >= CAST(GETDATE() AS DATE)",
            new { SellerAccountId = sellerAccountId }) ?? 0;

        var netProfit = revenue * 0.3m; // Simplified calculation

        var lowStockAlerts = await conn.ExecuteScalarAsync<int?>(@"
            SELECT COUNT(*) FROM dbo.Alerts
            WHERE SellerAccountId = @SellerAccountId AND AlertType = 'LOW_STOCK' AND IsRead = 0",
            new { SellerAccountId = sellerAccountId }) ?? 0;

        var openCases = await conn.ExecuteScalarAsync<int?>(@"
            SELECT COUNT(*) FROM dbo.Cases
            WHERE SellerAccountId = @SellerAccountId AND Status NOT IN ('Resolved', 'Closed')",
            new { SellerAccountId = sellerAccountId }) ?? 0;

        var unreadAlerts = await conn.ExecuteScalarAsync<int?>(@"
            SELECT COUNT(*) FROM dbo.Alerts
            WHERE SellerAccountId = @SellerAccountId AND IsRead = 0",
            new { SellerAccountId = sellerAccountId }) ?? 0;

        var ipiScore = await conn.ExecuteScalarAsync<decimal?>(@"
            SELECT TOP 1 IPI_Score FROM dbo.InventorySnapshots
            WHERE SellerAccountId = @SellerAccountId
            ORDER BY SnapshotDate DESC",
            new { SellerAccountId = sellerAccountId });

        return new DashboardSummaryDto
        {
            TotalRevenue = revenue,
            TotalUnitsSold = units,
            NetProfit = netProfit,
            LowStockAlerts = lowStockAlerts,
            OpenCases = openCases,
            UnreadAlerts = unreadAlerts,
            IPI_Score = ipiScore
        };
    }
}