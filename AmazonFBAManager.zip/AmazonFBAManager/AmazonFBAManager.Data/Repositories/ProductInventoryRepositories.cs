using Dapper;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;
using AmazonFBAManager.Data;

namespace AmazonFBAManager.Data.Repositories;

/// <summary>
/// Product Repository
/// </summary>
public class ProductRepository : IProductRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public ProductRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<ProductDto>> GetProductsAsync(int sellerAccountId, int page = 1, int pageSize = 20)
    {
        using var conn = _connectionFactory.Create();
        var offset = (page - 1) * pageSize;
        return await conn.QueryAsync<ProductDto>(@"
            SELECT ProductId, SellerAccountId, ASIN, SKU, FNSKU, ProductTitle, Brand, Category, Subcategory,
                   UPC, EAN, Weight, Length, Width, Height, COGS, TargetMargin, ReorderPoint, ReorderQty,
                   LeadTimeDays, IsActive
            FROM dbo.Products
            WHERE SellerAccountId = @SellerAccountId AND IsActive = 1
            ORDER BY SKU
            OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY",
            new { SellerAccountId = sellerAccountId, Offset = offset, PageSize = pageSize });
    }

    public async Task<ProductDto?> GetProductByIdAsync(int productId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<ProductDto>(@"
            SELECT ProductId, SellerAccountId, ASIN, SKU, FNSKU, ProductTitle, Brand, Category, Subcategory,
                   UPC, EAN, Weight, Length, Width, Height, COGS, TargetMargin, ReorderPoint, ReorderQty,
                   LeadTimeDays, IsActive
            FROM dbo.Products
            WHERE ProductId = @ProductId",
            new { ProductId = productId });
    }

    public async Task<ProductDto?> GetProductByASINAsync(int sellerAccountId, string asin)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<ProductDto>(@"
            SELECT ProductId, SellerAccountId, ASIN, SKU, FNSKU, ProductTitle, Brand, Category, Subcategory,
                   UPC, EAN, Weight, Length, Width, Height, COGS, TargetMargin, ReorderPoint, ReorderQty,
                   LeadTimeDays, IsActive
            FROM dbo.Products
            WHERE SellerAccountId = @SellerAccountId AND ASIN = @ASIN",
            new { SellerAccountId = sellerAccountId, ASIN = asin });
    }

    public async Task<ProductDto?> GetProductBySKUAsync(int sellerAccountId, string sku)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<ProductDto>(@"
            SELECT ProductId, SellerAccountId, ASIN, SKU, FNSKU, ProductTitle, Brand, Category, Subcategory,
                   UPC, EAN, Weight, Length, Width, Height, COGS, TargetMargin, ReorderPoint, ReorderQty,
                   LeadTimeDays, IsActive
            FROM dbo.Products
            WHERE SellerAccountId = @SellerAccountId AND SKU = @SKU",
            new { SellerAccountId = sellerAccountId, SKU = sku });
    }

    public async Task<int> CreateProductAsync(ProductDto product)
    {
        using var conn = _connectionFactory.Create();
        return await conn.ExecuteScalarAsync<int>(@"
            INSERT INTO dbo.Products (SellerAccountId, ASIN, SKU, FNSKU, ProductTitle, Brand, Category,
                                      COGS, Weight, Length, Width, Height, ReorderPoint, ReorderQty, LeadTimeDays)
            VALUES (@SellerAccountId, @ASIN, @SKU, @FNSKU, @ProductTitle, @Brand, @Category,
                    @COGS, @Weight, @Length, @Width, @Height, @ReorderPoint, @ReorderQty, @LeadTimeDays);
            SELECT SCOPE_IDENTITY();",
            product);
    }

    public async Task UpdateProductAsync(ProductDto product)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.Products
            SET SKU = @SKU, FNSKU = @FNSKU, ProductTitle = @ProductTitle, Brand = @Brand,
                Category = @Category, COGS = @COGS, Weight = @Weight, Length = @Length,
                Width = @Width, Height = @Height, ReorderPoint = @ReorderPoint,
                ReorderQty = @ReorderQty, LeadTimeDays = @LeadTimeDays, ModifiedDate = GETDATE()
            WHERE ProductId = @ProductId",
            product);
    }

    public async Task DeleteProductAsync(int productId)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.Products SET IsActive = 0 WHERE ProductId = @ProductId",
            new { ProductId = productId });
    }

    public async Task<int> ImportProductsAsync(int sellerAccountId, IEnumerable<ProductDto> products)
    {
        using var conn = _connectionFactory.Create();
        var count = 0;
        foreach (var product in products)
        {
            var existing = await conn.QueryFirstOrDefaultAsync<ProductDto>(@"
                SELECT ProductId FROM dbo.Products
                WHERE SellerAccountId = @SellerAccountId AND (SKU = @SKU OR ASIN = @ASIN)",
                new { sellerAccountId, product.SKU, product.ASIN });

            if (existing == null)
            {
                await conn.ExecuteAsync(@"
                    INSERT INTO dbo.Products (SellerAccountId, ASIN, SKU, FNSKU, ProductTitle, Brand, Category,
                                              COGS, Weight, Length, Width, Height, ReorderPoint, ReorderQty, LeadTimeDays)
                    VALUES (@SellerAccountId, @ASIN, @SKU, @FNSKU, @ProductTitle, @Brand, @Category,
                            @COGS, @Weight, @Length, @Width, @Height, @ReorderPoint, @ReorderQty, @LeadTimeDays)",
                    new { sellerAccountId, product.ASIN, product.SKU, product.FNSKU, product.ProductTitle,
                        product.Brand, product.Category, product.COGS, product.Weight, product.Length,
                        product.Width, product.Height, product.ReorderPoint, product.ReorderQty, product.LeadTimeDays });
                count++;
            }
            else
            {
                await conn.ExecuteAsync(@"
                    UPDATE dbo.Products SET
                        ProductTitle = COALESCE(@ProductTitle, ProductTitle),
                        Brand = COALESCE(@Brand, Brand),
                        Category = COALESCE(@Category, Category),
                        COGS = COALESCE(@COGS, COGS),
                        Weight = COALESCE(@Weight, Weight),
                        Length = COALESCE(@Length, Length),
                        Width = COALESCE(@Width, Width),
                        Height = COALESCE(@Height, Height),
                        ReorderPoint = COALESCE(@ReorderPoint, ReorderPoint),
                        ReorderQty = COALESCE(@ReorderQty, ReorderQty),
                        ModifiedDate = GETDATE()
                    WHERE ProductId = @ProductId",
                    new { ProductId = existing.ProductId, product.ProductTitle, product.Brand, product.Category,
                        product.COGS, product.Weight, product.Length, product.Width, product.Height,
                        product.ReorderPoint, product.ReorderQty });
                count++;
            }
        }
        return count;
    }

    public async Task<IEnumerable<ProductWithInventoryDto>> GetProductsWithInventoryAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<ProductWithInventoryDto>(@"
            SELECT p.ProductId, p.SellerAccountId, p.ASIN, p.SKU, p.FNSKU, p.ProductTitle, p.Brand, p.Category,
                   p.COGS, p.ReorderPoint, p.ReorderQty, p.LeadTimeDays,
                   ISNULL(i.QtyFBA, 0) AS CurrentFBAQty,
                   ISNULL(i.QtyInbound, 0) AS InboundQty,
                   (ISNULL(i.QtyFBA, 0) + ISNULL(i.QtyInbound, 0)) AS TotalFBA,
                   ISNULL(s.DailySalesVelocity, 0) AS DailySalesVelocity,
                   CASE WHEN ISNULL(s.DailySalesVelocity, 0) > 0
                        THEN (ISNULL(i.QtyFBA, 0) + ISNULL(i.QtyInbound, 0)) / s.DailySalesVelocity
                        ELSE 999 END AS DaysOfSupply
            FROM dbo.Products p
            LEFT JOIN (
                SELECT ProductId, SUM(QtyFBA) AS QtyFBA, SUM(QtyInbound) AS QtyInbound
                FROM dbo.InventorySnapshots
                WHERE SellerAccountId = @SellerAccountId AND SnapshotDate = CAST(GETDATE() AS DATE)
                GROUP BY ProductId
            ) i ON p.ProductId = i.ProductId
            LEFT JOIN (
                SELECT soi.ProductId, AVG(CAST(soi.QtySold AS DECIMAL(10,2))) / 30 AS DailySalesVelocity
                FROM dbo.SalesOrderItems soi
                JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
                WHERE so.SellerAccountId = @SellerAccountId AND so.OrderDate >= DATEADD(DAY, -90, CAST(GETDATE() AS DATE))
                GROUP BY soi.ProductId
            ) s ON p.ProductId = s.ProductId
            WHERE p.SellerAccountId = @SellerAccountId AND p.IsActive = 1",
            new { SellerAccountId = sellerAccountId });
    }

    public async Task UpdateCOGSAsync(int productId, decimal cogs)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.Products SET COGS = @COGS, ModifiedDate = GETDATE() WHERE ProductId = @ProductId",
            new { ProductId = productId, COGS = cogs });
    }
}

/// <summary>
/// Inventory Repository
/// </summary>
public class InventoryRepository : IInventoryRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public InventoryRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<InventorySnapshotDto>> GetInventorySnapshotsAsync(int sellerAccountId, DateTime? date = null)
    {
        using var conn = _connectionFactory.Create();
        var snapshotDate = date ?? DateTime.Today;
        return await conn.QueryAsync<InventorySnapshotDto>(@"
            SELECT SnapshotId, ProductId, SellerAccountId, SnapshotDate, QtyFBA, QtyFBM, QtyInbound,
                   QtyReserved, QtyUnfulfillable, QtyWarehouseAWD, EstStorageCost, IPI_Score, DataSource
            FROM dbo.InventorySnapshots
            WHERE SellerAccountId = @SellerAccountId AND SnapshotDate = @SnapshotDate",
            new { SellerAccountId = sellerAccountId, SnapshotDate = snapshotDate });
    }

    public async Task<InventorySnapshotDto?> GetCurrentInventoryAsync(int productId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<InventorySnapshotDto>(@"
            SELECT TOP 1 SnapshotId, ProductId, SellerAccountId, SnapshotDate, QtyFBA, QtyFBM, QtyInbound,
                   QtyReserved, QtyUnfulfillable, QtyWarehouseAWD, EstStorageCost, IPI_Score, DataSource
            FROM dbo.InventorySnapshots
            WHERE ProductId = @ProductId AND SnapshotDate = CAST(GETDATE() AS DATE)
            ORDER BY SnapshotDate DESC",
            new { ProductId = productId });
    }

    public async Task<int> ImportInventorySnapshotAsync(int sellerAccountId, long importId, IEnumerable<InventorySnapshotDto> data)
    {
        using var conn = _connectionFactory.Create();
        var snapshotDate = DateTime.Today;
        var count = 0;

        foreach (var item in data)
        {
            // Get or create product
            var productId = await conn.ExecuteScalarAsync<int?>(@"
                SELECT ProductId FROM dbo.Products WHERE SellerAccountId = @SellerAccountId AND SKU = @SKU",
                new { sellerAccountId, item.SKU });

            if (productId == null)
            {
                productId = await conn.ExecuteScalarAsync<int>(@"
                    INSERT INTO dbo.Products (SellerAccountId, ASIN, SKU, FNSKU)
                    VALUES (@SellerAccountId, @ASIN, @SKU, @FNSKU);
                    SELECT SCOPE_IDENTITY();",
                    new { sellerAccountId, item.ASIN, item.SKU, item.FNSKU });
            }

            // Upsert inventory snapshot
            await conn.ExecuteAsync(@"
                IF EXISTS (SELECT 1 FROM dbo.InventorySnapshots
                          WHERE ProductId = @ProductId AND SellerAccountId = @SellerAccountId AND SnapshotDate = @SnapshotDate)
                    UPDATE dbo.InventorySnapshots
                    SET QtyFBA = @QtyFBA, QtyFBM = @QtyFBM, QtyInbound = @QtyInbound,
                        QtyReserved = @QtyReserved, QtyUnfulfillable = @QtyUnfulfillable, DataSource = @DataSource
                    WHERE ProductId = @ProductId AND SellerAccountId = @SellerAccountId AND SnapshotDate = @SnapshotDate
                ELSE
                    INSERT INTO dbo.InventorySnapshots (ProductId, SellerAccountId, SnapshotDate, QtyFBA, QtyFBM, QtyInbound, QtyReserved, QtyUnfulfillable, DataSource)
                    VALUES (@ProductId, @SellerAccountId, @SnapshotDate, @QtyFBA, @QtyFBM, @QtyInbound, @QtyReserved, @QtyUnfulfillable, @DataSource)",
                new { ProductId = productId, SellerAccountId = sellerAccountId, SnapshotDate = snapshotDate,
                    item.QtyFBA, item.QtyFBM, item.QtyInbound, item.QtyReserved, item.QtyUnfulfillable, item.DataSource });
            count++;
        }

        return count;
    }

    public async Task<IEnumerable<ReorderSuggestionDto>> GetReorderSuggestionsAsync(int sellerAccountId, int leadTimeDays = 30, decimal serviceLevel = 0.95m)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<ReorderSuggestionDto>(@"
            EXEC dbo.usp_Inventory_GetReorderSuggestions @SellerAccountId, @LeadTimeDays, @ServiceLevel",
            new { SellerAccountId = sellerAccountId, LeadTimeDays = leadTimeDays, ServiceLevel = serviceLevel });
    }

    public async Task<IEnumerable<OverstockReportDto>> GetOverstockReportAsync(int sellerAccountId, int daysOfSupplyThreshold = 365)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<OverstockReportDto>(@"
            EXEC dbo.usp_Inventory_GetOverstockReport @SellerAccountId, @DaysOfSupplyThreshold",
            new { SellerAccountId = sellerAccountId, DaysOfSupplyThreshold = daysOfSupplyThreshold });
    }

    public async Task<IEnumerable<AgedInventoryFeeRiskDto>> GetAgedInventoryFeeRiskAsync(int sellerAccountId, DateTime? snapshotDate = null)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<AgedInventoryFeeRiskDto>(@"
            EXEC dbo.usp_Inventory_GetAgedInventoryFeeRisk @SellerAccountId, @SnapshotDate",
            new { SellerAccountId = sellerAccountId, SnapshotDate = snapshotDate ?? DateTime.Today });
    }

    public async Task<IEnumerable<StrandedInventoryDto>> GetStrandedInventoryAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<StrandedInventoryDto>(@"
            EXEC dbo.usp_Inventory_GetStrandedInventory @SellerAccountId",
            new { SellerAccountId = sellerAccountId });
    }

    public async Task<IEnumerable<IPIImprovementActionDto>> GetIPIImprovementActionsAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<IPIImprovementActionDto>(@"
            EXEC dbo.usp_Inventory_GetIPIImprovementActions @SellerAccountId",
            new { SellerAccountId = sellerAccountId });
    }

    public async Task CheckLowStockAlertsAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            EXEC dbo.usp_Inventory_CheckLowStockAlerts @SellerAccountId",
            new { SellerAccountId = sellerAccountId });
    }
}