using Dapper;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;
using AmazonFBAManager.Data;

namespace AmazonFBAManager.Data.Repositories;

/// <summary>
/// PPC Repository
/// </summary>
public class PPCRepository : IPPCRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public PPCRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<PPCCampaignDto>> GetCampaignsAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<PPCCampaignDto>(@"
            SELECT CampaignId, SellerAccountId, AmazonCampaignId, CampaignName, CampaignType,
                   TargetingType, State, DailyBudget, StartDate, EndDate
            FROM dbo.PPCCampaigns
            WHERE SellerAccountId = @SellerAccountId
            ORDER BY CampaignName",
            new { SellerAccountId = sellerAccountId });
    }

    public async Task<PPCCampaignDto?> GetCampaignByIdAsync(int campaignId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<PPCCampaignDto>(@"
            SELECT CampaignId, SellerAccountId, AmazonCampaignId, CampaignName, CampaignType,
                   TargetingType, State, DailyBudget, StartDate, EndDate
            FROM dbo.PPCCampaigns WHERE CampaignId = @CampaignId",
            new { CampaignId = campaignId });
    }

    public async Task<int> CreateCampaignAsync(PPCCampaignDto campaign)
    {
        using var conn = _connectionFactory.Create();
        return await conn.ExecuteScalarAsync<int>(@"
            INSERT INTO dbo.PPCCampaigns (SellerAccountId, AmazonCampaignId, CampaignName, CampaignType, TargetingType, State, DailyBudget)
            VALUES (@SellerAccountId, @AmazonCampaignId, @CampaignName, @CampaignType, @TargetingType, @State, @DailyBudget);
            SELECT SCOPE_IDENTITY();",
            campaign);
    }

    public async Task UpdateCampaignAsync(PPCCampaignDto campaign)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.PPCCampaigns SET CampaignName = @CampaignName, State = @State, DailyBudget = @DailyBudget, ModifiedDate = GETDATE()
            WHERE CampaignId = @CampaignId",
            campaign);
    }

    public async Task<IEnumerable<PPCKeywordDto>> GetKeywordsAsync(int sellerAccountId, int? campaignId = null, string? period = null)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<PPCKeywordDto>(@"
            SELECT k.KeywordId, k.CampaignId, k.AdGroupId, k.KeywordText, k.MatchType, k.Bid,
                   k.Impressions, k.Clicks, k.Spend, k.Sales, k.ACoS, k.ROAS, k.Period
            FROM dbo.PPCKeywords k
            JOIN dbo.PPCCampaigns c ON k.CampaignId = c.CampaignId
            WHERE c.SellerAccountId = @SellerAccountId
                AND (@CampaignId IS NULL OR k.CampaignId = @CampaignId)
                AND (@Period IS NULL OR k.Period = @Period)
            ORDER BY k.Spend DESC",
            new { SellerAccountId = sellerAccountId, CampaignId = campaignId, Period = period });
    }

    public async Task<int> ImportKeywordsAsync(int sellerAccountId, long importId, IEnumerable<PPCKeywordDto> keywords, string period)
    {
        using var conn = _connectionFactory.Create();
        var count = 0;

        foreach (var kw in keywords)
        {
            // Get or create campaign
            var campaignId = await conn.ExecuteScalarAsync<int?>(@"
                SELECT CampaignId FROM dbo.PPCCampaigns WHERE SellerAccountId = @SellerAccountId AND CampaignName = @CampaignName",
                new { sellerAccountId, kw.CampaignName });

            if (campaignId == null)
            {
                campaignId = await conn.ExecuteScalarAsync<int>(@"
                    INSERT INTO dbo.PPCCampaigns (SellerAccountId, CampaignName, CampaignType, TargetingType, State)
                    VALUES (@SellerAccountId, @CampaignName, 'SponsoredProducts', 'Manual', 'Enabled');
                    SELECT SCOPE_IDENTITY();",
                    new { sellerAccountId, kw.CampaignName });
            }

            // Calculate ACoS and ROAS
            var acos = kw.Sales > 0 ? (kw.Spend / kw.Sales) * 100 : 0m;
            var roas = kw.Spend > 0 ? kw.Sales / kw.Spend : 0m;

            await conn.ExecuteAsync(@"
                INSERT INTO dbo.PPCKeywords (CampaignId, AdGroupId, KeywordText, MatchType, Bid, Impressions, Clicks, Spend, Sales, ACoS, ROAS, Period)
                VALUES (@CampaignId, @AdGroupId, @KeywordText, @MatchType, @Bid, @Impressions, @Clicks, @Spend, @Sales, @ACoS, @ROAS, @Period)",
                new { CampaignId = campaignId, kw.AdGroupId, kw.KeywordText, kw.MatchType, kw.Bid,
                    kw.Impressions, kw.Clicks, kw.Spend, kw.Sales, ACoS = acos, ROAS = roas, Period = period });
            count++;
        }

        return count;
    }

    public async Task<IEnumerable<WastedSpendDto>> AuditCampaignsAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<WastedSpendDto>(@"
            EXEC dbo.usp_PPC_AuditCampaigns @SellerAccountId, @DateFrom, @DateTo",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }

    public async Task<TACoSReportDto> CalculateTACoSAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstAsync<TACoSReportDto>(@"
            EXEC dbo.usp_PPC_CalculateTACoS @SellerAccountId, @DateFrom, @DateTo",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }

    public async Task<IEnumerable<BidAdjustmentDto>> GetBidAdjustmentSuggestionsAsync(int sellerAccountId, decimal targetACoS = 25m)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<BidAdjustmentDto>(@"
            EXEC dbo.usp_PPC_GetBidAdjustmentSuggestions @SellerAccountId, @TargetACoS",
            new { SellerAccountId = sellerAccountId, TargetACoS = targetACoS });
    }
}

/// <summary>
/// Return Repository
/// </summary>
public class ReturnRepository : IReturnRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public ReturnRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<ReturnDto>> GetReturnsAsync(int sellerAccountId, DateTime? dateFrom = null, DateTime? dateTo = null)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<ReturnDto>(@"
            SELECT ReturnId, SellerAccountId, AmazonOrderId, ProductId, ReturnDate, CustomerRefundDate,
                   ReturnReceivedDate, ReturnStatus, ReturnReason, Qty, RefundAmount, ReturnlessRefund, DispositionCode
            FROM dbo.Returns
            WHERE SellerAccountId = @SellerAccountId
                AND (@DateFrom IS NULL OR ReturnDate >= @DateFrom)
                AND (@DateTo IS NULL OR ReturnDate <= @DateTo)
            ORDER BY ReturnDate DESC",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }

    public async Task<int> ImportReturnsAsync(int sellerAccountId, long importId, IEnumerable<ReturnDto> returns)
    {
        using var conn = _connectionFactory.Create();
        var count = 0;

        foreach (var ret in returns)
        {
            await conn.ExecuteAsync(@"
                INSERT INTO dbo.Returns (SellerAccountId, AmazonOrderId, ProductId, ReturnDate, ReturnStatus,
                                         ReturnReason, Qty, RefundAmount, ReturnlessRefund, DispositionCode)
                VALUES (@SellerAccountId, @AmazonOrderId, @ProductId, @ReturnDate, @ReturnStatus,
                        @ReturnReason, @Qty, @RefundAmount, @ReturnlessRefund, @DispositionCode)",
                new { sellerAccountId, ret.AmazonOrderId, ret.ProductId, ret.ReturnDate, ret.ReturnStatus,
                    ret.ReturnReason, ret.Qty, ret.RefundAmount, ret.ReturnlessRefund, ret.DispositionCode });
            count++;
        }

        return count;
    }

    public async Task<ReturnRateAnalysisDto> GetReturnRateAnalysisAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstAsync<ReturnRateAnalysisDto>(@"
            EXEC dbo.usp_Reports_ReturnRateAnalysis @SellerAccountId, @DateFrom, @DateTo",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }

    public async Task<IEnumerable<ReturnRateBySKUDto>> GetReturnRateBySKUAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<ReturnRateBySKUDto>(@"
            SELECT p.SKU, p.ASIN, p.ProductTitle, COUNT(r.ReturnId) AS ReturnCount, SUM(r.Qty) AS ReturnedUnits,
                   (SELECT SUM(soi.QtySold) FROM dbo.SalesOrderItems soi
                    JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
                    WHERE soi.ProductId = p.ProductId AND so.OrderDate BETWEEN @DateFrom AND @DateTo) AS UnitsSold,
                   CASE WHEN (SELECT SUM(soi.QtySold) FROM dbo.SalesOrderItems soi
                             JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
                             WHERE soi.ProductId = p.ProductId AND so.OrderDate BETWEEN @DateFrom AND @DateTo) > 0
                        THEN CAST(COUNT(r.ReturnId) AS DECIMAL(10,2)) /
                             (SELECT SUM(soi.QtySold) FROM dbo.SalesOrderItems soi
                              JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
                              WHERE soi.ProductId = p.ProductId AND so.OrderDate BETWEEN @DateFrom AND @DateTo) * 100
                        ELSE 0 END AS ReturnRatePct,
                   SUM(r.RefundAmount) AS TotalRefunded,
                   (SELECT TOP 1 r2.ReturnReason FROM dbo.Returns r2 WHERE r2.ProductId = p.ProductId
                    GROUP BY r2.ReturnReason ORDER BY COUNT(*) DESC) AS TopReturnReason,
                   CAST(SUM(CASE WHEN r.ReturnlessRefund = 1 THEN 1 ELSE 0 END) AS DECIMAL(10,2)) /
                   CAST(COUNT(*) AS DECIMAL(10,2)) * 100 AS ReturnlessRefundPct
            FROM dbo.Returns r
            JOIN dbo.Products p ON r.ProductId = p.ProductId
            WHERE r.SellerAccountId = @SellerAccountId AND r.ReturnDate BETWEEN @DateFrom AND @DateTo
            GROUP BY p.ProductId, p.SKU, p.ASIN, p.ProductTitle
            HAVING COUNT(r.ReturnId) > 0
            ORDER BY ReturnRatePct DESC",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }
}

/// <summary>
/// Fee Repository
/// </summary>
public class FeeRepository : IFeeRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public FeeRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<FBADebitNoteDto>> GetFeesAsync(int sellerAccountId, DateTime? dateFrom = null, DateTime? dateTo = null)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<FBADebitNoteDto>(@"
            SELECT FeeId, ProductId, SellerAccountId, FeeDate, FeeType, FeeAmount, Currency, ReferenceId, FulfillmentCenterId
            FROM dbo.FBAFees
            WHERE SellerAccountId = @SellerAccountId
                AND (@DateFrom IS NULL OR FeeDate >= @DateFrom)
                AND (@DateTo IS NULL OR FeeDate <= @DateTo)
            ORDER BY FeeDate DESC",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }

    public async Task<int> ImportFeesAsync(int sellerAccountId, long importId, IEnumerable<FBADebitNoteDto> fees)
    {
        using var conn = _connectionFactory.Create();
        var count = 0;

        foreach (var fee in fees)
        {
            await conn.ExecuteAsync(@"
                INSERT INTO dbo.FBAFees (ProductId, SellerAccountId, FeeDate, FeeType, FeeAmount, Currency, FulfillmentCenterId)
                VALUES (@ProductId, @SellerAccountId, @FeeDate, @FeeType, @FeeAmount, @Currency, @FulfillmentCenterId)",
                new { fee.ProductId, SellerAccountId = sellerAccountId, fee.FeeDate, fee.FeeType, fee.FeeAmount, fee.Currency, fee.FulfillmentCenterId });
            count++;
        }

        return count;
    }

    public async Task<IEnumerable<FeeBreakdownDto>> GetFeeBreakdownByASINAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<FeeBreakdownDto>(@"
            EXEC dbo.usp_Reports_FeeBreakdownByASIN @SellerAccountId, @DateFrom, @DateTo",
            new { SellerAccountId = sellerAccountId, DateFrom = dateFrom, DateTo = dateTo });
    }
}

/// <summary>
/// CSV Import Repository
/// </summary>
public class CSVImportRepository : ICSVImportRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public CSVImportRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<CSVImportDto>> GetImportsAsync(int sellerAccountId, int page = 1, int pageSize = 20)
    {
        using var conn = _connectionFactory.Create();
        var offset = (page - 1) * pageSize;
        return await conn.QueryAsync<CSVImportDto>(@"
            SELECT ImportId, SellerAccountId, UserId, ImportDate, ReportType, FileName, FilePath,
                   RowsTotal, RowsImported, RowsErrored, Status, ErrorLog, CompletedDate
            FROM dbo.CSVImports
            WHERE SellerAccountId = @SellerAccountId
            ORDER BY ImportDate DESC
            OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY",
            new { SellerAccountId = sellerAccountId, Offset = offset, PageSize = pageSize });
    }

    public async Task<CSVImportDto?> GetImportByIdAsync(long importId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<CSVImportDto>(@"
            SELECT ImportId, SellerAccountId, UserId, ImportDate, ReportType, FileName, FilePath,
                   RowsTotal, RowsImported, RowsErrored, Status, ErrorLog, CompletedDate
            FROM dbo.CSVImports WHERE ImportId = @ImportId",
            new { ImportId = importId });
    }

    public async Task<long> CreateImportAsync(CSVImportDto importDto)
    {
        using var conn = _connectionFactory.Create();
        return await conn.ExecuteScalarAsync<long>(@"
            INSERT INTO dbo.CSVImports (SellerAccountId, UserId, ReportType, FileName, FilePath, Status)
            VALUES (@SellerAccountId, @UserId, @ReportType, @FileName, @FilePath, 'Pending');
            SELECT SCOPE_IDENTITY();",
            importDto);
    }

    public async Task UpdateImportStatusAsync(long importId, string status, int rowsImported, int rowsErrored)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.CSVImports
            SET Status = @Status, RowsImported = @RowsImported, RowsErrored = @RowsErrored,
                CompletedDate = CASE WHEN @Status IN ('Complete', 'Partial', 'Failed') THEN GETDATE() ELSE CompletedDate END
            WHERE ImportId = @ImportId",
            new { ImportId = importId, Status = status, RowsImported = rowsImported, RowsErrored = rowsErrored });
    }

    public async Task<CSVImportResultDto> ImportInventorySnapshotAsync(int sellerAccountId, long importId, IEnumerable<InventorySnapshotDto> data)
    {
        var inventoryRepo = new InventoryRepository(_connectionFactory);
        var count = await inventoryRepo.ImportInventorySnapshotAsync(sellerAccountId, importId, data);
        return new CSVImportResultDto { RowsImported = count, RowsErrored = 0, Message = $"Imported {count} inventory records" };
    }

    public async Task<CSVImportResultDto> ImportProductsAsync(int sellerAccountId, long importId, IEnumerable<ProductDto> data)
    {
        var productRepo = new ProductRepository(_connectionFactory);
        var count = await productRepo.ImportProductsAsync(sellerAccountId, data);
        return new CSVImportResultDto { RowsImported = count, RowsErrored = 0, Message = $"Imported {count} products" };
    }

    public async Task<CSVImportResultDto> ImportReturnsAsync(int sellerAccountId, long importId, IEnumerable<ReturnDto> data)
    {
        var returnRepo = new ReturnRepository(_connectionFactory);
        var count = await returnRepo.ImportReturnsAsync(sellerAccountId, importId, data);
        return new CSVImportResultDto { RowsImported = count, RowsErrored = 0, Message = $"Imported {count} returns" };
    }

    public async Task<CSVImportResultDto> ImportFeesAsync(int sellerAccountId, long importId, IEnumerable<FBADebitNoteDto> data)
    {
        var feeRepo = new FeeRepository(_connectionFactory);
        var count = await feeRepo.ImportFeesAsync(sellerAccountId, importId, data);
        return new CSVImportResultDto { RowsImported = count, RowsErrored = 0, Message = $"Imported {count} fees" };
    }

    public async Task<CSVImportResultDto> ImportReimbursementsAsync(int sellerAccountId, long importId, IEnumerable<ReimbursementAuditDto> data)
    {
        return new CSVImportResultDto { RowsImported = 0, RowsErrored = 0, Message = "Reimbursement imports not yet implemented" };
    }

    public async Task<CSVImportResultDto> ImportPPCKeywordsAsync(int sellerAccountId, long importId, IEnumerable<PPCKeywordDto> data, string period)
    {
        var ppcRepo = new PPCRepository(_connectionFactory);
        var count = await ppcRepo.ImportKeywordsAsync(sellerAccountId, importId, data, period);
        return new CSVImportResultDto { RowsImported = count, RowsErrored = 0, Message = $"Imported {count} PPC keywords" };
    }
}

/// <summary>
/// Alert Repository
/// </summary>
public class AlertRepository : IAlertRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public AlertRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<AlertDto>> GetAlertsAsync(int sellerAccountId, bool? isRead = null, int page = 1, int pageSize = 20)
    {
        using var conn = _connectionFactory.Create();
        var offset = (page - 1) * pageSize;
        return await conn.QueryAsync<AlertDto>(@"
            SELECT AlertId, SellerAccountId, AlertType, ProductId, CaseId, AlertDate, Message, Severity, IsRead, ResolvedDate, ResolvedByUserId
            FROM dbo.Alerts
            WHERE SellerAccountId = @SellerAccountId
                AND (@IsRead IS NULL OR IsRead = @IsRead)
            ORDER BY AlertDate DESC
            OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY",
            new { SellerAccountId = sellerAccountId, IsRead = isRead, Offset = offset, PageSize = pageSize });
    }

    public async Task<AlertDto?> GetAlertByIdAsync(long alertId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<AlertDto>(@"
            SELECT AlertId, SellerAccountId, AlertType, ProductId, CaseId, AlertDate, Message, Severity, IsRead, ResolvedDate, ResolvedByUserId
            FROM dbo.Alerts WHERE AlertId = @AlertId",
            new { AlertId = alertId });
    }

    public async Task MarkAlertAsReadAsync(long alertId)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.Alerts SET IsRead = 1 WHERE AlertId = @AlertId",
            new { AlertId = alertId });
    }

    public async Task MarkAlertAsResolvedAsync(long alertId, int resolvedByUserId)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.Alerts SET IsRead = 1, ResolvedDate = GETDATE(), ResolvedByUserId = @ResolvedByUserId WHERE AlertId = @AlertId",
            new { AlertId = alertId, ResolvedByUserId = resolvedByUserId });
    }

    public async Task<AlertSummaryDto> GetAlertSummaryAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        var result = await conn.QueryFirstOrDefaultAsync<AlertSummaryDto>(@"
            SELECT
                COUNT(*) AS TotalAlerts,
                SUM(CASE WHEN IsRead = 0 THEN 1 ELSE 0 END) AS UnreadAlerts,
                SUM(CASE WHEN Severity = 'Critical' AND IsRead = 0 THEN 1 ELSE 0 END) AS CriticalAlerts,
                SUM(CASE WHEN Severity = 'High' AND IsRead = 0 THEN 1 ELSE 0 END) AS HighAlerts,
                SUM(CASE WHEN Severity = 'Medium' AND IsRead = 0 THEN 1 ELSE 0 END) AS MediumAlerts,
                SUM(CASE WHEN Severity = 'Low' AND IsRead = 0 THEN 1 ELSE 0 END) AS LowAlerts
            FROM dbo.Alerts WHERE SellerAccountId = @SellerAccountId",
            new { SellerAccountId = sellerAccountId });
        return result ?? new AlertSummaryDto();
    }

    public async Task<IEnumerable<AlertDto>> GetUnreadAlertsAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<AlertDto>(@"
            SELECT AlertId, SellerAccountId, AlertType, ProductId, CaseId, AlertDate, Message, Severity, IsRead, ResolvedDate, ResolvedByUserId
            FROM dbo.Alerts
            WHERE SellerAccountId = @SellerAccountId AND IsRead = 0
            ORDER BY
                CASE Severity WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END,
                AlertDate DESC",
            new { SellerAccountId = sellerAccountId });
    }
}

/// <summary>
/// Email Template Repository
/// </summary>
public class EmailTemplateRepository : IEmailTemplateRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public EmailTemplateRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<EmailTemplateDto>> GetTemplatesAsync(string? category = null, bool? isActive = true)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<EmailTemplateDto>(@"
            SELECT TemplateId, TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips, IsActive
            FROM dbo.EmailTemplates
            WHERE (@Category IS NULL OR Category = @Category)
                AND (@IsActive IS NULL OR IsActive = @IsActive)
            ORDER BY Category, TemplateName",
            new { Category = category, IsActive = isActive });
    }

    public async Task<EmailTemplateDto?> GetTemplateByIdAsync(int templateId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<EmailTemplateDto>(@"
            SELECT TemplateId, TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips, IsActive
            FROM dbo.EmailTemplates WHERE TemplateId = @TemplateId",
            new { TemplateId = templateId });
    }

    public async Task<EmailTemplateDto?> GetTemplateByNameAsync(string templateName)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<EmailTemplateDto>(@"
            SELECT TemplateId, TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips, IsActive
            FROM dbo.EmailTemplates WHERE TemplateName = @TemplateName",
            new { TemplateName = templateName });
    }
}

/// <summary>
/// Help Repository
/// </summary>
public class HelpRepository : IHelpRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public HelpRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<HelpTopicDto>> GetTopicsAsync(string? section = null)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<HelpTopicDto>(@"
            SELECT TopicId, Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake
            FROM dbo.HelpTopics
            WHERE (@Section IS NULL OR Section = @Section) AND IsActive = 1
            ORDER BY Section, TopicName",
            new { Section = section });
    }

    public async Task<HelpTopicDto?> GetTopicByIdAsync(int topicId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<HelpTopicDto>(@"
            SELECT TopicId, Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake
            FROM dbo.HelpTopics WHERE TopicId = @TopicId",
            new { TopicId = topicId });
    }

    public async Task<IEnumerable<string>> GetSectionsAsync()
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<string>(@"
            SELECT DISTINCT Section FROM dbo.HelpTopics WHERE IsActive = 1 ORDER BY Section");
    }
}

/// <summary>
/// Settings Repository
/// </summary>
public class SettingsRepository : ISettingsRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public SettingsRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<AlertThresholdDto>> GetAlertThresholdsAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<AlertThresholdDto>(@"
            SELECT ThresholdId, SellerAccountId, AlertType, ThresholdValue, IsEnabled
            FROM dbo.AlertThresholds
            WHERE SellerAccountId = @SellerAccountId",
            new { SellerAccountId = sellerAccountId });
    }

    public async Task SetAlertThresholdAsync(int sellerAccountId, string alertType, decimal thresholdValue, bool isEnabled = true)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            IF EXISTS (SELECT 1 FROM dbo.AlertThresholds WHERE SellerAccountId = @SellerAccountId AND AlertType = @AlertType)
                UPDATE dbo.AlertThresholds SET ThresholdValue = @ThresholdValue, IsEnabled = @IsEnabled
                WHERE SellerAccountId = @SellerAccountId AND AlertType = @AlertType
            ELSE
                INSERT INTO dbo.AlertThresholds (SellerAccountId, AlertType, ThresholdValue, IsEnabled)
                VALUES (@SellerAccountId, @AlertType, @ThresholdValue, @IsEnabled)",
            new { SellerAccountId = sellerAccountId, AlertType = alertType, ThresholdValue = thresholdValue, IsEnabled = isEnabled });
    }
}