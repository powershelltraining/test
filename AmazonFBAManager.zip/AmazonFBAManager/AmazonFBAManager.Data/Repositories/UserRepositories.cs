using Dapper;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;
using AmazonFBAManager.Data;

namespace AmazonFBAManager.Data.Repositories;

/// <summary>
/// User and Authentication Repository
/// </summary>
public class UserRepository : IUserRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public UserRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<LoginResponseDto> ValidateCredentialsAsync(string username, string password)
    {
        using var conn = _connectionFactory.Create();

        var user = await conn.QueryFirstOrDefaultAsync<UserDto>(@"
            SELECT u.UserId, u.Username, u.Email, r.RoleName, r.RoleId, u.IsActive, u.LastLoginDate, u.CreatedDate
            FROM dbo.Users u
            JOIN dbo.Roles r ON u.RoleId = r.RoleId
            WHERE u.Username = @Username AND u.IsActive = 1",
            new { Username = username });

        if (user == null)
        {
            return new LoginResponseDto { Success = false, Message = "User not found" };
        }

        // In production, use proper password hashing (e.g., BCrypt)
        // For demo purposes, comparing plain text - replace with proper implementation
        if (user.PasswordHash != password)
        {
            return new LoginResponseDto { Success = false, Message = "Invalid password" };
        }

        // Update last login
        await conn.ExecuteAsync(
            "UPDATE dbo.Users SET LastLoginDate = GETDATE() WHERE UserId = @UserId",
            new { user.UserId });

        // Generate token (in production, use proper JWT generation)
        var token = Convert.ToBase64String(Guid.NewGuid().ToByteArray());

        return new LoginResponseDto
        {
            Success = true,
            Token = token,
            User = user,
            Message = "Login successful"
        };
    }

    public async Task<UserDto?> GetUserByIdAsync(int userId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<UserDto>(@"
            SELECT u.UserId, u.Username, u.Email, r.RoleName, r.RoleId, u.IsActive, u.LastLoginDate, u.CreatedDate
            FROM dbo.Users u
            JOIN dbo.Roles r ON u.RoleId = r.RoleId
            WHERE u.UserId = @UserId",
            new { UserId = userId });
    }

    public async Task<IEnumerable<UserDto>> GetAllUsersAsync()
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<UserDto>(@"
            SELECT u.UserId, u.Username, u.Email, r.RoleName, r.RoleId, u.IsActive, u.LastLoginDate, u.CreatedDate
            FROM dbo.Users u
            JOIN dbo.Roles r ON u.RoleId = r.RoleId
            ORDER BY u.Username");
    }

    public async Task<int> CreateUserAsync(string username, string email, string passwordHash, int roleId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.ExecuteScalarAsync<int>(@"
            INSERT INTO dbo.Users (Username, Email, PasswordHash, RoleId)
            VALUES (@Username, @Email, @PasswordHash, @RoleId);
            SELECT SCOPE_IDENTITY();",
            new { Username = username, Email = email, PasswordHash = passwordHash, RoleId = roleId });
    }

    public async Task<UserAccountAccessDto> ValidateUserAccountAccessAsync(int userId, int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<UserAccountAccessDto>(@"
            SELECT TOP 1
                1 AS HasAccess,
                usa.PermissionLevel AS PermissionLevel
            FROM dbo.UserSellerAccounts usa
            JOIN dbo.Users u ON usa.UserId = u.UserId
            WHERE usa.UserId = @UserId
                AND usa.SellerAccountId = @SellerAccountId
                AND u.IsActive = 1",
            new { UserId = userId, SellerAccountId = sellerAccountId }) ?? new UserAccountAccessDto { HasAccess = false };
    }

    public async Task<IEnumerable<SellerAccountDto>> GetUserSellerAccountsAsync(int userId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<SellerAccountDto>(@"
            SELECT sa.SellerAccountId, sa.AccountName, sa.MarketplaceId, m.MarketplaceName, sa.Region, sa.IsActive, sa.CreatedDate, sa.ModifiedDate
            FROM dbo.SellerAccounts sa
            JOIN dbo.UserSellerAccounts usa ON sa.SellerAccountId = usa.SellerAccountId
            JOIN dbo.Marketplaces m ON sa.MarketplaceId = m.MarketplaceId
            WHERE usa.UserId = @UserId AND sa.IsActive = 1",
            new { UserId = userId });
    }

    public async Task AssignUserToAccountAsync(int userId, int sellerAccountId, string permissionLevel)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            IF EXISTS (SELECT 1 FROM dbo.UserSellerAccounts WHERE UserId = @UserId AND SellerAccountId = @SellerAccountId)
                UPDATE dbo.UserSellerAccounts SET PermissionLevel = @PermissionLevel WHERE UserId = @UserId AND SellerAccountId = @SellerAccountId
            ELSE
                INSERT INTO dbo.UserSellerAccounts (UserId, SellerAccountId, PermissionLevel) VALUES (@UserId, @SellerAccountId, @PermissionLevel)",
            new { UserId = userId, SellerAccountId = sellerAccountId, PermissionLevel = permissionLevel });
    }
}

/// <summary>
/// Seller Account Repository
/// </summary>
public class SellerAccountRepository : ISellerAccountRepository
{
    private readonly IConnectionFactory _connectionFactory;

    public SellerAccountRepository(IConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IEnumerable<SellerAccountDto>> GetAllSellerAccountsAsync()
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryAsync<SellerAccountDto>(@"
            SELECT sa.SellerAccountId, sa.AccountName, sa.MarketplaceId, m.MarketplaceName, sa.Region, sa.IsActive, sa.CreatedDate, sa.ModifiedDate
            FROM dbo.SellerAccounts sa
            JOIN dbo.Marketplaces m ON sa.MarketplaceId = m.MarketplaceId
            WHERE sa.IsActive = 1
            ORDER BY sa.AccountName");
    }

    public async Task<SellerAccountDto?> GetSellerAccountByIdAsync(int sellerAccountId)
    {
        using var conn = _connectionFactory.Create();
        return await conn.QueryFirstOrDefaultAsync<SellerAccountDto>(@"
            SELECT sa.SellerAccountId, sa.AccountName, sa.MarketplaceId, m.MarketplaceName, sa.Region, sa.IsActive, sa.CreatedDate, sa.ModifiedDate
            FROM dbo.SellerAccounts sa
            JOIN dbo.Marketplaces m ON sa.MarketplaceId = m.MarketplaceId
            WHERE sa.SellerAccountId = @SellerAccountId",
            new { SellerAccountId = sellerAccountId });
    }

    public async Task<int> CreateSellerAccountAsync(SellerAccountDto account)
    {
        using var conn = _connectionFactory.Create();
        return await conn.ExecuteScalarAsync<int>(@"
            INSERT INTO dbo.SellerAccounts (AccountName, MarketplaceId, Region, MerchantToken, SPAPIClientId, SPAPIClientSecret, RefreshToken)
            VALUES (@AccountName, @MarketplaceId, @Region, @MerchantToken, @SPAPIClientId, @SPAPIClientSecret, @RefreshToken);
            SELECT SCOPE_IDENTITY();",
            new { account.AccountName, account.MarketplaceId, account.Region, account.MerchantToken, account.SPAPIClientId, account.SPAPIClientSecret, account.RefreshToken });
    }

    public async Task UpdateSellerAccountAsync(SellerAccountDto account)
    {
        using var conn = _connectionFactory.Create();
        await conn.ExecuteAsync(@"
            UPDATE dbo.SellerAccounts
            SET AccountName = @AccountName,
                MarketplaceId = @MarketplaceId,
                Region = @Region,
                IsActive = @IsActive,
                ModifiedDate = GETDATE()
            WHERE SellerAccountId = @SellerAccountId",
            new { account.SellerAccountId, account.AccountName, account.MarketplaceId, account.Region, account.IsActive });
    }

    public async Task<bool> TestConnectionAsync(int sellerAccountId)
    {
        // In production, this would test the SP-API connection
        using var conn = _connectionFactory.Create();
        var result = await conn.QueryFirstOrDefaultAsync<int>(@"
            SELECT 1 FROM dbo.SellerAccounts WHERE SellerAccountId = @SellerAccountId AND IsActive = 1",
            new { SellerAccountId = sellerAccountId });
        return result == 1;
    }
}