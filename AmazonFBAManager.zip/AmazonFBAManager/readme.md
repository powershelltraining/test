# 🚀 MASTER PROMPT — Amazon FBA Multi-Seller Management Platform
### .NET Application · SQL Server Backend · All Logic in Stored Procedures · Web + Desktop

---

## 📌 OVERVIEW & OBJECTIVE

Build a **full-featured, dual-mode (Web + Desktop) .NET application** to manage multiple Amazon FBA seller accounts. The platform consolidates inventory, case management, refund auditing, sales reporting, PPC analytics, listing optimization, and niche research into one system. All business logic resides **exclusively in SQL Server Stored Procedures**—the application layer is purely a UI/API transport layer with zero embedded logic.

---

## 🏗️ ARCHITECTURE REQUIREMENTS

### Technology Stack
| Layer | Technology |
|---|---|
| **Web Frontend** | ASP.NET Core 8 MVC + Razor Pages OR Blazor Server |
| **Desktop Frontend** | WPF (.NET 8) or WinUI 3 — shared ViewModel layer with web |
| **API Layer** | ASP.NET Core 8 Web API (RESTful) |
| **Backend** | SQL Server 2022 (Azure SQL compatible) |
| **ORM / Data Access** | Dapper (thin micro-ORM — SP calls only, no LINQ-to-SQL, no EF migrations with logic) |
| **Auth** | ASP.NET Identity + JWT for API; Windows Auth option for desktop |
| **Scheduler** | Hangfire (background jobs: CSV import, nightly audits, alerts) |
| **File Handling** | CsvHelper for CSV parsing; Amazon SP-API SDK for live pulls |
| **Shared Logic** | .NET Standard 2.1 class library shared between Web and Desktop projects |
| **Reporting** | FastReport or SSRS for printable reports; Chart.js / ApexCharts for web dashboards |
| **Notifications** | SignalR for real-time alerts; SendGrid for email alerts |

### Project Structure
```
AmazonFBAManager/
├── AmazonFBAManager.Web/          ← ASP.NET Core MVC + Blazor hybrid
├── AmazonFBAManager.Desktop/      ← WPF / WinUI 3
├── AmazonFBAManager.API/          ← Web API (shared by Web + Desktop)
├── AmazonFBAManager.Shared/       ← DTOs, Interfaces, Constants
├── AmazonFBAManager.Data/         ← Dapper repositories, SP wrappers
├── AmazonFBAManager.Jobs/         ← Hangfire background workers
└── Database/
    ├── Tables/
    ├── StoredProcedures/
    ├── Views/
    └── Seed/
```

### Strict Rule: NO Logic in Application Layer
- Controllers/ViewModels call stored procedures via Dapper ONLY
- No C# `if/else` for business decisions — move all conditionals to SQL
- No LINQ-based filtering — pass filter params to SPs
- No calculations in C# — all math (fees, margins, reorder points) done in SQL
- Application layer responsibilities: **Authentication, File Upload, CSV Parsing to DataTable, SP invocation, JSON serialization, UI rendering**

---

## 🗄️ DATABASE SCHEMA

### Core Tables

```sql
-- Multi-Seller Account Management
SellerAccounts (SellerAccountId, AccountName, MarketplaceId, MerchantToken, 
                SPAPIClientId, SPAPIClientSecret, RefreshToken, Region, 
                IsActive, CreatedDate, ModifiedDate)

Users (UserId, Username, Email, PasswordHash, RoleId, IsActive)
UserSellerAccounts (UserId, SellerAccountId, PermissionLevel) -- many-to-many

-- Product / ASIN Master
Products (ProductId, SellerAccountId, ASIN, SKU, FNSKU, ProductTitle, 
          Brand, Category, Subcategory, UPC, EAN, Weight, Dimensions, 
          COGS, TargetMargin, ReorderPoint, ReorderQty, LeadTimeDays,
          IsActive, CreatedDate)

-- Inventory
InventorySnapshots (SnapshotId, ProductId, SellerAccountId, SnapshotDate,
                    QtyFBA, QtyFBM, QtyInbound, QtyReserved, QtyUnfulfillable,
                    QtyWarehouseAWD, EstStorageCost, IPI_Score, DataSource)

InventoryAdjustments (AdjustmentId, ProductId, SellerAccountId, AdjDate,
                       AdjReason, QtyAdjusted, DispositionCode, FulfillmentCenterId)

-- Sales History
SalesOrders (OrderId, SellerAccountId, AmazonOrderId, OrderDate, ShipDate,
             FulfillmentChannel, OrderStatus, TotalAmount, Currency)

SalesOrderItems (OrderItemId, OrderId, ProductId, ASIN, SKU, QtySold,
                 ItemPrice, PromotionDiscount, ShippingPrice, GiftWrapPrice)

-- Fees & Financials
FBAFees (FeeId, ProductId, SellerAccountId, FeeDate, FeeType, FeeAmount,
         Currency, ReferenceId, FulfillmentCenterId)

ProfitLoss (PLID, ProductId, SellerAccountId, Period, Revenue, COGS_Total,
            FBAFees_Total, PPC_Spend, RefundsIssued, ReimbursementsReceived,
            NetProfit, ACoS, TACoS, ROI)

-- Case Management
Cases (CaseId, SellerAccountId, AmazonCaseId, CaseType, CaseCategory,
       Status, Priority, OpenedDate, ResolvedDate, ResolvedAmount,
       Subject, Description, AssignedUserId, EscalationLevel, POARequired)

CaseTypes: LOST_INVENTORY, DAMAGED_INVENTORY, FEE_OVERCHARGE, 
           RETURNLESS_REFUND, LISTING_SUPPRESSION, HIJACK_REPORT,
           ACCOUNT_SUSPENSION, INBOUND_SHIPMENT_DISCREPANCY, AWD_LOSS

CaseNotes (NoteId, CaseId, UserId, NoteDate, NoteText, IsInternal)
CaseAttachments (AttachmentId, CaseId, FileName, FilePath, UploadDate)

-- Refunds & Reimbursements
ReimbursementAudit (AuditId, ProductId, SellerAccountId, AuditDate,
                    AuditType, QtyExpected, QtyAmazonReported, QtyVariance,
                    ClaimableAmount, CostBasis, Status, LinkedCaseId)

-- Note: As of March 10 2025, Amazon reimburses at COST BASIS not selling price.
-- Store COGS in Products table; use it here for accurate claim calculation.

Reimbursements (ReimbId, SellerAccountId, AmazonReimbId, ReimbDate,
                ProductId, QtyReimbursed, AmountPerUnit, TotalAmount,
                ReimbType, CaseId, ApprovalStatus)

-- PPC / Advertising
PPCCampaigns (CampaignId, SellerAccountId, AmazonCampaignId, CampaignName,
              CampaignType, TargetingType, State, DailyBudget, StartDate)

PPCKeywords (KeywordId, CampaignId, AdGroupId, KeywordText, MatchType,
             Bid, Impressions, Clicks, Spend, Sales, ACoS, ROAS, Period)

-- Listings
Listings (ListingId, ProductId, SellerAccountId, Title, BulletPoints,
          Description, APlusContent, BackendKeywords, SearchTerms,
          BuyBoxPrice, LowestOfferPrice, BSR, CategoryBSR,
          ReviewCount, StarRating, ListingStatus, SuppressedReason)

-- Returns
Returns (ReturnId, SellerAccountId, AmazonOrderId, ProductId, ReturnDate,
         CustomerRefundDate, ReturnReceivedDate, ReturnStatus, ReturnReason,
         Qty, RefundAmount, ReturnlessRefund, DispositionCode)

-- CSV Import Tracking
CSVImports (ImportId, SellerAccountId, UserId, ImportDate, ReportType,
            FileName, RowsTotal, RowsImported, RowsErrored, Status, ErrorLog)

-- Alerts & Notifications
Alerts (AlertId, SellerAccountId, AlertType, ProductId, AlertDate,
        Message, Severity, IsRead, ResolvedDate)

-- Niche / Product Research
NicheResearch (NicheId, SellerAccountId, UserId, ResearchDate, Keyword,
               EstMonthlySearchVolume, CompetitorCount, AvgReviewCount,
               AvgPrice, EstRevenue, OpportunityScore, Notes, Status)
```

---

## 📂 CSV IMPORT MODULE

### Amazon Reports to Support (Upload via UI)

| Report Name | Amazon Report Type | Key Fields |
|---|---|---|
| Inventory Report | `GET_FBA_MYI_UNSUPPRESSED_INVENTORY_DATA` | SKU, FNSKU, ASIN, Qty, Condition |
| Sales & Traffic | `GET_SALES_AND_TRAFFIC_REPORT` | Sessions, Units, Revenue, CVR |
| FBA Fee Preview | `GET_FBA_ESTIMATED_FBA_FEES_TXT_DATA` | Per-unit fee breakdown |
| Reimbursements | `GET_FBA_REIMBURSEMENTS_DATA` | ReimbID, ASIN, Amount, Type |
| Returns | `GET_FBA_FULFILLMENT_CUSTOMER_RETURNS_DATA` | Order, ASIN, Reason, Disposition |
| Inventory Adjustments | `GET_FBA_FULFILLMENT_INVENTORY_ADJUSTMENTS_DATA` | Reason, Qty, FC |
| Order Report | `GET_FLAT_FILE_ALL_ORDERS_DATA_BY_LAST_UPDATE_GENERAL` | Full order details |
| PPC Search Term | Sponsored Products Search Term Report | Keyword, Impressions, Clicks, Spend |
| Settlement Report | Settlement V2 | Fees, Refunds, Reimbursements breakdown |
| Stranded Inventory | Stranded Inventory Report | ASIN, Reason, Qty Stranded |
| Aged Inventory | FBA Inventory Age Report | Qty by age tier, est surcharge |
| Inbound Shipments | Inbound Shipments Report | ShipmentId, Qty shipped vs received |
| Removal Orders | Removal Order Detail Report | ASIN, Qty, RemovalType, Status |

### Import Stored Procedure Pattern
```sql
CREATE PROCEDURE dbo.usp_ImportCSV_InventorySnapshot
    @SellerAccountId INT,
    @ImportId INT,
    @DataTable dbo.TVP_InventorySnapshot READONLY  -- Table-Valued Parameter
AS
BEGIN
    -- All validation, dedup, upsert logic here
    -- Update InventorySnapshots
    -- Trigger alert SPs if thresholds crossed
    -- Update import status
END
```

---

## 🔧 STORED PROCEDURES SPECIFICATION

### A. Inventory Management SPs

```sql
-- Reorder Point Calculation (EOQ + Safety Stock)
usp_Inventory_GetReorderSuggestions(@SellerAccountId, @LeadTimeDays, @ServiceLevel)
  → Returns: SKU, CurrentQty, DailySalesVelocity, ReorderPoint, SuggestedOrderQty, UrgencyScore

-- Overstock Diagnosis
usp_Inventory_GetOverstockReport(@SellerAccountId, @DaysOfSupplyThreshold)
  → Returns: SKU, QtyOnHand, DaysOfSupply, EstStorageCost_90days, LiquidationSavings, MarkdownSuggestion

-- IPI Score Improvement
usp_Inventory_GetIPIImprovementActions(@SellerAccountId)
  → Returns: ActionType, AffectedSKUs, PotentialIPIGain, Priority, ActionDescription

-- Stranded Inventory
usp_Inventory_GetStrandedInventory(@SellerAccountId)
  → Returns: ASIN, SKU, QtyStranded, StrandReason, DailyStorageCost, RecommendedAction

-- Aged Inventory / Long-Term Storage Fees
usp_Inventory_GetAgedInventoryFeeRisk(@SellerAccountId, @SnapshotDate)
  → Returns: SKU, QtyByAgeTier, EstSurchargeFee, SalesPriceToClear, RemovalCost, NetBetterOption

-- FBA vs FBM Comparison
usp_Inventory_CompareFBAFBM(@ProductId, @SellerAccountId)
  → Returns: FBAMargin, FBMMargin, BreakevenSalesRank, RecommendedChannel, FeeBreakdown

-- Seasonal Replenishment Planning
usp_Inventory_GetSeasonalForecast(@SellerAccountId, @ForecastMonths)
  → Returns: SKU, MonthlyProjectedSales, SuggestedInboundDate, SuggestedInboundQty, PeakRiskScore

-- AWD (Amazon Warehousing & Distribution) Tracking
usp_Inventory_GetAWDDiscrepancies(@SellerAccountId, @DateFrom, @DateTo)
  → Returns: ShipmentId, QtyShipped, QtyReceived_AWD, QtyReceived_FC, Variance, ClaimableAmt
```

### B. Refund & Reimbursement SPs

```sql
-- Lost/Damaged Inventory Audit
usp_Reimbursement_AuditLostDamagedInventory(@SellerAccountId, @DateFrom, @DateTo)
  → Cross-references: AdjustmentsReport vs ReimbursementsReceived vs CurrentInventory
  → Returns: ASIN, QtyLost, QtyReimbursed, QtyUnclaimed, ClaimableAmount (at COGS basis per 2025 policy)

-- Fee Overcharge Detection
usp_Reimbursement_DetectFeeOvercharges(@SellerAccountId, @DateFrom, @DateTo)
  → Returns: ASIN, ExpectedFee, ChargedFee, Variance, OverchargeType, Claimable

-- Returnless Refund Audit
usp_Reimbursement_AuditReturnlessRefunds(@SellerAccountId, @DateFrom, @DateTo)
  → Matches refunds issued where no return was received in FBA
  → Returns: OrderId, ASIN, RefundAmount, ReturnReceived (Y/N), ClaimableAmount

-- Inbound Shipment Discrepancy
usp_Reimbursement_AuditInboundShipments(@SellerAccountId, @ShipmentId)
  → Returns: QtyShipped, QtyReceived, QtyMissing, ClaimableAmt, StatusAmazon, Disposition

-- Monthly Reimbursement Checklist
usp_Reimbursement_MonthlyChecklist(@SellerAccountId, @Month, @Year)
  → Returns: ChecklistItem, Status, PotentialAmount, ActionRequired, Deadline

-- COGS Update Impact (2025 policy: reimbursed at cost basis)
usp_Reimbursement_CalculateCOGSImpact(@SellerAccountId)
  → Returns: ASIN, CurrentCOGS, ReimbursablePerUnit, TotalPotentialRecovery, COGSEntered (Y/N)

-- Reimbursement KPI Dashboard
usp_Reimbursement_GetKPIDashboard(@SellerAccountId, @DateFrom, @DateTo)
  → Returns: TotalClaims, ApprovedAmount, PendingAmount, ApprovalRate, AvgResolutionDays
```

### C. Case Management SPs

```sql
-- Open Case
usp_Case_Create(@SellerAccountId, @CaseType, @ASIN, @Description, @Priority, @LinkedAuditId)

-- Escalation Handler
usp_Case_Escalate(@CaseId, @UserId, @EscalationReason)
  → Updates escalation level, assigns to senior queue, triggers alert

-- Suspension POA Template Data
usp_Case_GetSuspensionPOAData(@SellerAccountId, @CaseId)
  → Returns all context: violations cited, performance metrics, ASIN list, history

-- Listing Suppression Fix Tracker
usp_Case_GetListingSuppressedFixes(@SellerAccountId)
  → Returns: ASIN, SuppressedReason, RequiredAction, EstRevLost_PerDay, DaysSuppressed

-- Hijack Report Builder
usp_Case_BuildHijackReport(@ProductId, @SellerAccountId, @HijackerASIN)
  → Returns: OwnListing, HijackerOffer, PriceDiff, EvidenceCheckList, ReportDraftText

-- Case Aging & SLA Report
usp_Case_GetAgingReport(@SellerAccountId, @SLADays)
  → Returns: CaseId, Type, DaysOpen, SLAStatus, AssignedUser, AmountAtRisk
```

### D. Sales & Financial Reporting SPs

```sql
-- P&L by SKU / Period
usp_Reports_ProfitLossBySKU(@SellerAccountId, @DateFrom, @DateTo, @GroupBy)
  → Revenue, COGS, FBA Fees, PPC Spend, Refunds, Reimbursements, Net Profit, Margin%, ROI

-- Sales Velocity & Trend
usp_Reports_SalesVelocity(@SellerAccountId, @ASIN, @Periods)
  → Daily/Weekly/Monthly velocity, YoY comparison, Seasonal index

-- Fee Breakdown Analysis
usp_Reports_FeeBreakdownByASIN(@SellerAccountId, @DateFrom, @DateTo)
  → Referral Fee, FBA Fulfillment Fee, Storage Fee, Surcharges, Total Fee%, Net Margin After Fees

-- Settlement Reconciliation
usp_Reports_SettlementReconciliation(@SellerAccountId, @SettlementId)
  → Orders, Refunds, Fees, Reimbursements, Adjustments — matches expected vs disbursed

-- Multi-Account Consolidated Dashboard
usp_Reports_MultiAccountSummary(@UserId, @DateFrom, @DateTo)
  → All seller accounts side-by-side: Revenue, Units, NetProfit, TopSKUs, AlertCount

-- Return Rate Analysis
usp_Reports_ReturnRateAnalysis(@SellerAccountId, @DateFrom, @DateTo)
  → By ASIN: Return Rate, Top Return Reasons, Returnless Refund %, Refund Amount

-- Cash Flow Forecast
usp_Reports_CashFlowForecast(@SellerAccountId, @ForecastDays)
  → ProjectedRevenue, ProjectedCOGS, ProjectedFees, ProjectedPPCSpend, NetCashPosition
```

### E. PPC / Advertising SPs

```sql
-- PPC Audit
usp_PPC_AuditCampaigns(@SellerAccountId, @DateFrom, @DateTo)
  → Returns: WastedSpend (high spend / zero conversion keywords), 
             HarvestOpportunities (converting search terms not in exact),
             BidAdjustmentSuggestions, ACoS_Benchmark

-- Keyword Performance
usp_PPC_GetKeywordPerformance(@SellerAccountId, @CampaignId, @DateFrom, @DateTo)
  → Impressions, Clicks, Spend, Sales, ACoS, ROAS, QualityScore

-- TACoS (Total ACoS) Calculator
usp_PPC_CalculateTACoS(@SellerAccountId, @DateFrom, @DateTo)
  → PPC_Sales, Total_Sales, TotalSpend, ACoS, TACoS, OrganicSalesRatio
```

### F. Listing Management SPs

```sql
-- Listing Health Score
usp_Listing_GetHealthScore(@ProductId, @SellerAccountId)
  → TitleScore, BulletsScore, ImageScore, APlusScore, KeywordIndexScore, OverallScore, Recommendations

-- Suppressed Listings
usp_Listing_GetSuppressed(@SellerAccountId)
  → ASIN, SuppressedReason, DaysSuppressed, EstRevLostPerDay, FixAction

-- Hijack Monitoring
usp_Listing_GetBuyBoxLossReport(@SellerAccountId, @DateFrom, @DateTo)
  → ASIN, BuyBoxOwnership%, LostBuyBoxEvents, EstRevenueLost, CompetitorCount

-- Review Velocity
usp_Listing_GetReviewGapAnalysis(@SellerAccountId)
  → ASIN, OurReviewCount, AvgCompetitorReviews, Gap, VineEligible, ReviewVelocityPerMonth
```

### G. Niche / Product Research SPs

```sql
-- Opportunity Score
usp_Research_CalculateOpportunityScore(@Keyword, @SellerAccountId)
  → SearchVolume, CompetitorCount, AvgRevenue, AvgReviews, ReviewGap, OpportunityScore (0-100)

-- Bundle Strategy Analyzer
usp_Research_BundleOpportunities(@SellerAccountId)
  → Frequently bought together items, Margin uplift potential, Competitive moat score

-- Trend Detection
usp_Research_GetTrendingASINs(@SellerAccountId, @CategoryId, @VelocityThreshold)
  → ASINs with rising BSR velocity, Review acceleration, Price stability score
```

---

## 📊 DASHBOARD & REPORT MODULES

### Web Dashboard Panels
1. **Multi-Account Overview** — Consolidated revenue, profit, units, active cases, open reimbursements across all seller accounts (one card per account)
2. **Reimbursement Recovery Tracker** — Amount claimed, amount approved, pending, monthly trend, COGS coverage %
3. **Inventory Health Map** — IPI gauge, overstock risk, stockout risk, aged inventory fee exposure, stranded units
4. **Case Management Board** — Kanban-style by status (Open, Pending Amazon, Escalated, Resolved)
5. **P&L Summary** — Period selector, SKU drilldown, fee waterfall chart, margin trend
6. **PPC Performance** — ACoS, TACoS, ROAS, wasted spend, harvest opportunities
7. **Alert Center** — Real-time SignalR alerts: low stock, hijacks, fee spikes, case SLA breaches, new reimbursement opportunities

### Desktop-Specific Features
- Offline mode with local SQLite cache sync
- Bulk CSV drag-and-drop import panel
- Windows notification toasts for alerts
- Printable report generation (FastReport templates)
- Hot-key shortcuts for case creation and SP lookups

---

## 🔐 SECURITY & MULTI-TENANCY

```sql
-- Row-Level Security: All SPs filter by @SellerAccountId
-- Validate that requesting UserId has access to @SellerAccountId via UserSellerAccounts table

usp_Auth_ValidateUserAccountAccess(@UserId, @SellerAccountId)
  → Returns: HasAccess BIT, PermissionLevel VARCHAR

-- All SPs begin with:
IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
    RAISERROR('Access denied', 16, 1);
```

**Roles:** Admin, AccountManager, Analyst, VAReadOnly

---

## 📅 BACKGROUND JOBS (Hangfire)

| Job | Schedule | Description |
|---|---|---|
| `NightlyReimbursementAudit` | Daily 2AM | Runs all reimbursement audit SPs, creates alerts |
| `InventoryAlertCheck` | Every 4 hrs | Checks reorder points, stranded, aged, IPI |
| `PPCAuditWeekly` | Every Monday | Wasted spend + harvest keyword report |
| `ListingHealthScan` | Daily | Suppressed, hijack, Buy Box loss detection |
| `SettlementReconcile` | On new settlement CSV | Auto-reconciles disbursements |
| `CaseSLAMonitor` | Every 2 hrs | Escalates cases breaching SLA |
| `AWDDiscrepancyCheck` | Daily | Flags AWD shipment qty mismatches |

---

## 🌐 AMAZON SP-API INTEGRATION (Optional Live Pull)

Beyond CSV uploads, support direct SP-API pulls for:
- Live inventory levels
- Real-time order data
- Reimbursement report pull
- Listing status & suppression
- FBA fee estimates (FBA Calculator endpoint)

Store SP-API credentials per SellerAccount (encrypted at rest). Use the **Amazon Selling Partner API .NET SDK**.

---

## 💡 LATEST 2025/2026 FEATURES TO INCLUDE
*(informed by current Amazon FBA landscape)*

1. **2025 COGS-Based Reimbursement Engine** — Amazon changed reimbursement to cost basis (March 2025). Track COGS per ASIN, calculate true reimbursement amount, alert sellers to update COGS in Seller Central. Compare expected vs Amazon's estimate.

2. **AWD (Amazon Warehousing & Distribution) Tracker** — Track inventory through AWD → FC pipeline, flag discrepancies (AWD failures were a major issue in 2024–2025), open cases automatically.

3. **Multi-Marketplace Support** — US, CA, MX, UK, DE, FR, IT, ES, JP, AU marketplace handling with currency conversion and per-marketplace reporting.

4. **VA (Virtual Assistant) SOP Builder** — Generate step-by-step SOP documents for VAs from templates stored in DB. Assign tasks, track completion.

5. **FBA New Selection Program Tracker** — Track which ASINs qualify, monitor fee waiver windows, forecast long-term ordering adjustments post-program.

6. **Reimbursement Deadline Monitor** — Amazon has strict filing windows (18 months for most claim types). Auto-alert when claims approach deadlines.

7. **Removal Order Optimizer** — Compare removal cost vs continued storage vs liquidation for aged/overstock inventory, recommend best action per SP.

8. **SKU Economics Dashboard** — SKU-level ROI, margin after all fees (referral + FBA + PPC + COGS + returns), break-even price calculator.

9. **Seasonal Demand Forecasting** — Historical sales + YoY trend → projected inbound shipment dates and quantities by season.

10. **Competitor Price Monitor** — Track Buy Box price and lowest offer price per ASIN over time, alert on pricing threats.

---

## 🧩 SAMPLE DAPPER CALL PATTERN (Application Layer — NO Logic)

```csharp
// Repository — purely calls SP, returns DTO
public async Task<IEnumerable<ReorderSuggestionDto>> GetReorderSuggestions(
    int sellerAccountId, int leadTimeDays, decimal serviceLevel)
{
    using var conn = _connectionFactory.Create();
    return await conn.QueryAsync<ReorderSuggestionDto>(
        "usp_Inventory_GetReorderSuggestions",
        new { SellerAccountId = sellerAccountId, 
              LeadTimeDays = leadTimeDays, 
              ServiceLevel = serviceLevel },
        commandType: CommandType.StoredProcedure
    );
}

// Controller — no logic, just calls repo and returns view
public async Task<IActionResult> ReorderSuggestions(int accountId)
{
    var suggestions = await _inventoryRepo.GetReorderSuggestions(accountId, 30, 0.95m);
    return View(suggestions);
}
```

---

## 📋 CSV IMPORT FLOW

```
User uploads CSV file (web drag-drop or desktop file picker)
    ↓
CsvHelper parses → validates headers → maps to DataTable
    ↓
DataTable passed as Table-Valued Parameter (TVP) to SQL SP
    ↓
SP performs: deduplication, validation, upsert, alert triggers
    ↓
Import result (rows imported, errors) returned and logged to CSVImports table
    ↓
SignalR push notification to UI: "Import complete: 1,204 rows"
```

---

## 🖥️ UI MODULES CHECKLIST

- [ ] **Login / Account Switcher** — Switch between seller accounts without re-login
- [ ] **Dashboard Home** — Multi-account consolidated metrics
- [ ] **Inventory Manager** — Reorder grid, overstock report, IPI panel, stranded list, aged inventory
- [ ] **Case Manager** — Kanban board, case creation wizard, escalation panel, attachment upload
- [ ] **Refund Auditor** — Monthly checklist, lost/damaged audit, returnless audit, fee overcharge scan
- [ ] **Sales Reports** — P&L by SKU, settlement reconciliation, return analysis, fee waterfall
- [ ] **PPC Analyzer** — Wasted spend, TACoS, keyword harvest, bid suggestions
- [ ] **Listing Health** — Score per ASIN, suppression tracker, hijack monitor, keyword gap
- [ ] **Niche Research** — Opportunity scorer, trend detector, bundle analyzer, reverse ASIN lookup
- [ ] **CSV Import Center** — Drag-and-drop multi-file upload with import history
- [ ] **Alert Center** — All alerts with severity, read/unread, resolution actions
- [ ] **User & Permission Management** — Add users, assign accounts, set roles
- [ ] **SOP Builder** — VA task SOP generator with template library
- [ ] **Settings** — SP-API credentials per account, COGS management, alert thresholds

---
 
Hosting: Will the web app be hosted on Azure, AWS, on-premise IIS, or all three?  on perm 
SP-API Live Integration: Phase 1 CSV-only, or also SP-API live pulls from day one? both csv and live pulls based on user access
Desktop Deployment: ClickOnce, MSIX installer, or internal IT deployment? it deployment 
Number of Seller Accounts: Expected scale (5 accounts? 50? 500?) affects partitioning strategy. 50
Offline Desktop Mode: Does the desktop app need full offline capability with local SQLite sync? no desktop should connect to sql server
Reporting Output: PDF export only, or also Excel/CSV export from all reports? pdf and excel csv
PPC Data Source: Manual CSV uploads only, or Amazon Ads API integration? manual
Niche Research: Built-in scraped data, or integration with Jungle Scout / Helium 10 APIs? not now 
Multi-Marketplace Currency: Single base currency reporting (USD) or per-marketplace currency? USD for now
Existing Data Migration: Is there historical data from another tool (spreadsheets, Seller Central exports) to import? no
White-Label: Will this be sold to other agencies/sellers, or internal use only? sold 
2025 Reimbursement Policy: Do you have COGS entered in Seller Central for all ASINs, or do we need a COGS onboarding wizard? need cogs wizard


Email Templates Prompt -- seed to database 
You are an expert Amazon seller communications specialist and 
brand protection attorney with 15 years experience. You write 
professional, persuasive, legally aware email templates for 
Amazon FBA sellers. Every template is complete, ready to send 
with [BRACKETS] for fill-in fields only. Tone is firm but 
professional. Templates are optimized to get results from 
Amazon Seller Support, buyers, and manufacturers. 
Never truncate. Write every template in full.

Write a complete Email & Message Template Library for an Amazon 
FBA seller. Every template must be complete and ready to use.

Use this format for every template:

=== TEMPLATE: [Name] ===
USE WHEN: [exact scenario]
SEND TO: [Amazon / Buyer / Manufacturer / Distributor / etc.]
SUBJECT LINE: [exact subject]
---
[Full email body]
---
TIPS: [what to customize, what evidence to attach]
=== END TEMPLATE ===

---

CATEGORY 1 — AMAZON CASE MANAGEMENT EMAILS
(These go into Amazon Seller Support case messages)

1.1 Opening a Lost Inventory Case
1.2 Opening a Damaged Inventory Case  
1.3 Opening an Inbound Shipment Discrepancy Case
    (units shipped vs units received mismatch)
1.4 Opening an AWD Shipment Loss Case
    (Amazon Warehousing & Distribution loss)
1.5 Disputing a Fee Overcharge
1.6 Claiming a Returnless Refund Not Reimbursed
1.7 Escalating a Case After No Response (7 days)
1.8 Escalating a Case After First Escalation Fails (14 days)
1.9 Requesting a Case Be Reviewed by a Senior Specialist
1.10 Following Up on a Pending Reimbursement
1.11 Disputing Amazon's Reimbursement Amount
     (they used wrong cost basis — 2025 policy)
1.12 Requesting FBA Fee Recalculation Due to Wrong Dimensions
1.13 Requesting FBA Fee Recalculation Due to Wrong Weight
1.14 Stranded Inventory Relisting Request
1.15 Listing Suppression — Appeal to Reinstate
1.16 Account Health — Policy Warning Appeal
1.17 Account Suspension — Plan of Action (POA) Template
     (full POA format: Root Cause, Corrective Actions, 
      Preventive Actions — all three sections complete)
1.18 ASIN Reinstatement After Suspension
1.19 Intellectual Property Complaint Counter-Notice
     (seller received false IP complaint from competitor)
1.20 Reporting a Competitor for Review Manipulation
1.21 Reporting a Competitor for Counterfeit Products

---

CATEGORY 2 — BUYER / CUSTOMER MESSAGE TEMPLATES
(These go through Amazon Buyer-Seller Messaging)

2.1 Late Delivery Apology + Resolution Offer
2.2 Missing Package — Investigation Started
2.3 Missing Package — Replacement Offer
2.4 Missing Package — Refund Offer
2.5 Package Marked Delivered But Buyer Says Not Received
2.6 Wrong Item Sent — Apology + Resolution
2.7 Damaged Item Received — Apology + Resolution
2.8 Defective Product — Troubleshooting First Response
2.9 Defective Product — Replacement After Troubleshooting
2.10 Product Question — Technical Specs
2.11 Product Question — Compatibility
2.12 Product Question — Usage / How-To
2.13 Return Request — Acknowledge and Guide
2.14 Return Request — Outside Return Window (goodwill offer)
2.15 Negative Feedback Request for Removal
     (buyer left negative seller feedback — politely ask to revise)
2.16 Negative Review Response (public reply template)
2.17 FBA Order Refund Issued — Confirmation Message
2.18 Order Cancelled by Amazon — Buyer Notification
2.19 Customs Delay Notice (international orders)
2.20 Proactive Delivery Delay Warning
     (send before buyer complains — peak season delay)

---

CATEGORY 3 — BRAND & INTELLECTUAL PROPERTY EMAILS
(Sent to manufacturers, distributors, and unauthorized sellers)

3.1 Cease and Desist — Unauthorized Seller on Your Listing
    (another seller is selling your branded product without 
     authorization — demand removal)
3.2 Cease and Desist — Counterfeit Product Listing
    (someone is selling fake versions of your product)
3.3 Cease and Desist — Logo/Trademark Misuse by Manufacturer
    (your manufacturer is selling your branded product 
     directly on Amazon or to unauthorized channels)
3.4 Cease and Desist — Manufacturer Selling on Amazon 
    Without Authorization
3.5 Distributor Warning — Selling Outside Authorized Territory
3.6 Distributor Warning — Selling Below MAP (Minimum Advertised Price)
3.7 MAP Policy Violation — First Warning to Any Seller
3.8 MAP Policy Violation — Second Warning (escalation)
3.9 MAP Policy Violation — Final Warning Before Legal Action
3.10 Authorized Reseller Agreement Request 
     (asking a distributor to sign your reseller terms)
3.11 Brand Registry Enrollment Support Request to Manufacturer
     (asking your manufacturer for trademark documentation 
      to support your Amazon Brand Registry application)
3.12 Supplier Agreement — Adding Amazon Exclusivity Clause
     (email asking supplier to add clause preventing them 
      selling to competitors or on Amazon directly)
3.13 Hijack Report to Amazon — Someone Took Your Buy Box
     (submit via Brand Registry / Report a Violation)
3.14 Test Buy Confirmation Email
     (internal — documenting you purchased from hijacker 
      as evidence before reporting)
3.15 Manufacturer Selling Under Different ASIN 
     (same product, different listing — request to merge or stop)

---

CATEGORY 4 — INTERNAL OPERATIONS EMAILS
(Sent within your team or to VAs)

4.1 Daily Morning Briefing Template for VA
    (what to check, what to download, what to report back)
4.2 Weekly Reimbursement Audit Assignment to VA
4.3 New Case Assignment to VA
4.4 Escalation Notification to Account Manager
    (case has breached SLA — needs manager attention)
4.5 Monthly FBA Performance Report to Client
    (if you manage accounts for others — summary report email)
4.6 Onboarding Email for New VA
    (access, tools, daily responsibilities, what NOT to do)

---

Write every template completely. 
Do not summarize. Do not write "similar to above". 
Every template is unique and complete.
Start with Category 1.



Help & How-To Guide Prompt  seed data to database  
You are a senior Amazon FBA operations expert and technical writer. 
You write clear, step-by-step help documentation for sellers who 
use a custom .NET FBA management application. Your guides include 
exact menu paths, button names, screenshot descriptions, pro tips, 
and common mistakes to avoid. You never use vague language. 
Every step is numbered and actionable. You make no assumptions 
about the user's technical level — explain everything simply.

Write a complete Help & User Guide for an Amazon FBA Management 
application. This is used by Amazon FBA sellers and their VAs 
to manage inventory, cases, refunds, and reports.

The guide must cover every section below completely.
Write every section in full — no placeholders, no "see above", 
no truncation. Use this format for every topic:

=== HELP TOPIC: [Name] ===
WHAT IT DOES: [one paragraph explanation]
WHEN TO USE IT: [specific scenarios]
STEP BY STEP:
  1. ...
  2. ...
PRO TIP: [insider advice]
COMMON MISTAKE: [what users do wrong]
=== END TOPIC ===

---

SECTION 1 — GETTING STARTED
- Creating your account and first login
- Adding your first Amazon Seller Account (MWS/SP-API credentials)
- Adding multiple seller accounts and switching between them
- Setting up user roles (Admin, Account Manager, Analyst, VA Read-Only)
- Navigating the dashboard for the first time
- Setting alert thresholds (low stock, fee spikes, case SLA)
- Configuring your COGS (cost of goods) per ASIN — critical for 2025 
  reimbursement policy where Amazon reimburses at cost basis

---

SECTION 2 — DOWNLOADING REPORTS FROM AMAZON SELLER CENTRAL
Write a step-by-step guide for downloading EACH of these reports 
from Amazon Seller Central, including exact menu path clicks:

- FBA Inventory Report
  (Reports → Fulfillment → Inventory → All Listings)
- Sales & Traffic Report
  (Reports → Business Reports → Sales & Traffic)
- FBA Fee Preview Report
  (Reports → Fulfillment → Payments → Fee Preview)
- Reimbursements Report
  (Reports → Fulfillment → Payments → Reimbursements)
- FBA Returns Report
  (Reports → Fulfillment → Customer Concessions → Returns)
- Inventory Adjustments Report
  (Reports → Fulfillment → Inventory → Inventory Adjustments)
- Order Report — All Orders
  (Orders → Order Reports → New Report)
- PPC Search Term Report
  (Advertising → Campaign Manager → Reports → Search Term)
- Settlement Report
  (Reports → Payments → All Statements → Download)
- Stranded Inventory Report
  (Inventory → Fix Stranded Inventory)
- Aged Inventory / Long-Term Storage Report
  (Inventory → Manage Inventory → Inventory Age)
- Inbound Shipment Report
  (Inventory → Shipments → Shipment Reports)
- Removal Order Detail Report
  (Reports → Fulfillment → Removals → Removal Order Detail)
- AWD (Amazon Warehousing & Distribution) Report
  (Inventory → AWD → Inventory)

For each report include:
- Exact URL path in Seller Central
- Date range to select
- File format to choose (CSV/TSV/Excel)
- How long it takes to generate
- What the file will be named when downloaded
- Any gotchas (report not available in all marketplaces, 
  requires manual request, max date range limits, etc.)

---

SECTION 3 — UPLOADING CSV FILES INTO THE APPLICATION
- Where to find the CSV Upload Center in the app
- How to drag and drop vs browse to select files
- How to select which Seller Account the file belongs to
- How to select the Report Type from the dropdown
- How the app validates the file before importing
- What happens if a file has errors (partial import, error log)
- How to view import history and re-import a failed file
- How to upload multiple files at once
- What each status means: Pending, Processing, Complete, Failed
- How long each report type typically takes to process
- What to do if a column mapping error appears

---

SECTION 4 — INVENTORY MANAGEMENT FEATURES
- Reading the Inventory Dashboard — what each number means
- Understanding the Reorder Suggestions grid
  (what DailySalesVelocity, ReorderPoint, UrgencyScore mean)
- How to action a reorder suggestion (export to PO, mark ordered)
- Reading the Overstock Report and what to do with flagged SKUs
- Understanding IPI Score panel and improvement actions
- How to find and fix Stranded Inventory from inside the app
- Reading the Aged Inventory Fee Risk table
  (what each age tier means: 181-270 days, 271-365 days, 365+ days)
- How to compare FBA vs FBM for a specific product
- How to track AWD (Amazon Warehousing & Distribution) shipments
  and what to do when a discrepancy is flagged
- How to set seasonal replenishment plans

---

SECTION 5 — CASE MANAGEMENT FEATURES
- How to open a new case from inside the app
- Choosing the right Case Type
  (Lost Inventory, Damaged Inventory, Fee Overcharge, 
   Returnless Refund, Listing Suppression, Hijack Report, 
   Suspension POA, Inbound Shipment Discrepancy, AWD Loss)
- How to link a case to a reimbursement audit finding
- How to attach documents and evidence to a case
- How to escalate a case (when and how)
- How to use the Hijack Report Builder
- How to track case SLA and what happens when SLA is breached
- How to read the Case Aging Report
- How to generate a Suspension POA from the app
- How to mark a case resolved and log the recovered amount

---

SECTION 6 — REFUND & REIMBURSEMENT AUDITOR
- How to run the Monthly Reimbursement Checklist
- How to read the Lost/Damaged Inventory Audit results
  (what QtyExpected vs QtyReported vs Variance means)
- How the app calculates ClaimableAmount using your COGS
  (explanation of the 2025 Amazon policy: reimbursed at cost not selling price)
- How to run the Fee Overcharge scan and interpret results
- How to find Returnless Refunds you were not reimbursed for
- How to audit Inbound Shipment discrepancies
- How to track Reimbursement Deadlines 
  (18-month window — what happens if you miss it)
- How to read the Reimbursement KPI dashboard
  (ApprovalRate, AvgResolutionDays, TotalRecovered)
- How to export a reimbursement claim report to PDF

---

SECTION 7 — SALES & FINANCIAL REPORTS
- How to run a P&L report by SKU and date range
- How to read the Fee Waterfall chart
  (Revenue → minus Referral Fee → minus FBA Fee → minus PPC → 
   minus COGS → minus Returns → equals Net Profit)
- How to run a Settlement Reconciliation report
- How to read the Return Rate Analysis by ASIN
- How to view the Multi-Account Consolidated Dashboard
- How to use the Cash Flow Forecast report
- How to export any report to PDF or Excel

---

SECTION 8 — PPC ANALYZER
- How to upload your PPC Search Term CSV
- How to read the Wasted Spend report
  (what "high spend / zero conversion" means and what to do)
- How to find Harvest Opportunities
  (search terms converting organically that should be in exact match)
- How to read the TACoS calculation
  (difference between ACoS and TACoS — why TACoS matters more)
- How to read Bid Adjustment Suggestions

---

SECTION 9 — LISTING HEALTH MANAGER
- How to read the Listing Health Score breakdown
  (Title, Bullets, Images, A+, Keywords — what scores mean)
- How to find and action suppressed listings
- How to use the Hijack Monitor
- How to read the Buy Box Loss Report
- How to read the Review Gap Analysis

---

SECTION 10 — ALERTS & NOTIFICATIONS
- What each Alert Type means and what action to take:
  LOW_STOCK, OVERSTOCK, STRANDED, AGED_FEE_RISK, HIJACK_DETECTED,
  BUY_BOX_LOST, CASE_SLA_BREACH, NEW_REIMBURSEMENT_OPPORTUNITY,
  FEE_SPIKE, LISTING_SUPPRESSED, AWD_DISCREPANCY
- How to configure alert thresholds per SKU
- How to set up email notifications
- How to mark alerts as read / resolved
- How desktop toast notifications work

---

SECTION 11 — VA (VIRTUAL ASSISTANT) GUIDE
A special condensed guide written FOR virtual assistants, 
covering only the tasks VAs typically perform:
- Daily CSV download and upload routine (exact steps)
- How to check and action reorder suggestions
- How to check for new alerts each morning
- How to open a new case from an audit finding
- How to add notes to an existing case
- How to run the monthly reimbursement checklist
- What a VA should NEVER do (change COGS, delete imports, 
  close cases without manager approval)

---

Write every section completely.  