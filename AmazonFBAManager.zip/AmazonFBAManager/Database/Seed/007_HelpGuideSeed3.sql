-- ============================================================================
-- Help & User Guide Seed Data - Part 3
-- SECTIONS 3-6: CSV UPLOADS, INVENTORY, CASES, REIMBURSEMENTS
-- ============================================================================

SET NOCOUNT ON;

-- ============================================================================
-- SECTION 3: UPLOADING CSV FILES INTO THE APPLICATION
-- ============================================================================

-- 3.1 Finding the CSV Upload Center
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Uploading CSV Files', 'Finding the CSV Upload Center',
'Locates the central hub for uploading all Amazon reports into the application.',
'When you need to import any report data - the first step of the upload process.',
'1. Log in to the application
2. Look for "CSV Upload" in the main navigation menu
   - It may be under "Data" or "Imports" depending on your view
   - Look for an icon that looks like a file with an arrow
3. Click to open the CSV Upload Center
4. You will see a list of previous imports with their status',
'If you don''t see "CSV Upload" in your menu, you may not have permission. Contact your administrator.',
'Not knowing where to find the upload center. This is the gateway to all your Amazon data.');

-- 3.2 How to drag and drop vs browse to select files
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Uploading CSV Files', 'Drag and Drop vs Browse',
'Two methods for selecting files to upload. Drag and drop is faster if you have the file ready.',
'When you are ready to upload a CSV file and need to select it from your computer.',
'DRAG AND DROP:
1. Open the CSV Upload Center
2. Locate the file on your computer
3. Click and hold the file
4. Drag it into the upload area (usually a box with dashed border)
5. Release to drop the file

BROWSE TO SELECT:
1. Open the CSV Upload Center
2. Click "Browse" or "Choose File" button
3. A file picker window opens
4. Navigate to your file
5. Click the file to select it
6. Click "Open"
7. The file name will appear in the upload area',
'Drag and drop is faster once you get used to it. Save your reports to a consistent folder for quick access.',
'Not having your files organized. Create a "Amazon Reports" folder and save all downloads there.');

-- 3.3 Selecting Seller Account and Report Type
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Uploading CSV Files', 'Selecting Account and Report Type',
'Must tell the application which seller account the data belongs to and what type of report it is.',
'When uploading any CSV file - these are required fields.',
'1. After selecting your file
2. Look for "Seller Account" dropdown
3. Click and select the correct account
   - Make sure this matches where you downloaded the report
4. Look for "Report Type" dropdown
5. Select the type matching your file:
   - Inventory Report → "Inventory Snapshot"
   - Returns Report → "Returns"
   - Reimbursements Report → "Reimbursements"
   - etc.
6. Both fields must have values before you can proceed',
'Double-check you selected the correct account - uploading data to the wrong account corrupts your data.',
'Selecting the wrong report type. The app won''t process the file correctly.');

-- 3.4 File validation and error handling
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Uploading CSV Files', 'File Validation and Errors',
'How the application validates your file before importing and what happens if there are errors.',
'When you upload a file and want to understand why it might fail or show warnings.',
'1. After selecting file, account, and report type
2. Click "Validate" or "Upload"
3. The app checks the file:
   - Column headers match expected format
   - Required fields are present
   - Data types are correct
4. If validation passes: You see "Ready to import" with row count
5. If validation fails: You see error messages:
   - "Missing required column: [column name]"
   - "Invalid data in row 15: [error]"
   - "Unknown report type"
6. Fix the errors in your file or try a different file
7. Re-upload after fixing',
'Some errors are warnings and you can still proceed. Others are fatal and must be fixed first.',
'Ignoring error messages and trying to proceed. This usually results in failed or partial imports.');

-- 3.5 Viewing import history and re-importing
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Uploading CSV Files', 'Import History and Re-import',
'View past imports to see what was imported, check for errors, and re-import failed files.',
'When you need to check the status of a previous import or fix a failed import.',
'1. Navigate to CSV Upload Center
2. Look for "Import History" or "Past Imports" section
3. You will see a table with columns:
   - Date/Time: When the import happened
   - File Name: Original file name
   - Report Type: What type it was
   - Status: Pending / Processing / Complete / Failed / Partial
   - Rows: Total / Imported / Errored
4. Click on any row to see details
5. To re-import: Click "Re-import" button
   - This is useful if you fixed errors in the file',
'Sort by "Status = Failed" to quickly find imports that need attention.',
'Not checking import history. Failed imports mean your data is incomplete.');

-- ============================================================================
-- SECTION 4: INVENTORY MANAGEMENT FEATURES
-- ============================================================================

-- 4.1 Reading the Inventory Dashboard
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Inventory Management', 'Reading the Inventory Dashboard',
'Understanding all the numbers and metrics shown on the main inventory dashboard.',
'Every day to get a quick overview of inventory health.',
'1. Navigate to Inventory → Dashboard
2. You will see several panels:
   - TOTAL FBA UNITS: Sum of all sellable inventory
   - UNITS IN TRANSIT: Inbound shipment quantities
   - DAYS OF SUPPLY: Average days before stockout
   - LOW STOCK ALERTS: SKUs below reorder point
   - OVERSTOCK ALERTS: SKUs overstocked
   - STRANDED UNITS: Inventory on suppressed listings
   - AGED INVENTORY VALUE: Value of inventory over 180 days
   - IPI SCORE: Your Inventory Performance Index
3. Each panel shows a number and a trend arrow
4. Click any panel to see the detailed report',
'Look at trends, not just absolute numbers. A rising "Days of Supply" is good; rising "Low Stock Alerts" is bad.',
'Only looking at total units. The real story is in the breakdown - low stock + overstock means you have the wrong mix.');

-- 4.2 Understanding Reorder Suggestions
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Inventory Management', 'Understanding Reorder Suggestions',
'Shows which products need to be reordered and how much to order. The app calculates this based on your sales velocity and lead time.',
'Every day to decide what to order from your supplier.',
'1. Navigate to Inventory → Reorder Suggestions
2. The grid shows columns:
   - SKU: Your product SKU
   - CURRENT FBA QTY: What you have in Amazon now
   - INBOUND QTY: On the way (included in total)
   - DAILY SALES VELOCITY: Average units sold per day
   - REORDER POINT: When to trigger reorder
   - DAYS OF SUPPLY: Days until stockout at current rate
   - SUGGESTED ORDER QTY: How much to order (EOQ calculation)
   - URGENCY SCORE: 0-100, higher = more urgent
3. Sort by "Urgency Score" to see most critical first
4. For each item, decide if you want to order',
'Set your "Lead Time Days" in product settings to get accurate reorder points. This affects the calculation significantly.',
'Reordering exactly the suggested quantity without considering minimum order quantities or upcoming promotions.');

-- 4.3 IPI Score Panel
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Inventory Management', 'IPI Score Panel',
'The Inventory Performance Index (IPI) is Amazon''s measure of your inventory health. It affects storage limits and fees.',
'Weekly to monitor your IPI and see what actions can improve it.',
'1. Navigate to Inventory → IPI Score (or it may be on dashboard)
2. You see:
   - YOUR IPI: Current score (out of 1000, but shown as decimal)
   - TARGET: The threshold you need to hit
   - TREND: Up/down from last week
3. Below the score, you see IMPROVEMENT ACTIONS:
   - Fix Stranded Inventory: SKUs with no active listings
   - Reduce Excess Inventory: Items with high days of supply
   - Aged Inventory Removal: Items over 365 days
4. Each action shows affected units and potential score gain',
'Focus on "Fix Stranded Inventory" first - it''s usually the easiest and has the biggest impact on IPI.',
'Ignoring IPI warnings. Below 500 may result in storage limits; below 400 may result in storage restrictions.');

-- 4.4 Aged Inventory Fee Risk
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Inventory Management', 'Aged Inventory Fee Risk',
'Shows inventory approaching or in long-term storage fee tiers. Items over 365 days incur the highest fees.',
'Weekly, but especially important at month-end before storage fees are charged.',
'1. Navigate to Inventory → Aged Inventory
2. The table shows:
   - SKU: Product SKU
   - QTY BY AGE TIER: Units in each range (0-90, 91-180, 181-270, 271-365, 365+)
   - EST SURCHARGE: Estimated 90-day fees
   - SALES PRICE TO CLEAR: Price needed to recover fees through sales
   - REMOVAL COST: Cost to remove via Amazon
   - RECOMMENDATION: Remove / Monitor / OK
3. Red highlighted rows are items needing immediate action
4. Click on a row to see more detail or take action',
'Items in the 271-365 day tier are at risk of jumping to 365+ tier soon. Take action now.',
'Not checking this until you get a surprise bill. Long-term storage fees add up quickly.');

-- ============================================================================
-- SECTION 5: CASE MANAGEMENT FEATURES
-- ============================================================================

-- 5.1 How to open a new case
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Case Management', 'Opening a New Case',
'Creates a new case in the system for tracking an Amazon issue that needs resolution.',
'When you discover an issue that requires filing with Amazon Seller Support.',
'1. Navigate to Cases → New Case (or Cases → Create)
2. Fill in the form:
   - CASE TYPE: Select from dropdown
     * LOST_INVENTORY: Amazon lost your inventory
     * DAMAGED_INVENTORY: Amazon damaged your inventory
     * FEE_OVERCHARGE: Amazon charged incorrect fees
     * RETURNLESS_REFUND: Refund issued but no return received
     * LISTING_SUPPRESSION: Listing is suppressed
     * HIJACK_REPORT: Someone stealing your buy box
     * ACCOUNT_SUSPENSION: Your account is suspended
     * INBOUND_SHIPMENT: Shipment quantity mismatch
     * AWD_LOSS: Amazon Warehousing discrepancy
   - SUBJECT: Brief description
   - DESCRIPTION: Full details of the issue
   - PRIORITY: Low / Medium / High / Critical
   - ASIN: If applicable
3. Click "Create Case"
4. The case appears in your case list with status "Open"',
'Link the case to a reimbursement audit finding if applicable. This creates a trail connecting the data to the claim.',
'Creating vague cases without specifics. Amazon needs exact details to process claims.');

-- 5.2 Attaching documents and evidence
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Case Management', 'Attaching Documents to Cases',
'Adds supporting documentation like invoices, packing slips, or screenshots to your case.',
'When you need to provide evidence to Amazon for your case.',
'1. Open the case (Cases → Find the case and click it)
2. Look for "Attachments" section or "Add Attachment" button
3. Click "Add File" or drag and drop
4. Select your file (PDF, JPG, PNG supported)
5. Add a description: "Invoice showing cost basis" or "Tracking confirmation"
6. Click "Upload"
7. The file appears in the attachments list
8. You can add multiple files',
'Use descriptive file names and add descriptions. When Amazon reviews your case, they can quickly identify each document.',
'Attaching files without description. Amazon reviewers won''t know what each file is.');

-- 5.3 How to escalate a case
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Case Management', 'Escalating a Case',
'Moves a case to a higher level of support when it''s not getting resolved. Use after 7 days without response.',
'When you have waited 7+ business days without a substantive response from Amazon.',
'1. Open the case
2. Look for "Escalate" button (or menu → Escalate)
3. You may need to provide a reason:
   - No response after [X] days
   - Inadequate resolution offered
   - Incorrect information provided
4. Click "Escalate"
5. The case status changes to "Escalated"
6. A new escalation level is recorded (1, 2, etc.)
7. An alert is created for your manager',
'Wait at least 7 business days before escalating. Escalating too early can result in the case being sent back.',
'Escalating too quickly without giving Amazon time to respond. Be patient but persistent.');

-- ============================================================================
-- SECTION 6: REFUND & REIMBURSEMENT AUDITOR
-- ============================================================================

-- 6.1 Running the Monthly Reimbursement Checklist
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Reimbursement Auditor', 'Monthly Reimbursement Checklist',
'A comprehensive list of all potential reimbursement claims for the month. Shows what you may be owed.',
'Once per month, a few days after month-end when all data is available.',
'1. Navigate to Reimbursement → Monthly Checklist
2. Select the month and year
3. Click "Run Checklist"
4. The app runs all audit procedures and shows results:
   - LOST INVENTORY: Potential claims from Amazon-reported losses
   - DAMAGED INVENTORY: Potential claims from Amazon-reported damage
   - RETURNLESS REFUNDS: Refunds issued without returns received
   - FEE OVERCHARGES: Fees that seem higher than expected
5. Each section shows:
   - Number of potential claims
   - Total amount you may be owed
   - Status (New / Reviewed / Claimed)
6. Click on any section to see details
7. Mark items as "Claimed" after you file with Amazon',
'Do this every month without fail. Many sellers forget about claims and leave money on the table.',
'Not running this monthly. Reimbursement claims have an 18-month window - missing the deadline forfeits the claim.');

-- 6.2 Understanding ClaimableAmount calculation
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Reimbursement Auditor', 'Understanding ClaimableAmount',
'Understanding how the application calculates how much you can claim. This is CRITICAL because of the 2025 Amazon policy change.',
'When reviewing reimbursement audit results and before filing claims with Amazon.',
'1. The app calculates: ClaimableAmount = Unclaimed Qty × Your COGS
2. This is based on Amazon''s March 2025 policy:
   - Amazon now reimburses at COST BASIS, not selling price
3. The calculation uses YOUR cost from your product settings
4. If COGS is not entered, the app can''t calculate accurately
5. You will see warnings like "MISSING_COGS" if needed

WHY THIS MATTERS:
- Before 2025: Claim = Unclaimed Units × Selling Price
- After 2025: Claim = Unclaimed Units × Your COGS
- This can be 50-70% lower than before!

The app uses the lower COGS amount as required by Amazon''s new policy.',
'This is why entering COGS is critical. Without it, your claim amounts will be wrong.',
'Entering selling price instead of cost in the COGS field. This will overstate your claims and Amazon will reject them.');

PRINT 'Sections 3-6 help topics inserted.';

GO