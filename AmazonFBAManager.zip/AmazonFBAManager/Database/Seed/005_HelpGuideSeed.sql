-- ============================================================================
-- Help & User Guide Seed Data
-- Comprehensive guide for Amazon FBA Management application
-- ============================================================================

SET NOCOUNT ON;

-- ============================================================================
-- SECTION 1: GETTING STARTED
-- ============================================================================

-- 1.1 Creating your account and first login
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Getting Started', 'Creating Your Account and First Login',
'Creates your user account in the application and allows you to access the system for the first time. This is the first step for any new user.',
'When you are a new user setting up access to the FBA management platform for the first time.',
'1. Navigate to the application URL provided by your administrator
2. Click "Sign Up" or "Register New Account"
3. Enter your email address (this will be your username)
4. Create a strong password (must include: uppercase, lowercase, number, special character, minimum 12 characters)
5. Confirm your password
6. Enter your full name
7. Select your role from the dropdown (Admin, Account Manager, Analyst, or VA Read-Only)
8. Check the "I agree to the terms of service" checkbox
9. Click "Create Account"
10. You will receive an email verification link - click it to verify your email
11. Return to the application and log in with your credentials',
'Use a password manager to generate and store a strong password. Your password is encrypted and cannot be recovered if forgotten.',
'Forgetting your password and having to reset it repeatedly. Use the "Remember Me" feature on secure computers you control.');

-- 1.2 Adding your first Amazon Seller Account
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Getting Started', 'Adding Your First Amazon Seller Account',
'Connects your Amazon seller account to the application using SP-API credentials. This allows the app to pull data and manage that seller account.',
'When you are setting up your first seller account in the application after your account is created.',
'1. Log in to the application with your credentials
2. Navigate to Settings → Seller Accounts
3. Click the "Add Seller Account" button
4. Enter the Account Name (this is how it will appear in the app - e.g., "My Amazon Store")
5. Select the Marketplace from the dropdown (US, CA, UK, DE, etc.)
6. Enter your Seller Central email/username
7. Enter your SP-API Client ID (from Amazon Seller Central → Settings → Third-Party Developer Settings)
8. Enter your SP-API Client Secret
9. Enter your Refresh Token
10. Select your Region code (US, CA, UK, etc.)
11. Click "Save and Test Connection"
12. If successful, you will see a green "Connected" message
13. The account will now appear in your Seller Accounts list',
'Keep your SP-API credentials secure. They provide access to your Amazon data. Test the connection before saving to ensure credentials are correct.',
'Entering incorrect credentials and not testing before saving, then wondering why data doesn''t sync.');

-- 1.3 Adding multiple seller accounts and switching between them
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Getting Started', 'Adding Multiple Seller Accounts and Switching',
'Allows you to manage multiple Amazon seller accounts from a single login. You can switch between accounts without logging out.',
'When you manage more than one Amazon seller account and need to access all of them from one login.',
'1. To add another account: Follow steps in "Adding Your First Amazon Seller Account"
2. To switch accounts:
   a. Look for the account selector in the top navigation bar (usually shows current account name)
   b. Click the dropdown arrow
   c. Select the account you want to switch to
   d. The dashboard will refresh showing data for the selected account
3. To view all accounts at once:
   a. Go to Dashboard → Multi-Account Overview
   b. This shows consolidated metrics across all accounts',
'Use the keyboard shortcut Ctrl+Alt+S (Cmd+Alt+S on Mac) to quickly open the account switcher.',
'Forgetting which account is currently selected and viewing the wrong data. Always check the account selector.');

-- 1.4 Setting up user roles
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Getting Started', 'Setting Up User Roles',
'Assigns permission levels to users to control what they can see and do in the application. Different roles have different access levels.',
'When you are an Admin setting up new users or modifying permissions for existing users.',
'1. Log in as Admin
2. Navigate to Settings → User Management
3. Click "Add User" to create a new user, or click an existing user to edit
4. Enter or verify the user''s email and name
5. Select the appropriate Role from the dropdown:
   - Admin: Full system access, can manage all settings and users
   - Account Manager: Can manage all aspects of assigned accounts
   - Analyst: View-only access to reports and data
   - VA Read-Only: Limited view for virtual assistants
6. Assign the user to specific seller accounts using the account selector
7. Set permission level per account (Full, ReadOnly, or Execute)
8. Click "Save"',
'Use the principle of least privilege - give users only the permissions they need to perform their job.',
'Giving too many permissions to VAs or Analysts who don''t need full access, creating security risks.');

-- 1.5 Navigating the dashboard for the first time
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Getting Started', 'Navigating the Dashboard',
'The main dashboard provides a high-level overview of your Amazon business. It shows key metrics, alerts, and quick access to all features.',
'When you first log in and need to understand how to find your way around the application.',
'1. The top navigation bar shows: Logo (click for dashboard), Menu (all features), Account Selector, Notifications bell, User menu
2. The main dashboard cards show:
   - Revenue Summary: Today's revenue, week-to-date, month-to-date
   - Units Sold: Units sold today and this period
   - Net Profit: Profit after fees and COGS
   - Inventory Health: Low stock alerts, overstock count
   - Open Cases: Number of unresolved cases
   - Recent Alerts: Latest notifications requiring attention
3. Click any card to drill down into detailed reports
4. Use the date range selector to change the time period
5. Use the refresh button to update data',
'Click the "star" icon on any dashboard card to add it to your favorites for quick access.',
'Not customizing your dashboard. Everyone sees the same default - personalize it to your needs.');

-- 1.6 Setting alert thresholds
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Getting Started', 'Setting Alert Thresholds',
'Configures when the application sends you alerts for various conditions like low stock, fee spikes, or case SLA breaches.',
'When you want to customize which alerts you receive and at what thresholds.',
'1. Navigate to Settings → Alert Thresholds
2. You will see a list of alert types with their current thresholds
3. For each alert type, you can:
   - Enable or disable the alert entirely
   - Adjust the threshold value
   - Set the severity level
4. Available alert types:
   - LOW_STOCK: Alert when inventory falls below reorder point
   - OVERSTOCK: Alert when days of supply exceeds threshold
   - STRANDED: Alert when inventory becomes stranded
   - AGED_FEE_RISK: Alert when inventory approaches long-term storage fees
   - HIJACK_DETECTED: Alert when buy box is lost to unauthorized seller
   - BUY_BOX_LOST: Alert when buy box ownership drops
   - CASE_SLA_BREACH: Alert when case approaches SLA deadline
   - NEW_REIMBURSEMENT_OPPORTUNITY: Alert when new claim is detected
   - FEE_SPIKE: Alert when fees exceed normal by percentage
   - LISTING_SUPPRESSED: Alert when listing is suppressed
5. Click "Save Thresholds" after making changes',
'Set conservative thresholds initially and adjust based on your actual experience with alerts.',
'Setting thresholds too low and getting overwhelmed with alerts, or too high and missing important issues.');

-- 1.7 Configuring COGS (Critical for 2025 Reimbursement Policy)
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Getting Started', 'Configuring COGS (Cost of Goods Sold)',
'Enters your cost per unit for each product. This is CRITICAL because Amazon changed their reimbursement policy in March 2025 - they now reimburse at COST BASIS, not selling price.',
'When setting up products for the first time, or when entering COGS data that is required for accurate reimbursement calculations.',
'1. Navigate to Products → Product List
2. Click "Add Product" or select an existing product to edit
3. Enter the following fields:
   - SKU (required): Your internal SKU
   - ASIN (required): The Amazon ASIN
   - Product Title: For reference
   - Brand: The brand name
   - Category: Product category
   - COGS (CRITICAL): Your cost per unit in dollars
   - Weight: Product weight in pounds
   - Dimensions: Length x Width x Height in inches
   - Reorder Point: When to reorder
   - Reorder Qty: How much to reorder
   - Lead Time Days: Days from order to delivery
4. Click "Save"
5. Repeat for all products

BULK COGS IMPORT:
1. Navigate to CSV Import Center
2. Select "Products/COGS" as the report type
3. Upload a CSV with columns: SKU, ASIN, ProductTitle, COGS, Weight, Dimensions
4. Map columns if needed
5. Import - existing products will be updated, new products will be created',
'Enter COGS for EVERY product that has ever been in FBA inventory. This is the single most important field for reimbursement accuracy. Without COGS entered, you cannot accurately claim reimbursement for lost/damaged inventory.',
'Entering COGS as zero or leaving it blank because "I don''t know the exact cost." Use your average cost or last purchase price - an estimate is better than nothing for the 2025 reimbursement calculations.');

PRINT 'Section 1 (Getting Started) help topics inserted.';

GO