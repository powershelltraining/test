-- ============================================================================
-- Email Templates Seed Data
-- Complete 62 templates for Amazon FBA sellers
-- ============================================================================

SET NOCOUNT ON;

-- ============================================================================
-- CATEGORY 1: AMAZON CASE MANAGEMENT EMAILS (1.1 - 1.21)
-- ============================================================================

-- 1.1 Opening a Lost Inventory Case
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Opening Lost Inventory Case', 'CASE_MANAGEMENT', 'LOST_INVENTORY',
'Lost Inventory Reimbursement Request - [ASIN] - [ORDER_ID]',
'Dear Amazon Seller Support,

I am writing to request reimbursement for inventory reported as lost in your fulfillment center.

Details:
- ASIN: [ASIN]
- SKU: [SKU]
- Quantity Lost: [QTY]
- Loss Date: [DATE]
- Fulfillment Center: [FC_ID]
- Estimated Value at Cost: $[AMOUNT]

This loss occurred despite proper handling and tracking. I have attached documentation showing the shipment was delivered to your fulfillment center.

Please process this reimbursement claim at my cost basis of $[COGS] per unit, in accordance with Amazon''s reimbursement policy.

Thank you for your prompt attention to this matter.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Attach: 1) Tracking confirmation showing delivery to FC, 2) Packing list, 3) Invoice showing cost basis');

-- 1.2 Opening a Damaged Inventory Case
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Opening Damaged Inventory Case', 'CASE_MANAGEMENT', 'DAMAGED_INVENTORY',
'Damaged Inventory Reimbursement Request - [ASIN] - [DATE]',
'Dear Amazon Seller Support,

I am requesting reimbursement for inventory that was damaged while in Amazon''s possession.

Details:
- ASIN: [ASIN]
- SKU: [SKU]
- Quantity Damaged: [QTY]
- Damage Report Date: [DATE]
- Fulfillment Center: [FC_ID]
- Estimated Value at Cost: $[AMOUNT]

The units were in sellable condition when received by Amazon. The damage appears to have occurred during storage or handling in your fulfillment center.

Please reimburse at cost basis of $[COGS] per unit as per current Amazon reimbursement policy.

Thank you for your assistance.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Attach: Damage report from Seller Central, photos if available, cost basis documentation');

-- 1.3 Opening an Inbound Shipment Discrepancy Case
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Opening Inbound Shipment Discrepancy Case', 'CASE_MANAGEMENT', 'INBOUND_SHIPMENT',
'Inbound Shipment Discrepancy - Shipment ID [SHIPMENT_ID]',
'Dear Amazon Seller Support,

I am reporting a discrepancy between units shipped and units received for the following inbound shipment.

Shipment Details:
- Shipment ID: [SHIPMENT_ID]
- Destination FC: [FC_ID]
- Ship Date: [SHIP_DATE]
- Units Shipped: [QTY_SHIPPED]
- Units Received: [QTY_RECEIVED]
- Variance: [QTY_VARIANCE]

Attached please find:
1. Bill of Lading showing units shipped
2. Packing list
3. Carrier tracking confirmation

We request reimbursement for the missing [QTY_VARIANCE] units at our cost basis of $[COGS] per unit.

Please investigate and process the appropriate reimbursement.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Attach: Bill of lading, packing list, carrier tracking, receiving documents from Amazon');

-- 1.4 Opening an AWD Shipment Loss Case
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Opening AWD Shipment Loss Case', 'CASE_MANAGEMENT', 'AWD_LOSS',
'AWD Inventory Loss Claim - [ASIN] - Shipment [SHIPMENT_ID]',
'Dear Amazon Seller Support,

I am filing a claim for inventory loss related to Amazon Warehousing & Distribution (AWD).

AWD Shipment Details:
- Shipment ID: [SHIPMENT_ID]
- ASIN: [ASIN]
- SKU: [SKU]
- Units Shipped to AWD: [QTY_SHIPPED]
- Units Received at FC (after AWD): [QTY_RECEIVED]
- Units Missing: [QTY_MISSING]
- Cost Basis: $[COGS_PER_UNIT]
- Total Claim Amount: $[TOTAL_AMOUNT]

The inventory was transferred from AWD to the fulfillment center but fewer units were received than were sent.

Please investigate the AWD transfer and process reimbursement for the missing units.

Thank you for your prompt attention.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'This is critical - AWD discrepancies were a major issue in 2024-2025. Include all transfer documentation');

-- 1.5 Disputing a Fee Overcharge
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Disputing Fee Overcharge', 'CASE_MANAGEMENT', 'FEE_OVERCHARGE',
'Fee Overcharge Dispute - [ASIN] - [DATE_RANGE]',
'Dear Amazon Seller Support,

I am disputing the following fees charged to my account which appear to be incorrect.

Fee Details:
- ASIN: [ASIN]
- SKU: [SKU]
- Fee Type: [FEE_TYPE]
- Amount Charged: $[CHARGED_AMOUNT]
- Expected Fee: $[EXPECTED_AMOUNT]
- Overcharge: $[VARIANCE]
- Date Range: [DATE_RANGE]

I have calculated the expected fee based on:
- Product dimensions: [DIMENSIONS]
- Product weight: [WEIGHT]
- Current fee schedule

Please review and adjust this fee accordingly. I request a refund of the overcharged amount.

Thank you for your attention.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Include your calculation, reference Amazon''s current fee schedule, attach photos of product dimensions');

-- 1.6 Claiming a Returnless Refund Not Reimbursed
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Returnless Refund Claim', 'CASE_MANAGEMENT', 'RETURNLESS_REFUND',
'Returnless Refund Reimbursement Request - Order [ORDER_ID]',
'Dear Amazon Seller Support,

I am requesting reimbursement for a returnless refund that was issued but for which we have not received reimbursement.

Case Details:
- Amazon Order ID: [ORDER_ID]
- ASIN: [ASIN]
- Refund Amount: $[REFUND_AMOUNT]
- Refund Date: [REFUND_DATE]
- Return Status: No return received

We issued a full refund to the buyer on [DATE] but no return was received within the expected timeframe. The buyer kept the product without returning it.

Per Amazon policy, when a refund is issued without a corresponding return, the seller should be reimbursed.

Please process this reimbursement of $[AMOUNT].

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Attach refund confirmation, show that no return was received - check Returns dashboard');

-- 1.7 Escalating a Case After No Response (7 days)
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Escalation - No Response (7 Days)', 'CASE_MANAGEMENT', 'ESCALATION',
'URGENT: Escalation - Case [CASE_ID] - No Response After 7 Days',
'Dear Amazon Seller Support,

I am escalating Case #[CASE_ID] as there has been no response within the expected timeframe.

Original Case Details:
- Case ID: [CASE_ID]
- Case Type: [CASE_TYPE]
- Date Opened: [OPENED_DATE]
- Subject: [SUBJECT]
- Last Update: [LAST_UPDATE]

This matter remains unresolved and is affecting our business operations. We have been waiting 7+ business days without a substantive response.

Please assign this case to a specialist who can provide a resolution.

Thank you for your prompt attention to this escalation.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Be professional but firm. Reference previous case ID and dates of all correspondence');

-- 1.8 Escalating a Case After First Escalation Fails (14 days)
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Escalation - Second Level (14 Days)', 'CASE_MANAGEMENT', 'ESCALATION',
'URGENT: Second Level Escalation - Case [CASE_ID] - 14 Days Unresolved',
'Dear Amazon Seller Support,

I am requesting second-level escalation for Case #[CASE_ID]. Despite previous escalation, the case remains unresolved after 14 days.

Case History:
- Case ID: [CASE_ID]
- Original Submission: [ORIGINAL_DATE]
- First Escalation: [ESCALATION_DATE]
- Days Open: [DAYS_OPEN]
- Current Status: [STATUS]

This extended delay is causing significant financial impact to our business. We have been unable to recover $[AMOUNT_AT_RISK].

Please escalate to a senior specialist or manager for immediate resolution.

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Include timeline of all communications, quantify financial impact');

-- 1.9 Requesting a Case Be Reviewed by a Senior Specialist
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Request Senior Specialist Review', 'CASE_MANAGEMENT', 'SENIOR_REVIEW',
'Request for Senior Specialist Review - Case [CASE_ID]',
'Dear Amazon Seller Support,

I am formally requesting that Case #[CASE_ID] be reviewed by a senior specialist or account manager.

Case Details:
- Case ID: [CASE_ID]
- Type: [CASE_TYPE]
- Amount in Question: $[AMOUNT]
- Previous Responses: [SUMMARY_OF_RESPONSES]

The current resolution offered is inadequate and does not align with Amazon policy. We believe this case warrants senior review due to:

1. [REASON_1]
2. [REASON_2]
3. [REASON_3]

Please forward this case to a senior specialist for comprehensive review.

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Clearly outline why the current resolution is inadequate - be specific');

-- 1.10 Following Up on a Pending Reimbursement
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Following Up Pending Reimbursement', 'CASE_MANAGEMENT', 'FOLLOW_UP',
'Follow Up: Pending Reimbursement - Case [CASE_ID]',
'Dear Amazon Seller Support,

I am following up on the status of reimbursement Case #[CASE_ID] which was submitted on [SUBMISSION_DATE].

Original Case Details:
- Case ID: [CASE_ID]
- Claim Amount: $[CLAIM_AMOUNT]
- Days Pending: [DAYS_PENDING]

We have not received an update on the status of this claim. Could you please provide an update on when we can expect a resolution?

Thank you for your attention.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Check that claim is within the 18-month filing window. Be polite but persistent');

-- 1.11 Disputing Amazon's Reimbursement Amount (Wrong Cost Basis)
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Disputing Reimbursement Amount - Cost Basis', 'CASE_MANAGEMENT', 'DISPUTE',
'Reimbursement Amount Dispute - Case [CASE_ID] - 2025 Cost Basis Policy',
'Dear Amazon Seller Support,

I am disputing the reimbursement amount provided for Case #[CASE_ID].

Case Details:
- Case ID: [CASE_ID]
- Claim Submitted: [DATE]
- Units Claimed: [QTY]
- Amazon''s Offer: $[AMOUNT_OFFERED]
- Our Claim Amount: $[CLAIM_AMOUNT]

Dispute Reason:
Per Amazon''s reimbursement policy effective March 2025, reimbursements for lost and damaged inventory should be calculated at the seller''s cost basis, not the current selling price.

Our documented cost basis is $[COGS_PER_UNIT] per unit. For [QTY] units, the correct reimbursement should be $[CORRECT_AMOUNT].

Please recalculate using our documented cost basis and process the appropriate adjustment.

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Include invoice or cost documentation. This is critical for 2025 policy compliance');

-- 1.12 Requesting FBA Fee Recalculation (Wrong Dimensions)
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('FBA Fee Recalculation - Dimensions', 'CASE_MANAGEMENT', 'FEE_RECALC',
'FBA Fee Recalculation Request - [ASIN] - Incorrect Dimensions',
'Dear Amazon Seller Support,

I am requesting a recalculation of FBA fees for ASIN [ASIN] due to incorrect product dimensions in the system.

Current System Data:
- Listed Size: [LISTED_SIZE]
- Listed Weight: [LISTED_WEIGHT] oz

Actual Product Dimensions:
- Actual Size: [ACTUAL_SIZE]
- Actual Weight: [ACTUAL_WEIGHT] oz

The incorrect dimensions are causing us to be overcharged $[MONTHLY_OVERCHARGE] per month in fulfillment fees.

Please update our product data to reflect the accurate dimensions and refund the overcharged fees dating back to [DATE].

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Include photos measuring the product. Amazon only backrefunds 90 days typically');

-- 1.13 Requesting FBA Fee Recalculation (Wrong Weight)
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('FBA Fee Recalculation - Weight', 'CASE_MANAGEMENT', 'FEE_RECALC',
'FBA Fee Recalculation Request - [ASIN] - Incorrect Weight',
'Dear Amazon Seller Support,

I am requesting a recalculation of FBA fees for ASIN [ASIN] due to an incorrect product weight in the system.

Current System Weight: [SYSTEM_WEIGHT] oz
Actual Product Weight: [ACTUAL_WEIGHT] oz

The incorrect weight has resulted in incorrect fee tier assignment, causing overcharges of $[MONTHLY_OVERCHARGE].

Please update the product weight to [ACTUAL_WEIGHT] oz and refund the overcharged fees.

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Weigh the product yourself and take photos as evidence');

-- 1.14 Stranded Inventory Relisting Request
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Stranded Inventory Relisting', 'CASE_MANAGEMENT', 'STRANDED',
'Inventory Stranded - Request for Relisting - [ASIN]',
'Dear Amazon Seller Support,

Our inventory for ASIN [ASIN] has become stranded and we need assistance with relisting.

Details:
- ASIN: [ASIN]
- SKU: [SKU]
- Stranded Units: [QTY]
- Reason for Stranding: [REASON]

We have resolved the original listing issue and request that our [QTY] units be made active again.

Please assist in unstranding this inventory so we can resume sales.

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'First fix the listing issue in Seller Central, then request unstranding');

-- 1.15 Listing Suppression - Appeal to Reinstate
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Listing Suppression Appeal', 'CASE_MANAGEMENT', 'LISTING_SUPPRESSION',
'Appeal for Listing Reinstatement - [ASIN]',
'Dear Amazon Seller Support,

I am appealing the suppression of our listing for ASIN [ASIN].

Listing Details:
- ASIN: [ASIN]
- SKU: [SKU]
- Suppression Reason: [REASON]

Corrective Actions Taken:
1. [ACTION_1]
2. [ACTION_2]
3. [ACTION_3]

We have addressed all the issues that led to suppression and request reinstatement of our listing.

Please review and reactivate this listing.

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Document exactly what you fixed. Attach before/after screenshots');

-- 1.16 Account Health - Policy Warning Appeal
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Account Health Policy Warning Appeal', 'CASE_MANAGEMENT', 'ACCOUNT_HEALTH',
'Appeal: Account Health Warning - [WARNING_TYPE]',
'Dear Amazon Seller Support,

I am writing to appeal the account health warning regarding [WARNING_TYPE].

Current Performance Metrics:
- Order Defect Rate: [ODR]%
- Late Delivery Rate: [LATE]%
- Valid Tracking Rate: [VTR]%

Root Cause Analysis:
[Brief explanation of what caused the issue]

Corrective Actions Implemented:
1. [ACTION_1]
2. [ACTION_2]
3. [ACTION_3]

Preventive Measures:
1. [MEASURE_1]
2. [MEASURE_2]

We are committed to maintaining excellent account health and have implemented robust measures to prevent recurrence.

Thank you for your consideration.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Show concrete data and specific actions taken. Include metrics showing improvement');

-- 1.17 Account Suspension - Plan of Action (POA)
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Account Suspension POA', 'CASE_MANAGEMENT', 'SUSPENSION',
'Plan of Action - Account Suspension - [SELLER_ID]',
'Dear Amazon Seller Support,

Please find below our comprehensive Plan of Action regarding the account suspension notice received on [DATE].

==========================================
SECTION 1: ROOT CAUSE ANALYSIS
==========================================
[Brief overview of what caused the suspension]

Primary Factors:
1. [FACTOR_1]
2. [FACTOR_2]
3. [FACTOR_3]

==========================================
SECTION 2: CORRECTIVE ACTIONS TAKEN
==========================================
Actions completed to address the issues:

1. [ACTION_1]
   - Date Completed: [DATE]
   - Evidence: [LINK_OR_DESCRIPTION]

2. [ACTION_2]
   - Date Completed: [DATE]
   - Evidence: [LINK_OR_DESCRIPTION]

3. [ACTION_3]
   - Date Completed: [DATE]
   - Evidence: [LINK_OR_DESCRIPTION]

==========================================
SECTION 3: PREVENTIVE MEASURES
==========================================
Long-term measures to prevent recurrence:

1. [MEASURE_1]
   - Implementation Date: [DATE]
   - Responsible Party: [NAME/ROLE]

2. [MEASURE_2]
   - Implementation Date: [DATE]
   - Responsible Party: [NAME/ROLE]

3. [MEASURE_3]
   - Implementation Date: [DATE]
   - Responsible Party: [NAME/ROLE]

==========================================
REQUEST
==========================================
We respectfully request reinstatement of our selling privileges.

We have taken this matter seriously and have implemented comprehensive measures to ensure compliance with Amazon policies going forward.

Thank you for your consideration.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'DO NOT make excuses. Be specific and show evidence. Address ALL points in the suspension notice');

-- 1.18 ASIN Reinstatement After Suspension
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('ASIN Reinstatement Request', 'CASE_MANAGEMENT', 'ASIN_REINSTATEMENT',
'ASIN Reinstatement Request - [ASIN]',
'Dear Amazon Seller Support,

I am requesting reinstatement of ASIN [ASIN] which was previously suspended.

Product Details:
- ASIN: [ASIN]
- SKU: [SKU]
- Suspension Date: [DATE]
- Suspension Reason: [REASON]

Corrective Actions Taken:
1. [ACTION_1]
2. [ACTION_2]
3. [ACTION_3]

We have addressed all concerns and request that this product be reinstated to allow us to resume sales.

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Attach evidence of fixes. Make sure you fully addressed the suspension reason');

-- 1.19 Intellectual Property Complaint Counter-Notice
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('IP Counter-Notice (False Complaint)', 'CASE_MANAGEMENT', 'INTELLECTUAL_PROPERTY',
'Counter-Notice: False IP Complaint - [ASIN]',
'Dear Amazon Seller Support,

We are filing a counter-notice regarding a false intellectual property complaint received for our product.

Product Information:
- ASIN: [ASIN]
- Our Brand: [BRAND]
- Trademark Registration: [TRADEMARK_NUMBER]

Complaint Details:
- Claiming Party: [COMPLAINANT]
- Complaint Type: [TYPE]
- Date Received: [DATE]

Basis for Counter-Notice:
1. We are the legitimate rights holder or authorized reseller
2. Our product is genuine and legally sourced
3. The complaint appears to be from a competitor attempting to remove our listing

Documentation Provided:
- [DOC_1]
- [DOC_2]

We request immediate reinstatement of our listing pending formal review.

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Attach proof of authorization, invoices showing legitimate sourcing, trademark documentation');

-- 1.20 Reporting Competitor for Review Manipulation
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Report Competitor Review Manipulation', 'CASE_MANAGEMENT', 'REPORT_ABUSE',
'Report: Suspected Review Manipulation - [COMPETITOR_ASIN]',
'Dear Amazon Seller Support,

We are reporting suspected review manipulation by a competitor.

Suspected Violator:
- Seller Name: [SELLER_NAME]
- ASIN: [COMPETITOR_ASIN]
- Product: [PRODUCT_NAME]

Evidence of Manipulation:
1. [EVIDENCE_1]
2. [EVIDENCE_2]
3. [EVIDENCE_3]

Suspicious Patterns Noted:
- [PATTERN_1]
- [PATTERN_2]

We request investigation into this seller for potential policy violations including fake reviews.

Thank you for your attention to this matter.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Document specific suspicious reviews with dates. Include screenshots and dates');

-- 1.21 Reporting Competitor for Counterfeit Products
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Report Counterfeit Product', 'CASE_MANAGEMENT', 'COUNTERFEIT',
'Report: Counterfeit Product - [COMPETITOR_ASIN] - [OUR_BRAND]',
'Dear Amazon Seller Support,

We are reporting a seller listing counterfeit versions of our branded product.

Counterfeit Details:
- Seller: [SELLER_NAME]
- ASIN: [COMPETITOR_ASIN]
- Our Legitimate ASIN: [OUR_ASIN]
- Our Brand: [BRAND]

Evidence:
1. [EVIDENCE_1]
2. [EVIDENCE_2]
3. [EVIDENCE_3]

Differences Between Authentic and Counterfeit:
- [DIFFERENCE_1]
- [DIFFERENCE_2]

We have purchased the product for test buy and can provide documentation.

Please investigate and remove this listing to protect consumers and legitimate sellers.

Thank you.

Best regards,
[SELLER_NAME]
[SELLER_EMAIL]',
'Do a test buy! Document all differences. This is a seriousBrand Registry issue');

PRINT 'Category 1 (Case Management) templates inserted successfully.';