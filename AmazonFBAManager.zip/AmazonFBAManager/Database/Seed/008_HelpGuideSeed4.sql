-- ============================================================================
-- Help & User Guide Seed Data - Part 4
-- SECTIONS 7-11: REPORTS, PPC, LISTINGS, ALERTS, VA GUIDE
-- ============================================================================

SET NOCOUNT ON;

-- ============================================================================
-- SECTION 7: SALES & FINANCIAL REPORTS
-- ============================================================================

-- 7.1 Running P&L by SKU
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Sales Reports', 'Profit & Loss by SKU',
'Shows profit and loss for each SKU, breaking down revenue, COGS, fees, and other costs. This is your most important financial report.',
'Weekly or monthly to understand which products are profitable and which are not.',
'1. Navigate to Reports → Profit & Loss
2. Select date range (last 30 days, last month, or custom)
3. Select "Group By" = SKU
4. Click "Run Report"
5. The table shows each SKU with columns:
   - REVENUE: Total sales
   - COGS: Cost of goods sold
   - FBA FEES: Amazon fees
   - PPC SPEND: Advertising costs
   - REFUNDS: Refund amounts
   - REIMBURSEMENTS: Recovered amounts
   - NET PROFIT: Revenue minus all costs
   - MARGIN %: Net profit / Revenue
   - ROI: Return on investment
6. Sort by any column to find top/bottom performers
7. Click any row to see period breakdown',
'Focus on MARGIN % and ROI, not just absolute profit. A SKU with $10,000 profit at 3% margin is less valuable than $1,000 profit at 40% margin.',
'Ignoring products with negative margin. These may be driving traffic to higher-margin products, but you should verify that.');

-- 7.2 Reading Fee Waterfall Chart
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Sales Reports', 'Fee Waterfall Chart',
'Visual chart showing how your revenue is reduced by various fees. Shows exactly where your money goes.',
'When you want to visually understand your fee breakdown and profitability.',
'1. Navigate to Reports → Fee Analysis (or Reports → Financial → Fee Waterfall)
2. Select date range
3. The chart shows:
   - Top bar: Your total revenue
   - Then subtracts each fee in order:
     * Referral Fee (typically 15%)
     * FBA Fulfillment Fee
     * Monthly Storage Fee
     * Long-Term Storage Fee (if applicable)
     * PPC Spend
     * Refunds Issued
   - Bottom bar: Your Net Profit
4. Hover over any section to see exact amounts
5. Click on a fee section to see per-SKU breakdown',
'The chart often reveals surprising insights - storage fees may be higher than you realized, or referral fees add up faster than expected.',
'Not looking at the fee waterfall. Fees can easily consume 30-40% of revenue - know where your money is going.');

-- ============================================================================
-- SECTION 8: PPC ANALYZER
-- ============================================================================

-- 8.1 Understanding Wasted Spend Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('PPC Analyzer', 'Wasted Spend Report',
'Shows PPC keywords that are spending money but not generating sales. These are candidates for pausing or reducing bids.',
'Weekly to optimize your PPC spend and eliminate waste.',
'1. Navigate to PPC → Wasted Spend (or Audit)
2. The table shows keywords with:
   - KEYWORD: The search term
   - MATCH TYPE: Exact/Phrase/Broad
   - IMPPRESSIONS: Times shown
   - CLICKS: Times clicked
   - SPEND: Total spent
   - SALES: Revenue generated
   - ISSUE TYPE: "ZERO_CONVERSION" or "HIGH_ACOS"
   - RECOMMENDATION: What to do
3. Keywords with $50+ spend and $0 sales are flagged as HIGH priority
4. Keywords with ACoS > 50% are flagged as MEDIUM priority
5. Take action on each flagged keyword',
'Look for patterns: Are zero-conversion keywords all in "Broad" match? Consider switching to Exact for better control.',
'Ignoring wasted spend. Even a few zero-conversion keywords can burn through budget quickly.');

-- 8.2 Understanding TACoS vs ACoS
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('PPC Analyzer', 'TACoS vs ACoS',
'ACoS measures only PPC sales vs PPC spend. TACoS measures ALL sales (PPC + organic) vs PPC spend. TACoS is the better metric for understanding true PPC value.',
'When evaluating whether your PPC is profitable overall, not just within PPC.',
'1. Navigate to PPC → TACoS Calculator
2. Enter date range
3. The report shows:
   - PPC SALES: Revenue from PPC orders only
   - ORGANIC SALES: Revenue from organic (non-PPC) orders
   - TOTAL SALES: PPC + Organic
   - ACOS: (PPC Spend / PPC Sales) × 100
   - TACOS: (PPC Spend / Total Sales) × 100
4. Example:
   - You spend $100 on PPC
   - PPC generates $200 in sales → ACoS = 50%
   - But you also get $300 in organic sales from the exposure
   - Total sales = $500 → TACoS = 20%
5. TACoS shows the FULL value of PPC including organic lift',
'A lower TACoS than ACoS means your PPC is generating organic sales too. That''s great! Focus on TACoS for strategic decisions.',
'Using ACoS alone to decide if PPC is "profitable." You might be killing profitable campaigns that also drive organic sales.');

-- ============================================================================
-- SECTION 9: LISTING HEALTH MANAGER
-- ============================================================================

-- 9.1 Listing Health Score
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Listing Health', 'Listing Health Score',
'A composite score (0-100) showing overall listing health based on title, bullets, images, keywords, and A+ content.',
'Weekly to identify listings that need improvement.',
'1. Navigate to Listings → Health Score
2. The dashboard shows:
   - OVERALL SCORE: Your average listing health (0-100)
   - TITLE SCORE: Based on title length, keywords, brand
   - BULLETS SCORE: Quality of bullet points
   - IMAGES SCORE: Number and quality of images
   - APLUS SCORE: Whether A+ content is present
   - KEYWORDS SCORE: Backend keyword optimization
3. Each SKU gets a score - click to see breakdown
4. Items below 50 need immediate attention
5. Recommendations show exactly what to fix',
'Focus on the "Quick Wins" - items that are easy to fix but have big score impact.',
'Ignoring low scores. Poor listing health directly impacts conversion rate and sales.');

-- 9.2 Suppressed Listings
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Listing Health', 'Suppressed Listings',
'Shows listings that Amazon has suppressed and are not visible to customers. Must be fixed to restore sales.',
'Daily - suppressed listings mean lost sales.',
'1. Navigate to Listings → Suppressed
2. The table shows:
   - SKU / ASIN: Product identifier
   - REASON: Why it was suppressed
     * Missing bullet points
     * Invalid category
     * Missing image
     * Prohibited keyword in title
     * etc.
   - DAYS SUPPRESSED: How long it''s been hidden
   - EST. REVENUE LOST: Per day and total
   - REQUIRED ACTION: How to fix
3. Click on an item to see exactly what needs fixing
4. Fix the issue in Seller Central
5. Return to this page to mark as fixed or wait for auto-refresh',
'Fix the HIGH priority items first - those with highest revenue loss per day.',
'Ignoring suppressed listings. Every day it''s suppressed is a day of lost sales with no way to recover that revenue.');

-- ============================================================================
-- SECTION 10: ALERTS & NOTIFICATIONS
-- ============================================================================

-- 10.1 Understanding Alert Types
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Alerts', 'Understanding Alert Types',
'The application generates different alert types for different situations. Understanding what each means helps you respond appropriately.',
'When you receive an alert and need to understand what action to take.',
'LOW STOCK: Inventory below reorder point. → Order more.
OVERSTOCK: Days of supply too high. → Consider promotion or removal.
STRANDED: Inventory exists but listing is suppressed. → Fix the listing.
AGED_FEE_RISK: Inventory approaching long-term storage fees. → Consider removal.
HIJACK_DETECTED: Unauthorized seller on your listing. → Report to Brand Registry.
BUY_BOX_LOST: You lost the Buy Box. → Check pricing and availability.
CASE_SLA_BREACH: Case approaching SLA deadline. → Respond to Amazon immediately.
NEW_REIMBURSEMENT_OPPORTUNITY: New claim detected. → Review and file claim.
FEE_SPIKE: Fees higher than normal. → Review for overcharge.
LISTING_SUPPRESSED: Listing is suppressed. → Fix the issue.
AWD_DISCREPANCY: AWD shipment doesn''t match. → File claim.',
'Set aside time every morning to review alerts. New alerts appear throughout the day.',
'Dismissing alerts without action. Alerts are opportunities - investigate each one.');

-- 10.2 Configuring Email Notifications
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Alerts', 'Email Notifications',
'Set up email alerts so you receive notifications even when not logged into the app.',
'When you want to be notified of important issues via email in addition to in-app alerts.',
'1. Navigate to Settings → Notifications
2. Look for "Email Notifications" section
3. Toggle which alert types you want emailed:
   - CRITICAL: Always email (account suspension, case escalation)
   - HIGH: Email (low stock, reimbursement opportunity)
   - MEDIUM: Optional
   - LOW: Usually no email needed
4. Add your email address if not already set
5. Click "Save Notification Preferences"
6. Test by clicking "Send Test Email"
7. You should receive a test email within a few minutes',
'Start with only Critical and High alerts. Getting too many emails leads to alert fatigue.',
'Toggling on every alert type and getting overwhelmed by emails. Be selective.');

-- ============================================================================
-- SECTION 11: VA (VIRTUAL ASSISTANT) GUIDE
-- ============================================================================

-- 11.1 Daily CSV Download and Upload Routine
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('VA Guide', 'Daily CSV Routine',
'The standard daily procedure for downloading reports from Amazon and uploading them to the application.',
'Every morning at the start of your workday.',
'DAILY CHECKLIST:
□ 1. Log in to application (your credentials)
□ 2. Check Alerts panel - note any Critical or High alerts
□ 3. Download from Seller Central:
   - FBA Inventory Report
   - Sales & Traffic Report (if yesterday was month-end)
   - Returns Report
□ 4. Upload to application:
   - Inventory → CSV Upload Center
   - Select correct account
   - Select correct report type
   - Upload each file
□ 5. Verify imports complete successfully
□ 6. Report back to manager with status

EXPECTED TIME: 15-20 minutes',
'Use the same folder for downloads every day. Create desktop shortcuts to Seller Central and the app for speed.',
'Downloading reports without uploading them. The data is only useful in the app.');

-- 11.2 What a VA Should NEVER Do
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('VA Guide', 'VA Restrictions - What NOT to Do',
'Important restrictions on what virtual assistants should not do without manager approval.',
'Know the boundaries of your role to avoid making costly mistakes.',
'NEVER do these without manager approval:
✗ Change COGS values - only managers can update cost data
✗ Delete imported data - never delete historical imports
✗ Close or resolve cases - only managers approve case resolution
✗ Make claim decisions - only managers decide whether to pursue claims
✗ Delete products - never delete products from the system
✗ Change alert thresholds - only managers adjust settings
✗ Issue refunds to customers - this is handled by Amazon
✗ Modify other users'' permissions - only admins can do this
✗ Delete other users'' data or files

IF YOU DO ANY OF THESE, YOU MAY BE TERMINATED.

If you are unsure about something, ask your manager first.',
'When in doubt, ask. It''s better to ask than to make a mistake that costs money.',
'Thinking "it''s just a small change." Any of these can have serious consequences for the business.');

PRINT 'Sections 7-11 help topics inserted.';
PRINT 'Help & User Guide completed!';

GO

-- ============================================================================
-- Verify help topics count by section
-- ============================================================================
SELECT
    Section,
    COUNT(*) AS TopicCount
FROM dbo.HelpTopics
GROUP BY Section
ORDER BY
    CASE Section
        WHEN 'Getting Started' THEN 1
        WHEN 'Downloading Reports' THEN 2
        WHEN 'Uploading CSV Files' THEN 3
        WHEN 'Inventory Management' THEN 4
        WHEN 'Case Management' THEN 5
        WHEN 'Reimbursement Auditor' THEN 6
        WHEN 'Sales Reports' THEN 7
        WHEN 'PPC Analyzer' THEN 8
        WHEN 'Listing Health' THEN 9
        WHEN 'Alerts' THEN 10
        WHEN 'VA Guide' THEN 11
    END;

-- Expected: 11 sections with varying topic counts