-- ============================================================================
-- Help & User Guide Seed Data - Part 2
-- SECTION 2: DOWNLOADING REPORTS FROM AMAZON SELLER CENTRAL
-- ============================================================================

SET NOCOUNT ON;

-- 2.1 FBA Inventory Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'FBA Inventory Report',
'Downloads your current inventory levels from Amazon Seller Central. This is the most important report to run regularly - it shows what you have in Amazon''s warehouses.',
'Every day to check current stock levels, or before uploading to the app to get the latest inventory data.',
'1. Log in to Amazon Seller Central (sellercentral.amazon.com)
2. Go to INVENTORY → Inventory
3. Click "Inventory Dashboard"
4. Click "Download reports" button
5. Select "All Listings Report"
6. Choose file format: CSV
7. Click "Request Download"
8. Wait for the report to generate (usually 1-5 minutes)
9. Click "Download" when ready
10. Save the file - it will be named something like "inventory_YYYYMMDD.csv"',
'Run this report daily, especially in the morning. Your reorder decisions depend on accurate inventory data.',
'Not downloading this report frequently enough. Without current inventory data, your reorder suggestions will be wrong.');

-- 2.2 Sales & Traffic Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'Sales & Traffic Report',
'Shows your sales performance, sessions, and conversion rates. Critical for understanding which products are selling and how your traffic looks.',
'Weekly at minimum to track sales performance, or daily during peak seasons.',
'1. Seller Central → REPORTS → Business Reports
2. Click "Sales Dashboard"
3. Select date range (last 7 days, 30 days, or custom)
4. Click "Download" next to Sales and Traffic
5. Choose CSV format
6. Wait for generation
7. Download and save',
'Compare week-over-week to spot trends. Look at the "Sessions" column - more sessions with low conversion may indicate a listing problem.',
'Only looking at revenue. The traffic and conversion data in this report reveals listing health issues.');

-- 2.3 FBA Fee Preview Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'FBA Fee Preview Report',
'Shows the estimated FBA fees Amazon will charge for each product. Essential for profit calculations and identifying fee overcharges.',
'Monthly to verify fees, or before pricing decisions to ensure profitability.',
'1. Seller Central → REPORTS → Fulfillment
2. Click "Fee Preview"
3. Click "Request Fee Preview Report"
4. Select "Current inventory" or specify date range
5. Click "Request Report"
6. Wait 5-10 minutes
7. Download the report
8. File will show expected fees per SKU',
'Use this report to identify products where fees are higher than expected - these may be candidates for fee dispute claims.',
'Not checking this before pricing products. Some products have fees that make them unprofitable at certain price points.');

-- 2.4 Reimbursements Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'Reimbursements Report',
'Shows all reimbursements Amazon has issued for lost, damaged, or returned inventory. Use this to verify you received what you expected.',
'Weekly to verify reimbursement amounts, or before filing claims to see what Amazon has already reimbursed.',
'1. Seller Central → REPORTS → Fulfillment → Payments
2. Click "Reimbursements"
3. Select date range (last 30, 60, 90 days)
4. Click "Download CSV"
5. Save the file',
'Cross-reference this with your internal claims log. If Amazon reimbursed less than you claimed, you may have a dispute case.',
'Not tracking this over time. Reimbursements can add up to significant amounts - make sure you''re getting everything.');

-- 2.5 FBA Returns Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'FBA Returns Report',
'Shows all customer returns. Critical for identifying defective products, return reasons, and processing refund-related reimbursements.',
'Weekly to review return trends and identify products with high return rates.',
'1. Seller Central → REPORTS → Fulfillment → Customer Concessions
2. Click "Returns"
3. Select date range
4. Click "Download CSV"
5. Save the file',
'A high return rate can indicate a product problem. Use this data to identify items that may need improvements or discontinuation.',
'Ignoring returns data. A high return rate not only loses the sale but incurs additional fees.');

-- 2.6 Inventory Adjustments Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'Inventory Adjustments Report',
'Shows inventory adjustments including adjustments for lost, damaged, found, and customer return items. This is your source for lost inventory claims.',
'Weekly to identify any inventory Amazon reports as lost, which is the basis for reimbursement claims.',
'1. Seller Central → REPORTS → Fulfillment → Inventory
2. Click "Adjustments"
3. Select date range
4. Choose "All adjustments" or filter by reason
5. Click "Download"
6. Save the CSV',
'Look for "REMOVAL" adjustments and "DAMAGED" adjustments - these can trigger reimbursement claims.',
'Not downloading this regularly. If you don''t know what Amazon says is lost, you can''t file claims to recover the value.');

-- 2.7 Order Report - All Orders
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'Order Report - All Orders',
'Provides detailed order-level data including order ID, dates, items, quantities, and revenue. This is your source for sales analysis.',
'Daily to keep sales data current in the app, or weekly for historical analysis.',
'1. Seller Central → ORDERS → Order Reports
2. Click "Request Report"
3. Select "All Orders" report type
4. Choose date range
5. Click "Request Report"
6. Wait for generation (can take 10+ minutes for large date ranges)
7. Download when ready',
'This report can take a long time to generate. Request it during off-peak hours for faster processing.',
'Not using this report for sales analysis. The dashboard shows summary data, but the detailed order report allows SKU-level analysis.');

-- 2.8 PPC Search Term Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'PPC Search Term Report',
'Shows performance data for your PPC campaigns including search terms, clicks, spend, and sales. Essential for optimizing ad spend.',
'Weekly to review PPC performance and identify optimization opportunities.',
'1. Seller Central → ADVERTISING → Campaign Manager
2. Click "Reports" tab
3. Select "Search Term" report
4. Choose date range (last 7 or 30 days recommended)
5. Select your campaigns (or all)
6. Click "Download Report"
7. Choose CSV format
8. Save the file',
'Look for search terms with high spend but zero sales - these are candidates for being added as negative keywords.',
'Not downloading this regularly. PPC spend can quickly get out of control without regular optimization.');

-- 2.9 Settlement Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'Settlement Report',
'Shows the actual deposits Amazon makes to your bank account, including all fees, refunds, and payments. This is your source for financial reconciliation.',
'Weekly to verify Amazon''s deposits match expectations, or monthly for financial reconciliation.',
'1. Seller Central → REPORTS → Payments → All Statements
2. Click "Settlement statement" tab
3. Enter date range or select specific settlement ID
4. Click "Download"
5. Choose format (CSV recommended)
6. Save the file',
'Reconcile this against your accounting records. The settlement shows exactly what Amazon paid you and what they deducted.',
'Not reconciling settlements regularly. If Amazon makes errors, you may not catch them for months.');

-- 2.10 Stranded Inventory Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'Stranded Inventory Report',
'Shows inventory that cannot be sold because the listing has issues. Critical for fixing issues and recovering sales.',
'Daily to check for new stranded inventory, or immediately if you see a sales drop.',
'1. Seller Central → INVENTORY → Fix Stranded Inventory
2. The page will show all stranded inventory
3. Click "Download" button
4. Choose CSV format
5. Save the file',
'Fix stranded inventory immediately - every day it''s stranded is a day of lost sales. Common causes are listing suppressions or policy violations.',
'Ignoring stranded inventory. This is lost sales - fix the issue or remove the inventory to avoid ongoing storage fees.');

-- 2.11 Aged Inventory Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'Aged Inventory Report',
'Shows inventory age by how long items have been in Amazon''s warehouses. Critical for avoiding long-term storage fee surprises.',
'Monthly to see aging inventory and plan for removal orders before fees hit.',
'1. Seller Central → INVENTORY → Manage Inventory
2. Click "Inventory Age" tab
3. Select date range
4. Filter by FBA inventory
5. Click "Download"
6. Save the CSV',
'Items between 270-365 days are approaching the highest storage fees. Take action before day 365.',
'Not checking this monthly. Items older than 365 days incur the highest fees - plan removals early.');

-- 2.12 Inbound Shipment Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'Inbound Shipment Report',
'Shows the status of your inbound shipments including what was shipped, what''s in transit, and what was received. Use for discrepancy claims.',
'When shipments arrive and you want to verify Amazon received the correct quantities, or after delivery to check for discrepancies.',
'1. Seller Central → INVENTORY → Shipments
2. Click "Shipment Reports"
3. Select the date range of your shipments
4. Choose "Inbound Shipment Report"
5. Click "Download"
6. Save the CSV',
'Compare this against what you sent. Variances between shipped and received quantities can be claimed as reimbursement.',
'Not comparing received vs shipped quantities. If Amazon received less than you sent, you should file a claim.');

-- 2.13 Removal Order Detail Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'Removal Order Detail Report',
'Shows the status of removal orders - items you asked Amazon to return or dispose of. Use to verify removals were completed.',
'After requesting removals, to verify Amazon completed them correctly.',
'1. Seller Central → REPORTS → Fulfillment → Removals
2. Click "Removal Order Detail"
3. Select date range
4. Click "Download Report"
5. Save the CSV',
'Verify the "Request Status" column - items should show "Completed." If stuck in "Requested" or "InTransit," follow up.',
'Not tracking removal orders. If Amazon didn''t complete your removal, you may be paying for inventory you thought was gone.');

-- 2.14 AWD Report
INSERT INTO dbo.HelpTopics (Section, TopicName, WhatItDoes, WhenToUse, StepByStep, ProTip, CommonMistake) VALUES
('Downloading Reports', 'AWD (Amazon Warehousing) Report',
'Shows inventory in Amazon Warehousing & Distribution. Critical for tracking AWD-to-FC transfers and identifying AWD discrepancies.',
'Weekly if you use AWD, or after any AWD-to-FC transfer to verify quantities.',
'1. Seller Central → INVENTORY → AWD → Inventory
2. Click "Download Inventory Report"
3. Select date range
4. Download the CSV',
'AWD discrepancies were a major issue in 2024-2025. Compare what you sent to AWD vs what arrived at the FC.',
'Not using AWD tracking. If you use AWD, this report is essential for identifying lost inventory in the AWD pipeline.');

PRINT 'Section 2 (Downloading Reports) help topics inserted.';

GO