-- ============================================================================
-- Email Templates Seed Data - Part 2
-- CATEGORY 2: BUYER / CUSTOMER MESSAGE TEMPLATES (2.1 - 2.20)
-- ============================================================================

SET NOCOUNT ON;

-- 2.1 Late Delivery Apology + Resolution Offer
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Late Delivery Apology', 'BUYER', 'LATE_DELIVERY',
'We''re Sorry About Your Late Delivery - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Thank you for your order. We noticed your package arrived later than expected and we sincerely apologize for any inconvenience this may have caused.

Your Order Details:
- Order ID: [ORDER_ID]
- Expected Delivery: [EXPECTED_DATE]
- Actual Delivery: [ACTUAL_DATE]

We take delivery performance seriously, and while carrier delays were beyond our control, we want to make this right for you.

As a gesture of goodwill, we''d like to offer you [OFFER] (partial refund / store credit / discount on next order).

Please let us know how you''d like us to proceed, or if there''s anything else we can do to improve your experience.

Thank you for your understanding and for choosing us.

Best regards,
[SELLER_NAME]
[FBA STORE NAME]',
'Send within 24 hours of delivery. Be sincere, not defensive');

-- 2.2 Missing Package - Investigation Started
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Missing Package - Investigation Started', 'BUYER', 'MISSING_PACKAGE',
'Investigating Your Missing Package - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Thank you for reaching out about your missing package. We take this seriously and have started an immediate investigation.

Order Details:
- Order ID: [ORDER_ID]
- Tracking Number: [TRACKING_NUMBER]
- Carrier: [CARRIER]

What We''re Doing:
1. Contacted the carrier to trace the package
2. Filed a claim with the carrier if applicable
3. Checking with our fulfillment center

This typically takes 3-5 business days. We''ll keep you updated on our findings.

In the meantime, please let us know if the package shows up.

Thank you for your patience.

Best regards,
[SELLER_NAME]',
'File carrier claim same day. Give realistic timeline. Don''t refund until resolved');

-- 2.3 Missing Package - Replacement Offer
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Missing Package - Replacement Offer', 'BUYER', 'MISSING_PACKAGE',
'Your Replacement is on the Way - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Based on our investigation and the carrier''s confirmation that the package was lost, we are sending you a replacement immediately.

Replacement Order:
- New Order ID: [NEW_ORDER_ID]
- Estimated Delivery: [DATE]
- Tracking: [TRACKING]

You will not be charged for the replacement. Your original payment will be refunded once the carrier confirms the loss.

If the original package shows up, please let us know and you may keep it with our compliments.

Thank you for your patience and understanding.

Best regards,
[SELLER_NAME]',
'Send replacement same-day when confirmed lost. Consider customerLifetime value');

-- 2.4 Missing Package - Refund Offer
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Missing Package - Refund Offer', 'BUYER', 'MISSING_PACKAGE',
'Your Refund is Being Processed - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Thank you for your patience during our investigation. The carrier has confirmed the package was lost in transit.

Your Refund:
- Order ID: [ORDER_ID]
- Refund Amount: $[AMOUNT]
- Processing Time: 5-10 business days

The refund will be credited to your original payment method. You should see it within your next billing cycle.

We understand this experience was frustrating. As a gesture of goodwill, we''d like to offer you [OFFER] on your next order.

Thank you for your understanding.

Best regards,
[SELLER_NAME]',
'Offer discount on next order to retain customer. Process refund promptly');

-- 2.5 Package Marked Delivered But Buyer Says Not Received
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Delivered But Not Received', 'BUYER', 'DELIVERY_ISSUE',
'Package Marked Delivered - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Thank you for reaching out. We see the tracking shows the package as delivered, and we understand this is frustrating.

Here''s what we recommend:

1. Check with household members or neighbors
2. Look around the delivery location (porch, garage, etc.)
3. Check with your local post office/carrier

If after 48 hours you still haven''t received it, please let us know and we will:

- File a trace with the carrier
- Provide a replacement or full refund

We take this seriously and want to make sure you receive your order or get your money back.

Thank you for your patience.

Best regards,
[SELLER_NAME]',
'Don''t immediately refund. Give customer chance to find package');

-- 2.6 Wrong Item Sent - Apology + Resolution
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Wrong Item Sent - Apology', 'BUYER', 'WRONG_ITEM',
'We Sent the Wrong Item - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

We sincerely apologize for sending you the wrong item. This is not the experience we want for our customers.

What Happened:
- You received: [WRONG_ITEM]
- You ordered: [CORRECT_ITEM]

Here''s What We''ll Do:

1. You may keep the wrong item with our compliments
2. We are shipping the correct item today at no extra cost
3. We''ll provide a prepaid return label if you wish to return the wrong item

Correct Item Details:
- Tracking: [TRACKING]
- Estimated Delivery: [DATE]

Again, we''re very sorry for this error. Please let us know if you have any questions.

Best regards,
[SELLER_NAME]',
'Let them keep wrong item (write-off). Send correct item immediately');

-- 2.7 Damaged Item Received - Apology + Resolution
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Damaged Item Received', 'BUYER', 'DAMAGED_ITEM',
'Replacing Your Damaged Item - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

We were sorry to hear your item arrived damaged. This should never happen, and we''re very sorry for the inconvenience.

What We''re Doing:

1. A replacement is being shipped today via expedited shipping
2. You do not need to return the damaged item (it''s yours to keep)
3. We''ve registered a complaint with our fulfillment team to prevent this in the future

Replacement Details:
- New Tracking: [TRACKING]
- Estimated Delivery: [DATE]

Please dispose of or keep the damaged item at your discretion - no return needed.

We value your business and hope this experience doesn''t deter you from future purchases.

Best regards,
[SELLER_NAME]',
'No return needed for damaged items. Send replacement fast. Compensate for inconvenience');

-- 2.8 Defective Product - Troubleshooting First Response
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Defective Product - Troubleshooting', 'BUYER', 'DEFECTIVE',
'We Can Help - Troubleshooting Your Product - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Thank you for contacting us about your product issue. We want to help resolve this as quickly as possible.

Before we proceed with a replacement or refund, may we walk you through some quick troubleshooting steps?

Common Issues and Solutions:

[ISSUE_1]: [SOLUTION_1]
[ISSUE_2]: [SOLUTION_2]
[ISSUE_3]: [SOLUTION_3]

Please try these and let us know if they resolve the issue.

If troubleshooting doesn''t help, we''ll immediately ship a replacement or process a full refund - your choice.

Thank you for giving us a chance to help.

Best regards,
[SELLER_NAME]',
'Troubleshooting saves returns. Be patient and thorough. Don''t skip this step');

-- 2.9 Defective Product - Replacement After Troubleshooting
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Defective Product - Replacement Shipped', 'BUYER', 'DEFECTIVE',
'Your Replacement is on the Way - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Thank you for trying the troubleshooting steps. Since the issue couldn''t be resolved, we''re shipping a replacement right away.

Replacement Details:
- Order ID: [NEW_ORDER_ID]
- Tracking: [TRACKING]
- Estimated Delivery: [DATE]

You don''t need to return the defective item - please dispose of it or keep it as-is.

We apologize for the inconvenience and thank you for your patience.

If you have any issues with the replacement, please don''t hesitate to reach out.

Best regards,
[SELLER_NAME]',
'Process replacement same-day. Consider upgrading shipping as apology');

-- 2.10 Product Question - Technical Specs
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Product Question - Technical Specs', 'BUYER', 'PRODUCT_QUESTION',
'Your Question About [PRODUCT_NAME]',
'Dear [CUSTOMER_NAME],

Thank you for your interest in our product. Happy to help with your question!

Your Question: [QUESTION]

Answer:
[DETAILED_ANSWER]

Additional Specifications:
[SPEC_1]: [VALUE_1]
[SPEC_2]: [VALUE_2]
[SPEC_3]: [VALUE_3]

If you have any other questions, please don''t hesitate to ask.

Thank you,
[SELLER_NAME]',
'Be thorough and helpful. This builds trust and improves conversion');

-- 2.11 Product Question - Compatibility
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Product Question - Compatibility', 'BUYER', 'PRODUCT_QUESTION',
'Compatibility Question - [PRODUCT_NAME]',
'Dear [CUSTOMER_NAME],

Thanks for your question about compatibility!

Your Question: Will this work with [CUSTOMER_DEVICE]?

Answer:
[YES_NO] - This product is compatible with [DEVICE_LIST]

Important Notes:
- [COMPATIBILITY_NOTE_1]
- [COMPATIBILITY_NOTE_2]

Please confirm your specific model number if you''re unsure, and we''ll verify the match.

Thank you,
[SELLER_NAME]',
'Ask for model number if not provided. Better safe than sorry');

-- 2.12 Product Question - Usage / How-To
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Product Question - Usage', 'BUYER', 'PRODUCT_QUESTION',
'How to Use Your [PRODUCT_NAME]',
'Dear [CUSTOMER_NAME],

Great question! Here''s how to get the most out of your product:

Getting Started:
1. [STEP_1]
2. [STEP_2]
3. [STEP_3]

Tips for Best Results:
- [TIP_1]
- [TIP_2]

Common Questions:
Q: [QUESTION_1]
A: [ANSWER_1]

Q: [QUESTION_2]
A: [ANSWER_2]

Please reach out if you need any clarification!

Best regards,
[SELLER_NAME]',
'Be comprehensive. Include setup tips, FAQs. This reduces returns');

-- 2.13 Return Request - Acknowledge and Guide
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Return Request - Acknowledge', 'BUYER', 'RETURN',
'Your Return Request - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Thank you for contacting us about returning your purchase. We''ve received your request and here''s what you need to know:

Return Details:
- Order ID: [ORDER_ID]
- Item: [PRODUCT_NAME]
- Return Window: [DAYS_REMAINING] days remaining

How to Return:
1. Go to [RETURN_PORTAL_URL]
2. Print the prepaid label
3. Pack the item securely
4. Drop off at [CARRIER_LOCATION]

Refund Timeline:
Once we receive the item, refunds typically process within 5-7 business days.

Please let us know if you have any questions.

Thank you,
[SELLER_NAME]',
'Provide clear instructions. Include prepaid label. Be helpful, not passive-aggressive');

-- 2.14 Return Request - Outside Return Window (Goodwill Offer)
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Return Outside Window - Goodwill', 'BUYER', 'RETURN',
'Goodwill Return Offer - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Thank you for reaching out. We see your return request is just outside our standard return window, but we want to take care of you.

We''re offering a one-time goodwill return:
- You may return the item for a full refund
- We''ll provide a prepaid return label
- No restocking fee

Note: This is a one-time exception. Future returns must be within our standard window.

We appreciate your understanding and continued business.

Please let us know if you''d like to proceed with the return.

Best regards,
[SELLER_NAME]',
'Use judgment based on customer history. Sometimes it''s worth the goodwill');

-- 2.15 Negative Feedback Request for Removal
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Request Feedback Removal', 'BUYER', 'FEEDBACK',
'Could We Request a Favor? - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Thank you for your purchase. We noticed you left feedback that wasn''t entirely positive, and we completely understand your concern.

We want to make things right. Could you please consider revising your feedback?

Here''s what we can do:
- [SPECIFIC_RESOLUTION]

Your satisfaction is extremely important to us, and we''d love the chance to improve your experience.

Please contact us directly so we can resolve this for you. We''re ready to help.

Thank you for your time,
[SELLER_NAME]',
'DO NOT sound demanding. Offer resolution first, THEN ask. Don''t mention Amazon policies');

-- 2.16 Negative Review Response (Public Reply)
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Negative Review Response', 'BUYER', 'REVIEW_RESPONSE',
'Public Reply to Your Review - [PRODUCT_NAME]',
'Dear [CUSTOMER_NAME],

Thank you for your honest feedback. We''re sorry this product didn''t meet your expectations.

We want to make this right. Please contact us directly at [EMAIL] so we can:
- Understand your specific issue
- Provide a solution (replacement or refund)
- Ensure this doesn''t happen again

We take all feedback seriously and are working to improve.

Thank you,
[SELLER_NAME]',
'Be apologetic but brief. Take it offline for resolution. Don''t be defensive');

-- 2.17 FBA Order Refund Issued - Confirmation
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Refund Confirmation', 'BUYER', 'REFUND',
'Your Refund is Confirmed - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

Your refund has been processed!

Refund Details:
- Order ID: [ORDER_ID]
- Refund Amount: $[AMOUNT]
- Payment Method: [METHOD]
- Processing Time: 5-10 business days

You should see the refund in your account within your next billing cycle.

If you have any questions, please don''t hesitate to reach out.

Thank you for shopping with us.

Best regards,
[SELLER_NAME]',
'Send confirmation immediately. Set accurate expectations');

-- 2.18 Order Cancelled by Amazon - Buyer Notification
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Order Cancelled by Amazon', 'BUYER', 'CANCELLATION',
'Your Order Has Been Cancelled - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

We''re reaching out to let you know your order has been cancelled.

Order Details:
- Order ID: [ORDER_ID]
- Item: [PRODUCT_NAME]
- Amount Refunded: $[AMOUNT]

Reason: [REASON]

Your refund will be processed within 5-10 business days. You should see it in your account within your next billing cycle.

We apologize for any inconvenience. If you still need this item, you''re welcome to reorder when it becomes available.

Thank you for your understanding.

Best regards,
[SELLER_NAME]',
'Be apologetic. Don''t blame Amazon. Offer to help reorder');

-- 2.19 Customs Delay Notice (International Orders)
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Customs Delay Notice', 'BUYER', 'INTERNATIONAL',
'Customs Update - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

We''re contacting you about your international order which may be delayed at customs.

Order Details:
- Order ID: [ORDER_ID]
- Destination: [COUNTRY]

What May Be Happening:
- Customs inspection (routine)
- Documentation review
- Duty/tax processing

What You Can Do:
- Contact your local customs office with tracking: [TRACKING]
- Be prepared to provide identification if requested
- Check if any duties or taxes are owed

We apologize for any delay. Once it clears customs, delivery should proceed normally.

Please let us know if you have questions.

Best regards,
[SELLER_NAME]',
'Stay neutral on customs. Don''t blame anyone. Provide tracking');

-- 2.20 Proactive Delivery Delay Warning
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Proactive Delay Warning', 'BUYER', 'DELAY_WARNING',
'Delivery Update - Order [ORDER_ID]',
'Dear [CUSTOMER_NAME],

We wanted to let you know about a potential delay with your order.

Order Details:
- Order ID: [ORDER_ID]
- Original Expected Delivery: [ORIGINAL_DATE]
- New Expected Delivery: [NEW_DATE]

Reason for Delay:
[REASON]

We''re working hard to get your order to you as quickly as possible. We apologize for any inconvenience.

As a thank you for your patience, we''d like to offer [OFFER].

Thank you for your understanding.

Best regards,
[SELLER_NAME]',
'Send BEFORE the original delivery date. Offer compensation proactively');

PRINT 'Category 2 (Buyer/Customer) templates inserted successfully.';