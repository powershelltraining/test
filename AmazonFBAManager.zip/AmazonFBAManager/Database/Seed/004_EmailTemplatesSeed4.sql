-- ============================================================================
-- Email Templates Seed Data - Part 4
-- CATEGORY 4: INTERNAL OPERATIONS EMAILS (4.1 - 4.6)
-- ============================================================================

SET NOCOUNT ON;

-- ============================================================================
-- CATEGORY 4: INTERNAL OPERATIONS EMAILS
-- ============================================================================

-- 4.1 Daily Morning Briefing Template for VA
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Daily Morning Briefing - VA', 'OPERATIONS', 'DAILY',
'Daily Tasks - [DATE] - [ACCOUNT_NAME]',
'Hi [VA_NAME],

Here are your tasks for today:

==========================================
PRIORITY TASKS
==========================================
1. [TASK_1] - Est. Time: [TIME]
   - Where to find: [LOCATION]
   - How to complete: [INSTRUCTIONS]

2. [TASK_2] - Est. Time: [TIME]
   - Where to find: [LOCATION]
   - How to complete: [INSTRUCTIONS]

3. [TASK_3] - Est. Time: [TIME]
   - Where to find: [LOCATION]
   - How to complete: [INSTRUCTIONS]

==========================================
DOWNLOADS NEEDED TODAY
==========================================
- [REPORT_1] from Seller Central
- [REPORT_2] from Seller Central

==========================================
UPLOADS NEEDED TODAY
==========================================
- [UPLOAD_1] to the app
- [UPLOAD_2] to the app

==========================================
REPORT BACK
==========================================
Please report back by [TIME] with:
- What you completed
- Any issues found
- Questions

Thank you!
[MANAGER_NAME]',
'Keep it specific. Include links and exact instructions. Be realistic on time estimates');

-- 4.2 Weekly Reimbursement Audit Assignment to VA
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Weekly Reimbursement Audit Assignment', 'OPERATIONS', 'WEEKLY',
'Weekly Reimbursement Audit - [ACCOUNT] - Week of [DATE]',
'Hi [VA_NAME],

It''s time for the weekly reimbursement audit. Here''s your assignment:

==========================================
SCOPE
==========================================
Account: [ACCOUNT_NAME]
Date Range: [DATE_FROM] to [DATE_TO]
Reports to Review:
- Inventory Adjustments Report
- Reimbursements Report
- Returns Report

==========================================
TASKS
==========================================
1. Run the Reimbursement Audit in our app
   - Go to: [MENU_PATH]
   - Date range: [DATES]

2. Flag any unclaimed reimbursements:
   - Lost inventory not reimbursed
   - Damaged inventory not reimbursed
   - Returnless refunds not reimbursed
   - Fee overcharges

3. Create cases for any claims worth pursuing:
   - Minimum claim: $[MIN_AMOUNT]
   - Use the app to create cases
   - Attach relevant reports

4. Update the reimbursement tracker spreadsheet

==========================================
REPORTING
==========================================
Complete by: [DUE_DATE]
Report to: [REPORT_TO]
Format: [FORMAT]

==========================================
QUESTIONS?
==========================================
Contact: [CONTACT]
Documentation: [DOC_LINK]

Thank you!
[MANAGER_NAME]',
'Be specific about claim minimums. Provide exact menu paths');

-- 4.3 New Case Assignment to VA
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('New Case Assignment', 'OPERATIONS', 'CASE_ASSIGNMENT',
'New Case Assignment - [CASE_TYPE] - [ACCOUNT]',
'Hi [VA_NAME],

You have a new case assignment:

==========================================
CASE DETAILS
==========================================
- Case Type: [CASE_TYPE]
- Account: [ACCOUNT_NAME]
- Priority: [PRIORITY]
- Due Date: [DUE_DATE]

==========================================
WHAT TO DO
==========================================
1. Review case details in the app
   - Case ID: [CASE_ID]
   - Link: [CASE_LINK]

2. Gather required information:
   - [INFO_1]
   - [INFO_2]
   - [INFO_3]

3. Research the issue:
   - [RESEARCH_STEPS]

4. Draft initial response/claim
   - Use template: [TEMPLATE_NAME]

5. Update case with findings

==========================================
REFERENCE
==========================================
- Template: [TEMPLATE_LINK]
- Past similar cases: [CASE_REFERENCES]
- Amazon policy: [POLICY_LINK]

==========================================
REPORT BACK
==========================================
- When: [REPORT_DATE]
- Format: [FORMAT]
- Include: [DELIVERABLES]

Thank you!
[MANAGER_NAME]',
'Provide all context. Link to templates and references');

-- 4.4 Escalation Notification to Account Manager
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Escalation Notification', 'OPERATIONS', 'ESCALATION',
'URGENT: Case Escalation - [CASE_ID] - [ACCOUNT]',
'Hi [MANAGER_NAME],

A case has been escalated and requires your attention.

==========================================
CASE SUMMARY
==========================================
- Case ID: [CASE_ID]
- Type: [CASE_TYPE]
- Account: [ACCOUNT_NAME]
- Days Open: [DAYS]
- Amount at Risk: $[AMOUNT]
- Current Status: [STATUS]

==========================================
WHY ESCALATED
==========================================
[REASON_FOR_ESCALATION]

==========================================
WHAT''S BEEN TRIED
==========================================
[PREVIOUS_ACTIONS]

==========================================
WHAT''S NEEDED
==========================================
[REQUIRED_ACTION]

==========================================
DEADLINE
==========================================
Response needed by: [DEADLINE]

Please review the case in the app and take appropriate action.

Thank you!
[ESCALATING_PERSON]',
'Be clear on deadline and required action. Don''t bury the lead');

-- 4.5 Monthly FBA Performance Report to Client
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Monthly Performance Report', 'OPERATIONS', 'MONTHLY_REPORT',
'[MONTH] FBA Performance Report - [ACCOUNT]',
'Hi [CLIENT_NAME],

Here''s your monthly performance report for [MONTH]:

==========================================
EXECUTIVE SUMMARY
==========================================
- Revenue: $[REVENUE] ([CHANGE]% vs last month)
- Units Sold: [UNITS] ([CHANGE]%)
- Net Profit: $[PROFIT] ([CHANGE]%)
- Refund Rate: [REFUND_RATE]%

==========================================
KEY METRICS
==========================================
- New Products Added: [NEW_PRODUCTS]
- Cases Opened: [CASES_OPENED]
- Cases Resolved: [CASES_RESOLVED]
- Reimbursements Recovered: $[REIMBURSEMENTS]

==========================================
INVENTORY HEALTH
==========================================
- Low Stock SKUs: [LOW_STOCK]
- Overstock SKUs: [OVERSTOCK]
- Stranded Units: [STRANDED]
- Aged Inventory Value: $[AGED_VALUE]

==========================================
ALERTS
==========================================
[ALERTS_SUMMARY]

==========================================
RECOMMENDATIONS
==========================================
1. [RECOMMENDATION_1]
2. [RECOMMENDATION_2]
3. [RECOMMENDATION_3]

==========================================
LOOKING AHEAD
==========================================
[OUTLOOK]

Full report available in the app: [REPORT_LINK]

Questions? Let me know.

Best,
[YOUR_NAME]',
'Make it scannable. Lead with the numbers. Include actionable recommendations');

-- 4.6 Onboarding Email for New VA
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('VA Onboarding Email', 'OPERATIONS', 'ONBOARDING',
'Welcome! Your Onboarding Guide - [START_DATE]',
'Hi [VA_NAME],

Welcome to the team! Here''s everything you need to get started.

==========================================
ACCESS & CREDENTIALS
==========================================
Your login: [EMAIL]
Temporary password: [TEMP_PASSWORD]
App URL: [APP_URL]

Seller Central Access:
- Account: [ACCOUNT_NAME]
- Login: [SC_EMAIL]
- Password: [SC_PASSWORD]

==========================================
DAY 1 TASKS
==========================================
1. Log in and change your password
2. Explore the app - navigate all menus
3. Review these guides:
   - [GUIDE_1]
   - [GUIDE_2]
4. Download today''s reports

==========================================
DAILY ROUTINE
==========================================
Morning:
1. Check alerts in the app
2. Download new reports from Seller Central
3. Upload reports to the app

End of Day:
1. Complete assigned tasks
2. Report back to [MANAGER]
3. Note any issues in the task tracker

==========================================
KEY RULES - READ CAREFULLY
==========================================
DO:
- Ask questions when unsure
- Document everything
- Follow procedures exactly

DO NOT:
- Change COGS without manager approval
- Delete any imported data
- Close cases without approval
- Make decisions about claims above $[LIMIT]

==========================================
TRAINING
==========================================
Training sessions: [SCHEDULE]
Your trainer: [TRAINER]
Questions: [EMAIL]

==========================================
FIRST WEEK GOALS
==========================================
- [GOAL_1]
- [GOAL_2]
- [GOAL_3]

Let''s have a quick call on [DATE] to answer any questions.

Welcome aboard!
[MANAGER_NAME]',
'Be comprehensive. Review rules clearly. Set expectations for first week');

PRINT 'Category 4 (Internal Operations) templates inserted successfully.';
PRINT 'All 62 email templates completed!';

GO

-- ============================================================================
-- Verify template count
-- ============================================================================
SELECT
    Category,
    SubCategory,
    COUNT(*) AS TemplateCount
FROM dbo.EmailTemplates
GROUP BY Category, SubCategory
ORDER BY Category, SubCategory;

-- Expected:
-- CASE_MANAGEMENT: 21
-- BUYER: 20
-- BRAND: 15
-- OPERATIONS: 6
-- Total: 62