-- ============================================================================
-- Email Templates Seed Data - Part 3
-- CATEGORY 3: BRAND & INTELLECTUAL PROPERTY EMAILS (3.1 - 3.15)
-- CATEGORY 4: INTERNAL OPERATIONS EMAILS (4.1 - 4.6)
-- ============================================================================

SET NOCOUNT ON;

-- ============================================================================
-- CATEGORY 3: BRAND & INTELLECTUAL PROPERTY
-- ============================================================================

-- 3.1 Cease and Desist - Unauthorized Seller
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Cease and Desist - Unauthorized Seller', 'BRAND', 'UNAUTHORIZED_SELLER',
'Cease and Desist: Unauthorized Sale of [BRAND] Products',
'Dear [SELLER_NAME],

We are writing to you as the authorized trademark owner of [BRAND].

We have discovered that you are offering for sale on Amazon.com products bearing our trademark [BRAND] without our authorization.

Listing Details:
- Your ASIN: [YOUR_ASIN]
- Product: [PRODUCT_NAME]
- Your Price: $[PRICE]

This sale is unauthorized for the following reasons:
1. We have not authorized you as a reseller of our products
2. Our authorized reseller network is being harmed
3. Product authenticity cannot be verified

DEMAND:
We demand that you immediately:
1. Remove all [BRAND] listings from your Amazon store
2. Cease any sales of [BRAND] products
3. Confirm compliance within 7 days

If you do not comply, we will pursue all available remedies including:
- Brand Registry complaints
- Legal action for trademark infringement
- Report to Amazon policy enforcement

We reserve all rights to seek damages and injunctive relief.

Sincerely,
[BRAND_OWNER_NAME]
[BRAND_OWNER_CONTACT]',
'Be firm. Use proper legal language. Include trademark registration number if available');

-- 3.2 Cease and Desist - Counterfeit Product
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Cease and Desist - Counterfeit', 'BRAND', 'COUNTERFEIT',
'URGENT: Cease and Desist - Counterfeit [BRAND] Products',
'Dear [SELLER_NAME],

We are the exclusive trademark owner of [BRAND] and have confirmed that you are selling COUNTERFEIT products.

Evidence of Counterfeit:
- [EVIDENCE_1]
- [EVIDENCE_2]
- [EVIDENCE_3]

Genuine products feature:
- [AUTHENTIC_FEATURE_1]
- [AUTHENTIC_FEATURE_2]

DEMAND:
We demand immediate cessation of all sales of [BRAND] products. This is trademark counterfeiting, which is illegal.

We have documented your listings and will:
1. Report to Brand Registry immediately
2. Report to Amazon Legal
3. Pursue legal action including statutory damages

This is your final warning. Remove all listings within 48 hours.

Legal action is already being prepared.

Sincerely,
[BRAND_OWNER_NAME]
[BRAND_OWNER_ATTORNEY]',
'This is serious - counterfeiting is illegal. Use strongest language. Consider attorney involvement');

-- 3.3 Cease and Desist - Logo/Trademark Misuse
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Cease and Desist - Trademark Misuse', 'BRAND', 'TRADEMARK_MISUSE',
'Cease and Desist: Unauthorized Use of [BRAND] Trademark',
'Dear [MANUFACTURER_NAME],

We are the trademark owner of [BRAND].

We have discovered that you are using our registered trademark [BRAND] in your listings on Amazon without authorization.

Violation Details:
- Your Amazon listings using [BRAND]
- Your website: [WEBSITE_URL]

Our trademark registration:
- Registration Number: [REG_NUMBER]
- Registered Marks: [MARKS]

This unauthorized use is causing customer confusion and diluting our brand.

DEMAND:
1. Remove all [BRAND] references from Amazon listings immediately
2. Do not sell our products on Amazon or any unauthorized channel
3. Confirm compliance within 5 days

Failure to comply will result in:
- Trademark infringement lawsuit
- Report to Amazon
- Claims for damages

We prefer to resolve this amicably.

Sincerely,
[BRAND_OWNER_NAME]',
'Send to manufacturer if they''re selling directly. Be firm but professional');

-- 3.4 Cease and Desist - Manufacturer Selling on Amazon
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Cease and Desist - Manufacturer Amazon', 'BRAND', 'MANUFACTURER_VIOLATION',
'Immediate Cease Required: [BRAND] on Amazon',
'Dear [MANUFACTURER_NAME],

We are writing regarding our distribution agreement and your unauthorized activity.

Per our manufacturing/supply agreement, you are prohibited from selling [BRAND] products directly to consumers on Amazon or any e-commerce platform.

Violation:
- Your Amazon storefront: [STORE_URL]
- Products listed: [PRODUCT_LIST]

This violation of our agreement:
1. Undermines our authorized reseller network
2. Violates our distribution terms
3. Creates channel conflict

DEMAND:
Remove all [BRAND] products from Amazon within 48 hours.

If this continues, we will:
- Terminate our supply relationship
- Pursue legal remedies per our agreement
- Report to Amazon

Please confirm compliance.

Sincerely,
[BRAND_OWNER_NAME]',
'Reference your distribution agreement. This is a contract violation, not just IP');

-- 3.5 Distributor Warning - Selling Outside Territory
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Distributor Warning - Territory', 'BRAND', 'DISTRIBUTOR_TERRITORY',
'DISTRIBUTION VIOLATION: Selling Outside Authorized Territory',
'Dear [DISTRIBUTOR_NAME],

This is a formal notice regarding violations of our distribution agreement.

We have evidence that you are selling [BRAND] products into territories outside your authorized region.

Evidence:
- Sales into: [UNAUTHORIZED_TERRITORIES]
- Listings showing ship-to: [EVIDENCE]

This violates Section [X] of our distribution agreement which specifies:
"Your sales territory is limited to [TERRITORY]. Sales outside this territory are prohibited."

Required Actions:
1. Immediately cease all sales outside your authorized territory
2. Remove listings that ship to unauthorized territories
3. Confirm compliance within 5 business days

Failure to comply may result in:
- Termination of distribution agreement
- Loss of authorized dealer status
- Legal action

We value our business relationship and want to resolve this quickly.

Sincerely,
[BRAND_OWNER_NAME]',
'Reference specific agreement terms. Give specific evidence');

-- 3.6 Distributor Warning - Selling Below MAP
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Distributor Warning - MAP Violation', 'BRAND', 'MAP_VIOLATION',
'MAP Pricing Violation - [BRAND] Products',
'Dear [SELLER_NAME],

We are writing regarding your violation of our Minimum Advertised Price (MAP) policy.

Policy Summary:
- Minimum Advertised Price for [PRODUCT]: $[MAP]
- Your Listed Price: $[YOUR_PRICE]

This pricing is below our MAP policy and undermines our brand positioning and reseller relationships.

Required Action:
Adjust your advertised price to $[MAP] or above within 48 hours.

This is a first warning. Continued violations may result in:
- Loss of authorized reseller status
- Product allocation restrictions
- Termination of account

Please confirm compliance.

Sincerely,
[BRAND_OWNER_NAME]',
'Be firm on first warning. Document the violation with screenshots');

-- 3.7 MAP Policy Violation - First Warning
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('MAP Violation - First Warning', 'BRAND', 'MAP_VIOLATION',
'First Notice: MAP Policy Violation - [BRAND]',
'Dear [SELLER_NAME],

This is your FIRST warning regarding violations of our Minimum Advertised Price (MAP) Policy.

Violation Details:
- Product: [PRODUCT]
- MAP Price: $[MAP]
- Your Price: $[YOUR_PRICE]
- Listing URL: [URL]

This is a violation of our MAP agreement.

Required Action:
Adjust your price to $[MAP] or above within 48 hours.

Future violations will result in escalating consequences including loss of authorization.

Please confirm compliance.

Best regards,
[BRAND_OWNER_NAME]',
'Be clear about consequences. Document everything');

-- 3.8 MAP Policy Violation - Second Warning
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('MAP Violation - Second Warning', 'BRAND', 'MAP_VIOLATION',
'SECOND NOTICE: Final MAP Warning - [BRAND]',
'Dear [SELLER_NAME],

This is your SECOND and FINAL warning regarding MAP policy violations.

Violation Details:
- Product: [PRODUCT]
- Your Price: $[YOUR_PRICE]
- MAP: $[MAP]

This is your last chance before we take action.

Required Action:
Adjust your price to $[MAP] or above within 24 hours.

If you fail to comply, we will:
- Terminate your authorized reseller status immediately
- Block future product allocation
- Report to Amazon for policy violations

This is your final opportunity to remain an authorized seller.

Confirm compliance immediately.

Regards,
[BRAND_OWNER_NAME]',
'Be very firm. This is last chance before termination');

-- 3.9 MAP Policy Violation - Final Warning Before Legal Action
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('MAP Violation - Legal Action Warning', 'BRAND', 'MAP_VIOLATION',
'FINAL NOTICE: Legal Action Warning - [BRAND]',
'Dear [SELLER_NAME],

Despite multiple warnings, you continue to violate our MAP policy.

This correspondence serves as FINAL NOTICE before legal action.

Violation (Continuing):
- Product: [PRODUCT]
- Your Price: $[YOUR_PRICE]
- MAP: $[MAP]

We have documented [NUMBER] violations to date.

We are now preparing:
- Termination of all dealer agreements
- Legal action for damages under antitrust and contract law
- Report to Amazon Seller Performance

You have 24 hours to comply. After that, legal action will commence.

We strongly advise immediate compliance.

Regards,
[BRAND_OWNER_NAME]',
'Document thoroughly. Consult attorney about next steps');

-- 3.10 Authorized Reseller Agreement Request
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Authorized Reseller Agreement Request', 'BRAND', 'RESELLER_AGREEMENT',
'Become an Authorized Reseller - [BRAND]',
'Dear [POTENTIAL_RESELLER_NAME],

Thank you for your interest in becoming an authorized reseller of [BRAND].

As an authorized reseller, you will receive:
- Guaranteed product allocation
- Marketing support and resources
- Reseller pricing
- Priority customer service

Requirements:
- [REQUIREMENT_1]
- [REQUIREMENT_2]
- [REQUIREMENT_3]

To proceed, please:
1. Complete our reseller application: [APPLICATION_URL]
2. Provide business documentation
3. Sign our authorized reseller agreement

We look forward to partnering with you.

Best regards,
[BRAND_OWNER_NAME]',
'Provide clear application process. Make it easy to sign up');

-- 3.11 Brand Registry Enrollment Support Request to Manufacturer
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Brand Registry Support Request', 'BRAND', 'BRAND_REGISTRY',
'Brand Registry Support - Documentation Request',
'Dear [MANUFACTURER_CONTACT],

We are in the process of enrolling in Amazon Brand Registry to protect our brand on Amazon.

To complete our application, we need your assistance with the following documentation:

Required Documents:
1. Trademark registration certificate (we have: [TRADEMARK_NUMBER])
2. Authorization letter confirming we are the brand owner
3. Product images showing trademark usage
4. Invoices showing we purchase directly from you

Specifically for Amazon Brand Registry, we need:
- A letter authorizing us to sell [BRAND] products on Amazon
- Documentation showing we are the exclusive brand owner

Can you please provide these documents at your earliest convenience?

This will help us protect against counterfeit and unauthorized sellers.

Thank you for your support.

Best regards,
[BRAND_OWNER_NAME]',
'Be specific about what you need. Offer to draft the authorization letter');

-- 3.12 Supplier Agreement - Adding Amazon Exclusivity Clause
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Supplier Agreement - Amazon Exclusivity', 'BRAND', 'SUPPLIER_AGREEMENT',
'Amendment: Amazon Exclusivity Clause',
'Dear [SUPPLIER_NAME],

We would like to discuss adding an Amazon exclusivity clause to our supply agreement.

Proposed Addition:
"You agree not to supply [PRODUCT] to any other party for resale on Amazon.com or any Amazon marketplace. This restriction applies to direct sales and sales through distributors."

Rationale:
- Protects our brand positioning on Amazon
- Prevents unauthorized sellers from sourcing product
- Maintains our MAP policy effectiveness
- Protects our authorized reseller network

In exchange, we offer:
- [BENEFIT_1]
- [BENEFIT_2]
- [BENEFIT_3]

Please let us know your thoughts on this amendment.

Best regards,
[BRAND_OWNER_NAME]',
'This is sensitive. Be prepared to negotiate. Offer real benefits');

-- 3.13 Hijack Report to Amazon - Buy Box Loss
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Hijack Report to Amazon', 'BRAND', 'HIJACK',
'Buy Box Interference Report - [OUR_ASIN]',
'Dear Amazon Brand Registry,

We are reporting a seller who has taken control of our Buy Box through interference.

Our Product:
- ASIN: [OUR_ASIN]
- Brand: [BRAND]
- Our Seller ID: [OUR_SELLER_ID]

Violating Seller:
- Seller ID: [HIJACKER_SELLER_ID]
- ASIN: [HIJACKER_ASIN]
- Seller Name: [HIJACKER_NAME]

Evidence of Interference:
1. [EVIDENCE_1]
2. [EVIDENCE_2]
3. [EVIDENCE_3]

This seller is not authorized to sell our brand and is likely selling counterfeit products.

We request immediate investigation and removal of this seller.

Thank you,
[BRAND_OWNER_NAME]
[BRAND_REGISTRY_EMAIL]',
'This goes through Brand Registry "Report a Violation" tool. Be specific');

-- 3.14 Test Buy Confirmation (Internal)
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Test Buy Confirmation (Internal)', 'BRAND', 'TEST_BUY',
'Test Buy Completed - [COMPETITOR_ASIN]',
'Internal Team,

Test buy completed for hijack investigation.

Target Seller: [SELLER_NAME]
Target ASIN: [COMPETITOR_ASIN]

Purchase Details:
- Order ID: [ORDER_ID]
- Purchase Date: [DATE]
- Price Paid: $[PRICE]
- Delivery Date: [DELIVERY_DATE]

Product Received:
- Is authentic: [YES_NO]
- Matches our product: [YES_NO]
- Quality: [NOTES]

Photos taken: [NUMBER]
Saved to: [FILE_LOCATION]

Next steps: [ACTION_ITEMS]

This documentation will be used for Brand Registry report.

Team',
'Internal only. Document thoroughly. Take lots of photos');

-- 3.15 Manufacturer Selling Under Different ASIN
INSERT INTO dbo.EmailTemplates (TemplateName, Category, SubCategory, SubjectLine, BodyContent, Tips) VALUES
('Manufacturer Different ASIN', 'BRAND', 'ASIN_MERGE',
'Request to Merge Listings - Same Product, Different ASIN',
'Dear [MANUFACTURER_NAME],

We noticed our product is listed under multiple ASINs on Amazon, including one that appears to be from your company:

- Our ASIN: [OUR_ASIN]
- Your ASIN: [YOUR_ASIN]
- Product: [PRODUCT_NAME]

This creates customer confusion and splits our reviews/sales.

Request:
We would like to merge these listings under our ASIN ([OUR_ASIN]) so customers see one unified listing with all reviews.

This benefits both of us by:
- Consolidating reviews
- Improving Buy Box share
- Reducing customer confusion

Can we work together to resolve this?

Best regards,
[BRAND_OWNER_NAME]',
'Be collaborative. Explain mutual benefit');

PRINT 'Category 3 (Brand & IP) templates inserted successfully.';