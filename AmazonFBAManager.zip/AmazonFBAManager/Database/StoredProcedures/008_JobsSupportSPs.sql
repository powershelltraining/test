-- Additional Stored Procedures for Jobs and Dashboard
-- These SPs are called from C# but were missing from the initial schema

-- =============================================
-- sp_Dashboard_GetSummary
-- Returns dashboard summary metrics for a seller account
-- =============================================
CREATE PROCEDURE dbo.sp_Dashboard_GetSummary
    @SellerAccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        -- Active Listings Count
        (SELECT COUNT(*) FROM Products
         WHERE SellerAccountId = @SellerAccountId AND IsActive = 1) AS ActiveListings,

        -- Open Cases Count
        (SELECT COUNT(*) FROM Cases
         WHERE SellerAccountId = @SellerAccountId
         AND Status IN ('Open', 'In Progress')) AS OpenCases,

        -- Pending Reimbursements
        (SELECT ISNULL(SUM(ClaimableAmount), 0) FROM ReimbursementAudit
         WHERE SellerAccountId = @SellerAccountId AND Status = 'Pending') AS PendingReimbursements,

        -- Total Sales (30 days)
        (SELECT ISNULL(SUM(TotalAmount), 0) FROM SalesOrders
         WHERE SellerAccountId = @SellerAccountId
         AND OrderDate >= DATEADD(DAY, -30, GETDATE())) AS TotalSales30d,

        -- Low Stock Alerts
        (SELECT COUNT(*) FROM Products
         WHERE SellerAccountId = @SellerAccountId
         AND CurrentStock <= ReorderPoint
         AND ReorderPoint > 0) AS LowStockAlerts,

        -- Aged Inventory Count
        (SELECT COUNT(*) FROM InventorySnapshots
         WHERE SellerAccountId = @SellerAccountId
         AND DaysInStock >= 90) AS AgedInventoryCount;

END;
GO

-- =============================================
-- sp_Reimbursement_IdentifyMissingCOGS
-- Identifies products missing COGS data for 2025 reimbursement policy
-- =============================================
CREATE PROCEDURE dbo.sp_Reimbursement_IdentifyMissingCOGS
    @SellerAccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ProductId,
        p.SKU,
        p.ProductName,
        p.ASIN,
        p.COGS,
        CASE WHEN p.COGS IS NULL OR p.COGS = 0 THEN 1 ELSE 0 END AS IsMissingCOGS,
        CASE
            WHEN p.COGS IS NULL OR p.COGS = 0 THEN 'No COGS entered'
            ELSE 'COGS entered'
        END AS Status,
        GETDATE() AS AuditDate
    FROM Products p
    WHERE p.SellerAccountId = @SellerAccountId
      AND p.IsActive = 1
      AND (p.COGS IS NULL OR p.COGS = 0)
    ORDER BY p.ProductName;

END;
GO

-- =============================================
-- Wrapper SPs for Jobs (matching underscore naming)
-- =============================================
CREATE PROCEDURE dbo.sp_Reimbursement_AuditLostDamaged
    @SellerAccountId INT,
    @DateFrom DATETIME,
    @DateTo DATETIME
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.usp_Reimbursement_AuditLostDamagedInventory @SellerAccountId, @DateFrom, @DateTo;
END;
GO

CREATE PROCEDURE dbo.sp_Reimbursement_AuditReturnless
    @SellerAccountId INT,
    @DateFrom DATETIME,
    @DateTo DATETIME
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.usp_Reimbursement_AuditReturnlessRefunds @SellerAccountId, @DateFrom, @DateTo;
END;
GO

CREATE PROCEDURE dbo.sp_Reimbursement_AuditFeeOvercharges
    @SellerAccountId INT,
    @DateFrom DATETIME,
    @DateTo DATETIME
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.usp_Reimbursement_DetectFeeOvercharges @SellerAccountId, @DateFrom, @DateTo;
END;
GO

PRINT 'Jobs support SPs created successfully';
GO