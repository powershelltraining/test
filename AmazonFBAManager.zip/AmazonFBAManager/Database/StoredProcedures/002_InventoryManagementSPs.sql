-- ============================================================================
-- Inventory Management Stored Procedures
-- ============================================================================

-- Reorder Point Calculation (EOQ + Safety Stock)
CREATE PROCEDURE dbo.usp_Inventory_GetReorderSuggestions
    @SellerAccountId INT,
    @LeadTimeDays INT = 30,
    @ServiceLevel DECIMAL(5,2) = 0.95
AS
BEGIN
    SET NOCOUNT ON;

    -- Calculate daily sales velocity and reorder points for each product
    WITH DailySales AS (
        SELECT
            soi.ProductId,
            AVG(CAST(soi.QtySold AS DECIMAL(10,2))) / 30 AS DailyAvgSales,
            MAX(soi.QtySold) AS MaxDailySales,
            STDEV(soi.QtySold) AS SalesStdDev
        FROM dbo.SalesOrderItems soi
        JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
        WHERE so.SellerAccountId = @SellerAccountId
            AND so.OrderDate >= DATEADD(DAY, -90, CAST(SYSDATETIME() AS DATE))
            AND so.OrderStatus IN ('Shipped', 'Delivered')
        GROUP BY soi.ProductId
    ),
    CurrentInventory AS (
        SELECT
            ProductId,
            SUM(QtyFBA) AS TotalFBA,
            SUM(QtyInbound) AS TotalInbound
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId
            AND SnapshotDate = CAST(SYSDATETIME() AS DATE)
        GROUP BY ProductId
    ),
    ReorderCalc AS (
        SELECT
            p.ProductId,
            p.SKU,
            p.FNSKU,
            p.ProductTitle,
            p.ReorderPoint AS ConfiguredReorderPoint,
            p.ReorderQty AS ConfiguredReorderQty,
            p.LeadTimeDays,
            ISNULL(ds.DailyAvgSales, 0) AS DailySalesVelocity,
            ISNULL(ds.SalesStdDev, 0) AS SalesStdDev,
            ISNULL(ci.TotalFBA, 0) AS CurrentFBAQty,
            ISNULL(ci.TotalInbound, 0) AS InboundQty,
            -- Safety stock: z-score * std dev * sqrt(lead time)
            CASE
                WHEN @ServiceLevel = 0.95 THEN 1.645
                WHEN @ServiceLevel = 0.90 THEN 1.28
                WHEN @ServiceLevel = 0.99 THEN 2.33
                ELSE 1.645
            END * ISNULL(ds.SalesStdDev, 0) * SQRT(CAST(p.LeadTimeDays AS DECIMAL(10,2))) AS SafetyStock,
            -- Reorder point = (daily avg * lead time) + safety stock
            (ISNULL(ds.DailyAvgSales, 0) * p.LeadTimeDays) +
            (CASE
                WHEN @ServiceLevel = 0.95 THEN 1.645
                WHEN @ServiceLevel = 0.90 THEN 1.28
                WHEN @ServiceLevel = 0.99 THEN 2.33
                ELSE 1.645
            END * ISNULL(ds.SalesStdDev, 0) * SQRT(CAST(p.LeadTimeDays AS DECIMAL(10,2)))) AS CalculatedReorderPoint,
            -- Days of supply
            CASE
                WHEN ISNULL(ds.DailyAvgSales, 0) > 0 THEN
                    (ISNULL(ci.TotalFBA, 0) + ISNULL(ci.TotalInbound, 0)) / ISNULL(ds.DailyAvgSales, 0)
                ELSE 999
            END AS DaysOfSupply
        FROM dbo.Products p
        LEFT JOIN DailySales ds ON p.ProductId = ds.ProductId
        LEFT JOIN CurrentInventory ci ON p.ProductId = ci.ProductId
        WHERE p.SellerAccountId = @SellerAccountId AND p.IsActive = 1
    )
    SELECT
        SKU,
        FNSKU,
        ProductTitle,
        CurrentFBAQty,
        InboundQty,
        DailySalesVelocity,
        ROUND(DailySalesVelocity, 2) AS DailySalesVelocityRounded,
        CAST(SafetyStock AS INT) AS SafetyStock,
        CAST(CalculatedReorderPoint AS INT) AS ReorderPoint,
        CASE
            WHEN CurrentFBAQty < CalculatedReorderPoint THEN 'Order Now'
            WHEN DaysOfSupply < @LeadTimeDays THEN 'Order Soon'
            ELSE 'OK'
        END AS UrgencyStatus,
        ROUND(DaysOfSupply, 1) AS DaysOfSupply,
        -- Suggested order quantity: EOQ = sqrt(2 * D * S / H)
        -- D = annual demand, S = ordering cost (assume $50), H = holding cost (assume 25% of COGS)
        CASE
            WHEN p.COGS > 0 THEN
                CAST(CEILING(SQRT(2 * DailySalesVelocity * 365 * 50.0 / (p.COGS * 0.25))) AS INT)
            ELSE p.ReorderQty
        END AS SuggestedOrderQty,
        CASE
            WHEN CurrentFBAQty < CalculatedReorderPoint THEN 100
            WHEN DaysOfSupply < @LeadTimeDays THEN 50
            ELSE 0
        END AS UrgencyScore
    FROM ReorderCalc p
    WHERE CurrentFBAQty < ISNULL(p.ConfiguredReorderPoint, CalculatedReorderPoint)
       OR DaysOfSupply < @LeadTimeDays
    ORDER BY UrgencyScore DESC, DaysOfSupply ASC;
END
GO

-- Overstock Diagnosis
CREATE PROCEDURE dbo.usp_Inventory_GetOverstockReport
    @SellerAccountId INT,
    @DaysOfSupplyThreshold INT = 365
AS
BEGIN
    SET NOCOUNT ON;

    WITH CurrentInventory AS (
        SELECT
            ProductId,
            SUM(QtyFBA) AS TotalFBA
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId
            AND SnapshotDate = CAST(SYSDATETIME() AS DATE)
        GROUP BY ProductId
    ),
    Sales90Days AS (
        SELECT
            soi.ProductId,
            SUM(soi.QtySold) AS QtySold90Days,
            SUM(soi.ItemPrice * soi.QtySold) AS Revenue90Days,
            AVG(CAST(soi.QtySold AS DECIMAL(10,2))) / 30 AS DailyAvgSales
        FROM dbo.SalesOrderItems soi
        JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
        WHERE so.SellerAccountId = @SellerAccountId
            AND so.OrderDate >= DATEADD(DAY, -90, CAST(SYSDATETIME() AS DATE))
        GROUP BY soi.ProductId
    )
    SELECT
        p.SKU,
        p.FNSKU,
        p.ProductTitle,
        p.COGS,
        ISNULL(ci.TotalFBA, 0) AS QtyOnHand,
        ROUND(ISNULL(s.DailyAvgSales, 0), 2) AS DailySalesVelocity,
        CASE
            WHEN ISNULL(s.DailyAvgSales, 0) > 0 THEN
                ISNULL(ci.TotalFBA, 0) / ISNULL(s.DailyAvgSales, 0)
            ELSE 999
        END AS DaysOfSupply,
        -- Est. storage cost: $0.75/cubic foot/month base + long-term fees
        CASE
            WHEN (p.Length * p.Width * p.Height) > 0 THEN
                (p.Length * p.Width * p.Height) / 1728.0 * 0.75 * ISNULL(ci.TotalFBA, 0)
            ELSE 0
        END +
        CASE
            WHEN (SELECT DaysOfSupply) > 365 THEN p.COGS * 1.5 * ISNULL(ci.TotalFBA, 0)
            WHEN (SELECT DaysOfSupply) > 270 THEN p.COGS * 1.0 * ISNULL(ci.TotalFBA, 0)
            WHEN (SELECT DaysOfSupply) > 180 THEN p.COGS * 0.5 * ISNULL(ci.TotalFBA, 0)
            ELSE 0
        END AS EstStorageCost90days,
        -- Liquidation savings: assume 70% of COGS recovery vs. 90-day storage
        CASE
            WHEN (SELECT DaysOfSupply) > 365 THEN
                (p.COGS * 0.3 * ISNULL(ci.TotalFBA, 0)) -
                ((p.Length * p.Width * p.Height) / 1728.0 * 0.75 * ISNULL(ci.TotalFBA, 0) * 3)
            ELSE 0
        END AS LiquidationSavings,
        CASE
            WHEN (SELECT DaysOfSupply) > 365 THEN 'Remove Now'
            WHEN (SELECT DaysOfSupply) > 270 THEN 'Consider Removal'
            WHEN (SELECT DaysOfSupply) > 180 THEN 'Monitor'
            ELSE 'OK'
        END AS Recommendation,
        CASE
            WHEN (SELECT DaysOfSupply) > 365 THEN p.COGS * 0.70 * ISNULL(ci.TotalFBA, 0)
            ELSE 0
        END AS LiquidationRecovery
    FROM dbo.Products p
    JOIN CurrentInventory ci ON p.ProductId = ci.ProductId
    LEFT JOIN Sales90Days s ON p.ProductId = s.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
        AND p.IsActive = 1
        AND ci.TotalFBA > 0
        AND (
            s.DailyAvgSales IS NULL
            OR s.DailyAvgSales = 0
            OR (ci.TotalFBA / s.DailyAvgSales) >= @DaysOfSupplyThreshold
        )
    ORDER BY DaysOfSupply DESC;
END
GO

-- IPI Score Improvement
CREATE PROCEDURE dbo.usp_Inventory_GetIPIImprovementActions
    @SellerAccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CurrentIPI DECIMAL(5,2);
    DECLARE @TargetIPI DECIMAL(5,2) = 550;

    -- Get current IPI score
    SELECT TOP 1 @CurrentIPI = IPI_Score
    FROM dbo.InventorySnapshots
    WHERE SellerAccountId = @SellerAccountId
    ORDER BY SnapshotDate DESC;

    -- If no IPI score, return empty
    IF @CurrentIPI IS NULL
    BEGIN
        SELECT 'No IPI data available' AS Message;
        RETURN;
    END

    -- Return improvement actions based on IPI gaps
    SELECT
        'IPI Score Improvement' AS Category,
        CASE
            WHEN @CurrentIPI < 400 THEN 'CRITICAL'
            WHEN @CurrentIPI < 500 THEN 'HIGH'
            WHEN @CurrentIPI < 550 THEN 'MEDIUM'
            ELSE 'LOW'
        END AS Priority,
        @CurrentIPI AS CurrentScore,
        @TargetIPI AS TargetScore,
        @TargetIPI - @CurrentIPI AS GapToClose,
        CASE
            WHEN @CurrentIPI < 400 THEN
                'Your IPI score is critically low. Immediate action required to avoid storage restrictions.'
            WHEN @CurrentIPI < 500 THEN
                'Your IPI score needs improvement. Focus on stranded inventory and aged inventory removal.'
            WHEN @CurrentIPI < 550 THEN
                'Almost there! Focus on excess inventory reduction to reach target.'
            ELSE
                'Great job! Maintain your IPI score by monitoring inventory health.'
        END AS ActionDescription;

    -- Return stranded inventory impact
    SELECT
        'Stranded Inventory' AS ActionType,
        COUNT(*) AS AffectedSKUs,
        SUM(CAST(QtyFBA AS INT)) AS TotalUnits,
        CASE
            WHEN COUNT(*) > 0 THEN 'Fix stranded listings immediately to recover sales and improve IPI'
            ELSE 'No stranded inventory - great job!'
        END AS Description,
        CASE WHEN COUNT(*) > 0 THEN 'HIGH' ELSE 'NONE' END AS ImpactOnIPI
    FROM dbo.Products p
    LEFT JOIN (
        SELECT ProductId, SUM(QtyFBA) AS QtyFBA
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId
            AND SnapshotDate = CAST(SYSDATETIME() AS DATE)
        GROUP BY ProductId
    ) i ON p.ProductId = i.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
        AND p.ListingStatus = 'Suppressed'
        AND i.QtyFBA > 0;

    -- Return aged inventory impact
    SELECT
        'Aged Inventory' AS ActionType,
        COUNT(*) AS AffectedSKUs,
        SUM(CAST(QtyFBA AS INT)) AS UnitsOver180Days,
        CASE
            WHEN SUM(CAST(QtyFBA AS INT)) > 100 THEN 'Urgent removal needed - incurring long-term storage fees'
            WHEN SUM(CAST(QtyFBA AS INT)) > 50 THEN 'Consider removal to avoid additional fees'
            ELSE 'Monitor closely'
        END AS Description,
        CASE
            WHEN SUM(CAST(QtyFBA AS INT)) > 100 THEN 'HIGH'
            WHEN SUM(CAST(QtyFBA AS INT)) > 50 THEN 'MEDIUM'
            ELSE 'LOW'
        END AS ImpactOnIPI
    FROM dbo.Products p
    JOIN (
        SELECT ProductId, SUM(QtyFBA) AS QtyFBA
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId
            AND SnapshotDate >= DATEADD(DAY, -180, CAST(SYSDATETIME() AS DATE))
        GROUP BY ProductId
        HAVING SUM(QtyFBA) > 0
    ) aged ON p.ProductId = aged.ProductId
    WHERE p.SellerAccountId = @SellerAccountId;
END
GO

-- Stranded Inventory
CREATE PROCEDURE dbo.usp_Inventory_GetStrandedInventory
    @SellerAccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.SKU,
        p.ASIN,
        p.FNSKU,
        p.ProductTitle,
        ISNULL(SUM(i.QtyFBA), 0) AS QtyStranded,
        CASE
            WHEN l.ListingStatus = 'Suppressed' THEN l.SuppressedReason
            ELSE 'No active listing'
        END AS StrandReason,
        -- Daily storage cost estimate
        CASE
            WHEN (p.Length * p.Width * p.Height) > 0 THEN
                (p.Length * p.Width * p.Height) / 1728.0 * 0.75
            ELSE 0.50
        END AS DailyStorageCost,
        CASE
            WHEN l.ListingStatus = 'Suppressed' THEN 'Fix Listing'
            WHEN l.ListingStatus IS NULL THEN 'Create Listing'
            ELSE 'Review'
        END AS RecommendedAction,
        CASE
            WHEN l.ListingStatus = 'Suppressed' THEN
                (SELECT TOP 1 DailyAvgSales FROM (
                    SELECT soi.ProductId, AVG(CAST(soi.QtySold AS DECIMAL(10,2))) / 30 AS DailyAvgSales
                    FROM dbo.SalesOrderItems soi
                    JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
                    WHERE so.SellerAccountId = @SellerAccountId
                        AND so.OrderDate >= DATEADD(DAY, -90, CAST(SYSDATETIME() AS DATE))
                    GROUP BY soi.ProductId
                ) ds WHERE ds.ProductId = p.ProductId)
            ELSE 0
        END AS EstDailyRevenueLost
    FROM dbo.Products p
    LEFT JOIN dbo.Listings l ON p.ProductId = l.ProductId
    LEFT JOIN dbo.InventorySnapshots i ON p.ProductId = i.ProductId
        AND i.SnapshotDate = CAST(SYSDATETIME() AS DATE)
    WHERE p.SellerAccountId = @SellerAccountId
        AND p.IsActive = 1
        AND (l.ListingStatus = 'Suppressed' OR l.ListingStatus IS NULL)
    GROUP BY p.ProductId, p.SKU, p.ASIN, p.FNSKU, p.ProductTitle,
             p.Length, p.Width, p.Height, l.ListingStatus, l.SuppressedReason
    HAVING SUM(ISNULL(i.QtyFBA, 0)) > 0
    ORDER BY EstDailyRevenueLost DESC;
END
GO

-- Aged Inventory Fee Risk
CREATE PROCEDURE dbo.usp_Inventory_GetAgedInventoryFeeRisk
    @SellerAccountId INT,
    @SnapshotDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @SnapshotDate = COALESCE(@SnapshotDate, CAST(SYSDATETIME() AS DATE));

    -- Long-term storage fee tiers (as of 2025):
    -- 181-270 days: $1.50/cubic foot/month
    -- 271-365 days: $3.40/cubic foot/month
    -- 365+ days: $6.90/cubic foot/month + $0.50/unit/month

    WITH InventoryWithAge AS (
        SELECT
            p.ProductId,
            p.SKU,
            p.FNSKU,
            p.ProductTitle,
            p.COGS,
            p.Length,
            p.Width,
            p.Height,
            i.SnapshotDate,
            i.QtyFBA,
            DATEDIFF(DAY, i.SnapshotDate, @SnapshotDate) AS DaysInStorage,
            -- Calculate cubic feet
            CASE
                WHEN p.Length > 0 AND p.Width > 0 AND p.Height > 0 THEN
                    (p.Length * p.Width * p.Height) / 1728.0
                ELSE 0.25  -- Default to 1/4 cubic foot for small items
            END AS CubicFeet
        FROM dbo.Products p
        JOIN dbo.InventorySnapshots i ON p.ProductId = i.ProductId
        WHERE p.SellerAccountId = @SellerAccountId
            AND i.SnapshotDate <= @SnapshotDate
            AND i.SnapshotDate >= DATEADD(DAY, -365, @SnapshotDate)
    )
    SELECT
        SKU,
        FNSKU,
        ProductTitle,
        COGS,
        SUM(CASE WHEN DaysInStorage BETWEEN 0 AND 90 THEN QtyFBA ELSE 0 END) AS Qty0to90Days,
        SUM(CASE WHEN DaysInStorage BETWEEN 91 AND 180 THEN QtyFBA ELSE 0 END) AS Qty91to180Days,
        SUM(CASE WHEN DaysInStorage BETWEEN 181 AND 270 THEN QtyFBA ELSE 0 END) AS Qty181to270Days,
        SUM(CASE WHEN DaysInStorage BETWEEN 271 AND 365 THEN QtyFBA ELSE 0 END) AS Qty271to365Days,
        SUM(CASE WHEN DaysInStorage > 365 THEN QtyFBA ELSE 0 END) AS QtyOver365Days,
        -- Estimate fees for next 90 days
        SUM(CASE WHEN DaysInStorage BETWEEN 181 AND 270 THEN
            QtyFBA * CubicFeet * 1.50 * 3  -- 3 months at $1.50
        ELSE 0 END) +
        SUM(CASE WHEN DaysInStorage BETWEEN 271 AND 365 THEN
            QtyFBA * CubicFeet * 3.40 * 3  -- 3 months at $3.40
        ELSE 0 END) +
        SUM(CASE WHEN DaysInStorage > 365 THEN
            QtyFBA * (CubicFeet * 6.90 * 3 + 0.50 * 3)  -- 3 months at $6.90 + $0.50/unit
        ELSE 0 END) AS EstSurchargeFee90Days,
        -- Sales price needed to clear (at 70% liquidation value vs. fee)
        CASE
            WHEN SUM(CASE WHEN DaysInStorage > 365 THEN QtyFBA ELSE 0 END) > 0 THEN
                (SUM(CASE WHEN DaysInStorage > 365 THEN QtyFBA ELSE 0 END) * (CubicFeet * 6.90 * 3 + 0.50 * 3)) / NULLIF(SUM(CASE WHEN DaysInStorage > 365 THEN QtyFBA ELSE 0 END), 0) / 0.3
            ELSE 0
        END AS SalesPriceToClear,
        -- Removal cost estimate
        CASE
            WHEN SUM(QtyFBA) > 0 THEN SUM(QtyFBA) * 0.50  -- Approx $0.50/unit removal
            ELSE 0
        END AS EstRemovalCost,
        -- Net better option
        CASE
            WHEN (SUM(CASE WHEN DaysInStorage > 365 THEN QtyFBA ELSE 0 END) * COGS * 0.70) >
                 (SUM(CASE WHEN DaysInStorage > 365 THEN QtyFBA ELSE 0 END) * (CubicFeet * 6.90 * 3 + 0.50 * 3)) THEN
                'Liquidate'
            WHEN (SUM(CASE WHEN DaysInStorage > 365 THEN QtyFBA ELSE 0 END) * COGS * 0.70) >
                 (SUM(CASE WHEN DaysInStorage > 365 THEN QtyFBA ELSE 0 END) * 0.50) THEN
                'Remove'
            ELSE 'Continue Storing'
        END AS NetBetterOption
    FROM InventoryWithAge
    GROUP BY ProductId, SKU, FNSKU, ProductTitle, COGS, Length, Width, Height
    HAVING SUM(QtyFBA) > 0
    ORDER BY EstSurchargeFee90Days DESC;
END
GO

-- FBA vs FBM Comparison
CREATE PROCEDURE dbo.usp_Inventory_CompareFBAFBM
    @ProductId INT,
    @SellerAccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CurrentFBAQty INT, @AvgSalesPrice DECIMAL(10,2), @COGS DECIMAL(10,2);
    DECLARE @ReferralFee DECIMAL(5,2) = 0.15, @FBAFulfillmentFee DECIMAL(10,2) = 3.0;
    DECLARE @MonthlyStorage DECIMAL(10,2) = 0.75;

    -- Get product data
    SELECT @COGS = COGS FROM dbo.Products WHERE ProductId = @ProductId;

    -- Get current inventory
    SELECT @CurrentFBAQty = SUM(QtyFBA)
    FROM dbo.InventorySnapshots
    WHERE ProductId = @ProductId
        AND SnapshotDate = CAST(SYSDATETIME() AS DATE);

    -- Get average sales price
    SELECT TOP 1 @AvgSalesPrice = soi.ItemPrice
    FROM dbo.SalesOrderItems soi
    JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
    WHERE soi.ProductId = @ProductId
    ORDER BY so.OrderDate DESC;

    IF @AvgSalesPrice IS NULL SET @AvgSalesPrice = @COGS * 2;  -- Default if no sales

    -- Calculate FBA fees (estimated)
    DECLARE @ReferralFeeAmt DECIMAL(10,2) = @AvgSalesPrice * @ReferralFee;
    DECLARE @FBAFee DECIMAL(10,2) = @FBAFulfillmentFee + (@AvgSalesPrice * 0.01);  -- FBA fulfillment + weight handling
    DECLARE @MonthlyStorageCost DECIMAL(10,2) = @MonthlyStorage;  -- Simplified

    -- FBA margin calculation
    DECLARE @FBAMargin DECIMAL(10,2) = @AvgSalesPrice - @ReferralFeeAmt - @FBAFee - @COGS - @MonthlyStorageCost;
    DECLARE @FBAMarginPct DECIMAL(5,2) = (@FBAMargin / @AvgSalesPrice) * 100;

    -- FBM margin calculation (no Amazon fees, but shipping cost)
    DECLARE @FBM ShippingCost DECIMAL(10,2) = 5.00;  -- Approx FBM shipping
    DECLARE @FBMMargin DECIMAL(10,2) = @AvgSalesPrice - @COGS - @FBM ShippingCost;
    DECLARE @FBMMarginPct DECIMAL(5,2) = (@FBMMargin / @AvgSalesPrice) * 100;

    -- Return comparison
    SELECT
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        @AvgSalesPrice AS SalesPrice,
        @COGS AS COGS,
        @CurrentFBAQty AS CurrentFBAQty,
        @FBAMarginPct AS FBAMarginPct,
        @FBMMarginPct AS FBMMarginPct,
        CASE
            WHEN @FBAMarginPct > @FBMMarginPct THEN 'FBA'
            WHEN @FBMMarginPct > @FBAMarginPct THEN 'FBM'
            ELSE 'Either'
        END AS RecommendedChannel,
        -- Fee breakdown
        @ReferralFeeAmt AS ReferralFee,
        @FBAFee AS FBAFulfillmentFee,
        @MonthlyStorageCost AS MonthlyStorageFee,
        (@ReferralFeeAmt + @FBAFee + @MonthlyStorageCost) AS TotalFBAFees,
        -- Break-even BSR estimate
        CASE
            WHEN @FBAMargin > 0 THEN
                CAST(@COGS / @FBAMargin * 100000 AS INT)  -- Rough estimate
            ELSE 999999
        END AS BreakevenBSR;
END
GO

-- Check Low Stock Alerts
CREATE PROCEDURE dbo.usp_Inventory_CheckLowStockAlerts
    @SellerAccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Today DATE = CAST(SYSDATETIME() AS DATE);

    -- Find products at or below reorder point
    INSERT INTO dbo.Alerts (SellerAccountId, AlertType, ProductId, AlertDate, Message, Severity)
    SELECT
        p.SellerAccountId,
        'LOW_STOCK',
        p.ProductId,
        @Today,
        'Low stock alert: ' + p.SKU + ' has only ' + CAST(ISNULL(i.QtyFBA, 0) AS VARCHAR) + ' units (reorder point: ' + CAST(ISNULL(p.ReorderPoint, 0) AS VARCHAR) + ')',
        CASE
            WHEN ISNULL(i.QtyFBA, 0) <= p.ReorderPoint / 2 THEN 'High'
            WHEN ISNULL(i.QtyFBA, 0) <= p.ReorderPoint THEN 'Medium'
            ELSE 'Low'
        END
    FROM dbo.Products p
    LEFT JOIN (
        SELECT ProductId, SUM(QtyFBA) AS QtyFBA
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId AND SnapshotDate = @Today
        GROUP BY ProductId
    ) i ON p.ProductId = i.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
        AND p.ReorderPoint IS NOT NULL
        AND p.ReorderPoint > 0
        AND ISNULL(i.QtyFBA, 0) <= p.ReorderPoint
        AND NOT EXISTS (
            SELECT 1 FROM dbo.Alerts a
            WHERE a.SellerAccountId = p.SellerAccountId
                AND a.ProductId = p.ProductId
                AND a.AlertType = 'LOW_STOCK'
                AND a.AlertDate = @Today
                AND a.IsRead = 0
        );

    SELECT @@ROWCOUNT AS AlertsCreated;
END
GO

PRINT 'Inventory management stored procedures created successfully.';