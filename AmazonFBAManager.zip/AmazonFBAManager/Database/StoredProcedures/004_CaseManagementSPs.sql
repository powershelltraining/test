-- ============================================================================
-- Case Management Stored Procedures
-- ============================================================================

-- Create New Case
CREATE PROCEDURE dbo.usp_Case_Create
    @SellerAccountId INT,
    @CaseType NVARCHAR(50),
    @ASIN NVARCHAR(20) = NULL,
    @Subject NVARCHAR(500),
    @Description NVARCHAR(MAX),
    @Priority NVARCHAR(10) = 'Medium',
    @LinkedAuditId BIGINT = NULL,
    @AssignedUserId INT = NULL,
    @CaseId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    -- Validate case type
    IF @CaseType NOT IN ('LOST_INVENTORY', 'DAMAGED_INVENTORY', 'FEE_OVERCHARGE',
                         'RETURNLESS_REFUND', 'LISTING_SUPPRESSION', 'HIJACK_REPORT',
                         'ACCOUNT_SUSPENSION', 'INBOUND_SHIPMENT_DISCREPANCY', 'AWD_LOSS')
    BEGIN
        RAISERROR('Invalid case type', 16, 1);
        RETURN;
    END

    -- Determine priority based on case type
    SET @Priority = CASE
        WHEN @CaseType = 'ACCOUNT_SUSPENSION' THEN 'Critical'
        WHEN @CaseType IN ('LOST_INVENTORY', 'DAMAGED_INVENTORY') AND @Priority = 'Medium'
            THEN 'High'
        ELSE @Priority
    END;

    -- Create the case
    INSERT INTO dbo.Cases
        (SellerAccountId, CaseType, Subject, Description, Priority, Status, LinkedCaseId, AssignedUserId)
    VALUES
        (@SellerAccountId, @CaseType, @Subject, @Description, @Priority, 'Open', @LinkedAuditId, @AssignedUserId);

    SET @CaseId = SCOPE_IDENTITY();

    -- Create initial alert
    INSERT INTO dbo.Alerts (SellerAccountId, CaseId, AlertType, AlertDate, Message, Severity)
    VALUES (
        @SellerAccountId,
        @CaseId,
        'NEW_CASE',
        CAST(SYSDATETIME() AS DATE),
        'New case opened: ' + @Subject,
        CASE WHEN @Priority = 'Critical' THEN 'Critical' WHEN @Priority = 'High' THEN 'High' ELSE 'Medium' END
    );

    SELECT @CaseId AS CaseId;
END
GO

-- Escalate Case
CREATE PROCEDURE dbo.usp_Case_Escalate
    @CaseId INT,
    @UserId INT,
    @EscalationReason NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @SellerAccountId INT, @CurrentEscalationLevel INT, @CaseStatus NVARCHAR(20);

    -- Get current case info
    SELECT
        @SellerAccountId = SellerAccountId,
        @CurrentEscalationLevel = EscalationLevel,
        @CaseStatus = Status
    FROM dbo.Cases
    WHERE CaseId = @CaseId;

    IF @CaseId IS NULL
    BEGIN
        RAISERROR('Case not found', 16, 1);
        RETURN;
    END

    IF @CaseStatus IN ('Resolved', 'Closed')
    BEGIN
        RAISERROR('Cannot escalate resolved or closed case', 16, 1);
        RETURN;
    END

    -- Increment escalation level
    DECLARE @NewEscalationLevel INT = @CurrentEscalationLevel + 1;

    -- Add note
    INSERT INTO dbo.CaseNotes (CaseId, UserId, NoteDate, NoteText, IsInternal)
    VALUES (@CaseId, @UserId, SYSDATETIME(),
            'ESCALATION: ' + @EscalationReason + ' (Level: ' + CAST(@NewEscalationLevel AS VARCHAR) + ')', 1);

    -- Update case
    UPDATE dbo.Cases
    SET EscalationLevel = @NewEscalationLevel,
        Status = CASE
            WHEN @NewEscalationLevel >= 2 THEN 'Escalated'
            ELSE Status
        END,
        ModifiedDate = SYSDATETIME()
    WHERE CaseId = @CaseId;

    -- Create escalation alert
    INSERT INTO dbo.Alerts (SellerAccountId, CaseId, AlertType, AlertDate, Message, Severity)
    VALUES (
        @SellerAccountId,
        @CaseId,
        'CASE_ESCALATED',
        CAST(SYSDATETIME() AS DATE),
        'Case escalated to level ' + CAST(@NewEscalationLevel AS VARCHAR) + ': ' + @EscalationReason,
        'High'
    );

    -- Trigger senior queue assignment if level 2+
    IF @NewEscalationLevel >= 2
    BEGIN
        -- Find senior account manager
        DECLARE @SeniorUserId INT;
        SELECT TOP 1 @SeniorUserId = u.UserId
        FROM dbo.Users u
        JOIN dbo.Roles r ON u.RoleId = r.RoleId
        WHERE r.RoleName IN ('Admin', 'AccountManager')
            AND u.IsActive = 1;

        IF @SeniorUserId IS NOT NULL
        BEGIN
            UPDATE dbo.Cases SET AssignedUserId = @SeniorUserId WHERE CaseId = @CaseId;
        END
    END

    SELECT 'Case escalated to level ' + CAST(@NewEscalationLevel AS VARCHAR) AS Result;
END
GO

-- Get Suspension POA Data
CREATE PROCEDURE dbo.usp_Case_GetSuspensionPOAData
    @SellerAccountId INT,
    @CaseId INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Return all context needed for a Plan of Action
    SELECT
        c.CaseId,
        c.Subject,
        c.Description,
        c.OpenedDate,
        c.Priority,
        c.EscalationLevel
    FROM dbo.Cases c
    WHERE c.CaseId = @CaseId AND c.SellerAccountId = @SellerAccountId;

    -- Get performance metrics
    SELECT
        'Last 90 Days' AS Period,
        SUM(so.TotalAmount) AS Revenue,
        COUNT(DISTINCT so.OrderId) AS TotalOrders,
        SUM(so.TotalAmount) / COUNT(DISTINCT so.OrderId) AS AvgOrderValue
    FROM dbo.SalesOrders so
    WHERE so.SellerAccountId = @SellerAccountId
        AND so.OrderDate >= DATEADD(DAY, -90, CAST(SYSDATETIME() AS DATE));

    -- Get return rate
    SELECT
        CAST(COUNT(CASE WHEN ReturnStatus = 'Refunded' THEN 1 END) AS DECIMAL(10,2)) /
        CAST(COUNT(*) AS DECIMAL(10,2)) * 100 AS ReturnRatePct
    FROM dbo.Returns
    WHERE SellerAccountId = @SellerAccountId
        AND ReturnDate >= DATEADD(DAY, -90, CAST(SYSDATETIME() AS DATE));

    -- Get inventory health
    SELECT
        COUNT(CASE WHEN QtyFBA <= ReorderPoint THEN 1 END) AS LowStockSKUs,
        COUNT(CASE WHEN DaysOfSupply > 365 THEN 1 END) AS AgedInventorySKUs,
        COUNT(CASE WHEN ListingStatus = 'Suppressed' THEN 1 END) AS SuppressedListings
    FROM (
        SELECT
            p.ProductId,
            p.ReorderPoint,
            i.QtyFBA,
            CASE
                WHEN i.QtyFBA > 0 AND sales.DailyAvgSales > 0 THEN i.QtyFBA / sales.DailyAvgSales
                ELSE 999
            END AS DaysOfSupply,
            l.ListingStatus
        FROM dbo.Products p
        LEFT JOIN (
            SELECT ProductId, SUM(QtyFBA) AS QtyFBA
            FROM dbo.InventorySnapshots
            WHERE SellerAccountId = @SellerAccountId
                AND SnapshotDate = CAST(SYSDATETIME() AS DATE)
            GROUP BY ProductId
        ) i ON p.ProductId = i.ProductId
        LEFT JOIN dbo.Listings l ON p.ProductId = l.ProductId
        LEFT JOIN (
            SELECT soi.ProductId, AVG(CAST(soi.QtySold AS DECIMAL(10,2))) / 30 AS DailyAvgSales
            FROM dbo.SalesOrderItems soi
            JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
            WHERE so.SellerAccountId = @SellerAccountId
                AND so.OrderDate >= DATEADD(DAY, -90, CAST(SYSDATETIME() AS DATE))
            GROUP BY soi.ProductId
        ) sales ON p.ProductId = sales.ProductId
        WHERE p.SellerAccountId = @SellerAccountId
    ) inventory;

    -- Get recent cases
    SELECT
        CaseType,
        Status,
        OpenedDate,
        ResolvedAmount
    FROM dbo.Cases
    WHERE SellerAccountId = @SellerAccountId
        AND OpenedDate >= DATEADD(DAY, -90, CAST(SYSDATETIME() AS DATE))
    ORDER BY OpenedDate DESC;

    -- Get ASIN list with issues
    SELECT
        p.ASIN,
        p.SKU,
        p.ProductTitle,
        CASE
            WHEN l.ListingStatus = 'Suppressed' THEN 'Suppressed'
            WHEN l.ReviewCount < 3 THEN 'Low Reviews'
            ELSE 'OK'
        END AS IssueType
    FROM dbo.Products p
    LEFT JOIN dbo.Listings l ON p.ProductId = l.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
        AND (l.ListingStatus = 'Suppressed' OR l.ReviewCount < 3)
    ORDER BY IssueType;
END
GO

-- Get Listing Suppressed Fixes
CREATE PROCEDURE dbo.usp_Case_GetListingSuppressedFixes
    @SellerAccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        l.SuppressedReason,
        l.ListingStatus,
        DATEDIFF(DAY, l.LastSyncDate, CAST(SYSDATETIME() AS DATE)) AS DaysSuppressed,
        -- Est revenue lost per day
        COALESCE(sales.DailyAvgSales * p.COGS * 2, 0) AS EstRevLostPerDay,
        CASE
            WHEN l.SuppressedReason LIKE '%image%' THEN 'Upload high-quality image'
            WHEN l.SuppressedReason LIKE '%title%' THEN 'Update title to meet requirements'
            WHEN l.SuppressedReason LIKE '%bullet%' THEN 'Add required bullet points'
            WHEN l.SuppressedReason LIKE '%description%' THEN 'Update description'
            WHEN l.SuppressedReason LIKE '%keyword%' THEN 'Add search terms'
            WHEN l.SuppressedReason LIKE '%category%' THEN 'Select correct category'
            WHEN l.SuppressedReason LIKE '%brand%' THEN 'Verify brand attribute'
            ELSE 'Review and fix listing'
        END AS RequiredAction,
        CASE
            WHEN DATEDIFF(DAY, l.LastSyncDate, CAST(SYSDATETIME() AS DATE)) > 30 THEN 'URGENT'
            WHEN DATEDIFF(DAY, l.LastSyncDate, CAST(SYSDATETIME() AS DATE)) > 14 THEN 'HIGH'
            ELSE 'MEDIUM'
        END AS Priority
    FROM dbo.Products p
    JOIN dbo.Listings l ON p.ProductId = l.ProductId
    LEFT JOIN (
        SELECT soi.ProductId, AVG(CAST(soi.ItemPrice AS DECIMAL(10,2))) AS DailyAvgSales
        FROM dbo.SalesOrderItems soi
        JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
        WHERE so.SellerAccountId = @SellerAccountId
            AND so.OrderDate >= DATEADD(DAY, -30, CAST(SYSDATETIME() AS DATE))
        GROUP BY soi.ProductId
    ) sales ON p.ProductId = sales.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
        AND l.ListingStatus = 'Suppressed'
    ORDER BY EstRevLostPerDay DESC, DaysSuppressed DESC;
END
GO

-- Build Hijack Report
CREATE PROCEDURE dbo.usp_Case_BuildHijackReport
    @ProductId INT,
    @SellerAccountId INT,
    @HijackerASIN NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    -- Get our listing info
    DECLARE @OurSKU NVARCHAR(100), @OurTitle NVARCHAR(500), @OurPrice DECIMAL(10,2);
    DECLARE @OurBuyBoxPrice DECIMAL(10,2), @OurReviewCount INT, @OurStarRating DECIMAL(2,1);

    SELECT
        @OurSKU = p.SKU,
        @OurTitle = p.ProductTitle,
        @OurPrice = l.BuyBoxPrice,
        @OurBuyBoxPrice = l.BuyBoxPrice,
        @OurReviewCount = l.ReviewCount,
        @OurStarRating = l.StarRating
    FROM dbo.Products p
    JOIN dbo.Listings l ON p.ProductId = l.ProductId
    WHERE p.ProductId = @ProductId;

    -- Generate report draft
    SELECT
        'HIJACK REPORT' AS ReportType,
        'Case opened regarding Buy Box loss to unauthorized seller' AS Subject,
        'REPORT BODY:' AS Section1,
        'We are requesting investigation into Buy Box interference on our listing.' AS BodyStart,
        @OurSKU AS OurSKU,
        @HijackerASIN AS HijackerASIN,
        'EVIDENCE REQUIRED:' AS Section2,
        '1. Screenshot showing both listings side by side' AS Evidence1,
        '2. Price comparison showing significant undercutting' AS Evidence2,
        '3. Delivery Promise comparison' AS Evidence3,
        'REQUESTED ACTION:' AS Section3,
        'Removal of the hijacker listing and reinstatement of our Buy Box' AS Action;

    -- Add note to case
    INSERT INTO dbo.CaseNotes (CaseId, UserId, NoteDate, NoteText, IsInternal)
    VALUES (
        (SELECT TOP 1 CaseId FROM dbo.Cases WHERE SellerAccountId = @SellerAccountId AND CaseType = 'HIJACK_REPORT'),
        NULL, SYSDATETIME(),
        'Hijack report generated for ASIN: ' + @HijackerASIN, 1
    );
END
GO

-- Case Aging & SLA Report
CREATE PROCEDURE dbo.usp_Case_GetAgingReport
    @SellerAccountId INT,
    @SLADays INT = 14
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        c.CaseId,
        c.CaseType,
        c.Subject,
        c.Status,
        c.Priority,
        c.OpenedDate,
        DATEDIFF(DAY, c.OpenedDate, CAST(SYSDATETIME() AS DATE)) AS DaysOpen,
        CASE
            WHEN DATEDIFF(DAY, c.OpenedDate, CAST(SYSDATETIME() AS DATE)) > @SLADays * 2 THEN 'SLA_BREACHED'
            WHEN DATEDIFF(DAY, c.OpenedDate, CAST(SYSDATETIME() AS DATE)) > @SLADays THEN 'SLA_WARNING'
            ELSE 'ON_TRACK'
        END AS SLAStatus,
        u.Username AS AssignedUser,
        ISNULL(c.ResolvedAmount, 0) AS AmountAtRisk,
        CASE
            WHEN c.Priority = 'Critical' THEN @SLADays / 2
            WHEN c.Priority = 'High' THEN @SLADays * 0.75
            ELSE @SLADays
        END AS EffectiveSLA
    FROM dbo.Cases c
    LEFT JOIN dbo.Users u ON c.AssignedUserId = u.UserId
    WHERE c.SellerAccountId = @SellerAccountId
        AND c.Status NOT IN ('Resolved', 'Closed')
        AND c.OpenedDate >= DATEADD(DAY, -90, CAST(SYSDATETIME() AS DATE))
    ORDER BY
        CASE
            WHEN c.Priority = 'Critical' THEN 1
            WHEN c.Priority = 'High' THEN 2
            ELSE 3
        END,
        DaysOpen DESC;
END
GO

-- Resolve Case
CREATE PROCEDURE dbo.usp_Case_Resolve
    @CaseId INT,
    @ResolvedAmount DECIMAL(10,2) = 0,
    @ResolutionNote NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE dbo.Cases
    SET Status = 'Resolved',
        ResolvedDate = SYSDATETIME(),
        ResolvedAmount = @ResolvedAmount,
        ModifiedDate = SYSDATETIME()
    WHERE CaseId = @CaseId;

    -- Add resolution note
    IF @ResolutionNote IS NOT NULL
    BEGIN
        INSERT INTO dbo.CaseNotes (CaseId, UserId, NoteDate, NoteText, IsInternal)
        VALUES (@CaseId, NULL, SYSDATETIME(), 'RESOLUTION: ' + @ResolutionNote, 1);
    END

    -- Mark any related alerts as resolved
    UPDATE dbo.Alerts
    SET IsRead = 1,
        ResolvedDate = SYSDATETIME()
    WHERE CaseId = @CaseId;

    SELECT 'Case resolved. Amount recovered: $' + CAST(ISNULL(@ResolvedAmount, 0) AS VARCHAR) AS Result;
END
GO

PRINT 'Case management stored procedures created successfully.';