-- ============================================================================
-- Refund & Reimbursement Stored Procedures
-- ============================================================================

-- Lost/Damaged Inventory Audit
CREATE PROCEDURE dbo.usp_Reimbursement_AuditLostDamagedInventory
    @SellerAccountId INT,
    @DateFrom DATE,
    @DateTo DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Cross-reference: Inventory Adjustments (lost/damaged) vs Reimbursements Received vs Current Inventory
    WITH InventoryAdjustments AS (
        SELECT
            ProductId,
            AdjReason,
            SUM(QtyAdjusted) AS TotalAdjusted
        FROM dbo.InventoryAdjustments
        WHERE SellerAccountId = @SellerAccountId
            AND AdjDate BETWEEN @DateFrom AND @DateTo
            AND AdjReason IN ('LOST', 'DAMAGED')
        GROUP BY ProductId, AdjReason
    ),
    ReimbursementsReceived AS (
        SELECT
            ProductId,
            SUM(QtyReimbursed) AS TotalReimbursed,
            SUM(TotalAmount) AS TotalReimbursedAmount
        FROM dbo.Reimbursements
        WHERE SellerAccountId = @SellerAccountId
            AND ReimbDate BETWEEN @DateFrom AND @DateTo
            AND ReimbType IN ('LOST', 'DAMAGED')
            AND ApprovalStatus = 'Approved'
        GROUP BY ProductId
    ),
    CurrentInventory AS (
        SELECT
            ProductId,
            SUM(QtyFBA + QtyUnfulfillable) AS TotalOnHand
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId
            AND SnapshotDate = CAST(SYSDATETIME() AS DATE)
        GROUP BY ProductId
    )
    SELECT
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        p.COGS AS CostBasis,  -- 2025 policy: reimbursed at cost basis
        ISNULL(ia.TotalAdjusted, 0) AS QtyLost,
        ISNULL(rr.TotalReimbursed, 0) AS QtyReimbursed,
        ISNULL(ia.TotalAdjusted, 0) - ISNULL(rr.TotalReimbursed, 0) AS QtyUnclaimed,
        -- Claimable amount at cost basis (2025 Amazon policy)
        CASE
            WHEN (ISNULL(ia.TotalAdjusted, 0) - ISNULL(rr.TotalReimbursed, 0)) > 0 THEN
                (ISNULL(ia.TotalAdjusted, 0) - ISNULL(rr.TotalReimbursed, 0)) * p.COGS
            ELSE 0
        END AS ClaimableAmount,
        CASE
            WHEN rr.TotalReimbursedAmount > 0 THEN
                rr.TotalReimbursedAmount
            ELSE 0
        END AS AlreadyRecovered,
        CASE
            WHEN (ISNULL(ia.TotalAdjusted, 0) - ISNULL(rr.TotalReimbursed, 0)) > 0 AND p.COGS IS NULL THEN
                'MISSING_COGS'
            WHEN (ISNULL(ia.TotalAdjusted, 0) - ISNULL(rr.TotalReimbursed, 0)) > 0 THEN
                'CLAIMABLE'
            WHEN rr.TotalReimbursedAmount > 0 THEN
                'CLAIMED'
            ELSE
                'NO_LOSS'
        END AS Status,
        CASE
            WHEN p.COGS IS NULL THEN
                'COGS not entered for this product. Please update before filing claim.'
            WHEN (ISNULL(ia.TotalAdjusted, 0) - ISNULL(rr.TotalReimbursed, 0)) > 0 THEN
                'File claim for ' + CAST((ISNULL(ia.TotalAdjusted, 0) - ISNULL(rr.TotalReimbursed, 0)) AS VARCHAR) +
                ' units at $' + CAST(p.COGS AS VARCHAR) + ' each = $' +
                CAST((ISNULL(ia.TotalAdjusted, 0) - ISNULL(rr.TotalReimbursed, 0)) * p.COGS AS VARCHAR)
            ELSE
                'No unclaimed units'
        END AS Recommendation
    FROM dbo.Products p
    LEFT JOIN InventoryAdjustments ia ON p.ProductId = ia.ProductId
    LEFT JOIN ReimbursementsReceived rr ON p.ProductId = rr.ProductId
    LEFT JOIN CurrentInventory ci ON p.ProductId = ci.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
        AND p.IsActive = 1
        AND ia.TotalAdjusted IS NOT NULL
    ORDER BY ClaimableAmount DESC;
END
GO

-- Fee Overcharge Detection
CREATE PROCEDURE dbo.usp_Reimbursement_DetectFeeOvercharges
    @SellerAccountId INT,
    @DateFrom DATE,
    @DateTo DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Compare expected fees vs charged fees for common discrepancies
    WITH ExpectedFees AS (
        SELECT
            p.ProductId,
            p.SKU,
            p.ASIN,
            p.COGS,
            p.Weight,
            p.Length,
            p.Width,
            p.Height,
            -- Expected referral fee (15% for most categories)
            p.COGS * 1.5 * 0.15 AS ExpectedReferralFee,  -- Assume 50% markup
            -- Expected FBA fulfillment fee (based on size)
            CASE
                WHEN p.Weight <= 1 THEN 3.19
                WHEN p.Weight <= 2 THEN 4.79
                WHEN p.Weight <= 3 THEN 5.59
                WHEN p.Weight <= 20 THEN 7.87
                ELSE 9.19
            END +
            CASE
                WHEN (p.Length * p.Width * p.Height) / 1728.0 <= 0.125 THEN 0
                WHEN (p.Length * p.Width * p.Height) / 1728.0 <= 0.25 THEN 0.50
                WHEN (p.Length * p.Width * p.Height) / 1728.0 <= 0.5 THEN 1.00
                ELSE 2.00
            END AS ExpectedFBAFee
        FROM dbo.Products p
        WHERE p.SellerAccountId = @SellerAccountId
            AND p.COGS IS NOT NULL
    ),
    ChargedFees AS (
        SELECT
            ProductId,
            SUM(CASE WHEN FeeType = 'ReferralFee' THEN FeeAmount ELSE 0 END) AS ChargedReferralFee,
            SUM(CASE WHEN FeeType = 'FBAFulfillment' THEN FeeAmount ELSE 0 END) AS ChargedFBAFee,
            SUM(CASE WHEN FeeType = 'Storage' THEN FeeAmount ELSE 0 END) AS ChargedStorageFee,
            SUM(FeeAmount) AS TotalFees
        FROM dbo.FBAFees
        WHERE SellerAccountId = @SellerAccountId
            AND FeeDate BETWEEN @DateFrom AND @DateTo
        GROUP BY ProductId
    )
    SELECT
        ef.SKU,
        ef.ASIN,
        ef.ExpectedReferralFee,
        cf.ChargedReferralFee,
        CASE
            WHEN cf.ChargedReferralFee > ef.ExpectedReferralFee * 1.3 THEN
                cf.ChargedReferralFee - ef.ExpectedReferralFee
            ELSE 0
        END AS ReferralFeeVariance,
        ef.ExpectedFBAFee,
        cf.ChargedFBAFee,
        CASE
            WHEN cf.ChargedFBAFee > ef.ExpectedFBAFee * 1.3 THEN
                cf.ChargedFBAFee - ef.ExpectedFBAFee
            ELSE 0
        END AS FBAFeeVariance,
        cf.ChargedStorageFee,
        cf.TotalFees,
        CASE
            WHEN cf.ChargedReferralFee > ef.ExpectedReferralFee * 1.3 THEN 'OVERCHARGE'
            WHEN cf.ChargedFBAFee > ef.ExpectedFBAFee * 1.3 THEN 'OVERCHARGE'
            ELSE 'OK'
        END AS Status,
        CASE
            WHEN cf.ChargedReferralFee > ef.ExpectedReferralFee * 1.3 THEN
                'Referral fee ' + CAST(cf.ChargedReferralFee AS VARCHAR) +
                ' exceeds expected ' + CAST(ef.ExpectedReferralFee AS VARCHAR) + ' by ' +
                CAST(cf.ChargedReferralFee - ef.ExpectedReferralFee AS VARCHAR)
            WHEN cf.ChargedFBAFee > ef.ExpectedFBAFee * 1.3 THEN
                'FBA fee ' + CAST(cf.ChargedFBAFee AS VARCHAR) +
                ' exceeds expected ' + CAST(ef.ExpectedFBAFee AS VARCHAR) + ' by ' +
                CAST(cf.ChargedFBAFee - ef.ExpectedFBAFee AS VARCHAR)
            ELSE NULL
        END AS ClaimableReason
    FROM ExpectedFees ef
    JOIN ChargedFees cf ON ef.ProductId = cf.ProductId
    WHERE cf.ChargedReferralFee > ef.ExpectedReferralFee * 1.3
       OR cf.ChargedFBAFee > ef.ExpectedFBAFee * 1.3
    ORDER BY (cf.ChargedReferralFee - ef.ExpectedReferralFee) + (cf.ChargedFBAFee - ef.ExpectedFBAFee) DESC;
END
GO

-- Returnless Refund Audit
CREATE PROCEDURE dbo.usp_Reimbursement_AuditReturnlessRefunds
    @SellerAccountId INT,
    @DateFrom DATE,
    @DateTo DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Find refunds issued where no return was received in FBA
    WITH RefundsIssued AS (
        SELECT
            r.ReturnId,
            r.SellerAccountId,
            r.AmazonOrderId,
            r.ProductId,
            r.RefundAmount,
            r.ReturnDate AS RefundDate
        FROM dbo.Returns r
        WHERE r.SellerAccountId = @SellerAccountId
            AND r.CustomerRefundDate BETWEEN @DateFrom AND @DateTo
            AND r.ReturnlessRefund = 1
    ),
    ReturnsReceived AS (
        SELECT
            r.AmazonOrderId,
            r.ProductId,
            MAX(r.ReturnReceivedDate) AS ReturnReceivedDate
        FROM dbo.Returns r
        WHERE r.SellerAccountId = @SellerAccountId
            AND r.ReturnReceivedDate IS NOT NULL
        GROUP BY r.AmazonOrderId, r.ProductId
    )
    SELECT
        ri.ReturnId,
        ri.AmazonOrderId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        p.COGS AS CostBasis,
        ri.RefundAmount,
        rr.ReturnReceivedDate,
        CASE
            WHEN rr.ReturnReceivedDate IS NULL THEN 'NOT_RECEIVED'
            ELSE 'RECEIVED'
        END AS ReturnStatus,
        CASE
            WHEN rr.ReturnReceivedDate IS NULL THEN ri.RefundAmount
            ELSE 0
        END AS ClaimableAmount,
        CASE
            WHEN rr.ReturnReceivedDate IS NULL THEN
                'Refund of $' + CAST(ri.RefundAmount AS VARCHAR) +
                ' issued on ' + CAST(ri.RefundDate AS VARCHAR) +
                ' but no return received. File claim for reimbursement.'
            ELSE
                'Return has been received - no claim needed.'
        END AS Recommendation,
        CASE
            WHEN rr.ReturnReceivedDate IS NULL THEN 'CLAIMABLE'
            ELSE 'RESOLVED'
        END AS Status
    FROM RefundsIssued ri
    JOIN dbo.Products p ON ri.ProductId = p.ProductId
    LEFT JOIN ReturnsReceived rr ON ri.AmazonOrderId = rr.AmazonOrderId
        AND ri.ProductId = rr.ProductId
    WHERE ri.RefundAmount > 0
    ORDER BY ClaimableAmount DESC;
END
GO

-- Inbound Shipment Discrepancy
CREATE PROCEDURE dbo.usp_Reimbursement_AuditInboundShipments
    @SellerAccountId INT,
    @ShipmentId NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    SET NOCOUNT ON;

    -- Compare expected vs received for inbound shipments
    -- Note: Requires shipment data to be imported first
    WITH Expected AS (
        SELECT
            ProductId,
            SUM(QtyInbound) AS QtyShipped
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId
            AND FulfillmentCenterId = @ShipmentId
        GROUP BY ProductId
    ),
    Received AS (
        SELECT
            ProductId,
            SUM(QtyFBA) AS QtyAtFC
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId
            AND SnapshotDate >= DATEADD(DAY, -30, CAST(SYSDATETIME() AS DATE))
        GROUP BY ProductId
    )
    SELECT
        p.SKU,
        p.ASIN,
        ISNULL(e.QtyShipped, 0) AS QtyShipped,
        ISNULL(r.QtyAtFC, 0) AS QtyReceived,
        ISNULL(e.QtyShipped, 0) - ISNULL(r.QtyAtFC, 0) AS QtyVariance,
        CASE
            WHEN (ISNULL(e.QtyShipped, 0) - ISNULL(r.QtyAtFC, 0)) > 0 THEN
                (ISNULL(e.QtyShipped, 0) - ISNULL(r.QtyAtFC, 0)) * p.COGS
            ELSE 0
        END AS ClaimableAmt,
        CASE
            WHEN (ISNULL(e.QtyShipped, 0) - ISNULL(r.QtyAtFC, 0)) < 0 THEN 'OVER'
            WHEN (ISNULL(e.QtyShipped, 0) - ISNULL(r.QtyAtFC, 0)) > 0 THEN 'SHORT'
            ELSE 'MATCHED'
        END AS VarianceType,
        CASE
            WHEN (ISNULL(e.QtyShipped, 0) - ISNULL(r.QtyAtFC, 0)) > 0 THEN
                'File claim for ' + CAST((ISNULL(e.QtyShipped, 0) - ISNULL(r.QtyAtFC, 0)) AS VARCHAR) +
                ' missing units at $' + CAST(p.COGS AS VARCHAR) + ' each'
            ELSE 'Inventory accounted for'
        END AS RecommendedAction
    FROM dbo.Products p
    LEFT JOIN Expected e ON p.ProductId = e.ProductId
    LEFT JOIN Received r ON p.ProductId = r.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
        AND (ISNULL(e.QtyShipped, 0) - ISNULL(r.QtyAtFC, 0)) <> 0
    ORDER BY QtyVariance DESC;
END
GO

-- Monthly Reimbursement Checklist
CREATE PROCEDURE dbo.usp_Reimbursement_MonthlyChecklist
    @SellerAccountId INT,
    @Month INT,
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DateFrom DATE = CAST(CAST(@Year AS VARCHAR(4)) + '-' + CAST(@Month AS VARCHAR(2)) + '-01' AS DATE);
    DECLARE @DateTo DATE = DATEADD(MONTH, 1, @DateFrom) - 1;

    -- Get counts for each reimbursement type
    SELECT
        'Lost Inventory' AS ChecklistItem,
        COUNT(*) AS PotentialClaims,
        SUM(a.ClaimableAmount) AS PotentialAmount,
        CASE
            WHEN COUNT(*) > 0 THEN 'Review and file claims'
            ELSE 'No action needed'
        END AS ActionRequired,
        DATEADD(MONTH, 18, @DateTo) AS Deadline,  -- 18 month window
        'HIGH' AS Priority
    FROM dbo.ReimbursementAudit
    WHERE SellerAccountId = @SellerAccountId
        AND AuditType = 'LOST_INVENTORY'
        AND AuditDate BETWEEN @DateFrom AND @DateTo
        AND Status = 'Pending'

    UNION ALL

    SELECT
        'Damaged Inventory',
        COUNT(*) AS PotentialClaims,
        SUM(a.ClaimableAmount) AS PotentialAmount,
        CASE
            WHEN COUNT(*) > 0 THEN 'Review and file claims'
            ELSE 'No action needed'
        END AS ActionRequired,
        DATEADD(MONTH, 18, @DateTo) AS Deadline,
        'HIGH' AS Priority
    FROM dbo.ReimbursementAudit
    WHERE SellerAccountId = @SellerAccountId
        AND AuditType = 'DAMAGED_INVENTORY'
        AND AuditDate BETWEEN @DateFrom AND @DateTo
        AND Status = 'Pending'

    UNION ALL

    SELECT
        'Returnless Refunds',
        COUNT(*) AS PotentialClaims,
        SUM(a.ClaimableAmount) AS PotentialAmount,
        CASE
            WHEN COUNT(*) > 0 THEN 'Review and file claims'
            ELSE 'No action needed'
        END AS ActionRequired,
        DATEADD(MONTH, 18, @DateTo) AS Deadline,
        'MEDIUM' AS Priority
    FROM dbo.ReimbursementAudit
    WHERE SellerAccountId = @SellerAccountId
        AND AuditType = 'RETURNLESS_REFUND'
        AND AuditDate BETWEEN @DateFrom AND @DateTo
        AND Status = 'Pending'

    UNION ALL

    SELECT
        'Fee Overcharges',
        COUNT(*) AS PotentialClaims,
        SUM(a.ClaimableAmount) AS PotentialAmount,
        CASE
            WHEN COUNT(*) > 0 THEN 'Scan for discrepancies'
            ELSE 'No action needed'
        END AS ActionRequired,
        DATEADD(MONTH, 18, @DateTo) AS Deadline,
        'MEDIUM' AS Priority
    FROM dbo.ReimbursementAudit
    WHERE SellerAccountId = @SellerAccountId
        AND AuditType = 'FEE_OVERCHARGE'
        AND AuditDate BETWEEN @DateFrom AND @DateTo
        AND Status = 'Pending';
END
GO

-- COGS Update Impact (2025 policy: reimbursed at cost basis)
CREATE PROCEDURE dbo.usp_Reimbursement_CalculateCOGSImpact
    @SellerAccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Show impact of COGS on reimbursement calculations
    SELECT
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        p.COGS AS CurrentCOGS,
        CASE
            WHEN p.COGS IS NOT NULL THEN p.COGS
            ELSE 0
        END AS ReimbursablePerUnit,
        -- Total potential recovery if all unclaimed reimbursements were approved
        (SELECT SUM(ISNULL(ra.ClaimableAmount, 0))
         FROM dbo.ReimbursementAudit ra
         WHERE ra.ProductId = p.ProductId
            AND ra.Status = 'Pending') AS TotalPotentialRecovery,
        CASE
            WHEN p.COGS IS NULL THEN 'MISSING'
            WHEN p.COGS = 0 THEN 'ZERO'
            ELSE 'ENTERED'
        END AS COGSStatus,
        CASE
            WHEN p.COGS IS NULL THEN
                'URGENT: Enter COGS immediately. Amazon reimburses at cost basis since March 2025.'
            WHEN p.COGS = 0 THEN
                'WARNING: COGS is zero. Update to actual cost for accurate claims.'
            ELSE
                'COGS is set. Claims will be calculated correctly.'
        END AS Recommendation
    FROM dbo.Products p
    WHERE p.SellerAccountId = @SellerAccountId
        AND p.IsActive = 1
        AND EXISTS (
            SELECT 1 FROM dbo.ReimbursementAudit ra
            WHERE ra.ProductId = p.ProductId AND ra.Status = 'Pending'
        )
    ORDER BY TotalPotentialRecovery DESC;
END
GO

-- Reimbursement KPI Dashboard
CREATE PROCEDURE dbo.usp_Reimbursement_GetKPIDashboard
    @SellerAccountId INT,
    @DateFrom DATE,
    @DateTo DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Total claims filed
    DECLARE @TotalClaims INT;
    SELECT @TotalClaims = COUNT(*)
    FROM dbo.ReimbursementAudit
    WHERE SellerAccountId = @SellerAccountId
        AND AuditDate BETWEEN @DateFrom AND @DateTo;

    -- Approved amount
    DECLARE @ApprovedAmount DECIMAL(12,2);
    SELECT @ApprovedAmount = ISNULL(SUM(TotalAmount), 0)
    FROM dbo.Reimbursements
    WHERE SellerAccountId = @SellerAccountId
        AND ReimbDate BETWEEN @DateFrom AND @DateTo
        AND ApprovalStatus = 'Approved';

    -- Pending amount
    DECLARE @PendingAmount DECIMAL(12,2);
    SELECT @PendingAmount = ISNULL(SUM(ClaimableAmount), 0)
    FROM dbo.ReimbursementAudit
    WHERE SellerAccountId = @SellerAccountId
        AND AuditDate BETWEEN @DateFrom AND @DateTo
        AND Status = 'Pending';

    -- Approval rate
    DECLARE @ClaimsApproved INT;
    SELECT @ClaimsApproved = COUNT(*)
    FROM dbo.ReimbursementAudit
    WHERE SellerAccountId = @SellerAccountId
        AND AuditDate BETWEEN @DateFrom AND @DateTo
        AND Status = 'Approved';

    DECLARE @ApprovalRate DECIMAL(5,2);
    SET @ApprovalRate = CASE
        WHEN @TotalClaims > 0 THEN (@ClaimsApproved * 100.0) / @TotalClaims
        ELSE 0
    END;

    -- Average resolution days
    DECLARE @AvgResolutionDays DECIMAL(5,2);
    SELECT @AvgResolutionDays = AVG(DATEDIFF(DAY, AuditDate, ResolvedDate))
    FROM dbo.ReimbursementAudit
    WHERE SellerAccountId = @SellerAccountId
        AND AuditDate BETWEEN @DateFrom AND @DateTo
        AND ResolvedDate IS NOT NULL;

    -- Return dashboard
    SELECT
        @TotalClaims AS TotalClaims,
        @ApprovedAmount AS ApprovedAmount,
        @PendingAmount AS PendingAmount,
        @ApprovalRate AS ApprovalRate,
        ISNULL(@AvgResolutionDays, 0) AS AvgResolutionDays,
        @ApprovedAmount + @PendingAmount AS TotalPotentialRecovery;

    -- Monthly trend
    SELECT
        CAST(YEAR(ReimbDate) AS VARCHAR(4)) + '-' + RIGHT('0' + CAST(MONTH(ReimbDate) AS VARCHAR(2)), 2) AS Month,
        SUM(TotalAmount) AS AmountRecovered,
        COUNT(*) AS ClaimsApproved
    FROM dbo.Reimbursements
    WHERE SellerAccountId = @SellerAccountId
        AND ReimbDate BETWEEN @DateFrom AND @DateTo
        AND ApprovalStatus = 'Approved'
    GROUP BY YEAR(ReimbDate), MONTH(ReimbDate)
    ORDER BY Month DESC;
END
GO

PRINT 'Reimbursement stored procedures created successfully.';