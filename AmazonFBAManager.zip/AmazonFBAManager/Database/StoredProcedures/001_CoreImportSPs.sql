-- ============================================================================
-- Core Stored Procedures: CSV Import Module
-- ============================================================================

-- Import Inventory Snapshot from CSV
CREATE PROCEDURE dbo.usp_ImportCSV_InventorySnapshot
    @SellerAccountId INT,
    @ImportId BIGINT,
    @DataTable dbo.TVP_InventorySnapshot READONLY
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowsProcessed INT = 0;
    DECLARE @RowsErrored INT = 0;
    DECLARE @SnapshotDate DATE = CAST(SYSDATETIME() AS DATE);

    -- Cursor for processing each row
    DECLARE @SKU NVARCHAR(100), @FNSKU NVARCHAR(20), @ASIN NVARCHAR(20);
    DECLARE @Quantity INT, @Condition NVARCHAR(50), @FChannel NVARCHAR(10);

    DECLARE product_cursor CURSOR FOR
        SELECT SKU, FNSKU, ASIN, Quantity, Condition, FulfillmentChannel
        FROM @DataTable;

    OPEN product_cursor;
    FETCH NEXT FROM product_cursor INTO @SKU, @FNSKU, @ASIN, @Quantity, @Condition, @FChannel;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Get or create Product record
            DECLARE @ProductId INT;
            SELECT @ProductId = ProductId FROM dbo.Products
            WHERE SellerAccountId = @SellerAccountId AND SKU = @SKU;

            IF @ProductId IS NULL
            BEGIN
                INSERT INTO dbo.Products (SellerAccountId, ASIN, SKU, FNSKU, CreatedDate)
                VALUES (@SellerAccountId, @ASIN, @SKU, @FNSKU, SYSDATETIME());
                SET @ProductId = SCOPE_IDENTITY();
            END
            ELSE
            BEGIN
                -- Update FNSKU if changed
                UPDATE dbo.Products SET FNSKU = @FNSKU WHERE ProductId = @ProductId;
            END

            -- Insert inventory snapshot
            INSERT INTO dbo.InventorySnapshots
                (ProductId, SellerAccountId, SnapshotDate, QtyFBA, DataSource)
            VALUES
                (@ProductId, @SellerAccountId, @SnapshotDate,
                 CASE WHEN @FChannel = 'AFN' THEN @Quantity ELSE 0 END,
                 'CSV_UPLOAD');

            -- Insert FBM quantity if applicable
            IF @FChannel = 'MFN'
            BEGIN
                INSERT INTO dbo.InventorySnapshots
                    (ProductId, SellerAccountId, SnapshotDate, QtyFBM, DataSource)
                VALUES
                    (@ProductId, @SellerAccountId, @SnapshotDate, @Quantity, 'CSV_UPLOAD');
            END

            SET @RowsProcessed += 1;
        END TRY
        BEGIN CATCH
            SET @RowsErrored += 1;
            -- Log error - in production, insert to error log table
        END CATCH

        FETCH NEXT FROM product_cursor INTO @SKU, @FNSKU, @ASIN, @Quantity, @Condition, @FChannel;
    END

    CLOSE product_cursor;
    DEALLOCATE product_cursor;

    -- Update import status
    UPDATE dbo.CSVImports
    SET RowsTotal = (SELECT COUNT(*) FROM @DataTable),
        RowsImported = @RowsProcessed,
        RowsErrored = @RowsErrored,
        Status = CASE WHEN @RowsErrored > 0 THEN 'Partial' ELSE 'Complete' END,
        CompletedDate = SYSDATETIME()
    WHERE ImportId = @ImportId;

    -- Check for low stock alerts
    EXEC dbo.usp_Inventory_CheckLowStockAlerts @SellerAccountId;

    SELECT @RowsProcessed AS RowsImported, @RowsErrored AS RowsErrored;
END
GO

-- Import Sales Orders from CSV
CREATE PROCEDURE dbo.usp_ImportCSV_SalesOrders
    @SellerAccountId INT,
    @ImportId BIGINT,
    @OrdersTable dbo.TVP_SalesOrder READONLY,
    @ItemsTable dbo.TVP_SalesOrderItem READONLY
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowsProcessed INT = 0;
    DECLARE @RowsErrored INT = 0;

    -- Process orders
    DECLARE @OrderId BIGINT, @AmazonOrderId NVARCHAR(50);
    DECLARE order_cursor CURSOR FOR
        SELECT AmazonOrderId, OrderDate, ShipDate, FulfillmentChannel, OrderStatus, TotalAmount, Currency
        FROM @OrdersTable;

    OPEN order_cursor;
    FETCH NEXT FROM order_cursor INTO @AmazonOrderId, @OrderId, @OrderId, @OrderId, @OrderId, @OrderId, @OrderId;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Check if order exists
            IF NOT EXISTS (SELECT 1 FROM dbo.SalesOrders WHERE AmazonOrderId = @AmazonOrderId)
            BEGIN
                INSERT INTO dbo.SalesOrders
                    (SellerAccountId, AmazonOrderId, OrderDate, ShipDate, FulfillmentChannel, OrderStatus, TotalAmount, Currency)
                VALUES (@SellerAccountId, @AmazonOrderId, @OrderId, @OrderId, @OrderId, @OrderId, @OrderId, @OrderId);
            END

            SET @RowsProcessed += 1;
        END TRY
        BEGIN CATCH
            SET @RowsErrored += 1;
        END CATCH

        FETCH NEXT FROM order_cursor INTO @AmazonOrderId, @OrderId, @OrderId, @OrderId, @OrderId, @OrderId, @OrderId;
    END

    CLOSE order_cursor;
    DEALLOCATE order_cursor;

    -- Update import status
    UPDATE dbo.CSVImports
    SET RowsTotal = (SELECT COUNT(*) FROM @OrdersTable),
        RowsImported = @RowsProcessed,
        RowsErrored = @RowsErrored,
        Status = CASE WHEN @RowsErrored > 0 THEN 'Partial' ELSE 'Complete' END,
        CompletedDate = SYSDATETIME()
    WHERE ImportId = @ImportId;

    SELECT @RowsProcessed AS RowsImported, @RowsErrored AS RowsErrored;
END
GO

-- Import FBA Fees from CSV
CREATE PROCEDURE dbo.usp_ImportCSV_FBAFees
    @SellerAccountId INT,
    @ImportId BIGINT,
    @DataTable dbo.TVP_FBAFee READONLY
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowsProcessed INT = 0;
    DECLARE @RowsErrored INT = 0;
    DECLARE @FeeDate DATE = CAST(SYSDATETIME() AS DATE);

    DECLARE @SKU NVARCHAR(100), @ASIN NVARCHAR(20), @FeeType NVARCHAR(50);
    DECLARE @FeeAmount DECIMAL(10,2), @Currency NVARCHAR(3), @FCId NVARCHAR(50);
    DECLARE @ProductId INT;

    DECLARE fee_cursor CURSOR FOR
        SELECT SKU, ASIN, FeeType, FeeAmount, Currency, FulfillmentCenterId FROM @DataTable;

    OPEN fee_cursor;
    FETCH NEXT FROM fee_cursor INTO @SKU, @ASIN, @FeeType, @FeeAmount, @Currency, @FCId;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            SELECT @ProductId = ProductId FROM dbo.Products
            WHERE SellerAccountId = @SellerAccountId AND SKU = @SKU;

            IF @ProductId IS NOT NULL
            BEGIN
                INSERT INTO dbo.FBAFees
                    (ProductId, SellerAccountId, FeeDate, FeeType, FeeAmount, Currency, FulfillmentCenterId)
                VALUES (@ProductId, @SellerAccountId, @FeeDate, @FeeType, @FeeAmount, @Currency, @FCId);

                SET @RowsProcessed += 1;
            END
        END TRY
        BEGIN CATCH
            SET @RowsErrored += 1;
        END CATCH

        FETCH NEXT FROM fee_cursor INTO @SKU, @ASIN, @FeeType, @FeeAmount, @Currency, @FCId;
    END

    CLOSE fee_cursor;
    DEALLOCATE fee_cursor;

    UPDATE dbo.CSVImports
    SET RowsTotal = (SELECT COUNT(*) FROM @DataTable),
        RowsImported = @RowsProcessed,
        RowsErrored = @RowsErrored,
        Status = CASE WHEN @RowsErrored > 0 THEN 'Partial' ELSE 'Complete' END,
        CompletedDate = SYSDATETIME()
    WHERE ImportId = @ImportId;

    SELECT @RowsProcessed AS RowsImported, @RowsErrored AS RowsErrored;
END
GO

-- Import Returns from CSV
CREATE PROCEDURE dbo.usp_ImportCSV_Returns
    @SellerAccountId INT,
    @ImportId BIGINT,
    @DataTable dbo.TVP_Returns READONLY
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowsProcessed INT = 0;
    DECLARE @RowsErrored INT = 0;

    DECLARE @AmazonOrderId NVARCHAR(50), @ASIN NVARCHAR(20), @ReturnDate DATE;
    DECLARE @ReturnReason NVARCHAR(200), @Qty INT, @RefundAmount DECIMAL(10,2);
    DECLARE @DispositionCode NVARCHAR(10), @ProductId INT;

    DECLARE return_cursor CURSOR FOR
        SELECT AmazonOrderId, ASIN, ReturnDate, ReturnReason, Qty, RefundAmount, DispositionCode FROM @DataTable;

    OPEN return_cursor;
    FETCH NEXT FROM return_cursor INTO @AmazonOrderId, @ASIN, @ReturnDate, @ReturnReason, @Qty, @RefundAmount, @DispositionCode;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            SELECT @ProductId = ProductId FROM dbo.Products
            WHERE SellerAccountId = @SellerAccountId AND ASIN = @ASIN;

            INSERT INTO dbo.Returns
                (SellerAccountId, AmazonOrderId, ProductId, ReturnDate, ReturnReason, Qty, RefundAmount, DispositionCode)
            VALUES (@SellerAccountId, @AmazonOrderId, @ProductId, @ReturnDate, @ReturnReason, @Qty, @RefundAmount, @DispositionCode);

            SET @RowsProcessed += 1;
        END TRY
        BEGIN CATCH
            SET @RowsErrored += 1;
        END CATCH

        FETCH NEXT FROM return_cursor INTO @AmazonOrderId, @ASIN, @ReturnDate, @ReturnReason, @Qty, @RefundAmount, @DispositionCode;
    END

    CLOSE return_cursor;
    DEALLOCATE return_cursor;

    UPDATE dbo.CSVImports
    SET RowsTotal = (SELECT COUNT(*) FROM @DataTable),
        RowsImported = @RowsProcessed,
        RowsErrored = @RowsErrored,
        Status = CASE WHEN @RowsErrored > 0 THEN 'Partial' ELSE 'Complete' END,
        CompletedDate = SYSDATETIME()
    WHERE ImportId = @ImportId;

    SELECT @RowsProcessed AS RowsImported, @RowsErrored AS RowsErrored;
END
GO

-- Import Reimbursements from CSV
CREATE PROCEDURE dbo.usp_ImportCSV_Reimbursements
    @SellerAccountId INT,
    @ImportId BIGINT,
    @DataTable dbo.TVP_Reimbursement READONLY
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowsProcessed INT = 0;
    DECLARE @RowsErrored INT = 0;

    DECLARE @ReimbId NVARCHAR(50), @ReimbDate DATE, @ASIN NVARCHAR(20);
    DECLARE @ReimbType NVARCHAR(50), @QtyReimbursed INT, @AmountPerUnit DECIMAL(10,2);
    DECLARE @TotalAmount DECIMAL(10,2), @ApprovalStatus NVARCHAR(20), @ProductId INT;

    DECLARE reimb_cursor CURSOR FOR
        SELECT ReimbId, ReimbDate, ASIN, ReimbType, QtyReimbursed, AmountPerUnit, TotalAmount, ApprovalStatus FROM @DataTable;

    OPEN reimb_cursor;
    FETCH NEXT FROM reimb_cursor INTO @ReimbId, @ReimbDate, @ASIN, @ReimbType, @QtyReimbursed, @AmountPerUnit, @TotalAmount, @ApprovalStatus;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            SELECT @ProductId = ProductId FROM dbo.Products
            WHERE SellerAccountId = @SellerAccountId AND ASIN = @ASIN;

            INSERT INTO dbo.Reimbursements
                (SellerAccountId, AmazonReimbId, ReimbDate, ProductId, QtyReimbursed, AmountPerUnit, TotalAmount, ReimbType, ApprovalStatus)
            VALUES (@SellerAccountId, @ReimbId, @ReimbDate, @ProductId, @QtyReimbursed, @AmountPerUnit, @TotalAmount, @ReimbType, @ApprovalStatus);

            SET @RowsProcessed += 1;
        END TRY
        BEGIN CATCH
            SET @RowsErrored += 1;
        END CATCH

        FETCH NEXT FROM reimb_cursor INTO @ReimbId, @ReimbDate, @ASIN, @ReimbType, @QtyReimbursed, @AmountPerUnit, @TotalAmount, @ApprovalStatus;
    END

    CLOSE reimb_cursor;
    DEALLOCATE reimb_cursor;

    UPDATE dbo.CSVImports
    SET RowsTotal = (SELECT COUNT(*) FROM @DataTable),
        RowsImported = @RowsProcessed,
        RowsErrored = @RowsErrored,
        Status = CASE WHEN @RowsErrored > 0 THEN 'Partial' ELSE 'Complete' END,
        CompletedDate = SYSDATETIME()
    WHERE ImportId = @ImportId;

    SELECT @RowsProcessed AS RowsImported, @RowsErrored AS RowsErrored;
END
GO

-- Import Products/COGS from CSV
CREATE PROCEDURE dbo.usp_ImportCSV_Products
    @SellerAccountId INT,
    @ImportId BIGINT,
    @DataTable dbo.TVP_Product READONLY
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowsProcessed INT = 0;
    DECLARE @RowsInserted INT = 0;
    DECLARE @RowsErrored INT = 0;

    DECLARE @SKU NVARCHAR(100), @ASIN NVARCHAR(20), @ProductTitle NVARCHAR(500);
    DECLARE @Brand NVARCHAR(200), @Category NVARCHAR(200), @COGS DECIMAL(10,2);
    DECLARE @Weight DECIMAL(10,3), @Length DECIMAL(10,2), @Width DECIMAL(10,2);
    DECLARE @Height DECIMAL(10,2), @ReorderPoint INT, @ReorderQty INT, @LeadTimeDays INT;
    DECLARE @ExistingProductId INT;

    DECLARE product_cursor CURSOR FOR
        SELECT SKU, ASIN, ProductTitle, Brand, Category, COGS, Weight, Length, Width, Height, ReorderPoint, ReorderQty, LeadTimeDays
        FROM @DataTable;

    OPEN product_cursor;
    FETCH NEXT FROM product_cursor INTO @SKU, @ASIN, @ProductTitle, @Brand, @Category, @COGS, @Weight, @Length, @Width, @Height, @ReorderPoint, @ReorderQty, @LeadTimeDays;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            SELECT @ExistingProductId = ProductId FROM dbo.Products
            WHERE SellerAccountId = @SellerAccountId AND (SKU = @SKU OR ASIN = @ASIN);

            IF @ExistingProductId IS NULL
            BEGIN
                -- Insert new product
                INSERT INTO dbo.Products
                    (SellerAccountId, ASIN, SKU, ProductTitle, Brand, Category, COGS, Weight, Length, Width, Height, ReorderPoint, ReorderQty, LeadTimeDays)
                VALUES (@SellerAccountId, @ASIN, @SKU, @ProductTitle, @Brand, @Category, @COGS, @Weight, @Length, @Width, @Height, @ReorderPoint, @ReorderQty, ISNULL(@LeadTimeDays, 7));

                SET @RowsInserted += 1;
            END
            ELSE
            BEGIN
                -- Update existing product (only update if COGS is provided)
                UPDATE dbo.Products SET
                    ProductTitle = COALESCE(@ProductTitle, ProductTitle),
                    Brand = COALESCE(@Brand, Brand),
                    Category = COALESCE(@Category, Category),
                    COGS = COALESCE(@COGS, COGS),
                    Weight = COALESCE(@Weight, Weight),
                    Length = COALESCE(@Length, Length),
                    Width = COALESCE(@Width, Width),
                    Height = COALESCE(@Height, Height),
                    ReorderPoint = COALESCE(@ReorderPoint, ReorderPoint),
                    ReorderQty = COALESCE(@ReorderQty, ReorderQty),
                    LeadTimeDays = COALESCE(@LeadTimeDays, LeadTimeDays),
                    ModifiedDate = SYSDATETIME()
                WHERE ProductId = @ExistingProductId;
            END

            SET @RowsProcessed += 1;
        END TRY
        BEGIN CATCH
            SET @RowsErrored += 1;
        END CATCH

        FETCH NEXT FROM product_cursor INTO @SKU, @ASIN, @ProductTitle, @Brand, @Category, @COGS, @Weight, @Length, @Width, @Height, @ReorderPoint, @ReorderQty, @LeadTimeDays;
    END

    CLOSE product_cursor;
    DEALLOCATE product_cursor;

    UPDATE dbo.CSVImports
    SET RowsTotal = (SELECT COUNT(*) FROM @DataTable),
        RowsImported = @RowsProcessed,
        RowsErrored = @RowsErrored,
        Status = CASE WHEN @RowsErrored > 0 THEN 'Partial' ELSE 'Complete' END,
        CompletedDate = SYSDATETIME()
    WHERE ImportId = @ImportId;

    SELECT @RowsProcessed AS RowsImported, @RowsInserted AS NewProducts, @RowsErrored AS RowsErrored;
END
GO

-- Import PPC Keywords from CSV
CREATE PROCEDURE dbo.usp_ImportCSV_PPCKeywords
    @SellerAccountId INT,
    @ImportId BIGINT,
    @DataTable dbo.TVP_PPCKeyword READONLY,
    @Period NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowsProcessed INT = 0;
    DECLARE @RowsErrored INT = 0;

    DECLARE @CampaignName NVARCHAR(255), @AdGroupName NVARCHAR(255), @KeywordText NVARCHAR(255);
    DECLARE @MatchType NVARCHAR(10), @Bid DECIMAL(10,2), @Impressions INT, @Clicks INT;
    DECLARE @Spend DECIMAL(10,2), @Sales DECIMAL(10,2);
    DECLARE @CampaignId INT, @ACoS DECIMAL(8,2), @ROAS DECIMAL(8,2);

    DECLARE ppc_cursor CURSOR FOR
        SELECT CampaignName, AdGroupName, KeywordText, MatchType, Bid, Impressions, Clicks, Spend, Sales FROM @DataTable;

    OPEN ppc_cursor;
    FETCH NEXT FROM ppc_cursor INTO @CampaignName, @AdGroupName, @KeywordText, @MatchType, @Bid, @Impressions, @Clicks, @Spend, @Sales;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Get or create campaign
            SELECT @CampaignId = CampaignId FROM dbo.PPCCampaigns
            WHERE SellerAccountId = @SellerAccountId AND CampaignName = @CampaignName;

            IF @CampaignId IS NULL
            BEGIN
                INSERT INTO dbo.PPCCampaigns (SellerAccountId, CampaignName, CampaignType, TargetingType, State)
                VALUES (@SellerAccountId, @CampaignName, 'SponsoredProducts', 'Manual', 'Enabled');
                SET @CampaignId = SCOPE_IDENTITY();
            END

            -- Calculate ACoS and ROAS
            SET @ACoS = CASE WHEN @Sales > 0 THEN (@Spend / @Sales) * 100 ELSE 0 END;
            SET @ROAS = CASE WHEN @Spend > 0 THEN @Sales / @Spend ELSE 0 END;

            -- Insert keyword data
            INSERT INTO dbo.PPCKeywords
                (CampaignId, AdGroupId, KeywordText, MatchType, Bid, Impressions, Clicks, Spend, Sales, ACoS, ROAS, Period)
            VALUES (@CampaignId, @AdGroupName, @KeywordText, @MatchType, @Bid, @Impressions, @Clicks, @Spend, @Sales, @ACoS, @ROAS, @Period);

            SET @RowsProcessed += 1;
        END TRY
        BEGIN CATCH
            SET @RowsErrored += 1;
        END CATCH

        FETCH NEXT FROM ppc_cursor INTO @CampaignName, @AdGroupName, @KeywordText, @MatchType, @Bid, @Impressions, @Clicks, @Spend, @Sales;
    END

    CLOSE ppc_cursor;
    DEALLOCATE ppc_cursor;

    UPDATE dbo.CSVImports
    SET RowsTotal = (SELECT COUNT(*) FROM @DataTable),
        RowsImported = @RowsProcessed,
        RowsErrored = @RowsErrored,
        Status = CASE WHEN @RowsErrored > 0 THEN 'Partial' ELSE 'Complete' END,
        CompletedDate = SYSDATETIME()
    WHERE ImportId = @ImportId;

    SELECT @RowsProcessed AS RowsImported, @RowsErrored AS RowsErrored;
END
GO

PRINT 'Core import stored procedures created successfully.';