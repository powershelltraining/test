-- ============================================================================
-- Sales & Financial Reporting Stored Procedures
-- ============================================================================

-- P&L by SKU / Period
CREATE PROCEDURE dbo.usp_Reports_ProfitLossBySKU
    @SellerAccountId INT,
    @DateFrom DATE,
    @DateTo DATE,
    @GroupBy NVARCHAR(20) = 'SKU'  -- SKU, Category, Brand, Period
AS
BEGIN
    SET NOCOUNT ON;

    -- Revenue and COGS
    WITH RevenueCOGS AS (
        SELECT
            CASE WHEN @GroupBy = 'SKU' THEN p.SKU
                 WHEN @GroupBy = 'Category' THEN p.Category
                 WHEN @GroupBy = 'Brand' THEN p.Brand
                 ELSE 'All' END AS GroupKey,
            soi.ProductId,
            SUM(soi.ItemPrice * soi.QtySold) AS Revenue,
            SUM(p.COGS * soi.QtySold) AS COGS_Total,
            SUM(soi.QtySold) AS UnitsSold,
            SUM(soi.PromotionDiscount) AS PromotionDiscount,
            SUM(soi.ShippingPrice) AS ShippingRevenue,
            COUNT(DISTINCT soi.OrderId) AS OrderCount
        FROM dbo.SalesOrderItems soi
        JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
        JOIN dbo.Products p ON soi.ProductId = p.ProductId
        WHERE so.SellerAccountId = @SellerAccountId
            AND so.OrderDate BETWEEN @DateFrom AND @DateTo
            AND so.OrderStatus IN ('Shipped', 'Delivered')
        GROUP BY
            CASE WHEN @GroupBy = 'SKU' THEN p.SKU
                 WHEN @GroupBy = 'Category' THEN p.Category
                 WHEN @GroupBy = 'Brand' THEN p.Brand
                 ELSE 'All' END,
            soi.ProductId
    ),
    Fees AS (
        SELECT
            p.SKU,
            SUM(f.FeeAmount) AS FBAFees_Total
        FROM dbo.FBAFees f
        JOIN dbo.Products p ON f.ProductId = p.ProductId
        WHERE f.SellerAccountId = @SellerAccountId
            AND f.FeeDate BETWEEN @DateFrom AND @DateTo
        GROUP BY p.SKU
    ),
    PPC AS (
        SELECT
            p.SKU,
            SUM(k.Spend) AS PPC_Spend
        FROM dbo.PPCKeywords k
        JOIN dbo.PPCCampaigns c ON k.CampaignId = c.CampaignId
        JOIN dbo.Products p ON c.SellerAccountId = p.SellerAccountId  -- Simplified
        WHERE c.SellerAccountId = @SellerAccountId
            AND k.Period BETWEEN CAST(@DateFrom AS NVARCHAR(10)) AND CAST(@DateTo AS NVARCHAR(10))
        GROUP BY p.SKU
    ),
    Refunds AS (
        SELECT
            p.SKU,
            SUM(r.RefundAmount) AS RefundsIssued
        FROM dbo.Returns r
        JOIN dbo.Products p ON r.ProductId = p.ProductId
        WHERE r.SellerAccountId = @SellerAccountId
            AND r.CustomerRefundDate BETWEEN @DateFrom AND @DateTo
        GROUP BY p.SKU
    ),
    Reimbursements AS (
        SELECT
            p.SKU,
            SUM(r.TotalAmount) AS ReimbursementsReceived
        FROM dbo.Reimbursements r
        JOIN dbo.Products p ON r.ProductId = p.ProductId
        WHERE r.SellerAccountId = @SellerAccountId
            AND r.ReimbDate BETWEEN @DateFrom AND @DateTo
            AND r.ApprovalStatus = 'Approved'
        GROUP BY p.SKU
    )
    SELECT
        rc.GroupKey,
        SUM(rc.Revenue) AS Revenue,
        SUM(rc.COGS_Total) AS COGS_Total,
        SUM(ISNULL(f.FBAFees_Total, 0)) AS FBAFees_Total,
        SUM(ISNULL(ppc.PPC_Spend, 0)) AS PPC_Spend,
        SUM(ISNULL(ref.RefundsIssued, 0)) AS RefundsIssued,
        SUM(ISNULL(reim.ReimbursementsReceived, 0)) AS ReimbursementsReceived,
        SUM(rc.Revenue) - SUM(rc.COGS_Total) - SUM(ISNULL(f.FBAFees_Total, 0))
            - SUM(ISNULL(ppc.PPC_Spend, 0)) - SUM(ISNULL(ref.RefundsIssued, 0))
            + SUM(ISNULL(reim.ReimbursementsReceived, 0)) AS NetProfit,
        CASE
            WHEN SUM(rc.Revenue) > 0 THEN
                ((SUM(rc.Revenue) - SUM(rc.COGS_Total) - SUM(ISNULL(f.FBAFees_Total, 0))
                    - SUM(ISNULL(ppc.PPC_Spend, 0)) - SUM(ISNULL(ref.RefundsIssued, 0))
                    + SUM(ISNULL(reim.ReimbursementsReceived, 0))) / SUM(rc.Revenue)) * 100
            ELSE 0
        END AS MarginPct,
        CASE
            WHEN SUM(rc.COGS_Total) + SUM(ISNULL(f.FBAFees_Total, 0)) > 0 THEN
                (SUM(rc.Revenue) / (SUM(rc.COGS_Total) + SUM(ISNULL(f.FBAFees_Total, 0)))) - 1
            ELSE 0
        END AS ROI
    FROM RevenueCOGS rc
    LEFT JOIN Fees f ON rc.GroupKey = f.SKU
    LEFT JOIN PPC ppc ON rc.GroupKey = ppc.SKU
    LEFT JOIN Refunds ref ON rc.GroupKey = ref.SKU
    LEFT JOIN Reimbursements reim ON rc.GroupKey = reim.SKU
    GROUP BY rc.GroupKey
    ORDER BY NetProfit DESC;
END
GO

-- Sales Velocity & Trend
CREATE PROCEDURE dbo.usp_Reports_SalesVelocity
    @SellerAccountId INT,
    @ASIN NVARCHAR(20) = NULL,
    @Periods INT = 12
AS
BEGIN
    SET NOCOUNT ON;

    -- Get product ID if ASIN provided
    DECLARE @ProductId INT;
    IF @ASIN IS NOT NULL
    BEGIN
        SELECT @ProductId = ProductId FROM dbo.Products
        WHERE SellerAccountId = @SellerAccountId AND ASIN = @ASIN;
    END

    -- Monthly sales for last N periods
    SELECT
        CAST(YEAR(so.OrderDate) AS VARCHAR(4)) + '-' + RIGHT('0' + CAST(MONTH(so.OrderDate) AS VARCHAR(2)), 2) AS Month,
        COUNT(DISTINCT so.OrderId) AS OrderCount,
        SUM(soi.QtySold) AS UnitsSold,
        SUM(soi.ItemPrice * soi.QtySold) AS Revenue,
        AVG(soi.ItemPrice * soi.QtySold) AS AvgOrderValue
    FROM dbo.SalesOrders so
    JOIN dbo.SalesOrderItems soi ON so.OrderId = soi.OrderId
    WHERE so.SellerAccountId = @SellerAccountId
        AND (@ProductId IS NULL OR soi.ProductId = @ProductId)
        AND so.OrderDate >= DATEADD(MONTH, -@Periods, CAST(SYSDATETIME() AS DATE))
        AND so.OrderStatus IN ('Shipped', 'Delivered')
    GROUP BY YEAR(so.OrderDate), MONTH(so.OrderDate)
    ORDER BY Month DESC;

    -- Year-over-Year comparison if we have data
    IF @Periods >= 12
    BEGIN
        SELECT
            'YoY Comparison' AS AnalysisType,
            CAST(YEAR(so.OrderDate) AS VARCHAR(4)) AS Year,
            SUM(soi.QtySold) AS UnitsSold,
            SUM(soi.ItemPrice * soi.QtySold) AS Revenue,
            LAG(SUM(soi.ItemPrice * soi.QtySold)) OVER (ORDER BY YEAR(so.OrderDate)) AS PrevYearRevenue,
            CASE
                WHEN LAG(SUM(soi.ItemPrice * soi.QtySold)) OVER (ORDER BY YEAR(so.OrderDate)) > 0 THEN
                    ((SUM(soi.ItemPrice * soi.QtySold)) /
                     LAG(SUM(soi.ItemPrice * soi.QtySold)) OVER (ORDER BY YEAR(so.OrderDate)) - 1) * 100
                ELSE 0
            END AS YoYGrowthPct
        FROM dbo.SalesOrders so
        JOIN dbo.SalesOrderItems soi ON so.OrderId = soi.OrderId
        WHERE so.SellerAccountId = @SellerAccountId
            AND (@ProductId IS NULL OR soi.ProductId = @ProductId)
            AND so.OrderStatus IN ('Shipped', 'Delivered')
        GROUP BY YEAR(so.OrderDate)
        ORDER BY Year DESC;
    END

    -- Daily velocity for last 30 days
    SELECT
        CAST(so.OrderDate AS DATE) AS Date,
        SUM(soi.QtySold) AS UnitsSold,
        SUM(soi.ItemPrice * soi.QtySold) AS Revenue
    FROM dbo.SalesOrders so
    JOIN dbo.SalesOrderItems soi ON so.OrderId = soi.OrderId
    WHERE so.SellerAccountId = @SellerAccountId
        AND (@ProductId IS NULL OR soi.ProductId = @ProductId)
        AND so.OrderDate >= DATEADD(DAY, -30, CAST(SYSDATETIME() AS DATE))
        AND so.OrderStatus IN ('Shipped', 'Delivered')
    GROUP BY CAST(so.OrderDate AS DATE)
    ORDER BY Date DESC;
END
GO

-- Fee Breakdown Analysis
CREATE PROCEDURE dbo.usp_Reports_FeeBreakdownByASIN
    @SellerAccountId INT,
    @DateFrom DATE,
    @DateTo DATE
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        p.COGS,
        SUM(soi.ItemPrice * soi.QtySold) AS Revenue,
        -- Fee breakdown
        SUM(CASE WHEN f.FeeType = 'ReferralFee' THEN f.FeeAmount ELSE 0 END) AS ReferralFee,
        SUM(CASE WHEN f.FeeType = 'FBAFulfillment' THEN f.FeeAmount ELSE 0 END) AS FBAFulfillmentFee,
        SUM(CASE WHEN f.FeeType = 'Storage' THEN f.FeeAmount ELSE 0 END) AS StorageFee,
        SUM(CASE WHEN f.FeeType = 'LongTermStorage' THEN f.FeeAmount ELSE 0 END) AS LongTermStorageFee,
        SUM(CASE WHEN f.FeeType = 'Removal' THEN f.FeeAmount ELSE 0 END) AS RemovalFee,
        SUM(f.FeeAmount) AS TotalFees,
        -- Calculate fee %
        CASE
            WHEN SUM(soi.ItemPrice * soi.QtySold) > 0 THEN
                SUM(f.FeeAmount) / SUM(soi.ItemPrice * soi.QtySold) * 100
            ELSE 0
        END AS TotalFeePct,
        -- Net margin after fees
        SUM(soi.ItemPrice * soi.QtySold) - SUM(p.COGS * soi.QtySold) - SUM(f.FeeAmount) AS NetMarginAfterFees,
        CASE
            WHEN SUM(soi.ItemPrice * soi.QtySold) > 0 THEN
                (SUM(soi.ItemPrice * soi.QtySold) - SUM(p.COGS * soi.QtySold) - SUM(f.FeeAmount)) /
                SUM(soi.ItemPrice * soi.QtySold) * 100
            ELSE 0
        END AS NetMarginPct
    FROM dbo.Products p
    JOIN dbo.SalesOrderItems soi ON p.ProductId = soi.ProductId
    JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
    LEFT JOIN dbo.FBAFees f ON p.ProductId = f.ProductId
        AND f.FeeDate BETWEEN @DateFrom AND @DateTo
    WHERE p.SellerAccountId = @SellerAccountId
        AND so.OrderDate BETWEEN @DateFrom AND @DateTo
    GROUP BY p.SKU, p.ASIN, p.ProductTitle, p.COGS
    ORDER BY NetMarginAfterFees DESC;
END
GO

-- Settlement Reconciliation
CREATE PROCEDURE dbo.usp_Reports_SettlementReconciliation
    @SellerAccountId INT,
    @SettlementId NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    -- This would normally match against a settlement report
    -- For now, return summary of the period
    SELECT
        so.SellerAccountId,
        SUM(so.TotalAmount) AS ExpectedTotal,
        SUM(soi.ItemPrice * soi.QtySold) AS OrderRevenue,
        SUM(f.FeeAmount) AS TotalFees,
        SUM(r.TotalAmount) AS Reimbursements
    FROM dbo.SalesOrders so
    LEFT JOIN dbo.SalesOrderItems soi ON so.OrderId = soi.OrderId
    LEFT JOIN dbo.FBAFees f ON so.SellerAccountId = f.SellerAccountId
    LEFT JOIN dbo.Reimbursements r ON so.SellerAccountId = r.SellerAccountId
    WHERE so.SellerAccountId = @SellerAccountId
    GROUP BY so.SellerAccountId;
END
GO

-- Return Rate Analysis
CREATE PROCEDURE dbo.usp_Reports_ReturnRateAnalysis
    @SellerAccountId INT,
    @DateFrom DATE,
    @DateTo DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Overall return rate
    SELECT
        CAST(COUNT(CASE WHEN r.ReturnStatus = 'Refunded' THEN 1 END) AS DECIMAL(10,2)) /
        CAST(COUNT(*) AS DECIMAL(10,2)) * 100 AS OverallReturnRatePct,
        SUM(CASE WHEN r.ReturnStatus = 'Refunded' THEN r.RefundAmount ELSE 0 END) AS TotalRefundAmount,
        COUNT(*) AS TotalReturns
    FROM dbo.Returns r
    WHERE r.SellerAccountId = @SellerAccountId
        AND r.ReturnDate BETWEEN @DateFrom AND @DateTo;

    -- Return rate by ASIN
    SELECT
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        COUNT(r.ReturnId) AS ReturnCount,
        SUM(r.Qty) AS ReturnedUnits,
        (SELECT SUM(soi.QtySold) FROM dbo.SalesOrderItems soi
         JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
         WHERE soi.ProductId = p.ProductId
            AND so.OrderDate BETWEEN @DateFrom AND @DateTo) AS UnitsSold,
        CASE
            WHEN (SELECT SUM(soi.QtySold) FROM dbo.SalesOrderItems soi
                  JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
                  WHERE soi.ProductId = p.ProductId
                    AND so.OrderDate BETWEEN @DateFrom AND @DateTo) > 0 THEN
                CAST(COUNT(r.ReturnId) AS DECIMAL(10,2)) /
                (SELECT SUM(soi.QtySold) FROM dbo.SalesOrderItems soi
                 JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
                 WHERE soi.ProductId = p.ProductId
                    AND so.OrderDate BETWEEN @DateFrom AND @DateTo) * 100
            ELSE 0
        END AS ReturnRatePct,
        SUM(r.RefundAmount) AS TotalRefunded,
        -- Top return reasons
        (SELECT TOP 1 r2.ReturnReason
         FROM dbo.Returns r2
         WHERE r2.ProductId = p.ProductId
         GROUP BY r2.ReturnReason
         ORDER BY COUNT(*) DESC) AS TopReturnReason,
        -- Returnless refund %
        CAST(SUM(CASE WHEN r.ReturnlessRefund = 1 THEN 1 ELSE 0 END) AS DECIMAL(10,2)) /
        CAST(COUNT(*) AS DECIMAL(10,2)) * 100 AS ReturnlessRefundPct
    FROM dbo.Returns r
    JOIN dbo.Products p ON r.ProductId = p.ProductId
    WHERE r.SellerAccountId = @SellerAccountId
        AND r.ReturnDate BETWEEN @DateFrom AND @DateTo
    GROUP BY p.ProductId, p.SKU, p.ASIN, p.ProductTitle
    HAVING COUNT(r.ReturnId) > 0
    ORDER BY ReturnRatePct DESC;
END
GO

-- Multi-Account Consolidated Dashboard
CREATE PROCEDURE dbo.usp_Reports_MultiAccountSummary
    @UserId INT,
    @DateFrom DATE,
    @DateTo DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Get all seller accounts for this user
    SELECT
        sa.SellerAccountId,
        sa.AccountName,
        -- Revenue
        (SELECT SUM(so.TotalAmount)
         FROM dbo.SalesOrders so
         WHERE so.SellerAccountId = sa.SellerAccountId
            AND so.OrderDate BETWEEN @DateFrom AND @DateTo) AS Revenue,
        -- Units
        (SELECT SUM(soi.QtySold)
         FROM dbo.SalesOrderItems soi
         JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
         WHERE so.SellerAccountId = sa.SellerAccountId
            AND so.OrderDate BETWEEN @DateFrom AND @DateTo) AS Units,
        -- Net Profit (simplified)
        (SELECT SUM(so.TotalAmount) - ISNULL(SUM(f.FeeAmount), 0)
         FROM dbo.SalesOrders so
         LEFT JOIN dbo.FBAFees f ON so.SellerAccountId = f.SellerAccountId
         WHERE so.SellerAccountId = sa.SellerAccountId
            AND so.OrderDate BETWEEN @DateFrom AND @DateTo) AS NetProfit,
        -- Open Cases
        (SELECT COUNT(*)
         FROM dbo.Cases c
         WHERE c.SellerAccountId = sa.SellerAccountId
            AND c.Status NOT IN ('Resolved', 'Closed')) AS OpenCases,
        -- Pending Reimbursements
        (SELECT SUM(ClaimableAmount)
         FROM dbo.ReimbursementAudit
         WHERE SellerAccountId = sa.SellerAccountId
            AND Status = 'Pending') AS PendingReimbursements,
        -- Alerts
        (SELECT COUNT(*)
         FROM dbo.Alerts a
         WHERE a.SellerAccountId = sa.SellerAccountId
            AND a.IsRead = 0) AS UnreadAlerts
    FROM dbo.SellerAccounts sa
    JOIN dbo.UserSellerAccounts usa ON sa.SellerAccountId = usa.SellerAccountId
    WHERE usa.UserId = @UserId
        AND sa.IsActive = 1
    ORDER BY Revenue DESC;
END
GO

-- Cash Flow Forecast
CREATE PROCEDURE dbo.usp_Reports_CashFlowForecast
    @SellerAccountId,
    @ForecastDays INT = 30
AS
BEGIN
    SET NOCOUNT ON;

    -- Get last 30 days average
    DECLARE @AvgDailyRevenue DECIMAL(12,2);
    DECLARE @AvgDailyCOGS DECIMAL(12,2);
    DECLARE @AvgDailyFees DECIMAL(12,2);
    DECLARE @AvgDailyPPC DECIMAL(12,2);

    SELECT
        @AvgDailyRevenue = SUM(so.TotalAmount) / 30,
        @AvgDailyCOGS = SUM(so.TotalAmount) * 0.35 / 30,  -- Approx 35% COGS
        @AvgDailyFees = SUM(so.TotalAmount) * 0.15 / 30,   -- Approx 15% fees
        @AvgDailyPPC = ISNULL((SELECT SUM(Spend) / 30 FROM dbo.PPCKeywords k
            JOIN dbo.PPCCampaigns c ON k.CampaignId = c.CampaignId
            WHERE c.SellerAccountId = @SellerAccountId
                AND k.Period >= DATEADD(DAY, -30, CAST(SYSDATETIME() AS DATE))), 0)
    FROM dbo.SalesOrders so
    WHERE so.SellerAccountId = @SellerAccountId
        AND so.OrderDate >= DATEADD(DAY, -30, CAST(SYSDATETIME() AS DATE));

    -- Current cash position (simplified - would be from settlements)
    DECLARE @CurrentCash DECIMAL(12,2) = 0;
    SELECT @CurrentCash = ISNULL(SUM(TotalAmount), 0) - ISNULL(SUM(FeeAmount), 0)
    FROM dbo.SalesOrders
    WHERE SellerAccountId = @SellerAccountId;

    -- Projected
    SELECT
        'Current' AS Period,
        @CurrentCash AS CashPosition,
        @AvgDailyRevenue AS AvgDailyRevenue,
        @AvgDailyCOGS AS AvgDailyCOGS,
        @AvgDailyFees AS AvgDailyFees,
        @AvgDailyPPC AS AvgDailyPPCSpend,
        @AvgDailyRevenue - @AvgDailyCOGS - @AvgDailyFees - @AvgDailyPPC AS AvgDailyNet;

    -- Daily projection
    DECLARE @i INT = 1;
    WHILE @i <= @ForecastDays
    BEGIN
        SELECT
            @i AS DayOffset,
            DATEADD(DAY, @i, CAST(SYSDATETIME() AS DATE)) AS ProjectedDate,
            @AvgDailyRevenue * @i AS ProjectedRevenue,
            @AvgDailyCOGS * @i AS ProjectedCOGS,
            @AvgDailyFees * @i AS ProjectedFees,
            @AvgDailyPPC * @i AS ProjectedPPCSpend,
            @CurrentCash + (@AvgDailyRevenue - @AvgDailyCOGS - @AvgDailyFees - @AvgDailyPPC) * @i AS ProjectedCashPosition;

        SET @i = @i + 1;
    END;
END
GO

PRINT 'Sales and financial reporting stored procedures created successfully.';