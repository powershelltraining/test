-- ============================================================================
-- Authentication & Security Stored Procedures
-- ============================================================================

-- Validate User Account Access
CREATE PROCEDURE dbo.usp_Auth_ValidateUserAccountAccess
    @UserId INT,
    @SellerAccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @HasAccess BIT = 0;
    DECLARE @PermissionLevel NVARCHAR(20) = NULL;

    SELECT
        @HasAccess = 1,
        @PermissionLevel = usa.PermissionLevel
    FROM dbo.UserSellerAccounts usa
    JOIN dbo.Users u ON usa.UserId = u.UserId
    WHERE usa.UserId = @UserId
        AND usa.SellerAccountId = @SellerAccountId
        AND u.IsActive = 1;

    SELECT @HasAccess AS HasAccess, @PermissionLevel AS PermissionLevel;
END
GO

-- Validate User Credentials
CREATE PROCEDURE dbo.usp_Auth_ValidateCredentials
    @Username NVARCHAR(100),
    @PasswordHash NVARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @UserId INT, @IsValid BIT = 0;

    SELECT
        @UserId = UserId,
        @IsValid = CASE WHEN PasswordHash = @PasswordHash THEN 1 ELSE 0 END
    FROM dbo.Users
    WHERE Username = @Username AND IsActive = 1;

    -- Update last login
    IF @IsValid = 1
    BEGIN
        UPDATE dbo.Users SET LastLoginDate = SYSDATETIME() WHERE UserId = @UserId;
    END

    SELECT @IsValid AS IsValid, @UserId AS UserId;
END
GO

-- Create User
CREATE PROCEDURE dbo.usp_Auth_CreateUser
    @Username NVARCHAR(100),
    @Email NVARCHAR(255),
    @PasswordHash NVARCHAR(255),
    @RoleId INT,
    @UserId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if username or email already exists
    IF EXISTS (SELECT 1 FROM dbo.Users WHERE Username = @Username)
    BEGIN
        RAISERROR('Username already exists', 16, 1);
        RETURN;
    END

    IF EXISTS (SELECT 1 FROM dbo.Users WHERE Email = @Email)
    BEGIN
        RAISERROR('Email already exists', 16, 1);
        RETURN;
    END

    INSERT INTO dbo.Users (Username, Email, PasswordHash, RoleId)
    VALUES (@Username, @Email, @PasswordHash, @RoleId);

    SET @UserId = SCOPE_IDENTITY();

    -- Log audit
    INSERT INTO dbo.AuditLog (UserId, ActionType, TableName, RecordId, NewValue)
    VALUES (@UserId, 'CREATE', 'Users', @UserId, 'User created');
END
GO

-- Assign User to Seller Account
CREATE PROCEDURE dbo.usp_Auth_AssignUserToAccount
    @UserId INT,
    @SellerAccountId INT,
    @PermissionLevel NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    IF @PermissionLevel NOT IN ('Full', 'ReadOnly', 'Execute')
    BEGIN
        RAISERROR('Invalid permission level', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE UserId = @UserId)
    BEGIN
        RAISERROR('User not found', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM dbo.SellerAccounts WHERE SellerAccountId = @SellerAccountId)
    BEGIN
        RAISERROR('Seller account not found', 16, 1);
        RETURN;
    END

    -- Check if already assigned
    IF EXISTS (SELECT 1 FROM dbo.UserSellerAccounts WHERE UserId = @UserId AND SellerAccountId = @SellerAccountId)
    BEGIN
        UPDATE dbo.UserSellerAccounts
        SET PermissionLevel = @PermissionLevel
        WHERE UserId = @UserId AND SellerAccountId = @SellerAccountId;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.UserSellerAccounts (UserId, SellerAccountId, PermissionLevel)
        VALUES (@UserId, @SellerAccountId, @PermissionLevel);
    END

    -- Log audit
    INSERT INTO dbo.AuditLog (UserId, ActionType, TableName, RecordId, NewValue)
    VALUES (@UserId, 'ASSIGN', 'UserSellerAccounts', @SellerAccountId,
            'Assigned to account with ' + @PermissionLevel + ' permissions');
END
GO

-- Get User Permissions
CREATE PROCEDURE dbo.usp_Auth_GetUserPermissions
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        u.UserId,
        u.Username,
        u.Email,
        r.RoleName,
        r.RoleId,
        sa.SellerAccountId,
        sa.AccountName,
        usa.PermissionLevel
    FROM dbo.Users u
    JOIN dbo.Roles r ON u.RoleId = r.RoleId
    JOIN dbo.UserSellerAccounts usa ON u.UserId = usa.UserId
    JOIN dbo.SellerAccounts sa ON usa.SellerAccountId = sa.SellerAccountId
    WHERE u.UserId = @UserId
        AND u.IsActive = 1
        AND sa.IsActive = 1;
END
GO

-- ============================================================================
-- Utility Functions
-- ============================================================================

-- User has account access function
CREATE FUNCTION dbo.fn_UserHasAccountAccess
(
    @UserId INT,
    @SellerAccountId INT
)
RETURNS BIT
AS
BEGIN
    DECLARE @HasAccess BIT = 0;

    SELECT @HasAccess = 1
    FROM dbo.UserSellerAccounts usa
    JOIN dbo.Users u ON usa.UserId = u.UserId
    WHERE usa.UserId = @UserId
        AND usa.SellerAccountId = @SellerAccountId
        AND u.IsActive = 1;

    RETURN @HasAccess;
END
GO

-- Get Alert Thresholds
CREATE PROCEDURE dbo.usp_Settings_GetAlertThresholds
    @SellerAccountId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        AlertType,
        ThresholdValue,
        IsEnabled
    FROM dbo.AlertThresholds
    WHERE SellerAccountId = @SellerAccountId
        AND IsEnabled = 1;
END
GO

-- Set Alert Threshold
CREATE PROCEDURE dbo.usp_Settings_SetAlertThreshold
    @SellerAccountId INT,
    @AlertType NVARCHAR(50),
    @ThresholdValue DECIMAL(10,2),
    @IsEnabled BIT = 1
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1 FROM dbo.AlertThresholds
        WHERE SellerAccountId = @SellerAccountId AND AlertType = @AlertType
    )
    BEGIN
        UPDATE dbo.AlertThresholds
        SET ThresholdValue = @ThresholdValue,
            IsEnabled = @IsEnabled
        WHERE SellerAccountId = @SellerAccountId AND AlertType = @AlertType;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.AlertThresholds (SellerAccountId, AlertType, ThresholdValue, IsEnabled)
        VALUES (@SellerAccountId, @AlertType, @ThresholdValue, @IsEnabled);
    END
END
GO

PRINT 'Authentication and security stored procedures created successfully.';