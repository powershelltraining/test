-- ============================================================================
-- PPC / Advertising Stored Procedures
-- ============================================================================

-- PPC Audit - Find wasted spend and harvest opportunities
CREATE PROCEDURE dbo.usp_PPC_AuditCampaigns
    @SellerAccountId INT,
    @DateFrom DATE,
    @DateTo DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Wasted spend: High spend / zero or low conversion keywords
    SELECT
        c.CampaignName,
        k.KeywordText,
        k.MatchType,
        k.Impressions,
        k.Clicks,
        k.Spend,
        k.Sales,
        k.ACoS,
        CASE
            WHEN k.Spend > 50 AND (k.Sales IS NULL OR k.Sales = 0) THEN 'ZERO_CONVERSION'
            WHEN k.Spend > 20 AND k.ACoS > 50 THEN 'HIGH_ACOS'
            ELSE 'OK'
        END AS IssueType,
        CASE
            WHEN k.Spend > 50 AND (k.Sales IS NULL OR k.Sales = 0) THEN
                'Consider pausing or reducing bid - $' + CAST(k.Spend AS VARCHAR) + ' with no sales'
            WHEN k.Spend > 20 AND k.ACoS > 50 THEN
                'ACoS is ' + CAST(k.ACoS AS VARCHAR) + '%. Consider lowering bid to target ' +
                CAST((SELECT TargetMargin FROM dbo.Products p JOIN dbo.PPCCampaigns c2 ON c2.SellerAccountId = p.SellerAccountId WHERE c2.CampaignId = c.CampaignId LIMIT 1) AS VARCHAR) + '%'
            ELSE 'Performing well'
        END AS Recommendation,
        CASE
            WHEN k.Spend > 50 AND (k.Sales IS NULL OR k.Sales = 0) THEN 'HIGH'
            WHEN k.Spend > 20 AND k.ACoS > 50 THEN 'MEDIUM'
            ELSE 'LOW'
        END AS Priority
    FROM dbo.PPCKeywords k
    JOIN dbo.PPCCampaigns c ON k.CampaignId = c.CampaignId
    WHERE c.SellerAccountId = @SellerAccountId
        AND k.Period BETWEEN CAST(@DateFrom AS NVARCHAR(10)) AND CAST(@DateTo AS NVARCHAR(10))
        AND (k.Spend > 0)
    ORDER BY k.Spend DESC;

    -- Harvest opportunities: Converting search terms not in exact match
    SELECT
        c.CampaignName,
        k.KeywordText AS ExactMatchKeyword,
        k.Sales AS ExactMatchSales,
        -- This would need more complex logic in production to find related phrases
        'Consider adding phrase/broad match variations' AS HarvestSuggestion,
        'MEDIUM' AS Priority
    FROM dbo.PPCKeywords k
    JOIN dbo.PPCCampaigns c ON k.CampaignId = c.CampaignId
    WHERE c.SellerAccountId = @SellerAccountId
        AND k.Period BETWEEN CAST(@DateFrom AS NVARCHAR(10)) AND CAST(@DateTo AS NVARCHAR(10))
        AND k.MatchType = 'Exact'
        AND k.Sales > 0
        AND k.ACoS < 30  -- Profitable exact match keywords
    ORDER BY k.Sales DESC;
END
GO

-- Keyword Performance
CREATE PROCEDURE dbo.usp_PPC_GetKeywordPerformance
    @SellerAccountId INT,
    @CampaignId INT = NULL,
    @DateFrom DATE,
    @DateTo DATE
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        c.CampaignName,
        c.CampaignType,
        k.AdGroupId,
        k.KeywordText,
        k.MatchType,
        SUM(k.Impressions) AS TotalImpressions,
        SUM(k.Clicks) AS TotalClicks,
        CASE
            WHEN SUM(k.Impressions) > 0 THEN (SUM(k.Clicks) * 100.0) / SUM(k.Impressions)
            ELSE 0
        END AS CTR,
        SUM(k.Spend) AS TotalSpend,
        SUM(k.Sales) AS TotalSales,
        CASE
            WHEN SUM(k.Spend) > 0 THEN SUM(k.Sales) / SUM(k.Spend)
            ELSE 0
        END AS ROAS,
        CASE
            WHEN SUM(k.Sales) > 0 THEN (SUM(k.Spend) / SUM(k.Sales)) * 100
            ELSE 0
        END AS ACoS
    FROM dbo.PPCKeywords k
    JOIN dbo.PPCCampaigns c ON k.CampaignId = c.CampaignId
    WHERE c.SellerAccountId = @SellerAccountId
        AND (@CampaignId IS NULL OR c.CampaignId = @CampaignId)
        AND k.Period BETWEEN CAST(@DateFrom AS NVARCHAR(10)) AND CAST(@DateTo AS NVARCHAR(10))
    GROUP BY c.CampaignName, c.CampaignType, k.AdGroupId, k.KeywordText, k.MatchType
    ORDER BY TotalSpend DESC;
END
GO

-- TACoS (Total ACoS) Calculator
CREATE PROCEDURE dbo.usp_PPC_CalculateTACoS
    @SellerAccountId,
    @DateFrom DATE,
    @DateTo DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Get PPC sales
    DECLARE @PPCSales DECIMAL(12,2);
    DECLARE @TotalPPCSpend DECIMAL(12,2);

    SELECT
        @PPCSales = ISNULL(SUM(k.Sales), 0),
        @TotalPPCSpend = ISNULL(SUM(k.Spend), 0)
    FROM dbo.PPCKeywords k
    JOIN dbo.PPCCampaigns c ON k.CampaignId = c.CampaignId
    WHERE c.SellerAccountId = @SellerAccountId
        AND k.Period BETWEEN CAST(@DateFrom AS NVARCHAR(10)) AND CAST(@DateTo AS NVARCHAR(10));

    -- Get total organic sales (all sales - PPC sales)
    DECLARE @TotalSales DECIMAL(12,2);
    SELECT @TotalSales = ISNULL(SUM(soi.ItemPrice * soi.QtySold), 0)
    FROM dbo.SalesOrderItems soi
    JOIN dbo.SalesOrders so ON soi.OrderId = so.OrderId
    WHERE so.SellerAccountId = @SellerAccountId
        AND so.OrderDate BETWEEN @DateFrom AND @DateTo;

    DECLARE @OrganicSales DECIMAL(12,2) = @TotalSales - @PPCSales;

    -- Calculate ACoS and TACoS
    DECLARE @ACoS DECIMAL(8,2), @TACoS DECIMAL(8,2);

    SET @ACoS = CASE
        WHEN @PPCSales > 0 THEN (@TotalPPCSpend / @PPCSales) * 100
        ELSE 0
    END;

    SET @TACoS = CASE
        WHEN @TotalSales > 0 THEN (@TotalPPCSpend / @TotalSales) * 100
        ELSE 0
    END;

    SELECT
        @TotalSales AS TotalSales,
        @PPCSales AS PPCSales,
        @OrganicSales AS OrganicSales,
        CASE WHEN @TotalSales > 0 THEN (@PPCSales / @TotalSales) * 100 ELSE 0 END AS PPCSalesRatioPct,
        @TotalPPCSpend AS TotalSpend,
        @ACoS AS ACoS,
        @TACoS AS TACoS,
        CASE
            WHEN @TACoS < @ACoS THEN 'Organic sales are driving most revenue - PPC is supplemental'
            WHEN @TACoS > @ACoS * 1.5 THEN 'Heavy reliance on PPC - consider increasing organic reach'
            ELSE 'Balanced PPC and organic presence'
        END AS Interpretation;
END
GO

-- Bid Adjustment Suggestions
CREATE PROCEDURE dbo.usp_PPC_GetBidAdjustmentSuggestions
    @SellerAccountId INT,
    @TargetACoS DECIMAL(5,2) = 25.0
AS
BEGIN
    SET NOCOUNT ON;

    -- Get keywords needing bid adjustments
    SELECT
        c.CampaignName,
        k.KeywordText,
        k.MatchType,
        k.Bid AS CurrentBid,
        k.Spend,
        k.Sales,
        k.ACoS,
        -- Suggested bid calculation: Target ACoS * Sales / Spend * Current Bid
        CASE
            WHEN k.Sales > 0 AND k.Spend > 0 THEN
                @TargetACoS * (k.Sales / k.Spend) * k.Bid
            ELSE k.Bid
        END AS SuggestedBid,
        CASE
            WHEN k.ACoS > @TargetACoS * 1.5 THEN 'DECREASE'
            WHEN k.ACoS < @TargetACoS * 0.5 THEN 'INCREASE'
            ELSE 'MAINTAIN'
        END AS Adjustment,
        CASE
            WHEN k.ACoS > @TargetACoS * 1.5 THEN
                'Reduce bid by ' + CAST(ROUND((1 - (@TargetACoS * (k.Sales / k.Spend))) * 100, 0) AS VARCHAR) + '%'
            WHEN k.ACoS < @TargetACoS * 0.5 THEN
                'Increase bid - under-bidding on profitable keyword'
            ELSE 'Bid is optimal'
        END AS Reason
    FROM dbo.PPCKeywords k
    JOIN dbo.PPCCampaigns c ON k.CampaignId = c.CampaignId
    WHERE c.SellerAccountId = @SellerAccountId
        AND k.Sales > 0
        AND c.State = 'Enabled'
    ORDER BY k.Spend DESC;
END
GO

PRINT 'PPC stored procedures created successfully.';