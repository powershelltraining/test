-- ActivityLog table and AgedInventory view
-- These were missing but referenced in Jobs

-- =============================================
-- ActivityLog table
-- Tracks user activities for audit and reporting
-- =============================================
CREATE TABLE dbo.ActivityLog (
    LogId BIGINT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    ActivityType NVARCHAR(50) NOT NULL,
    Description NVARCHAR(MAX) NULL,
    UserId INT NULL,
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    CONSTRAINT FK_ActivityLog_SellerAccounts FOREIGN KEY (SellerAccountId)
        REFERENCES dbo.SellerAccounts(SellerAccountId)
);

CREATE INDEX IX_ActivityLog_SellerAccountId ON dbo.ActivityLog(SellerAccountId);
CREATE INDEX IX_ActivityLog_CreatedAt ON dbo.ActivityLog(CreatedAt);
CREATE INDEX IX_ActivityLog_ActivityType ON dbo.ActivityLog(ActivityType);
GO

-- =============================================
-- vw_AgedInventory view
-- Provides aged inventory analysis for alerts
-- =============================================
CREATE VIEW dbo.vw_AgedInventory
AS
SELECT
    p.SellerAccountId,
    p.ProductId,
    p.SKU,
    p.ProductName,
    p.ASIN,
    ISNULL(SUM(i.QtyFBA), 0) AS Quantity,
    DATEDIFF(DAY, MAX(i.SnapshotDate), GETDATE()) AS DaysInStock,
    CASE
        WHEN DATEDIFF(DAY, MAX(i.SnapshotDate), GETDATE()) >= 365 THEN '365+ days'
        WHEN DATEDIFF(DAY, MAX(i.SnapshotDate), GETDATE()) >= 271 THEN '271-365 days'
        WHEN DATEDIFF(DAY, MAX(i.SnapshotDate), GETDATE()) >= 181 THEN '181-270 days'
        WHEN DATEDIFF(DAY, MAX(i.SnapshotDate), GETDATE()) >= 91 THEN '91-180 days'
        ELSE '< 90 days'
    END AS AgeTier,
    SUM(i.EstStorageCost) AS EstStorageFee
FROM Products p
INNER JOIN InventorySnapshots i ON p.ProductId = i.ProductId
WHERE p.IsActive = 1
GROUP BY
    p.SellerAccountId,
    p.ProductId,
    p.SKU,
    p.ProductName,
    p.ASIN
HAVING DATEDIFF(DAY, MAX(i.SnapshotDate), GETDATE()) >= 90;
GO

PRINT 'ActivityLog table and vw_AgedInventory view created successfully';
GO