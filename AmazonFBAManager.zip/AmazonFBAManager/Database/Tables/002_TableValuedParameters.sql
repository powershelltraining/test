-- ============================================================================
-- Table-Valued Parameters (TVPs) for CSV Imports
-- Used for bulk data import via stored procedures
-- ============================================================================

-- TVP: Inventory Snapshot Import
CREATE TYPE dbo.TVP_InventorySnapshot AS TABLE (
    SKU NVARCHAR(100),
    FNSKU NVARCHAR(20),
    ASIN NVARCHAR(20),
    Quantity INT,
    Condition NVARCHAR(50),
    FulfillmentChannel NVARCHAR(10)
);

-- TVP: Sales Order Import
CREATE TYPE dbo.TVP_SalesOrder AS TABLE (
    AmazonOrderId NVARCHAR(50),
    OrderDate DATETIME2,
    ShipDate DATETIME2,
    FulfillmentChannel NVARCHAR(10),
    OrderStatus NVARCHAR(20),
    TotalAmount DECIMAL(10,2),
    Currency NVARCHAR(3)
);

-- TVP: Sales Order Items Import
CREATE TYPE dbo.TVP_SalesOrderItem AS TABLE (
    AmazonOrderId NVARCHAR(50),
    ASIN NVARCHAR(20),
    SKU NVARCHAR(100),
    QtySold INT,
    ItemPrice DECIMAL(10,2),
    PromotionDiscount DECIMAL(10,2),
    ShippingPrice DECIMAL(10,2),
    GiftWrapPrice DECIMAL(10,2)
);

-- TVP: FBA Fee Import
CREATE TYPE dbo.TVP_FBAFee AS TABLE (
    SKU NVARCHAR(100),
    ASIN NVARCHAR(20),
    FeeType NVARCHAR(50),
    FeeAmount DECIMAL(10,2),
    Currency NVARCHAR(3),
    FulfillmentCenterId NVARCHAR(50)
);

-- TVP: Returns Import
CREATE TYPE dbo.TVP_Returns AS TABLE (
    AmazonOrderId NVARCHAR(50),
    ASIN NVARCHAR(20),
    ReturnDate DATE,
    ReturnReason NVARCHAR(200),
    Qty INT,
    RefundAmount DECIMAL(10,2),
    DispositionCode NVARCHAR(10)
);

-- TVP: Reimbursement Import
CREATE TYPE dbo.TVP_Reimbursement AS TABLE (
    ReimbId NVARCHAR(50),
    ReimbDate DATE,
    ASIN NVARCHAR(20),
    ReimbType NVARCHAR(50),
    QtyReimbursed INT,
    AmountPerUnit DECIMAL(10,2),
    TotalAmount DECIMAL(10,2),
    ApprovalStatus NVARCHAR(20)
);

-- TVP: Inventory Adjustment Import
CREATE TYPE dbo.TVP_InventoryAdjustment AS TABLE (
    SKU NVARCHAR(100),
    AdjustmentDate DATE,
    AdjReason NVARCHAR(100),
    QtyAdjusted INT,
    DispositionCode NVARCHAR(10),
    FulfillmentCenterId NVARCHAR(50)
);

-- TVP: PPC Keyword Import
CREATE TYPE dbo.TVP_PPCKeyword AS TABLE (
    CampaignName NVARCHAR(255),
    AdGroupName NVARCHAR(255),
    KeywordText NVARCHAR(255),
    MatchType NVARCHAR(10),
    Bid DECIMAL(10,2),
    Impressions INT,
    Clicks INT,
    Spend DECIMAL(10,2),
    Sales DECIMAL(10,2)
);

-- TVP: Product/COGS Import
CREATE TYPE dbo.TVP_Product AS TABLE (
    SKU NVARCHAR(100),
    ASIN NVARCHAR(20),
    ProductTitle NVARCHAR(500),
    Brand NVARCHAR(200),
    Category NVARCHAR(200),
    COGS DECIMAL(10,2),
    Weight DECIMAL(10,3),
    Length DECIMAL(10,2),
    Width DECIMAL(10,2),
    Height DECIMAL(10,2),
    ReorderPoint INT,
    ReorderQty INT,
    LeadTimeDays INT
);

PRINT 'Table-Valued Parameters created successfully.';