-- ============================================================================
-- Amazon FBA Multi-Seller Management Platform - Database Schema
-- SQL Server 2022 Compatible
-- ============================================================================

-- ============================================================================
-- SECTION 1: CORE TABLES (Users, Accounts, Authentication)
-- ============================================================================

-- Seller Accounts - Multi-tenant Amazon seller accounts
CREATE TABLE dbo.SellerAccounts (
    SellerAccountId INT IDENTITY(1,1) PRIMARY KEY,
    AccountName NVARCHAR(255) NOT NULL,
    MarketplaceId INT NOT NULL,  -- FK to Marketplaces
    MerchantToken NVARCHAR(500) ENCRYPTED,  -- MWS credentials (encrypted at rest)
    SPAPIClientId NVARCHAR(255) ENCRYPTED,
    SPAPIClientSecret NVARCHAR(500) ENCRYPTED,
    RefreshToken NVARCHAR(500) ENCRYPTED,
    Region NVARCHAR(10) NOT NULL,  -- US, CA, UK, DE, FR, IT, ES, JP, AU, MX
    IsActive BIT DEFAULT 1,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    ModifiedDate DATETIME2 DEFAULT SYSDATETIME()
);

-- Marketplaces lookup
CREATE TABLE dbo.Marketplaces (
    MarketplaceId INT IDENTITY(1,1) PRIMARY KEY,
    MarketplaceName NVARCHAR(100) NOT NULL,
    RegionCode NVARCHAR(10) NOT NULL,
    CurrencyCode NVARCHAR(3) NOT NULL,
    Domain NVARCHAR(100) NOT NULL
);

-- Users - Application users
CREATE TABLE dbo.Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(100) NOT NULL UNIQUE,
    Email NVARCHAR(255) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    RoleId INT NOT NULL,  -- FK to Roles
    IsActive BIT DEFAULT 1,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    LastLoginDate DATETIME2 NULL
);

-- Roles
CREATE TABLE dbo.Roles (
    RoleId INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(50) NOT NULL UNIQUE,  -- Admin, AccountManager, Analyst, VAReadOnly
    RoleDescription NVARCHAR(255)
);

-- User-Seller Account Many-to-Many relationship
CREATE TABLE dbo.UserSellerAccounts (
    UserId INT NOT NULL,
    SellerAccountId INT NOT NULL,
    PermissionLevel NVARCHAR(20) NOT NULL,  -- Full, ReadOnly, Execute
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    PRIMARY KEY (UserId, SellerAccountId),
    FOREIGN KEY (UserId) REFERENCES dbo.Users(UserId),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId)
);

-- ============================================================================
-- SECTION 2: PRODUCT / ASIN MASTER
-- ============================================================================

-- Products - ASIN/SKU master data
CREATE TABLE dbo.Products (
    ProductId INT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    ASIN NVARCHAR(20) NOT NULL,
    SKU NVARCHAR(100) NOT NULL,
    FNSKU NVARCHAR(20),
    ProductTitle NVARCHAR(500),
    Brand NVARCHAR(200),
    Category NVARCHAR(200),
    Subcategory NVARCHAR(200),
    UPC NVARCHAR(50),
    EAN NVARCHAR(50),
    Weight DECIMAL(10,3),  -- in pounds
    Length DECIMAL(10,2),
    Width DECIMAL(10,2),
    Height DECIMAL(10,2),
    COGS DECIMAL(10,2),  -- Cost of Goods Sold - CRITICAL for 2025 reimbursement
    TargetMargin DECIMAL(5,2),  -- Target margin percentage
    ReorderPoint INT,
    ReorderQty INT,
    LeadTimeDays INT DEFAULT 7,
    IsActive BIT DEFAULT 1,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    ModifiedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId)
);

CREATE INDEX IX_Products_ASIN ON dbo.Products(ASIN);
CREATE INDEX IX_Products_SKU ON dbo.Products(SKU);
CREATE INDEX IX_Products_SellerAccountId ON dbo.Products(SellerAccountId);

-- ============================================================================
-- SECTION 3: INVENTORY MANAGEMENT
-- ============================================================================

-- Inventory Snapshots - Daily inventory levels
CREATE TABLE dbo.InventorySnapshots (
    SnapshotId BIGINT IDENTITY(1,1) PRIMARY KEY,
    ProductId INT NOT NULL,
    SellerAccountId INT NOT NULL,
    SnapshotDate DATE NOT NULL,
    QtyFBA INT DEFAULT 0,
    QtyFBM INT DEFAULT 0,
    QtyInbound INT DEFAULT 0,
    QtyReserved INT DEFAULT 0,
    QtyUnfulfillable INT DEFAULT 0,
    QtyWarehouseAWD INT DEFAULT 0,  -- Amazon Warehousing & Distribution
    EstStorageCost DECIMAL(10,2),
    IPI_Score DECIMAL(5,2),
    DataSource NVARCHAR(50),  -- 'AMAZON_API', 'CSV_UPLOAD', 'MANUAL'
    FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId)
);

CREATE INDEX IX_InventorySnapshots_Date ON dbo.InventorySnapshots(SnapshotDate);
CREATE INDEX IX_InventorySnapshots_ProductId ON dbo.InventorySnapshots(ProductId);

-- Inventory Adjustments - Manual/adjustment tracking
CREATE TABLE dbo.InventoryAdjustments (
    AdjustmentId BIGINT IDENTITY(1,1) PRIMARY KEY,
    ProductId INT NOT NULL,
    SellerAccountId INT NOT NULL,
    AdjDate DATE NOT NULL,
    AdjReason NVARCHAR(100) NOT NULL,  -- LOST, DAMAGED, FOUND, RECount, OTHER
    QtyAdjusted INT NOT NULL,
    DispositionCode NVARCHAR(10),  -- SELLABLE, UNSELLABLE, DAMAGED
    FulfillmentCenterId NVARCHAR(50),
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId)
);

-- ============================================================================
-- SECTION 4: SALES HISTORY
-- ============================================================================

-- Sales Orders
CREATE TABLE dbo.SalesOrders (
    OrderId BIGINT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    AmazonOrderId NVARCHAR(50) NOT NULL UNIQUE,
    OrderDate DATETIME2 NOT NULL,
    ShipDate DATETIME2,
    FulfillmentChannel NVARCHAR(10),  -- AFN (FBA), MFN (FBM)
    OrderStatus NVARCHAR(20),  -- Pending, Shipped, Delivered, Cancelled
    TotalAmount DECIMAL(10,2),
    Currency NVARCHAR(3) DEFAULT 'USD',
    IsActive BIT DEFAULT 1,
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId)
);

CREATE INDEX IX_SalesOrders_AmazonOrderId ON dbo.SalesOrders(AmazonOrderId);
CREATE INDEX IX_SalesOrders_OrderDate ON dbo.SalesOrders(OrderDate);

-- Sales Order Items
CREATE TABLE dbo.SalesOrderItems (
    OrderItemId BIGINT IDENTITY(1,1) PRIMARY KEY,
    OrderId BIGINT NOT NULL,
    ProductId INT,
    ASIN NVARCHAR(20) NOT NULL,
    SKU NVARCHAR(100),
    QtySold INT NOT NULL,
    ItemPrice DECIMAL(10,2),
    PromotionDiscount DECIMAL(10,2) DEFAULT 0,
    ShippingPrice DECIMAL(10,2) DEFAULT 0,
    GiftWrapPrice DECIMAL(10,2) DEFAULT 0,
    FOREIGN KEY (OrderId) REFERENCES dbo.SalesOrders(OrderId),
    FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId)
);

-- ============================================================================
-- SECTION 5: FEES & FINANCIALS
-- ============================================================================

-- FBA Fees
CREATE TABLE dbo.FBAFees (
    FeeId BIGINT IDENTITY(1,1) PRIMARY KEY,
    ProductId INT NOT NULL,
    SellerAccountId INT NOT NULL,
    FeeDate DATE NOT NULL,
    FeeType NVARCHAR(50) NOT NULL,  -- ReferralFee, FBAFulfillment, Storage, LongTermStorage, Removal
    FeeAmount DECIMAL(10,2) NOT NULL,
    Currency NVARCHAR(3) DEFAULT 'USD',
    ReferenceId NVARCHAR(100),
    FulfillmentCenterId NVARCHAR(50),
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId)
);

CREATE INDEX IX_FBAFees_Date ON dbo.FBAFees(FeeDate);
CREATE INDEX IX_FBAFees_ProductId ON dbo.FBAFees(ProductId);

-- Profit & Loss
CREATE TABLE dbo.ProfitLoss (
    PLId BIGINT IDENTITY(1,1) PRIMARY KEY,
    ProductId INT,
    SellerAccountId INT NOT NULL,
    Period NVARCHAR(20) NOT NULL,  -- '2025-01', '2025-Q1', etc.
    Revenue DECIMAL(12,2) DEFAULT 0,
    COGS_Total DECIMAL(12,2) DEFAULT 0,
    FBAFees_Total DECIMAL(12,2) DEFAULT 0,
    PPC_Spend DECIMAL(12,2) DEFAULT 0,
    RefundsIssued DECIMAL(12,2) DEFAULT 0,
    ReimbursementsReceived DECIMAL(12,2) DEFAULT 0,
    NetProfit DECIMAL(12,2) DEFAULT 0,
    ACoS DECIMAL(8,2),
    TACoS DECIMAL(8,2),
    ROI DECIMAL(8,2),
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId)
);

CREATE INDEX IX_ProfitLoss_Period ON dbo.ProfitLoss(Period);

-- ============================================================================
-- SECTION 6: CASE MANAGEMENT
-- ============================================================================

-- Cases
CREATE TABLE dbo.Cases (
    CaseId INT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    AmazonCaseId NVARCHAR(50),
    CaseType NVARCHAR(50) NOT NULL,  -- LOST_INVENTORY, DAMAGED_INVENTORY, FEE_OVERCHARGE, etc.
    CaseCategory NVARCHAR(100),
    Status NVARCHAR(20) NOT NULL,  -- Open, PendingAmazon, Escalated, Resolved, Closed
    Priority NVARCHAR(10),  -- Low, Medium, High, Critical
    OpenedDate DATETIME2 DEFAULT SYSDATETIME(),
    ResolvedDate DATETIME2 NULL,
    ResolvedAmount DECIMAL(10,2),
    Subject NVARCHAR(500),
    Description NVARCHAR(MAX),
    AssignedUserId INT,  -- FK to Users
    EscalationLevel INT DEFAULT 0,
    POARequired BIT DEFAULT 0,
    POASubmittedDate DATETIME2,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    ModifiedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId),
    FOREIGN KEY (AssignedUserId) REFERENCES dbo.Users(UserId)
);

CREATE INDEX IX_Cases_Status ON dbo.Cases(Status);
CREATE INDEX IX_Cases_Type ON dbo.Cases(CaseType);

-- Case Notes
CREATE TABLE dbo.CaseNotes (
    NoteId INT IDENTITY(1,1) PRIMARY KEY,
    CaseId INT NOT NULL,
    UserId INT NOT NULL,
    NoteDate DATETIME2 DEFAULT SYSDATETIME(),
    NoteText NVARCHAR(MAX) NOT NULL,
    IsInternal BIT DEFAULT 1,  -- Internal notes not visible to Amazon
    FOREIGN KEY (CaseId) REFERENCES dbo.Cases(CaseId),
    FOREIGN KEY (UserId) REFERENCES dbo.Users(UserId)
);

-- Case Attachments
CREATE TABLE dbo.CaseAttachments (
    AttachmentId INT IDENTITY(1,1) PRIMARY KEY,
    CaseId INT NOT NULL,
    FileName NVARCHAR(255) NOT NULL,
    FilePath NVARCHAR(500) NOT NULL,
    FileSize INT,
    ContentType NVARCHAR(100),
    UploadDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (CaseId) REFERENCES dbo.Cases(CaseId)
);

-- ============================================================================
-- SECTION 7: REFUNDS & REIMBURSEMENTS
-- ============================================================================

-- Reimbursement Audit
CREATE TABLE dbo.ReimbursementAudit (
    AuditId BIGINT IDENTITY(1,1) PRIMARY KEY,
    ProductId INT NOT NULL,
    SellerAccountId INT NOT NULL,
    AuditDate DATE NOT NULL,
    AuditType NVARCHAR(50) NOT NULL,  -- LOST_INVENTORY, DAMAGED_INVENTORY, RETURNLESS_REFUND, FEE_OVERCHARGE
    QtyExpected INT,
    QtyAmazonReported INT,
    QtyVariance INT,
    ClaimableAmount DECIMAL(10,2),
    CostBasis DECIMAL(10,2),  -- Per-unit cost from Products.COGS
    Status NVARCHAR(20) DEFAULT 'Pending',  -- Pending, Claimed, Approved, Rejected, Expired
    LinkedCaseId INT,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId),
    FOREIGN KEY (LinkedCaseId) REFERENCES dbo.Cases(CaseId)
);

-- Reimbursements Received
CREATE TABLE dbo.Reimbursements (
    ReimbId BIGINT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    AmazonReimbId NVARCHAR(50),
    ReimbDate DATE NOT NULL,
    ProductId INT,
    QtyReimbursed INT,
    AmountPerUnit DECIMAL(10,2),
    TotalAmount DECIMAL(10,2),
    ReimbType NVARCHAR(50),  -- LOST, DAMAGED, RETURNLESS, FEE_ADJUSTMENT
    CaseId INT,
    ApprovalStatus NVARCHAR(20),  -- Pending, Approved, Rejected
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId),
    FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    FOREIGN KEY (CaseId) REFERENCES dbo.Cases(CaseId)
);

-- ============================================================================
-- SECTION 8: PPC / ADVERTISING
-- ============================================================================

-- PPC Campaigns
CREATE TABLE dbo.PPCCampaigns (
    CampaignId INT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    AmazonCampaignId NVARCHAR(50),
    CampaignName NVARCHAR(255) NOT NULL,
    CampaignType NVARCHAR(20),  -- SponsoredProducts, SponsoredBrands, SponsoredDisplay
    TargetingType NVARCHAR(20),  -- Automatic, Manual
    State NVARCHAR(20),  -- Enabled, Paused, Archived
    DailyBudget DECIMAL(10,2),
    StartDate DATE,
    EndDate DATE,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    ModifiedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId)
);

-- PPC Keywords
CREATE TABLE dbo.PPCKeywords (
    KeywordId BIGINT IDENTITY(1,1) PRIMARY KEY,
    CampaignId INT NOT NULL,
    AdGroupId NVARCHAR(50),
    KeywordText NVARCHAR(255) NOT NULL,
    MatchType NVARCHAR(10),  -- Exact, Phrase, Broad
    Bid DECIMAL(10,2),
    Impressions INT DEFAULT 0,
    Clicks INT DEFAULT 0,
    Spend DECIMAL(10,2) DEFAULT 0,
    Sales DECIMAL(10,2) DEFAULT 0,
    ACoS DECIMAL(8,2),
    ROAS DECIMAL(8,2),
    Period NVARCHAR(20) NOT NULL,  -- '2025-01-01' daily, '2025-01' monthly
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (CampaignId) REFERENCES dbo.PPCCampaigns(CampaignId)
);

CREATE INDEX IX_PPCKeywords_Period ON dbo.PPCKeywords(Period);

-- ============================================================================
-- SECTION 9: LISTINGS
-- ============================================================================

-- Listings
CREATE TABLE dbo.Listings (
    ListingId INT IDENTITY(1,1) PRIMARY KEY,
    ProductId INT NOT NULL,
    SellerAccountId INT NOT NULL,
    Title NVARCHAR(500),
    BulletPoints NVARCHAR(MAX),  -- JSON array stored as NVARCHAR
    Description NVARCHAR(MAX),
    APlusContent NVARCHAR(MAX),
    BackendKeywords NVARCHAR(MAX),
    SearchTerms NVARCHAR(MAX),
    BuyBoxPrice DECIMAL(10,2),
    LowestOfferPrice DECIMAL(10,2),
    BSR INT,
    CategoryBSR INT,
    ReviewCount INT DEFAULT 0,
    StarRating DECIMAL(2,1) DEFAULT 0,
    ListingStatus NVARCHAR(20) DEFAULT 'Active',  -- Active, Inactive, Suppressed
    SuppressedReason NVARCHAR(200),
    LastSyncDate DATETIME2,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    ModifiedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId)
);

-- ============================================================================
-- SECTION 10: RETURNS
-- ============================================================================

-- Returns
CREATE TABLE dbo.Returns (
    ReturnId BIGINT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    AmazonOrderId NVARCHAR(50) NOT NULL,
    ProductId INT,
    ReturnDate DATE NOT NULL,
    CustomerRefundDate DATE,
    ReturnReceivedDate DATE,
    ReturnStatus NVARCHAR(20),  -- Pending, InTransit, Received, Refunded
    ReturnReason NVARCHAR(200),
    Qty INT DEFAULT 1,
    RefundAmount DECIMAL(10,2),
    ReturnlessRefund BIT DEFAULT 0,  -- TRUE if refund issued without return
    DispositionCode NVARCHAR(10),  -- SELLABLE, UNSELLABLE, DAMAGED
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId),
    FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId)
);

-- ============================================================================
-- SECTION 11: CSV IMPORT TRACKING
-- ============================================================================

-- CSV Imports
CREATE TABLE dbo.CSVImports (
    ImportId BIGINT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    UserId INT NOT NULL,
    ImportDate DATETIME2 DEFAULT SYSDATETIME(),
    ReportType NVARCHAR(100) NOT NULL,  -- INVENTORY_SNAPSHOT, SALES, RETURNS, etc.
    FileName NVARCHAR(255) NOT NULL,
    FilePath NVARCHAR(500) NOT NULL,
    RowsTotal INT DEFAULT 0,
    RowsImported INT DEFAULT 0,
    RowsErrored INT DEFAULT 0,
    Status NVARCHAR(20) DEFAULT 'Pending',  -- Pending, Processing, Complete, Failed
    ErrorLog NVARCHAR(MAX),
    CompletedDate DATETIME2,
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId),
    FOREIGN KEY (UserId) REFERENCES dbo.Users(UserId)
);

CREATE INDEX IX_CSVImports_Date ON dbo.CSVImports(ImportDate);
CREATE INDEX IX_CSVImports_Status ON dbo.CSVImports(Status);

-- ============================================================================
-- SECTION 12: ALERTS & NOTIFICATIONS
-- ============================================================================

-- Alerts
CREATE TABLE dbo.Alerts (
    AlertId BIGINT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    AlertType NVARCHAR(50) NOT NULL,  -- LOW_STOCK, OVERSTOCK, STRANDED, AGED_FEE_RISK, etc.
    ProductId INT,
    CaseId INT,
    AlertDate DATETIME2 DEFAULT SYSDATETIME(),
    Message NVARCHAR(500) NOT NULL,
    Severity NVARCHAR(10),  -- Low, Medium, High, Critical
    IsRead BIT DEFAULT 0,
    ResolvedDate DATETIME2,
    ResolvedByUserId INT,
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId),
    FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    FOREIGN KEY (CaseId) REFERENCES dbo.Cases(CaseId)
);

CREATE INDEX IX_Alerts_Type ON dbo.Alerts(AlertType);
CREATE INDEX IX_Alerts_IsRead ON dbo.Alerts(IsRead);

-- ============================================================================
-- SECTION 13: NICHE / PRODUCT RESEARCH
-- ============================================================================

-- Niche Research
CREATE TABLE dbo.NicheResearch (
    NicheId INT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    UserId INT NOT NULL,
    ResearchDate DATE DEFAULT CAST(SYSDATETIME() AS DATE),
    Keyword NVARCHAR(255) NOT NULL,
    EstMonthlySearchVolume INT,
    CompetitorCount INT,
    AvgReviewCount INT,
    AvgPrice DECIMAL(10,2),
    EstRevenue DECIMAL(12,2),
    OpportunityScore INT,  -- 0-100
    Notes NVARCHAR(MAX),
    Status NVARCHAR(20) DEFAULT 'Researching',  -- Researching, Validated, Rejected
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId),
    FOREIGN KEY (UserId) REFERENCES dbo.Users(UserId)
);

-- ============================================================================
-- SECTION 14: VA TASK MANAGEMENT
-- ============================================================================

-- VA Tasks / SOPs
CREATE TABLE dbo.VATasks (
    TaskId INT IDENTITY(1,1) PRIMARY KEY,
    TaskName NVARCHAR(255) NOT NULL,
    TaskDescription NVARCHAR(MAX),
    Category NVARCHAR(100),  -- DAILY, WEEKLY, MONTHLY, CASE_MANAGEMENT
    Priority NVARCHAR(10),
    EstimatedMinutes INT,
    SOPContent NVARCHAR(MAX),  -- Step-by-step instructions
    IsActive BIT DEFAULT 1,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    ModifiedDate DATETIME2 DEFAULT SYSDATETIME()
);

-- VA Task Assignments
CREATE TABLE dbo.VATaskAssignments (
    AssignmentId INT IDENTITY(1,1) PRIMARY KEY,
    TaskId INT NOT NULL,
    UserId INT NOT NULL,  -- The VA assigned
    AssignedByUserId INT NOT NULL,  -- Who assigned
    DueDate DATE,
    CompletedDate DATETIME2,
    Status NVARCHAR(20) DEFAULT 'Pending',  -- Pending, InProgress, Completed
    Notes NVARCHAR(MAX),
    FOREIGN KEY (TaskId) REFERENCES dbo.VATasks(TaskId),
    FOREIGN KEY (UserId) REFERENCES dbo.Users(UserId)
);

-- ============================================================================
-- SECTION 15: EMAIL TEMPLATES (Seed Data)
-- ============================================================================

-- Email Templates
CREATE TABLE dbo.EmailTemplates (
    TemplateId INT IDENTITY(1,1) PRIMARY KEY,
    TemplateName NVARCHAR(255) NOT NULL,
    Category NVARCHAR(50) NOT NULL,  -- CASE_MANAGEMENT, BUYER, BRAND, OPERATIONS
    SubCategory NVARCHAR(100),
    SubjectLine NVARCHAR(500) NOT NULL,
    BodyContent NVARCHAR(MAX) NOT NULL,
    Tips NVARCHAR(MAX),
    IsActive BIT DEFAULT 1,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    ModifiedDate DATETIME2 DEFAULT SYSDATETIME()
);

-- ============================================================================
-- SECTION 16: HELP & USER GUIDE (Seed Data)
-- ============================================================================

-- Help Topics
CREATE TABLE dbo.HelpTopics (
    TopicId INT IDENTITY(1,1) PRIMARY KEY,
    Section NVARCHAR(100) NOT NULL,
    TopicName NVARCHAR(255) NOT NULL,
    WhatItDoes NVARCHAR(MAX) NOT NULL,
    WhenToUse NVARCHAR(MAX) NOT NULL,
    StepByStep NVARCHAR(MAX) NOT NULL,
    ProTip NVARCHAR(MAX),
    CommonMistake NVARCHAR(MAX),
    IsActive BIT DEFAULT 1,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME()
);

-- ============================================================================
-- SECTION 17: SETTINGS & CONFIGURATION
-- ============================================================================

-- Alert Thresholds
CREATE TABLE dbo.AlertThresholds (
    ThresholdId INT IDENTITY(1,1) PRIMARY KEY,
    SellerAccountId INT NOT NULL,
    AlertType NVARCHAR(50) NOT NULL,
    ThresholdValue DECIMAL(10,2) NOT NULL,
    IsEnabled BIT DEFAULT 1,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts(SellerAccountId)
);

-- Audit Log
CREATE TABLE dbo.AuditLog (
    AuditLogId BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId INT,
    ActionType NVARCHAR(50) NOT NULL,
    TableName NVARCHAR(100),
    RecordId INT,
    OldValue NVARCHAR(MAX),
    NewValue NVARCHAR(MAX),
    IpAddress NVARCHAR(50),
    ActionDate DATETIME2 DEFAULT SYSDATETIME(),
    FOREIGN KEY (UserId) REFERENCES dbo.Users(UserId)
);

-- ============================================================================
-- SEED DATA: Marketplaces, Roles, Default Settings
-- ============================================================================

-- Seed Marketplaces
INSERT INTO dbo.Marketplaces (MarketplaceName, RegionCode, CurrencyCode, Domain) VALUES
('United States', 'US', 'USD', 'www.amazon.com'),
('Canada', 'CA', 'CAD', 'www.amazon.ca'),
('United Kingdom', 'UK', 'GBP', 'www.amazon.co.uk'),
('Germany', 'DE', 'EUR', 'www.amazon.de'),
('France', 'FR', 'EUR', 'www.amazon.fr'),
('Italy', 'IT', 'EUR', 'www.amazon.it'),
('Spain', 'ES', 'EUR', 'www.amazon.es'),
('Japan', 'JP', 'JPY', 'www.amazon.co.jp'),
('Australia', 'AU', 'AUD', 'www.amazon.com.au'),
('Mexico', 'MX', 'MXN', 'www.amazon.com.mx');

-- Seed Roles
INSERT INTO dbo.Roles (RoleName, RoleDescription) VALUES
('Admin', 'Full system access, can manage users and all accounts'),
('AccountManager', 'Can manage all aspects of assigned seller accounts'),
('Analyst', 'Can view reports and data, cannot make changes'),
('VAReadOnly', 'Virtual Assistant with read-only access to assigned accounts');

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================
PRINT 'Database schema created successfully.';