using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class PPCViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private decimal _adSpend30d;

    [ObservableProperty]
    private decimal _attributedSales;

    [ObservableProperty]
    private decimal _aCOS;

    [ObservableProperty]
    private ObservableCollection<CampaignItem> _campaigns = new();

    [ObservableProperty]
    private bool _isLoading;

    public PPCViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadDataAsync();
    }

    [RelayCommand]
    public async Task LoadDataAsync()
    {
        IsLoading = true;
        try
        {
            var summary = await _apiService.GetPpcSummaryAsync();
            if (summary != null)
            {
                AdSpend30d = summary.AdSpend30d;
                AttributedSales = summary.AttributedSales;
                ACOS = summary.ACOS;
            }

            var campaigns = await _apiService.GetCampaignsAsync();
            Campaigns = new ObservableCollection<CampaignItem>(
                campaigns.Select(c => new CampaignItem
                {
                    CampaignName = c.CampaignName,
                    Status = c.Status,
                    Spend = c.Spend,
                    Sales = c.Sales,
                    ACOS = c.ACOS,
                    Clicks = c.Clicks
                }));
        }
        finally
        {
            IsLoading = false;
        }
    }
}

public class CampaignItem
{
    public string CampaignName { get; set; } = "";
    public string Status { get; set; } = "";
    public decimal Spend { get; set; }
    public decimal Sales { get; set; }
    public decimal ACOS { get; set; }
    public int Clicks { get; set; }
}

public class PpcSummaryDto
{
    public decimal AdSpend30d { get; set; }
    public decimal AttributedSales { get; set; }
    public decimal ACOS { get; set; }
}

public class CampaignDto
{
    public string CampaignName { get; set; } = "";
    public string Status { get; set; } = "";
    public decimal Spend { get; set; }
    public decimal Sales { get; set; }
    public decimal ACOS { get; set; }
    public int Clicks { get; set; }
}