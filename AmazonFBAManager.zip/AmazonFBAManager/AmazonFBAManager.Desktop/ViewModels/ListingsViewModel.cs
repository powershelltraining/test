using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class ListingsViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private ObservableCollection<SuppressedListingItem> _suppressedListings = new();

    [ObservableProperty]
    private ObservableCollection<ProductListItem> _productList = new();

    [ObservableProperty]
    private bool _isLoading;

    public ListingsViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadDataAsync();
    }

    [RelayCommand]
    public async Task LoadDataAsync()
    {
        IsLoading = true;
        try
        {
            var suppressed = await _apiService.GetSuppressedListingsAsync();
            SuppressedListings = new ObservableCollection<SuppressedListingItem>(
                suppressed.Select(s => new SuppressedListingItem
                {
                    SKU = s.SKU,
                    ProductName = s.ProductName,
                    Issue = s.Issue,
                    MissingInfo = s.MissingInfo
                }));

            var products = await _apiService.GetProductListAsync();
            ProductList = new ObservableCollection<ProductListItem>(
                products.Select(p => new ProductListItem
                {
                    SKU = p.SKU,
                    ASIN = p.ASIN,
                    ProductName = p.ProductName,
                    Price = p.Price,
                    Stock = p.Stock,
                    Status = p.Status
                }));
        }
        finally
        {
            IsLoading = false;
        }
    }
}

public class SuppressedListingItem
{
    public string SKU { get; set; } = "";
    public string ProductName { get; set; } = "";
    public string Issue { get; set; } = "";
    public string MissingInfo { get; set; } = "";
}

public class ProductListItem
{
    public string SKU { get; set; } = "";
    public string ASIN { get; set; } = "";
    public string ProductName { get; set; } = "";
    public decimal Price { get; set; }
    public int Stock { get; set; }
    public string Status { get; set; } = "";
}

public class SuppressedListingDto
{
    public string SKU { get; set; } = "";
    public string ProductName { get; set; } = "";
    public string Issue { get; set; } = "";
    public string MissingInfo { get; set; } = ""
}

public class ProductListDto
{
    public string SKU { get; set; } = "";
    public string ASIN { get; set; } = "";
    public string ProductName { get; set; } = "";
    public decimal Price { get; set; }
    public int Stock { get; set; }
    public string Status { get; set; } = "";
}