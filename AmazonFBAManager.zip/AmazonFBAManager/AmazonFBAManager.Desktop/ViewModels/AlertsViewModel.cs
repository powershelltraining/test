using System.Collections.ObjectModel;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class AlertsViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private ObservableCollection<ActiveAlertItem> _activeAlerts = new();

    [ObservableProperty]
    private ObservableCollection<AlertHistoryItem> _alertHistory = new();

    [ObservableProperty]
    private bool _isLoading;

    public AlertsViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadDataAsync();
    }

    [RelayCommand]
    public async Task LoadDataAsync()
    {
        IsLoading = true;
        try
        {
            var alerts = await _apiService.GetAlertsAsync();

            ActiveAlerts = new ObservableCollection<ActiveAlertItem>(
                alerts.Where(a => a.Status == "Active").Select(a => new ActiveAlertItem
                {
                    Id = a.Id,
                    Icon = GetAlertIcon(a.AlertType),
                    Title = a.Title,
                    Description = a.Description,
                    SeverityColor = GetSeverityBrush(a.AlertType),
                    CreatedAt = a.CreatedAt.ToString("MM/dd/yyyy HH:mm")
                }));

            AlertHistory = new ObservableCollection<AlertHistoryItem>(
                alerts.Select(a => new AlertHistoryItem
                {
                    CreatedAt = a.CreatedAt.ToString("MM/dd/yyyy"),
                    AlertType = a.AlertType,
                    Title = a.Title,
                    Status = a.Status
                }));
        }
        finally
        {
            IsLoading = false;
        }
    }

    private static string GetAlertIcon(string alertType) => alertType switch
    {
        "Inventory" => "📦",
        "Case" => "📋",
        "Reimbursement" => "💰",
        "Listing" => "🏷️",
        "PPC" => "📢",
        _ => "🔔"
    };

    private static string GetSeverityBrush(string alertType) => alertType switch
    {
        "Inventory" => "#FF4CAF50",
        "Case" => "#FFFF9800",
        "Reimbursement" => "#FF2196F3",
        _ => "#FF9E9E9E"
    };
}

public class ActiveAlertItem
{
    public int Id { get; set; }
    public string Icon { get; set; } = "";
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string SeverityColor { get; set; } = "";
    public string CreatedAt { get; set; } = "";

    public ICommand? ViewCommand { get; set; }
}

public class AlertHistoryItem
{
    public string CreatedAt { get; set; } = "";
    public string AlertType { get; set; } = "";
    public string Title { get; set; } = "";
    public string Status { get; set; } = "";
}