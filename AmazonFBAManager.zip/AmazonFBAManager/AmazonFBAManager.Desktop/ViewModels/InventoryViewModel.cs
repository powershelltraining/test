using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class InventoryViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private ObservableCollection<ReorderSuggestion> _reorderSuggestions = new();

    [ObservableProperty]
    private ObservableCollection<AgedInventoryItem> _agedInventory = new();

    [ObservableProperty]
    private bool _isLoading;

    public InventoryViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadDataAsync();
    }

    [RelayCommand]
    public async Task LoadDataAsync()
    {
        IsLoading = true;
        try
        {
            var suggestions = await _apiService.GetReorderSuggestionsAsync();
            ReorderSuggestions = new ObservableCollection<ReorderSuggestion>(suggestions);

            var aged = await _apiService.GetAgedInventoryAsync();
            AgedInventory = new ObservableCollection<AgedInventoryItem>(aged);
        }
        finally
        {
            IsLoading = false;
        }
    }
}

public class ReorderSuggestion
{
    public string SKU { get; set; } = "";
    public string ProductName { get; set; } = "";
    public int CurrentStock { get; set; }
    public int SuggestedReorder { get; set; }
    public int DaysOfSupply { get; set; }
}

public class AgedInventoryItem
{
    public string SKU { get; set; } = "";
    public string ProductName { get; set; } = "";
    public int Quantity { get; set; }
    public int DaysInStock { get; set; }
    public decimal EstStorageFee { get; set; }
}