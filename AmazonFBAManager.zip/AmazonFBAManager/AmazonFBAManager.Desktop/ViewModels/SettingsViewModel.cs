using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class SettingsViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private string _email = "";

    [ObservableProperty]
    private string _fullName = "";

    [ObservableProperty]
    private string _selectedTimeZone = "Eastern Time (ET)";

    public ObservableCollection<string> TimeZones { get; } = new()
    {
        "Eastern Time (ET)",
        "Central Time (CT)",
        "Mountain Time (MT)",
        "Pacific Time (PT)",
        "Alaska Time (AKT)",
        "Hawaii Time (HT)"
    };

    [ObservableProperty]
    private bool _lowInventoryAlerts = true;

    [ObservableProperty]
    private bool _caseAlerts = true;

    [ObservableProperty]
    private bool _reimbursementAlerts = true;

    [ObservableProperty]
    private bool _dailySummary;

    [ObservableProperty]
    private ObservableCollection<AccountItem> _sellerAccounts = new();

    [ObservableProperty]
    private bool _isLoading;

    public SettingsViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadDataAsync();
    }

    [RelayCommand]
    public async Task LoadDataAsync()
    {
        IsLoading = true;
        try
        {
            var user = await _sessionService.GetCurrentUserAsync();
            if (user != null)
            {
                Email = user.Email ?? "";
                FullName = user.FullName ?? "";
            }

            var accounts = await _apiService.GetSellerAccountsAsync();
            SellerAccounts = new ObservableCollection<AccountItem>(
                accounts.Select(a => new AccountItem
                {
                    SellerName = a.SellerName,
                    SellerId = a.SellerId,
                    Marketplace = a.Marketplace
                }));
        }
        finally
        {
            IsLoading = false;
        }
    }

    [RelayCommand]
    private async Task SaveSettingsAsync()
    {
        var result = await _apiService.UpdateUserSettingsAsync(new UserSettingsDto
        {
            Email = Email,
            FullName = FullName,
            TimeZone = SelectedTimeZone
        });

        if (result)
        {
            // Show success message
        }
    }

    [RelayCommand]
    private async Task SaveAlertsAsync()
    {
        var result = await _apiService.UpdateAlertPreferencesAsync(new AlertPreferencesDto
        {
            LowInventoryAlerts = LowInventoryAlerts,
            CaseAlerts = CaseAlerts,
            ReimbursementAlerts = ReimbursementAlerts,
            DailySummary = DailySummary
        });

        if (result)
        {
            // Show success message
        }
    }

    [RelayCommand]
    private void AddAccount()
    {
        // Would open a dialog to add a new Amazon seller account
    }
}

public class AccountItem
{
    public string SellerName { get; set; } = "";
    public string SellerId { get; set; } = "";
    public string Marketplace { get; set; } = "";
}

public class UserSettingsDto
{
    public string Email { get; set; } = "";
    public string FullName { get; set; } = "";
    public string TimeZone { get; set; } = "";
}

public class AlertPreferencesDto
{
    public bool LowInventoryAlerts { get; set; }
    public bool CaseAlerts { get; set; }
    public bool ReimbursementAlerts { get; set; }
    public bool DailySummary { get; set; }
}