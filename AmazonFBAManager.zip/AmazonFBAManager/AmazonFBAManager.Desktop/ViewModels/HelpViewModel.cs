using CommunityToolkit.Mvvm.ComponentModel;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class HelpViewModel : ObservableObject
{
    // Help content is displayed directly in the XAML DataTemplate
    // This ViewModel can be extended to load dynamic help content from API
}