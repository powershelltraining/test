using System.Collections.ObjectModel;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class MainWindowViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;
    private readonly Window _window;

    [ObservableProperty]
    private ObservableCollection<SellerAccount> _accounts = new();

    [ObservableProperty]
    private SellerAccount? _selectedAccount;

    [ObservableProperty]
    private string _currentUserName = string.Empty;

    [ObservableProperty]
    private string _currentUserEmail = string.Empty;

    [ObservableProperty]
    private string _pageTitle = "Dashboard";

    [ObservableProperty]
    private string _lastSyncTime = "Last sync: Never";

    [ObservableProperty]
    private object? _currentPage;

    [ObservableProperty]
    private DashboardViewModel? _dashboardViewModel;

    [ObservableProperty]
    private InventoryViewModel? _inventoryViewModel;

    [ObservableProperty]
    private CasesViewModel? _casesViewModel;

    [ObservableProperty]
    private ReimbursementsViewModel? _reimbursementsViewModel;

    [ObservableProperty]
    private SalesViewModel? _salesViewModel;

    [ObservableProperty]
    private PPCViewModel? _ppcViewModel;

    [ObservableProperty]
    private ListingsViewModel? _listingsViewModel;

    [ObservableProperty]
    private AlertsViewModel? _alertsViewModel;

    [ObservableProperty]
    private UploadViewModel? _uploadViewModel;

    [ObservableProperty]
    private ReportsViewModel? _reportsViewModel;

    [ObservableProperty]
    private SettingsViewModel? _settingsViewModel;

    [ObservableProperty]
    private HelpViewModel? _helpViewModel;

    public MainWindowViewModel(ISessionService sessionService, IApiService apiService, Window window)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _window = window;

        LoadUserInfo();
        LoadAccounts();

        // Initialize ViewModels
        DashboardViewModel = new DashboardViewModel(_sessionService, _apiService);
        InventoryViewModel = new InventoryViewModel(_sessionService, _apiService);
        CasesViewModel = new CasesViewModel(_sessionService, _apiService);
        ReimbursementsViewModel = new ReimbursementsViewModel(_sessionService, _apiService);
        SalesViewModel = new SalesViewModel(_sessionService, _apiService);
        PPCViewModel = new PPCViewModel(_sessionService, _apiService);
        ListingsViewModel = new ListingsViewModel(_sessionService, _apiService);
        AlertsViewModel = new AlertsViewModel(_sessionService, _apiService);
        UploadViewModel = new UploadViewModel(_sessionService, _apiService);
        ReportsViewModel = new ReportsViewModel(_sessionService, _apiService);
        SettingsViewModel = new SettingsViewModel(_sessionService, _apiService);
        HelpViewModel = new HelpViewModel();

        // Default to dashboard
        CurrentPage = DashboardViewModel;
    }

    private async void LoadUserInfo()
    {
        var user = await _sessionService.GetCurrentUserAsync();
        if (user != null)
        {
            CurrentUserName = user.FullName ?? "User";
            CurrentUserEmail = user.Email ?? "";
        }
    }

    private async void LoadAccounts()
    {
        var accounts = await _apiService.GetSellerAccountsAsync();
        Accounts = new ObservableCollection<SellerAccount>(accounts);
        if (Accounts.Count > 0)
        {
            SelectedAccount = Accounts[0];
            await _sessionService.SetCurrentAccountAsync(SelectedAccount.SellerId);
        }
    }

    partial void OnSelectedAccountChanged(SellerAccount? value)
    {
        if (value != null)
        {
            _sessionService.SetCurrentAccountAsync(value.SellerId).ConfigureAwait(false);
            RefreshCommand.Execute(null);
        }
    }

    [RelayCommand]
    private void Navigate(string page)
    {
        PageTitle = page switch
        {
            "Dashboard" => "Dashboard",
            "Inventory" => "Inventory",
            "Cases" => "Cases",
            "Reimbursements" => "Reimbursements",
            "Sales" => "Sales",
            "PPC" => "PPC Advertising",
            "Listings" => "Listings",
            "Alerts" => "Alerts",
            "Upload" => "Upload Data",
            "Reports" => "Reports",
            "Settings" => "Settings",
            "Help" => "Help",
            _ => page
        };

        CurrentPage = page switch
        {
            "Dashboard" => DashboardViewModel,
            "Inventory" => InventoryViewModel,
            "Cases" => CasesViewModel,
            "Reimbursements" => ReimbursementsViewModel,
            "Sales" => SalesViewModel,
            "PPC" => PPCViewModel,
            "Listings" => ListingsViewModel,
            "Alerts" => AlertsViewModel,
            "Upload" => UploadViewModel,
            "Reports" => ReportsViewModel,
            "Settings" => SettingsViewModel,
            "Help" => HelpViewModel,
            _ => DashboardViewModel
        };
    }

    [RelayCommand]
    private async Task Refresh()
    {
        LastSyncTime = $"Last sync: {DateTime.Now:HH:mm}";
        await DashboardViewModel!.LoadDataAsync();
        await InventoryViewModel!.LoadDataAsync();
        await CasesViewModel!.LoadDataAsync();
        await ReimbursementsViewModel!.LoadDataAsync();
        await SalesViewModel!.LoadDataAsync();
        await PPCViewModel!.LoadDataAsync();
        await ListingsViewModel!.LoadDataAsync();
        await AlertsViewModel!.LoadDataAsync();
    }

    [RelayCommand]
    private void Logout()
    {
        _sessionService.Logout();
        var loginWindow = new LoginWindow();
        loginWindow.Show();
        _window.Close();
    }

    public void HandleFileDrop(string filePath)
    {
        Navigate("Upload");
        UploadViewModel?.HandleFileDrop(filePath);
    }
}

public class SellerAccount
{
    public int Id { get; set; }
    public string SellerId { get; set; } = string.Empty;
    public string SellerName { get; set; } = string.Empty;
    public string Marketplace { get; set; } = string.Empty;
}