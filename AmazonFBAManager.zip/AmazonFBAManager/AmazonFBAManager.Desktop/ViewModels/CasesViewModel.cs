using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class CasesViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private ObservableCollection<CaseItem> _openCases = new();

    [ObservableProperty]
    private ObservableCollection<CaseItem> _caseHistory = new();

    [ObservableProperty]
    private bool _isLoading;

    public CasesViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadDataAsync();
    }

    [RelayCommand]
    public async Task LoadDataAsync()
    {
        IsLoading = true;
        try
        {
            var openCases = await _apiService.GetOpenCasesAsync();
            OpenCases = new ObservableCollection<CaseItem>(openCases.Select(c => new CaseItem
            {
                CaseId = c.CaseId,
                CaseType = c.CaseType,
                Subject = c.Subject,
                Status = c.Status,
                DaysOpen = c.DaysOpen,
                ClosedDate = ""
            }));

            var history = await _apiService.GetCaseHistoryAsync();
            CaseHistory = new ObservableCollection<CaseItem>(history.Select(c => new CaseItem
            {
                CaseId = c.CaseId,
                CaseType = c.CaseType,
                Subject = c.Subject,
                Status = c.Status,
                Resolution = c.Resolution,
                ClosedDate = c.ClosedDate?.ToString("MM/dd/yyyy") ?? ""
            }));
        }
        finally
        {
            IsLoading = false;
        }
    }

    [RelayCommand]
    private void NewCase()
    {
        // Would open a dialog to create new case
    }
}

public class CaseItem
{
    public string CaseId { get; set; } = "";
    public string CaseType { get; set; } = "";
    public string Subject { get; set; } = "";
    public string Status { get; set; } = "";
    public int DaysOpen { get; set; }
    public string Resolution { get; set; } = "";
    public string ClosedDate { get; set; } = "";
}

public class CaseDto
{
    public string CaseId { get; set; } = "";
    public string CaseType { get; set; } = "";
    public string Subject { get; set; } = "";
    public string Status { get; set; } = "";
    public int DaysOpen { get; set; }
    public string? Resolution { get; set; }
    public DateTime? ClosedDate { get; set; }
}