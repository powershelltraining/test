using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;
using Microsoft.Win32;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class UploadViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private string? _selectedFile;

    [ObservableProperty]
    private bool _isUploading;

    [ObservableProperty]
    private string _uploadStatus = "";

    [ObservableProperty]
    private bool _uploadHistoryVisibility = true;

    [ObservableProperty]
    private ObservableCollection<UploadHistoryItem> _uploadHistory = new();

    public UploadViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadUploadHistoryAsync();
    }

    [RelayCommand]
    private async Task BrowseAsync()
    {
        var dialog = new OpenFileDialog
        {
            Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*",
            Title = "Select CSV File to Upload"
        };

        if (dialog.ShowDialog() == true)
        {
            SelectedFile = dialog.FileName;
            await UploadFileAsync(dialog.FileName);
        }
    }

    public async Task HandleFileDrop(string filePath)
    {
        var extension = Path.GetExtension(filePath).ToLower();
        if (extension == ".csv")
        {
            SelectedFile = filePath;
            await UploadFileAsync(filePath);
        }
        else
        {
            UploadStatus = "Error: Only CSV files are supported.";
        }
    }

    private async Task UploadFileAsync(string filePath)
    {
        if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath))
        {
            UploadStatus = "Error: File not found.";
            return;
        }

        IsUploading = true;
        UploadStatus = "Uploading...";

        try
        {
            var fileName = Path.GetFileName(filePath);
            var result = await _apiService.UploadInventoryCsvAsync(filePath);

            if (result.Success)
            {
                UploadStatus = $"Success! {result.RecordCount} records imported.";
                await LoadUploadHistoryAsync();
            }
            else
            {
                UploadStatus = $"Error: {result.ErrorMessage}";
            }
        }
        catch (Exception ex)
        {
            UploadStatus = $"Error: {ex.Message}";
        }
        finally
        {
            IsUploading = false;
        }
    }

    private async Task LoadUploadHistoryAsync()
    {
        var history = await _apiService.GetUploadHistoryAsync();
        UploadHistory = new ObservableCollection<UploadHistoryItem>(
            history.Select(h => new UploadHistoryItem
            {
                UploadDate = h.UploadDate.ToString("MM/dd/yyyy HH:mm"),
                FileName = h.FileName,
                RecordCount = h.RecordCount,
                Status = h.Status
            }));
    }
}

public class UploadHistoryItem
{
    public string UploadDate { get; set; } = "";
    public string FileName { get; set; } = "";
    public int RecordCount { get; set; }
    public string Status { get; set; } = "";
}

public class UploadHistoryDto
{
    public DateTime UploadDate { get; set; }
    public string FileName { get; set; } = "";
    public int RecordCount { get; set; }
    public string Status { get; set; } = "";
}

public class UploadResult
{
    public bool Success { get; set; }
    public int RecordCount { get; set; }
    public string ErrorMessage { get; set; } = "";
}