using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class ReportsViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private ObservableCollection<SavedReportItem> _savedReports = new();

    [ObservableProperty]
    private bool _isLoading;

    [ObservableProperty]
    private string _statusMessage = "";

    public ReportsViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadDataAsync();
    }

    [RelayCommand]
    public async Task LoadDataAsync()
    {
        IsLoading = true;
        try
        {
            var reports = await _apiService.GetSavedReportsAsync();
            SavedReports = new ObservableCollection<SavedReportItem>(
                reports.Select(r => new SavedReportItem
                {
                    ReportName = r.ReportName,
                    ReportType = r.ReportType,
                    GeneratedAt = r.GeneratedAt.ToString("MM/dd/yyyy HH:mm")
                }));
        }
        finally
        {
            IsLoading = false;
        }
    }

    [RelayCommand]
    private async Task InventoryReportAsync()
    {
        StatusMessage = "Generating Inventory Report...";
        await _apiService.GenerateInventoryReportAsync();
        StatusMessage = "Inventory report generated successfully.";
        await LoadDataAsync();
    }

    [RelayCommand]
    private async Task SalesReportAsync()
    {
        StatusMessage = "Generating Sales Report...";
        await _apiService.GenerateSalesReportAsync();
        StatusMessage = "Sales report generated successfully.";
        await LoadDataAsync();
    }

    [RelayCommand]
    private async Task ReimbursementReportAsync()
    {
        StatusMessage = "Generating Reimbursement Report...";
        await _apiService.GenerateReimbursementReportAsync();
        StatusMessage = "Reimbursement report generated successfully.";
        await LoadDataAsync();
    }

    [RelayCommand]
    private async Task CaseReportAsync()
    {
        StatusMessage = "Generating Case Report...";
        await _apiService.GenerateCaseReportAsync();
        StatusMessage = "Case report generated successfully.";
        await LoadDataAsync();
    }

    [RelayCommand]
    private async Task PPCReportAsync()
    {
        StatusMessage = "Generating PPC Report...";
        await _apiService.GeneratePpcReportAsync();
        StatusMessage = "PPC report generated successfully.";
        await LoadDataAsync();
    }
}

public class SavedReportItem
{
    public string ReportName { get; set; } = "";
    public string ReportType { get; set; } = "";
    public string GeneratedAt { get; set; } = "";
}

public class SavedReportDto
{
    public string ReportName { get; set; } = "";
    public string ReportType { get; set; } = "";
    public DateTime GeneratedAt { get; set; }
}