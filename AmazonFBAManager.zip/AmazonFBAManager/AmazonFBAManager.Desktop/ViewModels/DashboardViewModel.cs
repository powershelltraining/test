using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class DashboardViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private int _activeListings;

    [ObservableProperty]
    private string _activeListingsChange = "";

    [ObservableProperty]
    private int _openCases;

    [ObservableProperty]
    private string _openCasesChange = "";

    [ObservableProperty]
    private decimal _pendingReimbursements;

    [ObservableProperty]
    private string _reimbursementChange = "";

    [ObservableProperty]
    private decimal _totalSales30d;

    [ObservableProperty]
    private string _salesChange = "";

    [ObservableProperty]
    private ObservableCollection<AlertItem> _recentAlerts = new();

    [ObservableProperty]
    private ObservableCollection<ActivityItem> _recentActivity = new();

    [ObservableProperty]
    private bool _isLoading;

    public DashboardViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadDataAsync();
    }

    [RelayCommand]
    public async Task LoadDataAsync()
    {
        IsLoading = true;
        try
        {
            var summary = await _apiService.GetDashboardSummaryAsync();
            if (summary != null)
            {
                ActiveListings = summary.ActiveListings;
                ActiveListingsChange = summary.ActiveListingsChange;
                OpenCases = summary.OpenCases;
                OpenCasesChange = summary.OpenCasesChange;
                PendingReimbursements = summary.PendingReimbursements;
                ReimbursementChange = summary.ReimbursementChange;
                TotalSales30d = summary.TotalSales30d;
                SalesChange = summary.SalesChange;
            }

            var alerts = await _apiService.GetAlertsAsync();
            RecentAlerts = new ObservableCollection<AlertItem>(
                alerts.Where(a => a.Status == "Active").Take(5).Select(a => new AlertItem
                {
                    Icon = a.AlertType switch
                    {
                        "Inventory" => "📦",
                        "Case" => "📋",
                        "Reimbursement" => "💰",
                        _ => "🔔"
                    },
                    Message = a.Title,
                    TimeAgo = GetTimeAgo(a.CreatedAt)
                }));

            var activity = await _apiService.GetRecentActivityAsync();
            RecentActivity = new ObservableCollection<ActivityItem>(
                activity.Take(10).Select(a => new ActivityItem
                {
                    ActivityDate = a.ActivityDate.ToString("MM/dd/yyyy"),
                    ActivityType = a.ActivityType,
                    Description = a.Description,
                    AccountName = a.AccountName
                }));
        }
        finally
        {
            IsLoading = false;
        }
    }

    private static string GetTimeAgo(DateTime dateTime)
    {
        var span = DateTime.Now - dateTime;
        if (span.TotalMinutes < 60)
            return $"{(int)span.TotalMinutes}m ago";
        if (span.TotalHours < 24)
            return $"{(int)span.TotalHours}h ago";
        if (span.TotalDays < 7)
            return $"{(int)span.TotalDays}d ago";
        return dateTime.ToString("MM/dd/yyyy");
    }
}

public class AlertItem
{
    public string Icon { get; set; } = "";
    public string Message { get; set; } = "";
    public string TimeAgo { get; set; } = "";
}

public class ActivityItem
{
    public string ActivityDate { get; set; } = "";
    public string ActivityType { get; set; } = "";
    public string Description { get; set; } = "";
    public string AccountName { get; set; } = "";
}

public class DashboardSummary
{
    public int ActiveListings { get; set; }
    public string ActiveListingsChange { get; set; } = "";
    public int OpenCases { get; set; }
    public string OpenCasesChange { get; set; } = "";
    public decimal PendingReimbursements { get; set; }
    public string ReimbursementChange { get; set; } = "";
    public decimal TotalSales30d { get; set; }
    public string SalesChange { get; set; } = "";
}

public class AlertDto
{
    public int Id { get; set; }
    public string AlertType { get; set; } = "";
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string Status { get; set; } = "";
    public DateTime CreatedAt { get; set; }
}

public class ActivityDto
{
    public DateTime ActivityDate { get; set; }
    public string ActivityType { get; set; } = "";
    public string Description { get; set; } = "";
    public string AccountName { get; set; } = "";
}