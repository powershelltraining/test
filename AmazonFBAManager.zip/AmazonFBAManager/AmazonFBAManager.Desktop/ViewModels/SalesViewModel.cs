using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class SalesViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private ObservableCollection<SalesSummaryItem> _salesSummary = new();

    [ObservableProperty]
    private ObservableCollection<TopProductItem> _topProducts = new();

    [ObservableProperty]
    private bool _isLoading;

    public SalesViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadDataAsync();
    }

    [RelayCommand]
    public async Task LoadDataAsync()
    {
        IsLoading = true;
        try
        {
            var summary = await _apiService.GetSalesSummaryAsync();
            SalesSummary = new ObservableCollection<SalesSummaryItem>(
                summary.Select(s => new SalesSummaryItem
                {
                    Period = s.Period,
                    Revenue = s.Revenue,
                    UnitsSold = s.UnitsSold,
                    AvgOrderValue = s.AvgOrderValue,
                    Refunds = s.Refunds
                }));

            var products = await _apiService.GetTopProductsAsync();
            TopProducts = new ObservableCollection<TopProductItem>(
                products.Select(p => new TopProductItem
                {
                    SKU = p.SKU,
                    ProductName = p.ProductName,
                    UnitsSold = p.UnitsSold,
                    Revenue = p.Revenue,
                    Growth = p.Growth
                }));
        }
        finally
        {
            IsLoading = false;
        }
    }
}

public class SalesSummaryItem
{
    public string Period { get; set; } = "";
    public decimal Revenue { get; set; }
    public int UnitsSold { get; set; }
    public decimal AvgOrderValue { get; set; }
    public decimal Refunds { get; set; }
}

public class TopProductItem
{
    public string SKU { get; set; } = "";
    public string ProductName { get; set; } = "";
    public int UnitsSold { get; set; }
    public decimal Revenue { get; set; }
    public decimal Growth { get; set; }
}

public class SalesSummaryDto
{
    public string Period { get; set; } = "";
    public decimal Revenue { get; set; }
    public int UnitsSold { get; set; }
    public decimal AvgOrderValue { get; set; }
    public decimal Refunds { get; set; }
}

public class TopProductDto
{
    public string SKU { get; set; } = "";
    public string ProductName { get; set; } = "";
    public int UnitsSold { get; set; }
    public decimal Revenue { get; set; }
    public decimal Growth { get; set; }
}