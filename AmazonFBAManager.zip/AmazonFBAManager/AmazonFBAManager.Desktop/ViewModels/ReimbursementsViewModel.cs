using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop.ViewModels;

public partial class ReimbursementsViewModel : ObservableObject
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    [ObservableProperty]
    private decimal _lostDamaged;

    [ObservableProperty]
    private decimal _feeOvercharges;

    [ObservableProperty]
    private decimal _pendingClaims;

    [ObservableProperty]
    private ObservableCollection<ReimbursementItem> _recentReimbursements = new();

    [ObservableProperty]
    private bool _isLoading;

    public ReimbursementsViewModel(ISessionService sessionService, IApiService apiService)
    {
        _sessionService = sessionService;
        _apiService = apiService;
        _ = LoadDataAsync();
    }

    [RelayCommand]
    public async Task LoadDataAsync()
    {
        IsLoading = true;
        try
        {
            var summary = await _apiService.GetReimbursementSummaryAsync();
            if (summary != null)
            {
                LostDamaged = summary.LostDamaged;
                FeeOvercharges = summary.FeeOvercharges;
                PendingClaims = summary.PendingClaims;
            }

            var reimbursements = await _apiService.GetReimbursementsAsync();
            RecentReimbursements = new ObservableCollection<ReimbursementItem>(
                reimbursements.Select(r => new ReimbursementItem
                {
                    ApprovalDate = r.ApprovalDate?.ToString("MM/dd/yyyy") ?? "",
                    ReimbursementType = r.ReimbursementType,
                    SKU = r.SKU,
                    Amount = r.Amount,
                    Status = r.Status
                }));
        }
        finally
        {
            IsLoading = false;
        }
    }
}

public class ReimbursementItem
{
    public string ApprovalDate { get; set; } = "";
    public string ReimbursementType { get; set; } = "";
    public string SKU { get; set; } = "";
    public decimal Amount { get; set; }
    public string Status { get; set; } = "";
}

public class ReimbursementSummaryDto
{
    public decimal LostDamaged { get; set; }
    public decimal FeeOvercharges { get; set; }
    public decimal PendingClaims { get; set; }
}

public class ReimbursementDto
{
    public DateTime? ApprovalDate { get; set; }
    public string ReimbursementType { get; set; } = "";
    public string SKU { get; set; } = "";
    public decimal Amount { get; set; }
    public string Status { get; set; } = "";
}