using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using AmazonFBAManager.Desktop.ViewModels;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // Configure services
        var services = new ServiceCollection();
        ConfigureServices(services);
        Services = services.BuildServiceProvider();

        // Show login window first
        var loginWindow = new LoginWindow();
        if (loginWindow.ShowDialog() == true)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
        }
        else
        {
            Shutdown();
        }
    }

    public static IServiceProvider Services { get; private set; } = null!;

    public static T GetService<T>() where T : class
    {
        return Services.GetRequiredService<T>();
    }

    private void ConfigureServices(IServiceCollection services)
    {
        // Register services
        services.AddSingleton<IApiService, ApiService>();
        services.AddSingleton<ISessionService, SessionService>();
        services.AddHttpClient("ApiClient", client =>
        {
            client.BaseAddress = new Uri("http://localhost:5001");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        });

        // Register Windows
        services.AddTransient<MainWindow>();
    }
}

public class ApiService : IApiService
{
    private readonly HttpClient _http;
    private readonly ISessionService _session;

    public ApiService(HttpClient http, ISessionService session)
    {
        _http = http;
        _session = session;
    }

    private async Task AddAuthHeader()
    {
        var token = await _session.GetToken();
        if (!string.IsNullOrEmpty(token))
        {
            _http.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }
    }

    public async Task<LoginResponseDto> LoginAsync(string username, string password)
    {
        var response = await _http.PostAsJsonAsync("api/auth/login", new LoginRequestDto { Username = username, Password = password });
        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<LoginResponseDto>();
        return result ?? new LoginResponseDto { Success = false, Message = "Login failed" };
    }

    public async Task<IEnumerable<SellerAccountDto>> GetUserAccountsAsync(int userId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<SellerAccountDto>>($"api/auth/accounts?userId={userId}") ?? new List<SellerAccountDto>();
    }

    public async Task<DashboardSummaryDto> GetDashboardSummaryAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<DashboardSummaryDto>($"api/Dashboard/summary?sellerAccountId={sellerAccountId}") ?? new DashboardSummaryDto();
    }

    public async Task<IEnumerable<ReorderSuggestionDto>> GetReorderSuggestionsAsync(int sellerAccountId, int leadTimeDays = 30, decimal serviceLevel = 0.95m)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ReorderSuggestionDto>>($"api/Inventory/reorder-suggestions?sellerAccountId={sellerAccountId}&leadTimeDays={leadTimeDays}&serviceLevel={serviceLevel}") ?? new List<ReorderSuggestionDto>();
    }

    public async Task<IEnumerable<CaseDto>> GetCasesAsync(int sellerAccountId, string? status = null, int page = 1, int pageSize = 20)
    {
        await AddAuthHeader();
        var url = $"api/Cases?sellerAccountId={sellerAccountId}&page={page}&pageSize={pageSize}";
        if (!string.IsNullOrEmpty(status)) url += $"&status={status}";
        return await _http.GetFromJsonAsync<IEnumerable<CaseDto>>(url) ?? new List<CaseDto>();
    }

    public async Task<IEnumerable<ReimbursementAuditDto>> AuditLostDamagedAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ReimbursementAuditDto>>($"api/Reimbursement/lost-damaged?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new List<ReimbursementAuditDto>();
    }

    public async Task<IEnumerable<ProfitLossBySKUDto>> GetProfitLossAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo, string groupBy = "SKU")
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ProfitLossBySKUDto>>($"api/Sales/profit-loss?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}&groupBy={groupBy}") ?? new List<ProfitLossBySKUDto>();
    }

    public async Task<IEnumerable<PPCCampaignDto>> GetCampaignsAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<PPCCampaignDto>>($"api/PPC/campaigns?sellerAccountId={sellerAccountId}") ?? new List<PPCCampaignDto>();
    }

    public async Task<IEnumerable<WastedSpendDto>> AuditCampaignsAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<WastedSpendDto>>($"api/PPC/audit?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new List<WastedSpendDto>();
    }

    public async Task<IEnumerable<AlertDto>> GetAlertsAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<AlertDto>>($"api/Alerts?sellerAccountId={sellerAccountId}") ?? new List<AlertDto>();
    }

    public async Task<AlertSummaryDto> GetAlertSummaryAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<AlertSummaryDto>($"api/Alerts/summary?sellerAccountId={sellerAccountId}") ?? new AlertSummaryDto();
    }

    public async Task MarkAlertReadAsync(long alertId)
    {
        await AddAuthHeader();
        await _http.PutAsync($"api/Alerts/{alertId}/read", null);
    }

    public async Task<IEnumerable<OverstockReportDto>> GetOverstockReportAsync(int sellerAccountId, int daysOfSupplyThreshold = 365)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<OverstockReportDto>>($"api/Inventory/overstock?sellerAccountId={sellerAccountId}&daysOfSupplyThreshold={daysOfSupplyThreshold}") ?? new List<OverstockReportDto>();
    }

    public async Task<IEnumerable<AgedInventoryFeeRiskDto>> GetAgedInventoryAsync(int sellerAccountId, DateTime? snapshotDate = null)
    {
        await AddAuthHeader();
        var url = $"api/Inventory/aged?sellerAccountId={sellerAccountId}";
        if (snapshotDate.HasValue) url += $"&snapshotDate={snapshotDate:yyyy-MM-dd}";
        return await _http.GetFromJsonAsync<IEnumerable<AgedInventoryFeeRiskDto>>(url) ?? new List<AgedInventoryFeeRiskDto>();
    }

    public async Task<IEnumerable<StrandedInventoryDto>> GetStrandedInventoryAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<StrandedInventoryDto>>($"api/Inventory/stranded?sellerAccountId={sellerAccountId}") ?? new List<StrandedInventoryDto>();
    }

    public async Task<IEnumerable<ProductDto>> GetProductsAsync(int sellerAccountId, int page = 1, int pageSize = 20)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ProductDto>>($"api/Products?sellerAccountId={sellerAccountId}&page={page}&pageSize={pageSize}") ?? new List<ProductDto>();
    }

    public async Task<IEnumerable<ReturnlessRefundAuditDto>> AuditReturnlessAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ReturnlessRefundAuditDto>>($"api/Reimbursement/returnless?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new List<ReturnlessRefundAuditDto>();
    }

    public async Task<IEnumerable<FeeOverchargeDto>> GetFeeOverchargesAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<FeeOverchargeDto>>($"api/Reimbursement/fee-overcharges?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new List<FeeOverchargeDto>();
    }

    public async Task<ReimbursementKPIDashboardDto> GetReimbursementKPIAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<ReimbursementKPIDashboardDto>($"api/Reimbursement/kpi?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new ReimbursementKPIDashboardDto();
    }

    public async Task<IEnumerable<COGSImpactDto>> GetCOGSImpactAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<COGSImpactDto>>($"api/Reimbursement/cogs-impact?sellerAccountId={sellerAccountId}") ?? new List<COGSImpactDto>();
    }

    public async Task<IEnumerable<ReimbursementAuditDto>> GetPendingAuditsAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ReimbursementAuditDto>>($"api/Reimbursement/pending?sellerAccountId={sellerAccountId}") ?? new List<ReimbursementAuditDto>();
    }

    public async Task<int> RegisterAsync(string username, string email, string password, int roleId = 2)
    {
        var response = await _http.PostAsJsonAsync("api/auth/register", new { Username = username, Email = email, PasswordHash = password, RoleId = roleId });
        return await response.Content.ReadFromJsonAsync<int>();
    }

    public async Task<IEnumerable<UserDto>> GetUsersAsync() => new List<UserDto>();
    public async Task<IEnumerable<InventorySnapshotDto>> GetInventorySnapshotsAsync(int sellerAccountId, DateTime? date = null) => new List<InventorySnapshotDto>();
    public async Task<IEnumerable<IPIImprovementActionDto>> GetIPIImprovementActionsAsync(int sellerAccountId) => new List<IPIImprovementActionDto>();
    public async Task<ProductDto?> GetProductByIdAsync(int id) => null;
    public async Task<int> CreateProductAsync(ProductDto product) => 0;
    public async Task UpdateProductAsync(ProductDto product) { }
    public async Task UpdateCOGSAsync(int productId, decimal cogs) { }
    public async Task<CaseDto?> GetCaseByIdAsync(int id) => null;
    public async Task<int> CreateCaseAsync(CaseCreateDto caseDto) => 0;
    public async Task ResolveCaseAsync(int id, decimal? resolvedAmount = null, string? resolutionNote = null) { }
    public async Task EscalateCaseAsync(int id, int userId, string reason) { }
    public async Task<IEnumerable<CaseNoteDto>> GetCaseNotesAsync(int caseId) => new List<CaseNoteDto>();
    public async Task<IEnumerable<CaseAgingReportDto>> GetCaseAgingReportAsync(int sellerAccountId, int slaDays = 14) => new List<CaseAgingReportDto>();
    public async Task<IEnumerable<SuppressedListingDto>> GetSuppressedListingsAsync(int sellerAccountId) => new List<SuppressedListingDto>();
    public async Task<IEnumerable<ReimbursementChecklistItemDto>> GetMonthlyChecklistAsync(int sellerAccountId, int month, int year) => new List<ReimbursementChecklistItemDto>();
    public async Task<IEnumerable<SalesOrderDto>> GetSalesOrdersAsync(int sellerAccountId, DateTime? dateFrom = null, DateTime? dateTo = null, int page = 1, int pageSize = 20) => new List<SalesOrderDto>();
    public async Task<SalesOrderDto?> GetSalesOrderByIdAsync(long id) => null;
    public async Task<IEnumerable<SalesOrderItemDto>> GetSalesOrderItemsAsync(long orderId) => new List<SalesOrderItemDto>();
    public async Task<IEnumerable<SalesVelocityDto>> GetSalesVelocityAsync(int sellerAccountId, string? asin = null, int periods = 12) => new List<SalesVelocityDto>();
    public async Task<IEnumerable<PPCKeywordDto>> GetKeywordsAsync(int sellerAccountId, int? campaignId = null, string? period = null) => new List<PPCKeywordDto>();
    public async Task<TACoSReportDto> GetTACoSAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo) => new TACoSReportDto();
    public async Task<IEnumerable<BidAdjustmentDto>> GetBidSuggestionsAsync(int sellerAccountId, decimal targetACoS = 25m) => new List<BidAdjustmentDto>();
    public async Task<CSVImportResultDto> ImportCSVAsync(long importId, string reportType) => new CSVImportResultDto();
    public async Task<IEnumerable<CSVImportDto>> GetImportHistoryAsync(int sellerAccountId) => new List<CSVImportDto>();
    public async Task ResolveAlertAsync(long alertId, int resolvedByUserId) { }
    public async Task<IEnumerable<MultiAccountSummaryDto>> GetMultiAccountSummaryAsync(int userId, DateTime dateFrom, DateTime dateTo) => new List<MultiAccountSummaryDto>();
}

public class SessionService : ISessionService
{
    private readonly Dictionary<string, object> _storage = new();

    public Task<string?> GetToken() => Task.FromResult(_storage.ContainsKey("JWT") ? _storage["JWT"]?.ToString() : null);
    public Task SetToken(string token) { _storage["JWT"] = token; return Task.CompletedTask; }
    public Task ClearToken() { _storage.Remove("JWT"); return Task.CompletedTask; }

    public Task<UserDto?> GetCurrentUser()
    {
        if (_storage.ContainsKey("CurrentUser"))
            return Task.FromResult(System.Text.Json.JsonSerializer.Deserialize<UserDto>(_storage["CurrentUser"].ToString()!));
        return Task.FromResult<UserDto?>(null);
    }

    public Task SetCurrentUser(UserDto user)
    {
        _storage["CurrentUser"] = System.Text.Json.JsonSerializer.Serialize(user);
        return Task.CompletedTask;
    }

    public Task<int?> GetUserId() => Task.FromResult(_storage.ContainsKey("UserId") ? (int?)Convert.ToInt32(_storage["UserId"]) : null);
    public Task SetUserId(int userId) { _storage["UserId"] = userId; return Task.CompletedTask; }

    public Task<int?> GetSelectedAccountId() => Task.FromResult(_storage.ContainsKey("SelectedAccountId") ? (int?)Convert.ToInt32(_storage["SelectedAccountId"]) : null);
    public Task SetSelectedAccountId(int accountId) { _storage["SelectedAccountId"] = accountId; return Task.CompletedTask; }
    public Task ClearSelectedAccountId() { _storage.Remove("SelectedAccountId"); return Task.CompletedTask; }
}

// Need these imports for the DTOs
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using System.Net.Http.Json;