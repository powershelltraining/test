using System.Windows;
using AmazonFBAManager.Desktop.ViewModels;
using AmazonFBAManager.Desktop.Services;

namespace AmazonFBAManager.Desktop;

public partial class MainWindow : Window
{
    private readonly ISessionService _sessionService;
    private readonly IApiService _apiService;

    public MainWindow()
    {
        InitializeComponent();

        _sessionService = App.GetService<ISessionService>();
        _apiService = App.GetService<IApiService>();

        DataContext = new MainWindowViewModel(_sessionService, _apiService, this);
    }

    private void FileDragOver(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.FileDrop))
        {
            e.Effects = DragDropEffects.Copy;
        }
        else
        {
            e.Effects = DragDropEffects.None;
        }
        e.Handled = true;
    }

    private void FileDrop(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.FileDrop))
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files?.Length > 0 && DataContext is MainWindowViewModel vm)
            {
                vm.HandleFileDrop(files[0]);
            }
        }
    }
}