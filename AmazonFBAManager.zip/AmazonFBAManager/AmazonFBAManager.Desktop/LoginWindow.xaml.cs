using System.Windows;
using AmazonFBAManager.Desktop.Services;
using AmazonFBAManager.Shared.DTOs;

namespace AmazonFBAManager.Desktop;

public partial class LoginWindow : Window
{
    private readonly IApiService _apiService;
    private readonly ISessionService _sessionService;

    public string Email { get; set; } = "";

    public LoginWindow()
    {
        InitializeComponent();
        DataContext = this;

        // Create services
        var httpClient = new HttpClient { BaseAddress = new Uri("http://localhost:5001") };
        httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

        _sessionService = new SessionService();
        _apiService = new ApiService(httpClient, _sessionService);
    }

    private async void LoginButton_Click(object sender, RoutedEventArgs e)
    {
        ErrorMessage.Text = "";
        var email = EmailTextBox.Text;
        var password = PasswordBox.Password;

        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
        {
            ErrorMessage.Text = "Please enter email and password.";
            return;
        }

        try
        {
            var result = await _apiService.LoginAsync(email, password);

            if (result.Success)
            {
                await _sessionService.SetToken(result.Token!);
                await _sessionService.SetUserId(result.UserId);

                var user = await _apiService.GetCurrentUserAsync();
                if (user != null)
                {
                    await _sessionService.SetCurrentUser(user);
                }

                DialogResult = true;
                Close();
            }
            else
            {
                ErrorMessage.Text = result.Message ?? "Login failed. Please try again.";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage.Text = $"Connection error: {ex.Message}";
        }
    }

    private async void RegisterButton_Click(object sender, RoutedEventArgs e)
    {
        // Simple registration - in production would be a separate dialog
        ErrorMessage.Text = "";
        var email = EmailTextBox.Text;
        var password = PasswordBox.Password;

        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
        {
            ErrorMessage.Text = "Please enter email and password to register.";
            return;
        }

        try
        {
            var userId = await _apiService.RegisterAsync(email, email, password);
            if (userId > 0)
            {
                ErrorMessage.Text = "Registration successful! Please sign in.";
            }
            else
            {
                ErrorMessage.Text = "Registration failed. Please try again.";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage.Text = $"Registration error: {ex.Message}";
        }
    }
}