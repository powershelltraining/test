using Microsoft.AspNetCore.Mvc;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;

namespace AmazonFBAManager.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CSVImportController : ControllerBase
{
    private readonly ICSVImportRepository _csvImportRepository;
    private readonly IProductRepository _productRepository;
    private readonly IInventoryRepository _inventoryRepository;

    public CSVImportController(ICSVImportRepository csvImportRepository, IProductRepository productRepository, IInventoryRepository inventoryRepository)
    {
        _csvImportRepository = csvImportRepository;
        _productRepository = productRepository;
        _inventoryRepository = inventoryRepository;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<CSVImportDto>>> Get([FromQuery] int sellerAccountId, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        var imports = await _csvImportRepository.GetImportsAsync(sellerAccountId, page, pageSize);
        return Ok(imports);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<CSVImportDto>> GetById(long id)
    {
        var import = await _csvImportRepository.GetImportByIdAsync(id);
        if (import == null) return NotFound();
        return Ok(import);
    }

    [HttpPost("inventory")]
    public async Task<ActionResult<CSVImportResultDto>> ImportInventory([FromBody] ImportInventoryRequest request)
    {
        var importDto = new CSVImportDto
        {
            SellerAccountId = request.SellerAccountId,
            UserId = request.UserId,
            ReportType = "INVENTORY_SNAPSHOT",
            FileName = request.FileName,
            FilePath = request.FilePath,
            Status = "Processing"
        };

        var importId = await _csvImportRepository.CreateImportAsync(importDto);

        // Import the data
        var result = await _csvImportRepository.ImportInventorySnapshotAsync(request.SellerAccountId, importId, request.Data);

        await _csvImportRepository.UpdateImportStatusAsync(importId, result.RowsErrored > 0 ? "Partial" : "Complete", result.RowsImported, result.RowsErrored);

        return Ok(result);
    }

    [HttpPost("products")]
    public async Task<ActionResult<CSVImportResultDto>> ImportProducts([FromBody] ImportProductsRequest request)
    {
        var importDto = new CSVImportDto
        {
            SellerAccountId = request.SellerAccountId,
            UserId = request.UserId,
            ReportType = "PRODUCTS_COGS",
            FileName = request.FileName,
            FilePath = request.FilePath,
            Status = "Processing"
        };

        var importId = await _csvImportRepository.CreateImportAsync(importDto);
        var result = await _csvImportRepository.ImportProductsAsync(request.SellerAccountId, importId, request.Data);

        await _csvImportRepository.UpdateImportStatusAsync(importId, result.RowsErrored > 0 ? "Partial" : "Complete", result.RowsImported, result.RowsErrored);

        return Ok(result);
    }

    [HttpPost("ppc")]
    public async Task<ActionResult<CSVImportResultDto>> ImportPPC([FromBody] ImportPPCRequest request)
    {
        var importDto = new CSVImportDto
        {
            SellerAccountId = request.SellerAccountId,
            UserId = request.UserId,
            ReportType = "PPC_KEYWORDS",
            FileName = request.FileName,
            FilePath = request.FilePath,
            Status = "Processing"
        };

        var importId = await _csvImportRepository.CreateImportAsync(importDto);
        var result = await _csvImportRepository.ImportPPCKeywordsAsync(request.SellerAccountId, importId, request.Data, request.Period);

        await _csvImportRepository.UpdateImportStatusAsync(importId, result.RowsErrored > 0 ? "Partial" : "Complete", result.RowsImported, result.RowsErrored);

        return Ok(result);
    }
}

public class ImportInventoryRequest
{
    public int SellerAccountId { get; set; }
    public int UserId { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string FilePath { get; set; } = string.Empty;
    public IEnumerable<InventorySnapshotDto> Data { get; set; } = Enumerable.Empty<InventorySnapshotDto>();
}

public class ImportProductsRequest
{
    public int SellerAccountId { get; set; }
    public int UserId { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string FilePath { get; set; } = string.Empty;
    public IEnumerable<ProductDto> Data { get; set; } = Enumerable.Empty<ProductDto>();
}

public class ImportPPCRequest
{
    public int SellerAccountId { get; set; }
    public int UserId { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string FilePath { get; set; } = string.Empty;
    public string Period { get; set; } = string.Empty;
    public IEnumerable<PPCKeywordDto> Data { get; set; } = Enumerable.Empty<PPCKeywordDto>();
}

[ApiController]
[Route("api/[controller]")]
public class AlertsController : ControllerBase
{
    private readonly IAlertRepository _alertRepository;

    public AlertsController(IAlertRepository alertRepository)
    {
        _alertRepository = alertRepository;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<AlertDto>>> Get([FromQuery] int sellerAccountId, [FromQuery] bool? isRead = null, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        var alerts = await _alertRepository.GetAlertsAsync(sellerAccountId, isRead, page, pageSize);
        return Ok(alerts);
    }

    [HttpGet("summary")]
    public async Task<ActionResult<AlertSummaryDto>> GetSummary([FromQuery] int sellerAccountId)
    {
        var summary = await _alertRepository.GetAlertSummaryAsync(sellerAccountId);
        return Ok(summary);
    }

    [HttpGet("unread")]
    public async Task<ActionResult<IEnumerable<AlertDto>>> GetUnread([FromQuery] int sellerAccountId)
    {
        var alerts = await _alertRepository.GetUnreadAlertsAsync(sellerAccountId);
        return Ok(alerts);
    }

    [HttpPut("{id}/read")]
    public async Task<IActionResult> MarkAsRead(long id)
    {
        await _alertRepository.MarkAlertAsReadAsync(id);
        return Ok();
    }

    [HttpPut("{id}/resolve")]
    public async Task<IActionResult> Resolve(long id, [FromQuery] int resolvedByUserId)
    {
        await _alertRepository.MarkAlertAsResolvedAsync(id, resolvedByUserId);
        return Ok();
    }
}

[ApiController]
[Route("api/[controller]")]
public class EmailTemplatesController : ControllerBase
{
    private readonly IEmailTemplateRepository _emailTemplateRepository;

    public EmailTemplatesController(IEmailTemplateRepository emailTemplateRepository)
    {
        _emailTemplateRepository = emailTemplateRepository;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<EmailTemplateDto>>> Get([FromQuery] string? category = null)
    {
        var templates = await _emailTemplateRepository.GetTemplatesAsync(category);
        return Ok(templates);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<EmailTemplateDto>> GetById(int id)
    {
        var template = await _emailTemplateRepository.GetTemplateByIdAsync(id);
        if (template == null) return NotFound();
        return Ok(template);
    }
}

[ApiController]
[Route("api/[controller]")]
public class HelpController : ControllerBase
{
    private readonly IHelpRepository _helpRepository;

    public HelpController(IHelpRepository helpRepository)
    {
        _helpRepository = helpRepository;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<HelpTopicDto>>> Get([FromQuery] string? section = null)
    {
        var topics = await _helpRepository.GetTopicsAsync(section);
        return Ok(topics);
    }

    [HttpGet("sections")]
    public async Task<ActionResult<IEnumerable<string>>> GetSections()
    {
        var sections = await _helpRepository.GetSectionsAsync();
        return Ok(sections);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<HelpTopicDto>> GetById(int id)
    {
        var topic = await _helpRepository.GetTopicByIdAsync(id);
        if (topic == null) return NotFound();
        return Ok(topic);
    }
}

[ApiController]
[Route("api/[controller]")]
public class SettingsController : ControllerBase
{
    private readonly ISettingsRepository _settingsRepository;

    public SettingsController(ISettingsRepository settingsRepository)
    {
        _settingsRepository = settingsRepository;
    }

    [HttpGet("alert-thresholds")]
    public async Task<ActionResult<IEnumerable<AlertThresholdDto>>> GetAlertThresholds([FromQuery] int sellerAccountId)
    {
        var thresholds = await _settingsRepository.GetAlertThresholdsAsync(sellerAccountId);
        return Ok(thresholds);
    }

    [HttpPost("alert-thresholds")]
    public async Task<IActionResult> SetAlertThreshold([FromQuery] int sellerAccountId, [FromQuery] string alertType, [FromQuery] decimal thresholdValue, [FromQuery] bool isEnabled = true)
    {
        await _settingsRepository.SetAlertThresholdAsync(sellerAccountId, alertType, thresholdValue, isEnabled);
        return Ok();
    }
}