using Microsoft.AspNetCore.Mvc;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;

namespace AmazonFBAManager.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IUserRepository _userRepository;

    public AuthController(IUserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    [HttpPost("login")]
    public async Task<ActionResult<LoginResponseDto>> Login([FromBody] LoginRequestDto request)
    {
        var result = await _userRepository.ValidateCredentialsAsync(request.Username, request.Password);
        if (!result.Success)
        {
            return Unauthorized(result);
        }
        return Ok(result);
    }

    [HttpPost("register")]
    public async Task<ActionResult<int>> Register([FromBody] RegisterRequestDto request)
    {
        try
        {
            var userId = await _userRepository.CreateUserAsync(request.Username, request.Email, request.PasswordHash, request.RoleId);
            return Ok(userId);
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpGet("users")]
    public async Task<ActionResult<IEnumerable<UserDto>>> GetUsers()
    {
        var users = await _userRepository.GetAllUsersAsync();
        return Ok(users);
    }

    [HttpGet("accounts")]
    public async Task<ActionResult<IEnumerable<SellerAccountDto>>> GetUserAccounts([FromQuery] int userId)
    {
        var accounts = await _userRepository.GetUserSellerAccountsAsync(userId);
        return Ok(accounts);
    }
}

public class RegisterRequestDto
{
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public int RoleId { get; set; } = 2;
}