using Microsoft.AspNetCore.Mvc;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;

namespace AmazonFBAManager.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private readonly IProductRepository _productRepository;

    public ProductsController(IProductRepository productRepository)
    {
        _productRepository = productRepository;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ProductDto>>> Get([FromQuery] int sellerAccountId, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        var products = await _productRepository.GetProductsAsync(sellerAccountId, page, pageSize);
        return Ok(products);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ProductDto>> GetById(int id)
    {
        var product = await _productRepository.GetProductByIdAsync(id);
        if (product == null) return NotFound();
        return Ok(product);
    }

    [HttpPost]
    public async Task<ActionResult<int>> Create([FromBody] ProductDto product)
    {
        var id = await _productRepository.CreateProductAsync(product);
        return Ok(id);
    }

    [HttpPut]
    public async Task<IActionResult> Update([FromBody] ProductDto product)
    {
        await _productRepository.UpdateProductAsync(product);
        return Ok();
    }

    [HttpPut("cogs")]
    public async Task<IActionResult> UpdateCOGS([FromQuery] int productId, [FromQuery] decimal cogs)
    {
        await _productRepository.UpdateCOGSAsync(productId, cogs);
        return Ok();
    }
}

[ApiController]
[Route("api/[controller]")]
public class InventoryController : ControllerBase
{
    private readonly IInventoryRepository _inventoryRepository;

    public InventoryController(IInventoryRepository inventoryRepository)
    {
        _inventoryRepository = inventoryRepository;
    }

    [HttpGet("snapshots")]
    public async Task<ActionResult<IEnumerable<InventorySnapshotDto>>> GetSnapshots([FromQuery] int sellerAccountId, [FromQuery] DateTime? date = null)
    {
        var snapshots = await _inventoryRepository.GetInventorySnapshotsAsync(sellerAccountId, date);
        return Ok(snapshots);
    }

    [HttpGet("reorder-suggestions")]
    public async Task<ActionResult<IEnumerable<ReorderSuggestionDto>>> GetReorderSuggestions([FromQuery] int sellerAccountId, [FromQuery] int leadTimeDays = 30, [FromQuery] decimal serviceLevel = 0.95m)
    {
        var suggestions = await _inventoryRepository.GetReorderSuggestionsAsync(sellerAccountId, leadTimeDays, serviceLevel);
        return Ok(suggestions);
    }

    [HttpGet("overstock")]
    public async Task<ActionResult<IEnumerable<OverstockReportDto>>> GetOverstock([FromQuery] int sellerAccountId, [FromQuery] int daysOfSupplyThreshold = 365)
    {
        var report = await _inventoryRepository.GetOverstockReportAsync(sellerAccountId, daysOfSupplyThreshold);
        return Ok(report);
    }

    [HttpGet("aged")]
    public async Task<ActionResult<IEnumerable<AgedInventoryFeeRiskDto>>> GetAgedInventory([FromQuery] int sellerAccountId, [FromQuery] DateTime? snapshotDate = null)
    {
        var report = await _inventoryRepository.GetAgedInventoryFeeRiskAsync(sellerAccountId, snapshotDate);
        return Ok(report);
    }

    [HttpGet("stranded")]
    public async Task<ActionResult<IEnumerable<StrandedInventoryDto>>> GetStranded([FromQuery] int sellerAccountId)
    {
        var report = await _inventoryRepository.GetStrandedInventoryAsync(sellerAccountId);
        return Ok(report);
    }

    [HttpGet("ipi-actions")]
    public async Task<ActionResult<IEnumerable<IPIImprovementActionDto>>> GetIPIActions([FromQuery] int sellerAccountId)
    {
        var actions = await _inventoryRepository.GetIPIImprovementActionsAsync(sellerAccountId);
        return Ok(actions);
    }

    [HttpPost("check-alerts")]
    public async Task<IActionResult> CheckAlerts([FromQuery] int sellerAccountId)
    {
        await _inventoryRepository.CheckLowStockAlertsAsync(sellerAccountId);
        return Ok();
    }
}

[ApiController]
[Route("api/[controller]")]
public class DashboardController : ControllerBase
{
    private readonly ISalesRepository _salesRepository;

    public DashboardController(ISalesRepository salesRepository)
    {
        _salesRepository = salesRepository;
    }

    [HttpGet("summary")]
    public async Task<ActionResult<DashboardSummaryDto>> GetSummary([FromQuery] int sellerAccountId)
    {
        var summary = await _salesRepository.GetDashboardSummaryAsync(sellerAccountId);
        return Ok(summary);
    }

    [HttpGet("multi-account")]
    public async Task<ActionResult<IEnumerable<MultiAccountSummaryDto>>> GetMultiAccount([FromQuery] int userId, [FromQuery] DateTime dateFrom, [FromQuery] DateTime dateTo)
    {
        var summary = await _salesRepository.GetMultiAccountSummaryAsync(userId, dateFrom, dateTo);
        return Ok(summary);
    }
}