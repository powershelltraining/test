using Microsoft.AspNetCore.Mvc;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;

namespace AmazonFBAManager.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CasesController : ControllerBase
{
    private readonly ICaseRepository _caseRepository;

    public CasesController(ICaseRepository caseRepository)
    {
        _caseRepository = caseRepository;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<CaseDto>>> Get([FromQuery] int sellerAccountId, [FromQuery] string? status = null, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        var cases = await _caseRepository.GetCasesAsync(sellerAccountId, status, page, pageSize);
        return Ok(cases);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<CaseDto>> GetById(int id)
    {
        var caseItem = await _caseRepository.GetCaseByIdAsync(id);
        if (caseItem == null) return NotFound();
        return Ok(caseItem);
    }

    [HttpPost]
    public async Task<ActionResult<int>> Create([FromBody] CaseCreateDto caseDto)
    {
        var id = await _caseRepository.CreateCaseAsync(caseDto);
        return Ok(id);
    }

    [HttpPut("{id}/resolve")]
    public async Task<IActionResult> Resolve(int id, [FromQuery] decimal? resolvedAmount = null, [FromQuery] string? resolutionNote = null)
    {
        await _caseRepository.ResolveCaseAsync(id, resolvedAmount, resolutionNote);
        return Ok();
    }

    [HttpPut("{id}/escalate")]
    public async Task<IActionResult> Escalate(int id, [FromQuery] int userId, [FromQuery] string reason)
    {
        await _caseRepository.EscalateCaseAsync(id, userId, reason);
        return Ok();
    }

    [HttpGet("{id}/notes")]
    public async Task<ActionResult<IEnumerable<CaseNoteDto>>> GetNotes(int id)
    {
        var notes = await _caseRepository.GetCaseNotesAsync(id);
        return Ok(notes);
    }

    [HttpGet("aging")]
    public async Task<ActionResult<IEnumerable<CaseAgingReportDto>>> GetAging([FromQuery] int sellerAccountId, [FromQuery] int slaDays = 14)
    {
        var report = await _caseRepository.GetCaseAgingReportAsync(sellerAccountId, slaDays);
        return Ok(report);
    }

    [HttpGet("suppressed-listings")]
    public async Task<ActionResult<IEnumerable<SuppressedListingDto>>> GetSuppressedListings([FromQuery] int sellerAccountId)
    {
        var listings = await _caseRepository.GetListingSuppressedFixesAsync(sellerAccountId);
        return Ok(listings);
    }
}

[ApiController]
[Route("api/[controller]")]
public class ReimbursementController : ControllerBase
{
    private readonly IReimbursementRepository _reimbursementRepository;

    public ReimbursementController(IReimbursementRepository reimbursementRepository)
    {
        _reimbursementRepository = reimbursementRepository;
    }

    [HttpGet("lost-damaged")]
    public async Task<ActionResult<IEnumerable<ReimbursementAuditDto>>> AuditLostDamaged([FromQuery] int sellerAccountId, [FromQuery] DateTime dateFrom, [FromQuery] DateTime dateTo)
    {
        var audit = await _reimbursementRepository.AuditLostDamagedInventoryAsync(sellerAccountId, dateFrom, dateTo);
        return Ok(audit);
    }

    [HttpGet("returnless")]
    public async Task<ActionResult<IEnumerable<ReturnlessRefundAuditDto>>> AuditReturnless([FromQuery] int sellerAccountId, [FromQuery] DateTime dateFrom, [FromQuery] DateTime dateTo)
    {
        var audit = await _reimbursementRepository.AuditReturnlessRefundsAsync(sellerAccountId, dateFrom, dateTo);
        return Ok(audit);
    }

    [HttpGet("fee-overcharges")]
    public async Task<ActionResult<IEnumerable<FeeOverchargeDto>>> GetFeeOvercharges([FromQuery] int sellerAccountId, [FromQuery] DateTime dateFrom, [FromQuery] DateTime dateTo)
    {
        var overcharges = await _reimbursementRepository.DetectFeeOverchargesAsync(sellerAccountId, dateFrom, dateTo);
        return Ok(overcharges);
    }

    [HttpGet("checklist")]
    public async Task<ActionResult<IEnumerable<ReimbursementChecklistItemDto>>> GetChecklist([FromQuery] int sellerAccountId, [FromQuery] int month, [FromQuery] int year)
    {
        var checklist = await _reimbursementRepository.GetMonthlyChecklistAsync(sellerAccountId, month, year);
        return Ok(checklist);
    }

    [HttpGet("kpi")]
    public async Task<ActionResult<ReimbursementKPIDashboardDto>> GetKPI([FromQuery] int sellerAccountId, [FromQuery] DateTime dateFrom, [FromQuery] DateTime dateTo)
    {
        var kpi = await _reimbursementRepository.GetKPIDashboardAsync(sellerAccountId, dateFrom, dateTo);
        return Ok(kpi);
    }

    [HttpGet("cogs-impact")]
    public async Task<ActionResult<IEnumerable<COGSImpactDto>>> GetCOGSImpact([FromQuery] int sellerAccountId)
    {
        var impact = await _reimbursementRepository.CalculateCOGSImpactAsync(sellerAccountId);
        return Ok(impact);
    }

    [HttpGet("pending")]
    public async Task<ActionResult<IEnumerable<ReimbursementAuditDto>>> GetPending([FromQuery] int sellerAccountId)
    {
        var pending = await _reimbursementRepository.GetPendingAuditsAsync(sellerAccountId);
        return Ok(pending);
    }
}

[ApiController]
[Route("api/[controller]")]
public class SalesController : ControllerBase
{
    private readonly ISalesRepository _salesRepository;

    public SalesController(ISalesRepository salesRepository)
    {
        _salesRepository = salesRepository;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<SalesOrderDto>>> Get([FromQuery] int sellerAccountId, [FromQuery] DateTime? dateFrom = null, [FromQuery] DateTime? dateTo = null, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        var orders = await _salesRepository.GetSalesOrdersAsync(sellerAccountId, dateFrom, dateTo, page, pageSize);
        return Ok(orders);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<SalesOrderDto>> GetById(long id)
    {
        var order = await _salesRepository.GetSalesOrderByIdAsync(id);
        if (order == null) return NotFound();
        return Ok(order);
    }

    [HttpGet("{id}/items")]
    public async Task<ActionResult<IEnumerable<SalesOrderItemDto>>> GetItems(long id)
    {
        var items = await _salesRepository.GetSalesOrderItemsAsync(id);
        return Ok(items);
    }

    [HttpGet("profit-loss")]
    public async Task<ActionResult<IEnumerable<ProfitLossBySKUDto>>> GetProfitLoss([FromQuery] int sellerAccountId, [FromQuery] DateTime dateFrom, [FromQuery] DateTime dateTo, [FromQuery] string groupBy = "SKU")
    {
        var report = await _salesRepository.GetProfitLossBySKUAsync(sellerAccountId, dateFrom, dateTo, groupBy);
        return Ok(report);
    }

    [HttpGet("velocity")]
    public async Task<ActionResult<IEnumerable<SalesVelocityDto>>> GetVelocity([FromQuery] int sellerAccountId, [FromQuery] string? asin = null, [FromQuery] int periods = 12)
    {
        var velocity = await _salesRepository.GetSalesVelocityAsync(sellerAccountId, asin, periods);
        return Ok(velocity);
    }
}

[ApiController]
[Route("api/[controller]")]
public class PPCController : ControllerBase
{
    private readonly IPPCRepository _ppcRepository;

    public PPCController(IPPCRepository ppcRepository)
    {
        _ppcRepository = ppcRepository;
    }

    [HttpGet("campaigns")]
    public async Task<ActionResult<IEnumerable<PPCCampaignDto>>> GetCampaigns([FromQuery] int sellerAccountId)
    {
        var campaigns = await _ppcRepository.GetCampaignsAsync(sellerAccountId);
        return Ok(campaigns);
    }

    [HttpGet("keywords")]
    public async Task<ActionResult<IEnumerable<PPCKeywordDto>>> GetKeywords([FromQuery] int sellerAccountId, [FromQuery] int? campaignId = null, [FromQuery] string? period = null)
    {
        var keywords = await _ppcRepository.GetKeywordsAsync(sellerAccountId, campaignId, period);
        return Ok(keywords);
    }

    [HttpGet("audit")]
    public async Task<ActionResult<IEnumerable<WastedSpendDto>>> Audit([FromQuery] int sellerAccountId, [FromQuery] DateTime dateFrom, [FromQuery] DateTime dateTo)
    {
        var audit = await _ppcRepository.AuditCampaignsAsync(sellerAccountId, dateFrom, dateTo);
        return Ok(audit);
    }

    [HttpGet("tacos")]
    public async Task<ActionResult<TACoSReportDto>> GetTACoS([FromQuery] int sellerAccountId, [FromQuery] DateTime dateFrom, [FromQuery] DateTime dateTo)
    {
        var tacos = await _ppcRepository.CalculateTACoSAsync(sellerAccountId, dateFrom, dateTo);
        return Ok(tacos);
    }

    [HttpGet("bid-suggestions")]
    public async Task<ActionResult<IEnumerable<BidAdjustmentDto>>> GetBidSuggestions([FromQuery] int sellerAccountId, [FromQuery] decimal targetACoS = 25m)
    {
        var suggestions = await _ppcRepository.GetBidAdjustmentSuggestionsAsync(sellerAccountId, targetACoS);
        return Ok(suggestions);
    }
}