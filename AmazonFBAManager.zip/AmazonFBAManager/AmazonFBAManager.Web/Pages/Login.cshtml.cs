using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using AmazonFBAManager.Web.Services;

namespace AmazonFBAManager.Web.Pages;

public class LoginModel : PageModel
{
    private readonly IApiService _apiService;
    private readonly ISessionService _sessionService;

    [BindProperty]
    public string Username { get; set; } = string.Empty;

    [BindProperty]
    public string Password { get; set; } = string.Empty;

    public string? ErrorMessage { get; set; }

    public LoginModel(IApiService apiService, ISessionService sessionService)
    {
        _apiService = apiService;
        _sessionService = sessionService;
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(Password))
        {
            ErrorMessage = "Please enter username and password.";
            return Page();
        }

        var result = await _apiService.LoginAsync(Username, Password);
        if (!result.Success)
        {
            ErrorMessage = result.Message;
            return Page();
        }

        // Store session data
        await _sessionService.SetToken(result.Token);
        await _sessionService.SetCurrentUser(result.User!);
        await _sessionService.SetUserId(result.User!.UserId);

        // Redirect to return URL or dashboard
        var returnUrl = Request.Query["returnUrl"].ToString();
        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
        {
            return Redirect(returnUrl);
        }

        return Redirect("/");
    }
}