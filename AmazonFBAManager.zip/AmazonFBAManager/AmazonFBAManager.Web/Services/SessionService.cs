using AmazonFBAManager.Shared.DTOs;
using Newtonsoft.Json;

namespace AmazonFBAManager.Web.Services;

public class SessionService : ISessionService
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public SessionService(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    private ISession Session => _httpContextAccessor.HttpContext!.Session;

    public async Task<string?> GetToken()
    {
        return await Task.FromResult(Session.GetString("JWT"));
    }

    public async Task SetToken(string token)
    {
        Session.SetString("JWT", token);
        await Task.CompletedTask;
    }

    public async Task ClearToken()
    {
        Session.Remove("JWT");
        await Task.CompletedTask;
    }

    public async Task<UserDto?> GetCurrentUser()
    {
        var userJson = Session.GetString("CurrentUser");
        if (string.IsNullOrEmpty(userJson)) return null;
        return await Task.FromResult(JsonConvert.DeserializeObject<UserDto>(userJson));
    }

    public async Task SetCurrentUser(UserDto user)
    {
        Session.SetString("CurrentUser", JsonConvert.SerializeObject(user));
        await Task.CompletedTask;
    }

    public async Task<int?> GetUserId()
    {
        var userId = Session.GetInt32("UserId");
        return await Task.FromResult(userId);
    }

    public async Task SetUserId(int userId)
    {
        Session.SetInt32("UserId", userId);
        await Task.CompletedTask;
    }

    public async Task<int?> GetSelectedAccountId()
    {
        var accountId = Session.GetInt32("SelectedAccountId");
        return await Task.FromResult(accountId);
    }

    public async Task SetSelectedAccountId(int accountId)
    {
        Session.SetInt32("SelectedAccountId", accountId);
        await Task.CompletedTask;
    }

    public async Task ClearSelectedAccountId()
    {
        Session.Remove("SelectedAccountId");
        await Task.CompletedTask;
    }
}