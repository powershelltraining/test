using System.Net.Http.Json;
using AmazonFBAManager.Shared.DTOs;

namespace AmazonFBAManager.Web.Services;

public class ApiService : IApiService
{
    private readonly HttpClient _http;
    private readonly ISessionService _session;

    public ApiService(IHttpClientFactory httpFactory, ISessionService session)
    {
        _http = httpFactory.CreateClient("ApiClient");
        _session = session;
    }

    private async Task AddAuthHeader()
    {
        var token = await _session.GetToken();
        if (!string.IsNullOrEmpty(token))
        {
            _http.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }
    }

    #region Auth
    public async Task<LoginResponseDto> LoginAsync(string username, string password)
    {
        var response = await _http.PostAsJsonAsync("api/auth/login", new LoginRequestDto { Username = username, Password = password });
        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<LoginResponseDto>();
        return result ?? new LoginResponseDto { Success = false, Message = "Login failed" };
    }

    public async Task<int> RegisterAsync(string username, string email, string password, int roleId = 2)
    {
        var response = await _http.PostAsJsonAsync("api/auth/register", new { Username = username, Email = email, PasswordHash = password, RoleId = roleId });
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<int>();
    }

    public async Task<IEnumerable<UserDto>> GetUsersAsync()
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<UserDto>>("api/auth/users") ?? new List<UserDto>();
    }

    public async Task<IEnumerable<SellerAccountDto>> GetUserAccountsAsync(int userId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<SellerAccountDto>>($"api/auth/accounts?userId={userId}") ?? new List<SellerAccountDto>();
    }
    #endregion

    #region Dashboard
    public async Task<DashboardSummaryDto> GetDashboardSummaryAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<DashboardSummaryDto>($"api/Dashboard/summary?sellerAccountId={sellerAccountId}") ?? new DashboardSummaryDto();
    }

    public async Task<IEnumerable<MultiAccountSummaryDto>> GetMultiAccountSummaryAsync(int userId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<MultiAccountSummaryDto>>($"api/Dashboard/multi-account?userId={userId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new List<MultiAccountSummaryDto>();
    }
    #endregion

    #region Products
    public async Task<IEnumerable<ProductDto>> GetProductsAsync(int sellerAccountId, int page = 1, int pageSize = 20)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ProductDto>>($"api/Products?sellerAccountId={sellerAccountId}&page={page}&pageSize={pageSize}") ?? new List<ProductDto>();
    }

    public async Task<ProductDto?> GetProductByIdAsync(int id)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<ProductDto>($"api/Products/{id}");
    }

    public async Task<int> CreateProductAsync(ProductDto product)
    {
        await AddAuthHeader();
        var response = await _http.PostAsJsonAsync("api/Products", product);
        return await response.Content.ReadFromJsonAsync<int>();
    }

    public async Task UpdateProductAsync(ProductDto product)
    {
        await AddAuthHeader();
        await _http.PutAsJsonAsync("api/Products", product);
    }

    public async Task UpdateCOGSAsync(int productId, decimal cogs)
    {
        await AddAuthHeader();
        await _http.PutAsJsonAsync($"api/Products/cogs?productId={productId}&cogs={cogs}", new { });
    }
    #endregion

    #region Inventory
    public async Task<IEnumerable<InventorySnapshotDto>> GetInventorySnapshotsAsync(int sellerAccountId, DateTime? date = null)
    {
        await AddAuthHeader();
        var url = $"api/Inventory/snapshots?sellerAccountId={sellerAccountId}";
        if (date.HasValue) url += $"&date={date:yyyy-MM-dd}";
        return await _http.GetFromJsonAsync<IEnumerable<InventorySnapshotDto>>(url) ?? new List<InventorySnapshotDto>();
    }

    public async Task<IEnumerable<ReorderSuggestionDto>> GetReorderSuggestionsAsync(int sellerAccountId, int leadTimeDays = 30, decimal serviceLevel = 0.95m)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ReorderSuggestionDto>>($"api/Inventory/reorder-suggestions?sellerAccountId={sellerAccountId}&leadTimeDays={leadTimeDays}&serviceLevel={serviceLevel}") ?? new List<ReorderSuggestionDto>();
    }

    public async Task<IEnumerable<OverstockReportDto>> GetOverstockReportAsync(int sellerAccountId, int daysOfSupplyThreshold = 365)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<OverstockReportDto>>($"api/Inventory/overstock?sellerAccountId={sellerAccountId}&daysOfSupplyThreshold={daysOfSupplyThreshold}") ?? new List<OverstockReportDto>();
    }

    public async Task<IEnumerable<AgedInventoryFeeRiskDto>> GetAgedInventoryAsync(int sellerAccountId, DateTime? snapshotDate = null)
    {
        await AddAuthHeader();
        var url = $"api/Inventory/aged?sellerAccountId={sellerAccountId}";
        if (snapshotDate.HasValue) url += $"&snapshotDate={snapshotDate:yyyy-MM-dd}";
        return await _http.GetFromJsonAsync<IEnumerable<AgedInventoryFeeRiskDto>>(url) ?? new List<AgedInventoryFeeRiskDto>();
    }

    public async Task<IEnumerable<StrandedInventoryDto>> GetStrandedInventoryAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<StrandedInventoryDto>>($"api/Inventory/stranded?sellerAccountId={sellerAccountId}") ?? new List<StrandedInventoryDto>();
    }

    public async Task<IEnumerable<IPIImprovementActionDto>> GetIPIImprovementActionsAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<IPIImprovementActionDto>>($"api/Inventory/ipi-actions?sellerAccountId={sellerAccountId}") ?? new List<IPIImprovementActionDto>();
    }
    #endregion

    #region Cases
    public async Task<IEnumerable<CaseDto>> GetCasesAsync(int sellerAccountId, string? status = null, int page = 1, int pageSize = 20)
    {
        await AddAuthHeader();
        var url = $"api/Cases?sellerAccountId={sellerAccountId}&page={page}&pageSize={pageSize}";
        if (!string.IsNullOrEmpty(status)) url += $"&status={status}";
        return await _http.GetFromJsonAsync<IEnumerable<CaseDto>>(url) ?? new List<CaseDto>();
    }

    public async Task<CaseDto?> GetCaseByIdAsync(int id)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<CaseDto>($"api/Cases/{id}");
    }

    public async Task<int> CreateCaseAsync(CaseCreateDto caseDto)
    {
        await AddAuthHeader();
        var response = await _http.PostAsJsonAsync("api/Cases", caseDto);
        return await response.Content.ReadFromJsonAsync<int>();
    }

    public async Task ResolveCaseAsync(int id, decimal? resolvedAmount = null, string? resolutionNote = null)
    {
        await AddAuthHeader();
        await _http.PutAsync($"api/Cases/{id}/resolve?resolvedAmount={resolvedAmount}&resolutionNote={resolutionNote}", null);
    }

    public async Task EscalateCaseAsync(int id, int userId, string reason)
    {
        await AddAuthHeader();
        await _http.PutAsync($"api/Cases/{id}/escalate?userId={userId}&reason={reason}", null);
    }

    public async Task<IEnumerable<CaseNoteDto>> GetCaseNotesAsync(int caseId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<CaseNoteDto>>($"api/Cases/{caseId}/notes") ?? new List<CaseNoteDto>();
    }

    public async Task<IEnumerable<CaseAgingReportDto>> GetCaseAgingReportAsync(int sellerAccountId, int slaDays = 14)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<CaseAgingReportDto>>($"api/Cases/aging?sellerAccountId={sellerAccountId}&slaDays={slaDays}") ?? new List<CaseAgingReportDto>();
    }

    public async Task<IEnumerable<SuppressedListingDto>> GetSuppressedListingsAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<SuppressedListingDto>>($"api/Cases/suppressed-listings?sellerAccountId={sellerAccountId}") ?? new List<SuppressedListingDto>();
    }
    #endregion

    #region Reimbursements
    public async Task<IEnumerable<ReimbursementAuditDto>> AuditLostDamagedAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ReimbursementAuditDto>>($"api/Reimbursement/lost-damaged?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new List<ReimbursementAuditDto>();
    }

    public async Task<IEnumerable<ReturnlessRefundAuditDto>> AuditReturnlessAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ReturnlessRefundAuditDto>>($"api/Reimbursement/returnless?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new List<ReturnlessRefundAuditDto>();
    }

    public async Task<IEnumerable<FeeOverchargeDto>> GetFeeOverchargesAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<FeeOverchargeDto>>($"api/Reimbursement/fee-overcharges?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new List<FeeOverchargeDto>();
    }

    public async Task<IEnumerable<ReimbursementChecklistItemDto>> GetMonthlyChecklistAsync(int sellerAccountId, int month, int year)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ReimbursementChecklistItemDto>>($"api/Reimbursement/checklist?sellerAccountId={sellerAccountId}&month={month}&year={year}") ?? new List<ReimbursementChecklistItemDto>();
    }

    public async Task<ReimbursementKPIDashboardDto> GetReimbursementKPIAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<ReimbursementKPIDashboardDto>($"api/Reimbursement/kpi?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new ReimbursementKPIDashboardDto();
    }

    public async Task<IEnumerable<COGSImpactDto>> GetCOGSImpactAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<COGSImpactDto>>($"api/Reimbursement/cogs-impact?sellerAccountId={sellerAccountId}") ?? new List<COGSImpactDto>();
    }

    public async Task<IEnumerable<ReimbursementAuditDto>> GetPendingAuditsAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ReimbursementAuditDto>>($"api/Reimbursement/pending?sellerAccountId={sellerAccountId}") ?? new List<ReimbursementAuditDto>();
    }
    #endregion

    #region Sales
    public async Task<IEnumerable<SalesOrderDto>> GetSalesOrdersAsync(int sellerAccountId, DateTime? dateFrom = null, DateTime? dateTo = null, int page = 1, int pageSize = 20)
    {
        await AddAuthHeader();
        var url = $"api/Sales?sellerAccountId={sellerAccountId}&page={page}&pageSize={pageSize}";
        if (dateFrom.HasValue) url += $"&dateFrom={dateFrom:yyyy-MM-dd}";
        if (dateTo.HasValue) url += $"&dateTo={dateTo:yyyy-MM-dd}";
        return await _http.GetFromJsonAsync<IEnumerable<SalesOrderDto>>(url) ?? new List<SalesOrderDto>();
    }

    public async Task<SalesOrderDto?> GetSalesOrderByIdAsync(long id)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<SalesOrderDto>($"api/Sales/{id}");
    }

    public async Task<IEnumerable<SalesOrderItemDto>> GetSalesOrderItemsAsync(long orderId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<SalesOrderItemDto>>($"api/Sales/{orderId}/items") ?? new List<SalesOrderItemDto>();
    }

    public async Task<IEnumerable<ProfitLossBySKUDto>> GetProfitLossAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo, string groupBy = "SKU")
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<ProfitLossBySKUDto>>($"api/Sales/profit-loss?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}&groupBy={groupBy}") ?? new List<ProfitLossBySKUDto>();
    }

    public async Task<IEnumerable<SalesVelocityDto>> GetSalesVelocityAsync(int sellerAccountId, string? asin = null, int periods = 12)
    {
        await AddAuthHeader();
        var url = $"api/Sales/velocity?sellerAccountId={sellerAccountId}&periods={periods}";
        if (!string.IsNullOrEmpty(asin)) url += $"&asin={asin}";
        return await _http.GetFromJsonAsync<IEnumerable<SalesVelocityDto>>(url) ?? new List<SalesVelocityDto>();
    }
    #endregion

    #region PPC
    public async Task<IEnumerable<PPCCampaignDto>> GetCampaignsAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<PPCCampaignDto>>($"api/PPC/campaigns?sellerAccountId={sellerAccountId}") ?? new List<PPCCampaignDto>();
    }

    public async Task<IEnumerable<PPCKeywordDto>> GetKeywordsAsync(int sellerAccountId, int? campaignId = null, string? period = null)
    {
        await AddAuthHeader();
        var url = $"api/PPC/keywords?sellerAccountId={sellerAccountId}";
        if (campaignId.HasValue) url += $"&campaignId={campaignId}";
        if (!string.IsNullOrEmpty(period)) url += $"&period={period}";
        return await _http.GetFromJsonAsync<IEnumerable<PPCKeywordDto>>(url) ?? new List<PPCKeywordDto>();
    }

    public async Task<IEnumerable<WastedSpendDto>> AuditCampaignsAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<WastedSpendDto>>($"api/PPC/audit?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new List<WastedSpendDto>();
    }

    public async Task<TACoSReportDto> GetTACoSAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<TACoSReportDto>($"api/PPC/tacos?sellerAccountId={sellerAccountId}&dateFrom={dateFrom:yyyy-MM-dd}&dateTo={dateTo:yyyy-MM-dd}") ?? new TACoSReportDto();
    }

    public async Task<IEnumerable<BidAdjustmentDto>> GetBidSuggestionsAsync(int sellerAccountId, decimal targetACoS = 25m)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<BidAdjustmentDto>>($"api/PPC/bid-suggestions?sellerAccountId={sellerAccountId}&targetACoS={targetACoS}") ?? new List<BidAdjustmentDto>();
    }
    #endregion

    #region CSV Import
    public async Task<CSVImportResultDto> ImportCSVAsync(long importId, string reportType)
    {
        await AddAuthHeader();
        var response = await _http.PostAsync($"api/CSV/import?importId={importId}&reportType={reportType}", null);
        return await response.Content.ReadFromJsonAsync<CSVImportResultDto>() ?? new CSVImportResultDto();
    }

    public async Task<IEnumerable<CSVImportDto>> GetImportHistoryAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<CSVImportDto>>($"api/CSV/history?sellerAccountId={sellerAccountId}") ?? new List<CSVImportDto>();
    }
    #endregion

    #region Alerts
    public async Task<IEnumerable<AlertDto>> GetAlertsAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<AlertDto>>($"api/Alerts?sellerAccountId={sellerAccountId}") ?? new List<AlertDto>();
    }

    public async Task<AlertSummaryDto> GetAlertSummaryAsync(int sellerAccountId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<AlertSummaryDto>($"api/Alerts/summary?sellerAccountId={sellerAccountId}") ?? new AlertSummaryDto();
    }

    public async Task MarkAlertReadAsync(long alertId)
    {
        await AddAuthHeader();
        await _http.PutAsync($"api/Alerts/{alertId}/read", null);
    }

    public async Task ResolveAlertAsync(long alertId, int resolvedByUserId)
    {
        await AddAuthHeader();
        await _http.PutAsync($"api/Alerts/{alertId}/resolve?resolvedByUserId={resolvedByUserId}", null);
    }
    #endregion

    #region Niche Research
    public async Task<IEnumerable<OpportunityScoreResult>> GetNicheResearchAsync(int sellerAccountId, string keyword)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<OpportunityScoreResult>>($"api/Niche/opportunity?sellerAccountId={sellerAccountId}&keyword={keyword}") ?? new List<OpportunityScoreResult>();
    }

    public async Task<IEnumerable<TrendingProduct>> GetTrendingProductsAsync(int sellerAccountId, string? category = null, string velocity = "Medium")
    {
        await AddAuthHeader();
        var url = $"api/Niche/trending?sellerAccountId={sellerAccountId}&velocity={velocity}";
        if (!string.IsNullOrEmpty(category)) url += $"&category={category}";
        return await _http.GetFromJsonAsync<IEnumerable<TrendingProduct>>(url) ?? new List<TrendingProduct>();
    }

    public async Task<IEnumerable<BundleOpportunity>> GetBundleOpportunitiesAsync(int sellerAccountId, string asin)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<BundleOpportunity>>($"api/Niche/bundles?sellerAccountId={sellerAccountId}&asin={asin}") ?? new List<BundleOpportunity>();
    }

    public async Task<AsinAnalysisResult> GetAsinAnalysisAsync(int sellerAccountId, string asin)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<AsinAnalysisResult>($"api/Niche/reverse-asin?sellerAccountId={sellerAccountId}&asin={asin}") ?? new AsinAnalysisResult();
    }
    #endregion

    #region User Management
    public async Task<IEnumerable<SellerAccountDto>> GetSellerAccountsAsync()
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<SellerAccountDto>>("api/Accounts") ?? new List<SellerAccountDto>();
    }

    public async Task<IEnumerable<SellerAccountDto>> GetUserAccountsAsync(int userId)
    {
        await AddAuthHeader();
        return await _http.GetFromJsonAsync<IEnumerable<SellerAccountDto>>($"api/Accounts/user/{userId}") ?? new List<SellerAccountDto>();
    }
    #endregion
}