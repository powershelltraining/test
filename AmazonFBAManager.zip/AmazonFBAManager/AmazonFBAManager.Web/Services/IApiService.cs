using AmazonFBAManager.Shared.DTOs;

namespace AmazonFBAManager.Web.Services;

public interface IApiService
{
    // Auth
    Task<LoginResponseDto> LoginAsync(string username, string password);
    Task<int> RegisterAsync(string username, string email, string password, int roleId = 2);
    Task<IEnumerable<UserDto>> GetUsersAsync();
    Task<IEnumerable<SellerAccountDto>> GetUserAccountsAsync(int userId);

    // Dashboard
    Task<DashboardSummaryDto> GetDashboardSummaryAsync(int sellerAccountId);
    Task<IEnumerable<MultiAccountSummaryDto>> GetMultiAccountSummaryAsync(int userId, DateTime dateFrom, DateTime dateTo);

    // Products
    Task<IEnumerable<ProductDto>> GetProductsAsync(int sellerAccountId, int page = 1, int pageSize = 20);
    Task<ProductDto?> GetProductByIdAsync(int id);
    Task<int> CreateProductAsync(ProductDto product);
    Task UpdateProductAsync(ProductDto product);
    Task UpdateCOGSAsync(int productId, decimal cogs);

    // Inventory
    Task<IEnumerable<InventorySnapshotDto>> GetInventorySnapshotsAsync(int sellerAccountId, DateTime? date = null);
    Task<IEnumerable<ReorderSuggestionDto>> GetReorderSuggestionsAsync(int sellerAccountId, int leadTimeDays = 30, decimal serviceLevel = 0.95m);
    Task<IEnumerable<OverstockReportDto>> GetOverstockReportAsync(int sellerAccountId, int daysOfSupplyThreshold = 365);
    Task<IEnumerable<AgedInventoryFeeRiskDto>> GetAgedInventoryAsync(int sellerAccountId, DateTime? snapshotDate = null);
    Task<IEnumerable<StrandedInventoryDto>> GetStrandedInventoryAsync(int sellerAccountId);
    Task<IEnumerable<IPIImprovementActionDto>> GetIPIImprovementActionsAsync(int sellerAccountId);

    // Cases
    Task<IEnumerable<CaseDto>> GetCasesAsync(int sellerAccountId, string? status = null, int page = 1, int pageSize = 20);
    Task<CaseDto?> GetCaseByIdAsync(int id);
    Task<int> CreateCaseAsync(CaseCreateDto caseDto);
    Task ResolveCaseAsync(int id, decimal? resolvedAmount = null, string? resolutionNote = null);
    Task EscalateCaseAsync(int id, int userId, string reason);
    Task<IEnumerable<CaseNoteDto>> GetCaseNotesAsync(int caseId);
    Task<IEnumerable<CaseAgingReportDto>> GetCaseAgingReportAsync(int sellerAccountId, int slaDays = 14);
    Task<IEnumerable<SuppressedListingDto>> GetSuppressedListingsAsync(int sellerAccountId);

    // Reimbursements
    Task<IEnumerable<ReimbursementAuditDto>> AuditLostDamagedAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<ReturnlessRefundAuditDto>> AuditReturnlessAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<FeeOverchargeDto>> GetFeeOverchargesAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<ReimbursementChecklistItemDto>> GetMonthlyChecklistAsync(int sellerAccountId, int month, int year);
    Task<ReimbursementKPIDashboardDto> GetReimbursementKPIAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<COGSImpactDto>> GetCOGSImpactAsync(int sellerAccountId);
    Task<IEnumerable<ReimbursementAuditDto>> GetPendingAuditsAsync(int sellerAccountId);

    // Sales
    Task<IEnumerable<SalesOrderDto>> GetSalesOrdersAsync(int sellerAccountId, DateTime? dateFrom = null, DateTime? dateTo = null, int page = 1, int pageSize = 20);
    Task<SalesOrderDto?> GetSalesOrderByIdAsync(long id);
    Task<IEnumerable<SalesOrderItemDto>> GetSalesOrderItemsAsync(long orderId);
    Task<IEnumerable<ProfitLossBySKUDto>> GetProfitLossAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo, string groupBy = "SKU");
    Task<IEnumerable<SalesVelocityDto>> GetSalesVelocityAsync(int sellerAccountId, string? asin = null, int periods = 12);

    // PPC
    Task<IEnumerable<PPCCampaignDto>> GetCampaignsAsync(int sellerAccountId);
    Task<IEnumerable<PPCKeywordDto>> GetKeywordsAsync(int sellerAccountId, int? campaignId = null, string? period = null);
    Task<IEnumerable<WastedSpendDto>> AuditCampaignsAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<TACoSReportDto> GetTACoSAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<BidAdjustmentDto>> GetBidSuggestionsAsync(int sellerAccountId, decimal targetACoS = 25m);

    // CSV Import
    Task<CSVImportResultDto> ImportCSVAsync(long importId, string reportType);
    Task<IEnumerable<CSVImportDto>> GetImportHistoryAsync(int sellerAccountId);

    // Alerts
    Task<IEnumerable<AlertDto>> GetAlertsAsync(int sellerAccountId);
    Task<AlertSummaryDto> GetAlertSummaryAsync(int sellerAccountId);
    Task MarkAlertReadAsync(long alertId);
    Task ResolveAlertAsync(long alertId, int resolvedByUserId);

    // Niche Research
    Task<IEnumerable<OpportunityScoreResult>> GetNicheResearchAsync(int sellerAccountId, string keyword);
    Task<IEnumerable<TrendingProduct>> GetTrendingProductsAsync(int sellerAccountId, string? category = null, string velocity = "Medium");
    Task<IEnumerable<BundleOpportunity>> GetBundleOpportunitiesAsync(int sellerAccountId, string asin);
    Task<AsinAnalysisResult> GetAsinAnalysisAsync(int sellerAccountId, string asin);

    // User Management
    Task<IEnumerable<SellerAccountDto>> GetSellerAccountsAsync();
    Task<IEnumerable<SellerAccountDto>> GetUserAccountsAsync(int userId);
}