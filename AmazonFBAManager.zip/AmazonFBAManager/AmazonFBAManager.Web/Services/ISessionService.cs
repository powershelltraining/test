using AmazonFBAManager.Shared.DTOs;

namespace AmazonFBAManager.Web.Services;

public interface ISessionService
{
    Task<string?> GetToken();
    Task SetToken(string token);
    Task ClearToken();

    Task<UserDto?> GetCurrentUser();
    Task SetCurrentUser(UserDto user);

    Task<int?> GetUserId();
    Task SetUserId(int userId);

    Task<int?> GetSelectedAccountId();
    Task SetSelectedAccountId(int accountId);
    Task ClearSelectedAccountId();
}