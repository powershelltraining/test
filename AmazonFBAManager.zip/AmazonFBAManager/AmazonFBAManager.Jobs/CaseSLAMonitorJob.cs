using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

namespace AmazonFBAManager.Jobs;

/// <summary>
/// Hourly job that monitors case SLAs and creates alerts for:
/// - Cases approaching SLA deadline
/// - Cases that have breached SLA
/// - Case status changes
/// </summary>
public class CaseSLAMonitorJob
{
    private readonly ILogger<CaseSLAMonitorJob> _logger;
    private readonly string _connectionString;

    public CaseSLAMonitorJob(ILogger<CaseSLAMonitorJob> logger, IConfiguration configuration)
    {
        _logger = logger;
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? "Server=localhost;Database=AmazonFBAManager;Trusted_Connection=True;TrustServerCertificate=True;";
    }

    public async Task ExecuteAsync()
    {
        _logger.LogInformation("Starting case SLA monitor job");

        try
        {
            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            // Get all active seller accounts
            var sellerAccounts = await connection.QueryAsync<int>(
                "SELECT Id FROM SellerAccounts WHERE IsActive = 1");

            foreach (var accountId in sellerAccounts)
            {
                try
                {
                    await MonitorCasesForAccountAsync(connection, accountId);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error monitoring cases for account {AccountId}", accountId);
                }
            }

            _logger.LogInformation("Case SLA monitor completed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Fatal error in case SLA monitor job");
            throw;
        }
    }

    private async Task MonitorCasesForAccountAsync(SqlConnection connection, int accountId)
    {
        var today = DateTime.Today;

        // 1. Check for cases approaching SLA (within 48 hours)
        var approachingCases = await connection.QueryAsync<CaseInfo>(
            @"SELECT c.Id, c.CaseId, c.Subject, c.CaseType, c.Status, c.SLADays, c.CreatedAt,
                     DATEADD(DAY, c.SLADays, c.CreatedAt) AS SLADeadline
              FROM Cases c
              WHERE c.SellerAccountId = @AccountId
                AND c.Status IN ('Open', 'In Progress')
                AND DATEADD(DAY, c.SLADays, c.CreatedAt) BETWEEN @Today AND @Deadline",
            new
            {
                AccountId = accountId,
                Today = today,
                Deadline = today.AddDays(2)
            });

        foreach (var c in approachingCases)
        {
            var existingAlert = await connection.QueryFirstOrDefaultAsync<int>(
                @"SELECT COUNT(*) FROM Alerts
                  WHERE SellerAccountId = @AccountId
                    AND AlertType = 'Case'
                    AND Title LIKE @CaseId
                    AND Status = 'Active'
                    AND CreatedAt > @RecentTime",
                new { AccountId = accountId, CaseId = $"%{c.CaseId}%", RecentTime = DateTime.Now.AddHours(-12) });

            if (existingAlert == 0)
            {
                var hoursUntilSLA = (c.SLADeadline - today).TotalHours;
                await connection.ExecuteAsync(
                    @"INSERT INTO Alerts (SellerAccountId, AlertType, Title, Description, Severity, CreatedAt, Status)
                      VALUES (@AccountId, 'Case', @Title, @Description, 'Warning', GETDATE(), 'Active')",
                    new
                    {
                        AccountId = accountId,
                        Title = $"SLA Warning: Case {c.CaseId}",
                        Description = $"Case \"{c.Subject}\" will reach SLA in {(int)hoursUntilSLA} hours"
                    });
            }
        }

        // 2. Check for cases that have breached SLA
        var breachedCases = await connection.QueryAsync<CaseInfo>(
            @"SELECT c.Id, c.CaseId, c.Subject, c.CaseType, c.Status, c.SLADays, c.CreatedAt,
                     DATEADD(DAY, c.SLADays, c.CreatedAt) AS SLADeadline
              FROM Cases c
              WHERE c.SellerAccountId = @AccountId
                AND c.Status IN ('Open', 'In Progress')
                AND DATEADD(DAY, c.SLADays, c.CreatedAt) < @Today",
            new { AccountId = accountId, Today = today });

        foreach (var c in breachedCases)
        {
            var existingAlert = await connection.QueryFirstOrDefaultAsync<int>(
                @"SELECT COUNT(*) FROM Alerts
                  WHERE SellerAccountId = @AccountId
                    AND AlertType = 'Case'
                    AND Title LIKE @BreachedTitle
                    AND Status = 'Active'",
                new { AccountId = accountId, BreachedTitle = $"%SLA Breached: {c.CaseId}%" });

            if (existingAlert == 0)
            {
                var daysBreached = (today - c.SLADeadline).Days;
                await connection.ExecuteAsync(
                    @"INSERT INTO Alerts (SellerAccountId, AlertType, Title, Description, Severity, CreatedAt, Status)
                      VALUES (@AccountId, 'Case', @Title, @Description, 'Critical', GETDATE(), 'Active')",
                    new
                    {
                        AccountId = accountId,
                        Title = $"SLA Breached: Case {c.CaseId}",
                        Description = $"Case \"{c.Subject}\" has breached SLA by {daysBreached} days"
                    });
            }
        }

        _logger.LogInformation("Monitored cases for account {AccountId}", accountId);
    }

    private class CaseInfo
    {
        public int Id { get; set; }
        public string CaseId { get; set; } = "";
        public string Subject { get; set; } = "";
        public string CaseType { get; set; } = "";
        public string Status { get; set; } = "";
        public int SLADays { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime SLADeadline { get; set; }
    }
}