using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

namespace AmazonFBAManager.Jobs;

/// <summary>
/// Periodic job that checks inventory levels and creates alerts for:
/// - Low stock items (below reorder point)
/// - Aged inventory (90+ days)
/// - Stranded inventory
/// - IPI score warnings
/// </summary>
public class InventoryAlertCheckJob
{
    private readonly ILogger<InventoryAlertCheckJob> _logger;
    private readonly string _connectionString;

    public InventoryAlertCheckJob(ILogger<InventoryAlertCheckJob> logger, IConfiguration configuration)
    {
        _logger = logger;
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? "Server=localhost;Database=AmazonFBAManager;Trusted_Connection=True;TrustServerCertificate=True;";
    }

    public async Task ExecuteAsync()
    {
        _logger.LogInformation("Starting inventory alert check job");

        try
        {
            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            // Get all active seller accounts
            var sellerAccounts = await connection.QueryAsync<int>(
                "SELECT Id FROM SellerAccounts WHERE IsActive = 1");

            foreach (var accountId in sellerAccounts)
            {
                try
                {
                    await CheckInventoryForAccountAsync(connection, accountId);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error checking inventory for account {AccountId}", accountId);
                }
            }

            _logger.LogInformation("Inventory alert check completed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Fatal error in inventory alert check job");
            throw;
        }
    }

    private async Task CheckInventoryForAccountAsync(SqlConnection connection, int accountId)
    {
        // Check for low stock items
        var lowStockItems = await connection.QueryAsync<LowStockItem>(
            @"SELECT p.SKU, p.ProductName, p.CurrentStock, p.ReorderPoint
              FROM Products p
              WHERE p.SellerAccountId = @AccountId
                AND p.CurrentStock <= p.ReorderPoint
                AND p.ReorderPoint > 0",
            new { AccountId = accountId });

        foreach (var item in lowStockItems)
        {
            // Check if alert already exists
            var existingAlert = await connection.QueryFirstOrDefaultAsync<int>(
                @"SELECT COUNT(*) FROM Alerts
                  WHERE SellerAccountId = @AccountId
                    AND AlertType = 'Inventory'
                    AND Title LIKE @SKU
                    AND Status = 'Active'
                    AND CreatedAt > @RecentTime",
                new { AccountId = accountId, SKU = $"%{item.SKU}%", RecentTime = DateTime.Now.AddHours(-24) });

            if (existingAlert == 0)
            {
                await connection.ExecuteAsync(
                    @"INSERT INTO Alerts (SellerAccountId, AlertType, Title, Description, Severity, CreatedAt, Status)
                      VALUES (@AccountId, 'Inventory', @Title, @Description, 'Warning', GETDATE(), 'Active')",
                    new
                    {
                        AccountId = accountId,
                        Title = $"Low Stock Alert: {item.SKU}",
                        Description = $"Product {item.ProductName} has {item.CurrentStock} units (reorder point: {item.ReorderPoint})"
                    });
            }
        }

        // Check for aged inventory (90+ days)
        var agedItems = await connection.QueryAsync<AgedInventoryItem>(
            @"SELECT SKU, ProductName, Quantity, DaysInStock
              FROM vw_AgedInventory
              WHERE SellerAccountId = @AccountId AND DaysInStock >= 90",
            new { AccountId = accountId });

        var agedCount = agedItems.Count();
        if (agedCount > 0)
        {
            var existingAlert = await connection.QueryFirstOrDefaultAsync<int>(
                @"SELECT COUNT(*) FROM Alerts
                  WHERE SellerAccountId = @AccountId
                    AND AlertType = 'Inventory'
                    AND Title LIKE 'Aged Inventory%'
                    AND Status = 'Active'
                    AND CreatedAt > @RecentTime",
                new { AccountId = accountId, RecentTime = DateTime.Now.AddHours(-24) });

            if (existingAlert == 0)
            {
                await connection.ExecuteAsync(
                    @"INSERT INTO Alerts (SellerAccountId, AlertType, Title, Description, Severity, CreatedAt, Status)
                      VALUES (@AccountId, 'Inventory', @Title, @Description, 'Warning', GETDATE(), 'Active')",
                    new
                    {
                        AccountId = accountId,
                        Title = $"Aged Inventory Alert: {agedCount} items",
                        Description = $"{agedCount} items have been in Amazon's warehouse for 90+ days"
                    });
            }
        }

        _logger.LogInformation("Checked inventory for account {AccountId}", accountId);
    }

    private class LowStockItem
    {
        public string SKU { get; set; } = "";
        public string ProductName { get; set; } = "";
        public int CurrentStock { get; set; }
        public int ReorderPoint { get; set; }
    }

    private class AgedInventoryItem
    {
        public string SKU { get; set; } = "";
        public string ProductName { get; set; } = "";
        public int Quantity { get; set; }
        public int DaysInStock { get; set; }
    }
}