using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

namespace AmazonFBAManager.Jobs;

/// <summary>
/// Daily job that generates summary reports for all users.
/// Sends email notifications with key metrics for their seller accounts.
/// </summary>
public class DailySummaryJob
{
    private readonly ILogger<DailySummaryJob> _logger;
    private readonly string _connectionString;

    public DailySummaryJob(ILogger<DailySummaryJob> logger, IConfiguration configuration)
    {
        _logger = logger;
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? "Server=localhost;Database=AmazonFBAManager;Trusted_Connection=True;TrustServerCertificate=True;";
    }

    public async Task ExecuteAsync()
    {
        _logger.LogInformation("Starting daily summary job");

        try
        {
            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            // Get all users who want daily summaries
            var users = await connection.QueryAsync<UserInfo>(
                @"SELECT u.Id, u.Email, u.FullName, u.Preferences
                  FROM Users u
                  WHERE u.Preferences LIKE '%DailySummary%'");

            foreach (var user in users)
            {
                try
                {
                    await GenerateSummaryForUserAsync(connection, user);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error generating summary for user {UserId}", user.Id);
                }
            }

            _logger.LogInformation("Daily summary job completed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Fatal error in daily summary job");
            throw;
        }
    }

    private async Task GenerateSummaryForUserAsync(SqlConnection connection, UserInfo user)
    {
        // Get user's seller accounts
        var accounts = await connection.QueryAsync<SellerAccountInfo>(
            @"SELECT sa.Id, sa.SellerName, sa.SellerId
              FROM SellerAccounts sa
              WHERE sa.UserId = @UserId AND sa.IsActive = 1",
            new { UserId = user.Id });

        foreach (var account in accounts)
        {
            // Get summary metrics
            var metrics = await connection.QueryFirstOrDefaultAsync<DailyMetrics>(
                @"EXEC sp_Dashboard_GetSummary @SellerAccountId",
                new { SellerAccountId = account.Id });

            if (metrics != null)
            {
                // Record activity
                await connection.ExecuteAsync(
                    @"INSERT INTO ActivityLog (SellerAccountId, ActivityType, Description, CreatedAt)
                      VALUES (@AccountId, 'DailySummary', @Description, GETDATE())",
                    new
                    {
                        AccountId = account.Id,
                        Description = $"Daily summary: {metrics.OpenCases} open cases, ${metrics.PendingReimbursements:N2} pending reimbursements, {metrics.ActiveListings} active listings"
                    });
            }
        }

        _logger.LogInformation("Generated daily summary for user {UserId}", user.Id);
    }

    private class UserInfo
    {
        public int Id { get; set; }
        public string Email { get; set; } = "";
        public string FullName { get; set; } = "";
        public string? Preferences { get; set; }
    }

    private class SellerAccountInfo
    {
        public int Id { get; set; }
        public string SellerName { get; set; } = "";
        public string SellerId { get; set; } = ""
    }

    private class DailyMetrics
    {
        public int OpenCases { get; set; }
        public decimal PendingReimbursements { get; set; }
        public int ActiveListings { get; set; }
    }
}