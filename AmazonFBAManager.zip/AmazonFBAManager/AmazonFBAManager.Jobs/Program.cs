using Hangfire;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using AmazonFBAManager.Jobs;

var builder = Host.CreateApplicationBuilder(args);

// Configure Hangfire
builder.Services.AddHangfire(configuration => configuration
    .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
    .UseSimpleAssemblyNameTypeSerializer()
    .UseRecommendedSerializerSettings()
    .UseSqlServerStorage(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        new Hangfire.SqlServer.SqlServerStorageOptions
        {
            CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
            SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
            QueuePollInterval = TimeSpan.FromSeconds(15),
            UseRecommendedIsolationLevel = true,
            DisableGlobalLocks = true
        }));

builder.Services.AddHangfireServer();

// Register jobs
builder.Services.AddTransient<NightlyReimbursementAuditJob>();
builder.Services.AddTransient<InventoryAlertCheckJob>();
builder.Services.AddTransient<CaseSLAMonitorJob>();
builder.Services.AddTransient<DailySummaryJob>();

var host = builder.Build();

// Configure recurring jobs
using (var scope = host.Services.CreateScope())
{
    var dashboard = scope.ServiceProvider.GetRequiredService<IRecurringJobManager>();

    // Nightly reimbursement audit - runs at 2:00 AM
    dashboard.AddOrUpdate<NightlyReimbursementAuditJob>(
        "nightly-reimbursement-audit",
        job => job.ExecuteAsync(),
        "0 2 * * *", // Cron: 2:00 AM daily
        new RecurringJobOptions { TimeZone = TimeZoneInfo.Local });

    // Inventory alert check - runs every 4 hours
    dashboard.AddOrUpdate<InventoryAlertCheckJob>(
        "inventory-alert-check",
        job => job.ExecuteAsync(),
        "0 */4 * * *", // Cron: Every 4 hours
        new RecurringJobOptions { TimeZone = TimeZoneInfo.Local });

    // Case SLA monitor - runs every hour
    dashboard.AddOrUpdate<CaseSLAMonitorJob>(
        "case-sla-monitor",
        job => job.ExecuteAsync(),
        "0 * * * *", // Cron: Every hour
        new RecurringJobOptions { TimeZone = TimeZoneInfo.Local });

    // Daily summary report - runs at 8:00 AM
    dashboard.AddOrUpdate<DailySummaryJob>(
        "daily-summary",
        job => job.ExecuteAsync(),
        "0 8 * * *", // Cron: 8:00 AM daily
        new RecurringJobOptions { TimeZone = TimeZoneInfo.Local });
}

Console.WriteLine("Amazon FBA Manager Jobs starting...");
host.Run();