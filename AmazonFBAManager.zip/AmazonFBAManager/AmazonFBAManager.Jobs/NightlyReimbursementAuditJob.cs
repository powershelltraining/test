using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

namespace AmazonFBAManager.Jobs;

/// <summary>
/// Nightly job that runs reimbursement audits for all seller accounts.
/// Scans for: lost/damaged inventory, fee overcharges, returnless refunds, missing COGS.
/// Uses 2025 Amazon reimbursement policy (cost basis, not selling price).
/// </summary>
public class NightlyReimbursementAuditJob
{
    private readonly ILogger<NightlyReimbursementAuditJob> _logger;
    private readonly string _connectionString;

    public NightlyReimbursementAuditJob(ILogger<NightlyReimbursementAuditJob> logger, IConfiguration configuration)
    {
        _logger = logger;
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? "Server=localhost;Database=AmazonFBAManager;Trusted_Connection=True;TrustServerCertificate=True;";
    }

    public async Task ExecuteAsync()
    {
        _logger.LogInformation("Starting nightly reimbursement audit job");

        try
        {
            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            // Get all active seller accounts
            var sellerAccounts = await connection.QueryAsync<int>(
                "SELECT Id FROM SellerAccounts WHERE IsActive = 1");

            var dateTo = DateTime.Today;
            var dateFrom = dateTo.AddDays(-90); // Look back 90 days

            foreach (var accountId in sellerAccounts)
            {
                try
                {
                    await RunAuditForAccountAsync(connection, accountId, dateFrom, dateTo);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error auditing account {AccountId}", accountId);
                }
            }

            _logger.LogInformation("Nightly reimbursement audit completed");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Fatal error in nightly reimbursement audit job");
            throw;
        }
    }

    private async Task RunAuditForAccountAsync(SqlConnection connection, int accountId, DateTime dateFrom, DateTime dateTo)
    {
        _logger.LogInformation("Auditing account {AccountId}", accountId);

        // 1. Audit lost/damaged inventory (using stored procedure)
        await connection.ExecuteAsync(
            "sp_Reimbursement_AuditLostDamaged",
            new { SellerAccountId = accountId, DateFrom = dateFrom, DateTo = dateTo },
            commandType: System.Data.CommandType.StoredProcedure);

        // 2. Audit returnless refunds
        await connection.ExecuteAsync(
            "sp_Reimbursement_AuditReturnless",
            new { SellerAccountId = accountId, DateFrom = dateFrom, DateTo = dateTo },
            commandType: System.Data.CommandType.StoredProcedure);

        // 3. Audit fee overcharges
        await connection.ExecuteAsync(
            "sp_Reimbursement_AuditFeeOvercharges",
            new { SellerAccountId = accountId, DateFrom = dateFrom, DateTo = dateTo },
            commandType: System.Data.CommandType.StoredProcedure);

        // 4. Identify missing COGS (2025 policy requires cost basis)
        await connection.ExecuteAsync(
            "sp_Reimbursement_IdentifyMissingCOGS",
            new { SellerAccountId = accountId },
            commandType: System.Data.CommandType.StoredProcedure);

        _logger.LogInformation("Completed audit for account {AccountId}", accountId);
    }
}