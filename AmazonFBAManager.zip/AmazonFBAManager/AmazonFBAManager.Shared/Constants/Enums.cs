namespace AmazonFBAManager.Shared.Constants;

/// <summary>
/// All enumerations and constants for the application
/// </summary>

public static class AppConstants
{
    public const string AppName = "Amazon FBA Manager";
    public const string AppVersion = "1.0.0";

    // Default page sizes
    public const int DefaultPageSize = 20;
    public const int MaxPageSize = 100;

    // Date formats
    public const string DateFormat = "yyyy-MM-dd";
    public const string DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
    public const string MonthYearFormat = "yyyy-MM";

    // Default service level for reorder calculations
    public const decimal DefaultServiceLevel = 0.95m;

    // Default lead time days
    public const int DefaultLeadTimeDays = 7;

    // IPI thresholds
    public const decimal IPIExcellentThreshold = 700;
    public const decimal IPIGoodThreshold = 550;
    public const decimal IPINeedsImprovementThreshold = 500;
    public const decimal IPICriticalThreshold = 400;

    // Reimbursement claim window (18 months)
    public const int ReimbursementClaimWindowDays = 547; // 18 months * 30.4

    // Case SLA days by priority
    public const int CriticalCaseSLADays = 3;
    public const int HighCaseSLADays = 7;
    public const int MediumCaseSLADays = 14;
    public const int LowCaseSLADays = 21;
}

#region Enums
public enum UserRole
{
    Admin = 1,
    AccountManager = 2,
    Analyst = 3,
    VAReadOnly = 4
}

public enum PermissionLevel
{
    Full,
    ReadOnly,
    Execute
}

public enum CaseType
{
    LOST_INVENTORY,
    DAMAGED_INVENTORY,
    FEE_OVERCHARGE,
    RETURNLESS_REFUND,
    LISTING_SUPPRESSION,
    HIJACK_REPORT,
    ACCOUNT_SUSPENSION,
    INBOUND_SHIPMENT_DISCREPANCY,
    AWD_LOSS
}

public enum CaseStatus
{
    Open,
    PendingAmazon,
    Escalated,
    Resolved,
    Closed
}

public enum CasePriority
{
    Low,
    Medium,
    High,
    Critical
}

public enum AlertType
{
    LOW_STOCK,
    OVERSTOCK,
    STRANDED,
    AGED_FEE_RISK,
    HIJACK_DETECTED,
    BUY_BOX_LOST,
    CASE_SLA_BREACH,
    NEW_REIMBURSEMENT_OPPORTUNITY,
    FEE_SPIKE,
    LISTING_SUPPRESSED,
    AWD_DISCREPANCY,
    NEW_CASE,
    CASE_ESCALATED
}

public enum AlertSeverity
{
    Low,
    Medium,
    High,
    Critical
}

public enum ReportType
{
    INVENTORY_SNAPSHOT,
    SALES_ORDER,
    SALES_ORDER_ITEM,
    FBA_FEE,
    RETURNS,
    REIMBURSEMENTS,
    INVENTORY_ADJUSTMENT,
    PPC_KEYWORDS,
    PRODUCTS_COGS,
    SETTLEMENT,
    INBOUND_SHIPMENT
}

public enum ImportStatus
{
    Pending,
    Processing,
    Complete,
    Partial,
    Failed
}

public enum AuditType
{
    LOST_INVENTORY,
    DAMAGED_INVENTORY,
    RETURNLESS_REFUND,
    FEE_OVERCHARGE,
    INBOUND_SHIPMENT
}

public enum AuditStatus
{
    Pending,
    Claimed,
    Approved,
    Rejected,
    Expired
}

public enum ReimbType
{
    LOST,
    DAMAGED,
    RETURNLESS,
    FEE_ADJUSTMENT,
    AWD_LOSS
}

public enum ReimbApprovalStatus
{
    Pending,
    Approved,
    Rejected
}

public enum AdjustmentReason
{
    LOST,
    DAMAGED,
    FOUND,
    RECOUNT,
    CUSTOMER_RETURN,
    OTHER
}

public enum FulfillmentChannel
{
    AFN, // FBA
    MFN  // FBM
}

public enum OrderStatus
{
    Pending,
    Shipped,
    Delivered,
    Cancelled
}

public enum ReturnStatus
{
    Pending,
    InTransit,
    Received,
    Refunded
}

public enum CampaignType
{
    SponsoredProducts,
    SponsoredBrands,
    SponsoredDisplay
}

public enum TargetingType
{
    Automatic,
    Manual
}

public enum CampaignState
{
    Enabled,
    Paused,
    Archived
}

public enum MatchType
{
    Exact,
    Phrase,
    Broad
}

public enum ListingStatus
{
    Active,
    Inactive,
    Suppressed
}

public enum EmailTemplateCategory
{
    CASE_MANAGEMENT,
    BUYER,
    BRAND,
    OPERATIONS
}

public enum EmailTemplateSubCategory
{
    // Case Management
    LOST_INVENTORY,
    DAMAGED_INVENTORY,
    INBOUND_SHIPMENT,
    AWD_LOSS,
    FEE_OVERCHARGE,
    RETURNLESS_REFUND,
    ESCALATION,
    SENIOR_REVIEW,
    FEE_RECALC,
    STRANDED,
    LISTING_SUPPRESSION,
    ACCOUNT_HEALTH,
    SUSPENSION,
    ASIN_REINSTATEMENT,
    INTELLECTUAL_PROPERTY,
    REPORT_ABUSE,
    COUNTERFEIT,

    // Buyer
    LATE_DELIVERY,
    MISSING_PACKAGE,
    DELIVERY_ISSUE,
    WRONG_ITEM,
    DAMAGED_ITEM,
    DEFECTIVE,
    PRODUCT_QUESTION,
    RETURN,
    REFUND,
    FEEDBACK,
    REVIEW_RESPONSE,
    CANCELLATION,
    INTERNATIONAL,
    DELAY_WARNING,

    // Brand
    UNAUTHORIZED_SELLER,
    COUNTERFEIT,
    TRADEMARK_MISUSE,
    MANUFACTURER_VIOLATION,
    DISTRIBUTOR_TERRITORY,
    MAP_VIOLATION,
    RESELLER_AGREEMENT,
    BRAND_REGISTRY,
    SUPPLIER_AGREEMENT,
    HIJACK,
    TEST_BUY,
    ASIN_MERGE,

    // Operations
    DAILY,
    WEEKLY,
    CASE_ASSIGNMENT,
    ESCALATION,
    MONTHLY_REPORT,
    ONBOARDING
}

public enum Marketplace
{
    US = 1,
    CA = 2,
    UK = 3,
    DE = 4,
    FR = 5,
    IT = 6,
    ES = 7,
    JP = 8,
    AU = 9,
    MX = 10
}
#endregion

public static class LookupTables
{
    public static readonly Dictionary<string, string> CaseTypeDescriptions = new()
    {
        { "LOST_INVENTORY", "Amazon lost inventory in their warehouse" },
        { "DAMAGED_INVENTORY", "Amazon damaged inventory in their warehouse" },
        { "FEE_OVERCHARGE", "Amazon charged incorrect fees" },
        { "RETURNLESS_REFUND", "Refund issued but no return received" },
        { "LISTING_SUPPRESSION", "Listing is suppressed by Amazon" },
        { "HIJACK_REPORT", "Unauthorized seller stealing buy box" },
        { "ACCOUNT_SUSPENSION", "Amazon account suspension" },
        { "INBOUND_SHIPMENT_DISCREPANCY", "Shipment quantity mismatch" },
        { "AWD_LOSS", "Amazon Warehousing & Distribution loss" }
    };

    public static readonly Dictionary<string, string> AlertTypeDescriptions = new()
    {
        { "LOW_STOCK", "Inventory below reorder point" },
        { "OVERSTOCK", "Days of supply exceeds threshold" },
        { "STRANDED", "Inventory on suppressed listing" },
        { "AGED_FEE_RISK", "Inventory approaching long-term storage fees" },
        { "HIJACK_DETECTED", "Unauthorized seller on listing" },
        { "BUY_BOX_LOST", "Buy box ownership lost" },
        { "CASE_SLA_BREACH", "Case approaching SLA deadline" },
        { "NEW_REIMBURSEMENT_OPPORTUNITY", "New claim detected" },
        { "FEE_SPIKE", "Fees exceed normal threshold" },
        { "LISTING_SUPPRESSED", "Listing is suppressed" },
        { "AWD_DISCREPANCY", "AWD shipment quantity mismatch" },
        { "NEW_CASE", "New case opened" },
        { "CASE_ESCALATED", "Case escalated" }
    };

    public static readonly Dictionary<string, string> ReportTypeMappings = new()
    {
        { "Inventory Report", "INVENTORY_SNAPSHOT" },
        { "Sales & Traffic", "SALES_ORDER" },
        { "FBA Fee Preview", "FBA_FEE" },
        { "Reimbursements", "REIMBURSEMENTS" },
        { "Returns", "RETURNS" },
        { "Inventory Adjustments", "INVENTORY_ADJUSTMENT" },
        { "Order Report", "SALES_ORDER" },
        { "PPC Search Term", "PPC_KEYWORDS" },
        { "Settlement", "SETTLEMENT" },
        { "Stranded Inventory", "STRANDED_INVENTORY" },
        { "Aged Inventory", "AGED_INVENTORY" },
        { "Inbound Shipment", "INBOUND_SHIPMENT" },
        { "Removal Orders", "REMOVAL_ORDER" },
        { "Products/COGS", "PRODUCTS_COGS" }
    };
}