using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Constants;

namespace AmazonFBAManager.Shared.Interfaces;

/// <summary>
/// Repository interfaces for all data access
/// </summary>

public interface IUserRepository
{
    Task<LoginResponseDto> ValidateCredentialsAsync(string username, string password);
    Task<UserDto?> GetUserByIdAsync(int userId);
    Task<IEnumerable<UserDto>> GetAllUsersAsync();
    Task<int> CreateUserAsync(string username, string email, string passwordHash, int roleId);
    Task<UserAccountAccessDto> ValidateUserAccountAccessAsync(int userId, int sellerAccountId);
    Task<IEnumerable<SellerAccountDto>> GetUserSellerAccountsAsync(int userId);
    Task AssignUserToAccountAsync(int userId, int sellerAccountId, string permissionLevel);
}

public interface ISellerAccountRepository
{
    Task<IEnumerable<SellerAccountDto>> GetAllSellerAccountsAsync();
    Task<SellerAccountDto?> GetSellerAccountByIdAsync(int sellerAccountId);
    Task<int> CreateSellerAccountAsync(SellerAccountDto account);
    Task UpdateSellerAccountAsync(SellerAccountDto account);
    Task<bool> TestConnectionAsync(int sellerAccountId);
}

public interface IProductRepository
{
    Task<IEnumerable<ProductDto>> GetProductsAsync(int sellerAccountId, int page = 1, int pageSize = 20);
    Task<ProductDto?> GetProductByIdAsync(int productId);
    Task<ProductDto?> GetProductByASINAsync(int sellerAccountId, string asin);
    Task<ProductDto?> GetProductBySKUAsync(int sellerAccountId, string sku);
    Task<int> CreateProductAsync(ProductDto product);
    Task UpdateProductAsync(ProductDto product);
    Task DeleteProductAsync(int productId);
    Task<int> ImportProductsAsync(int sellerAccountId, IEnumerable<ProductDto> products);
    Task<IEnumerable<ProductWithInventoryDto>> GetProductsWithInventoryAsync(int sellerAccountId);
    Task UpdateCOGSAsync(int productId, decimal cogs);
}

public interface IInventoryRepository
{
    Task<IEnumerable<InventorySnapshotDto>> GetInventorySnapshotsAsync(int sellerAccountId, DateTime? date = null);
    Task<InventorySnapshotDto?> GetCurrentInventoryAsync(int productId);
    Task<int> ImportInventorySnapshotAsync(int sellerAccountId, long importId, IEnumerable<InventorySnapshotDto> data);
    Task<IEnumerable<ReorderSuggestionDto>> GetReorderSuggestionsAsync(int sellerAccountId, int leadTimeDays = 30, decimal serviceLevel = 0.95m);
    Task<IEnumerable<OverstockReportDto>> GetOverstockReportAsync(int sellerAccountId, int daysOfSupplyThreshold = 365);
    Task<IEnumerable<AgedInventoryFeeRiskDto>> GetAgedInventoryFeeRiskAsync(int sellerAccountId, DateTime? snapshotDate = null);
    Task<IEnumerable<StrandedInventoryDto>> GetStrandedInventoryAsync(int sellerAccountId);
    Task<IEnumerable<IPIImprovementActionDto>> GetIPIImprovementActionsAsync(int sellerAccountId);
    Task CheckLowStockAlertsAsync(int sellerAccountId);
}

public interface ISalesRepository
{
    Task<IEnumerable<SalesOrderDto>> GetSalesOrdersAsync(int sellerAccountId, DateTime? dateFrom = null, DateTime? dateTo = null, int page = 1, int pageSize = 20);
    Task<SalesOrderDto?> GetSalesOrderByIdAsync(long orderId);
    Task<SalesOrderDto?> GetSalesOrderByAmazonIdAsync(int sellerAccountId, string amazonOrderId);
    Task<int> ImportSalesOrdersAsync(int sellerAccountId, long importId, IEnumerable<SalesOrderDto> orders);
    Task<IEnumerable<SalesOrderItemDto>> GetSalesOrderItemsAsync(long orderId);
    Task<IEnumerable<ProfitLossBySKUDto>> GetProfitLossBySKUAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo, string groupBy = "SKU");
    Task<IEnumerable<SalesVelocityDto>> GetSalesVelocityAsync(int sellerAccountId, string? asin = null, int periods = 12);
    Task<IEnumerable<MultiAccountSummaryDto>> GetMultiAccountSummaryAsync(int userId, DateTime dateFrom, DateTime dateTo);
    Task<DashboardSummaryDto> GetDashboardSummaryAsync(int sellerAccountId);
}

public interface ICaseRepository
{
    Task<IEnumerable<CaseDto>> GetCasesAsync(int sellerAccountId, string? status = null, int page = 1, int pageSize = 20);
    Task<CaseDto?> GetCaseByIdAsync(int caseId);
    Task<int> CreateCaseAsync(CaseCreateDto caseDto);
    Task UpdateCaseAsync(CaseDto caseDto);
    Task ResolveCaseAsync(int caseId, decimal? resolvedAmount = null, string? resolutionNote = null);
    Task EscalateCaseAsync(int caseId, int userId, string escalationReason);
    Task<IEnumerable<CaseNoteDto>> GetCaseNotesAsync(int caseId);
    Task AddCaseNoteAsync(int caseId, int userId, string noteText, bool isInternal = true);
    Task<IEnumerable<CaseAgingReportDto>> GetCaseAgingReportAsync(int sellerAccountId, int slaDays = 14);
    Task<IEnumerable<SuppressedListingDto>> GetListingSuppressedFixesAsync(int sellerAccountId);
}

public interface IReimbursementRepository
{
    Task<IEnumerable<ReimbursementAuditDto>> AuditLostDamagedInventoryAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<ReturnlessRefundAuditDto>> AuditReturnlessRefundsAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<FeeOverchargeDto>> DetectFeeOverchargesAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<ReimbursementChecklistItemDto>> GetMonthlyChecklistAsync(int sellerAccountId, int month, int year);
    Task<ReimbursementKPIDashboardDto> GetKPIDashboardAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<COGSImpactDto>> CalculateCOGSImpactAsync(int sellerAccountId);
    Task<IEnumerable<ReimbursementAuditDto>> GetPendingAuditsAsync(int sellerAccountId);
    Task UpdateAuditStatusAsync(long auditId, string status);
    Task LinkAuditToCaseAsync(long auditId, int caseId);
}

public interface IPPCRepository
{
    Task<IEnumerable<PPCCampaignDto>> GetCampaignsAsync(int sellerAccountId);
    Task<PPCCampaignDto?> GetCampaignByIdAsync(int campaignId);
    Task<int> CreateCampaignAsync(PPCCampaignDto campaign);
    Task UpdateCampaignAsync(PPCCampaignDto campaign);
    Task<IEnumerable<PPCKeywordDto>> GetKeywordsAsync(int sellerAccountId, int? campaignId = null, string? period = null);
    Task<int> ImportKeywordsAsync(int sellerAccountId, long importId, IEnumerable<PPCKeywordDto> keywords, string period);
    Task<IEnumerable<WastedSpendDto>> AuditCampaignsAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<TACoSReportDto> CalculateTACoSAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<BidAdjustmentDto>> GetBidAdjustmentSuggestionsAsync(int sellerAccountId, decimal targetACoS = 25m);
}

public interface IReturnRepository
{
    Task<IEnumerable<ReturnDto>> GetReturnsAsync(int sellerAccountId, DateTime? dateFrom = null, DateTime? dateTo = null);
    Task<int> ImportReturnsAsync(int sellerAccountId, long importId, IEnumerable<ReturnDto> returns);
    Task<ReturnRateAnalysisDto> GetReturnRateAnalysisAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
    Task<IEnumerable<ReturnRateBySKUDto>> GetReturnRateBySKUAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
}

public interface IFeeRepository
{
    Task<IEnumerable<FBADebitNoteDto>> GetFeesAsync(int sellerAccountId, DateTime? dateFrom = null, DateTime? dateTo = null);
    Task<int> ImportFeesAsync(int sellerAccountId, long importId, IEnumerable<FBADebitNoteDto> fees);
    Task<IEnumerable<FeeBreakdownDto>> GetFeeBreakdownByASINAsync(int sellerAccountId, DateTime dateFrom, DateTime dateTo);
}

public interface ICSVImportRepository
{
    Task<IEnumerable<CSVImportDto>> GetImportsAsync(int sellerAccountId, int page = 1, int pageSize = 20);
    Task<CSVImportDto?> GetImportByIdAsync(long importId);
    Task<long> CreateImportAsync(CSVImportDto importDto);
    Task UpdateImportStatusAsync(long importId, string status, int rowsImported, int rowsErrored);
    Task<CSVImportResultDto> ImportInventorySnapshotAsync(int sellerAccountId, long importId, IEnumerable<InventorySnapshotDto> data);
    Task<CSVImportResultDto> ImportProductsAsync(int sellerAccountId, long importId, IEnumerable<ProductDto> data);
    Task<CSVImportResultDto> ImportReturnsAsync(int sellerAccountId, long importId, IEnumerable<ReturnDto> data);
    Task<CSVImportResultDto> ImportFeesAsync(int sellerAccountId, long importId, IEnumerable<FBADebitNoteDto> data);
    Task<CSVImportResultDto> ImportReimbursementsAsync(int sellerAccountId, long importId, IEnumerable<ReimbursementAuditDto> data);
    Task<CSVImportResultDto> ImportPPCKeywordsAsync(int sellerAccountId, long importId, IEnumerable<PPCKeywordDto> data, string period);
}

public interface IAlertRepository
{
    Task<IEnumerable<AlertDto>> GetAlertsAsync(int sellerAccountId, bool? isRead = null, int page = 1, int pageSize = 20);
    Task<AlertDto?> GetAlertByIdAsync(long alertId);
    Task MarkAlertAsReadAsync(long alertId);
    Task MarkAlertAsResolvedAsync(long alertId, int resolvedByUserId);
    Task<AlertSummaryDto> GetAlertSummaryAsync(int sellerAccountId);
    Task<IEnumerable<AlertDto>> GetUnreadAlertsAsync(int sellerAccountId);
}

public interface IEmailTemplateRepository
{
    Task<IEnumerable<EmailTemplateDto>> GetTemplatesAsync(string? category = null, bool? isActive = true);
    Task<EmailTemplateDto?> GetTemplateByIdAsync(int templateId);
    Task<EmailTemplateDto?> GetTemplateByNameAsync(string templateName);
}

public interface IHelpRepository
{
    Task<IEnumerable<HelpTopicDto>> GetTopicsAsync(string? section = null);
    Task<HelpTopicDto?> GetTopicByIdAsync(int topicId);
    Task<IEnumerable<string>> GetSectionsAsync();
}

public interface ISettingsRepository
{
    Task<IEnumerable<AlertThresholdDto>> GetAlertThresholdsAsync(int sellerAccountId);
    Task SetAlertThresholdAsync(int sellerAccountId, string alertType, decimal thresholdValue, bool isEnabled = true);
}