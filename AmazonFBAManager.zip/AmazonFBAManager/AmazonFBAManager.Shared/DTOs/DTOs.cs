namespace AmazonFBAManager.Shared.DTOs;

/// <summary>
/// Core DTOs for the Amazon FBA Management Platform
/// </summary>

#region User & Account DTOs
public class UserDto
{
    public int UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string RoleName { get; set; } = string.Empty;
    public int RoleId { get; set; }
    public bool IsActive { get; set; }
    public DateTime? LastLoginDate { get; set; }
    public DateTime CreatedDate { get; set; }
}

public class SellerAccountDto
{
    public int SellerAccountId { get; set; }
    public string AccountName { get; set; } = string.Empty;
    public int MarketplaceId { get; set; }
    public string MarketplaceName { get; set; } = string.Empty;
    public string Region { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime ModifiedDate { get; set; }
}

public class UserAccountAccessDto
{
    public bool HasAccess { get; set; }
    public string? PermissionLevel { get; set; }
}

public class LoginRequestDto
{
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}

public class LoginResponseDto
{
    public bool Success { get; set; }
    public string Token { get; set; } = string.Empty;
    public UserDto? User { get; set; }
    public string Message { get; set; } = string.Empty;
}
#endregion

#region Product DTOs
public class ProductDto
{
    public int ProductId { get; set; }
    public int SellerAccountId { get; set; }
    public string ASIN { get; set; } = string.Empty;
    public string SKU { get; set; } = string.Empty;
    public string? FNSKU { get; set; }
    public string? ProductTitle { get; set; }
    public string? Brand { get; set; }
    public string? Category { get; set; }
    public string? Subcategory { get; set; }
    public string? UPC { get; set; }
    public string? EAN { get; set; }
    public decimal? Weight { get; set; }
    public decimal? Length { get; set; }
    public decimal? Width { get; set; }
    public decimal? Height { get; set; }
    public decimal? COGS { get; set; } // Critical for 2025 reimbursement policy
    public decimal? TargetMargin { get; set; }
    public int? ReorderPoint { get; set; }
    public int? ReorderQty { get; set; }
    public int LeadTimeDays { get; set; } = 7;
    public bool IsActive { get; set; }
}

public class ProductWithInventoryDto : ProductDto
{
    public int CurrentFBAQty { get; set; }
    public int InboundQty { get; set; }
    public int TotalFBA { get; set; }
    public decimal DailySalesVelocity { get; set; }
    public decimal DaysOfSupply { get; set; }
}
#endregion

#region Inventory DTOs
public class InventorySnapshotDto
{
    public long SnapshotId { get; set; }
    public int ProductId { get; set; }
    public int SellerAccountId { get; set; }
    public DateTime SnapshotDate { get; set; }
    public int QtyFBA { get; set; }
    public int QtyFBM { get; set; }
    public int QtyInbound { get; set; }
    public int QtyReserved { get; set; }
    public int QtyUnfulfillable { get; set; }
    public int QtyWarehouseAWD { get; set; }
    public decimal? EstStorageCost { get; set; }
    public decimal? IPI_Score { get; set; }
    public string? DataSource { get; set; }
}

public class ReorderSuggestionDto
{
    public string SKU { get; set; } = string.Empty;
    public string? FNSKU { get; set; }
    public string? ProductTitle { get; set; }
    public int CurrentFBAQty { get; set; }
    public int InboundQty { get; set; }
    public decimal DailySalesVelocity { get; set; }
    public int SafetyStock { get; set; }
    public int ReorderPoint { get; set; }
    public string UrgencyStatus { get; set; } = string.Empty;
    public decimal DaysOfSupply { get; set; }
    public int SuggestedOrderQty { get; set; }
    public int UrgencyScore { get; set; }
}

public class OverstockReportDto
{
    public string SKU { get; set; } = string.Empty;
    public string? FNSKU { get; set; }
    public string? ProductTitle { get; set; }
    public decimal? COGS { get; set; }
    public int QtyOnHand { get; set; }
    public decimal DailySalesVelocity { get; set; }
    public decimal DaysOfSupply { get; set; }
    public decimal EstStorageCost90days { get; set; }
    public decimal LiquidationSavings { get; set; }
    public string Recommendation { get; set; } = string.Empty;
    public decimal LiquidationRecovery { get; set; }
}

public class AgedInventoryFeeRiskDto
{
    public string SKU { get; set; } = string.Empty;
    public string? FNSKU { get; set; }
    public string? ProductTitle { get; set; }
    public decimal? COGS { get; set; }
    public int Qty0to90Days { get; set; }
    public int Qty91to180Days { get; set; }
    public int Qty181to270Days { get; set; }
    public int Qty271to365Days { get; set; }
    public int QtyOver365Days { get; set; }
    public decimal EstSurchargeFee90Days { get; set; }
    public decimal SalesPriceToClear { get; set; }
    public decimal EstRemovalCost { get; set; }
    public string NetBetterOption { get; set; } = string.Empty;
}

public class StrandedInventoryDto
{
    public string SKU { get; set; } = string.Empty;
    public string ASIN { get; set; } = string.Empty;
    public string? FNSKU { get; set; }
    public string? ProductTitle { get; set; }
    public int QtyStranded { get; set; }
    public string StrandReason { get; set; } = string.Empty;
    public decimal DailyStorageCost { get; set; }
    public string RecommendedAction { get; set; } = string.Empty;
    public decimal EstDailyRevenueLost { get; set; }
}

public class IPIImprovementActionDto
{
    public string ActionType { get; set; } = string.Empty;
    public int AffectedSKUs { get; set; }
    public int TotalUnits { get; set; }
    public string Description { get; set; } = string.Empty;
    public string ImpactOnIPI { get; set; } = string.Empty;
}
#endregion

#region Sales & Financial DTOs
public class SalesOrderDto
{
    public long OrderId { get; set; }
    public int SellerAccountId { get; set; }
    public string AmazonOrderId { get; set; } = string.Empty;
    public DateTime OrderDate { get; set; }
    public DateTime? ShipDate { get; set; }
    public string? FulfillmentChannel { get; set; }
    public string? OrderStatus { get; set; }
    public decimal TotalAmount { get; set; }
    public string Currency { get; set; } = "USD";
}

public class SalesOrderItemDto
{
    public long OrderItemId { get; set; }
    public long OrderId { get; set; }
    public int? ProductId { get; set; }
    public string ASIN { get; set; } = string.Empty;
    public string? SKU { get; set; }
    public int QtySold { get; set; }
    public decimal ItemPrice { get; set; }
    public decimal PromotionDiscount { get; set; }
    public decimal ShippingPrice { get; set; }
    public decimal GiftWrapPrice { get; set; }
}

public class ProfitLossBySKUDto
{
    public string GroupKey { get; set; } = string.Empty;
    public decimal Revenue { get; set; }
    public decimal COGS_Total { get; set; }
    public decimal FBAFees_Total { get; set; }
    public decimal PPC_Spend { get; set; }
    public decimal RefundsIssued { get; set; }
    public decimal ReimbursementsReceived { get; set; }
    public decimal NetProfit { get; set; }
    public decimal MarginPct { get; set; }
    public decimal ROI { get; set; }
}

public class SalesVelocityDto
{
    public string Month { get; set; } = string.Empty;
    public int OrderCount { get; set; }
    public int UnitsSold { get; set; }
    public decimal Revenue { get; set; }
    public decimal AvgOrderValue { get; set; }
}

public class MultiAccountSummaryDto
{
    public int SellerAccountId { get; set; }
    public string AccountName { get; set; } = string.Empty;
    public decimal Revenue { get; set; }
    public int Units { get; set; }
    public decimal NetProfit { get; set; }
    public int OpenCases { get; set; }
    public decimal PendingReimbursements { get; set; }
    public int UnreadAlerts { get; set; }
}

public class DashboardSummaryDto
{
    public decimal TotalRevenue { get; set; }
    public int TotalUnitsSold { get; set; }
    public decimal NetProfit { get; set; }
    public decimal RefundRate { get; set; }
    public int LowStockAlerts { get; set; }
    public int OverstockAlerts { get; set; }
    public int StrandedUnits { get; set; }
    public decimal AgedInventoryValue { get; set; }
    public decimal? IPI_Score { get; set; }
    public int OpenCases { get; set; }
    public int UnreadAlerts { get; set; }
}
#endregion

#region Case Management DTOs
public class CaseDto
{
    public int CaseId { get; set; }
    public int SellerAccountId { get; set; }
    public string? AmazonCaseId { get; set; }
    public string CaseType { get; set; } = string.Empty;
    public string? CaseCategory { get; set; }
    public string Status { get; set; } = string.Empty;
    public string Priority { get; set; } = string.Empty;
    public DateTime OpenedDate { get; set; }
    public DateTime? ResolvedDate { get; set; }
    public decimal? ResolvedAmount { get; set; }
    public string Subject { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int? AssignedUserId { get; set; }
    public string? AssignedUsername { get; set; }
    public int EscalationLevel { get; set; }
    public bool POARequired { get; set; }
}

public class CaseCreateDto
{
    public int SellerAccountId { get; set; }
    public string CaseType { get; set; } = string.Empty;
    public string? ASIN { get; set; }
    public string Subject { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Priority { get; set; } = "Medium";
    public long? LinkedAuditId { get; set; }
    public int? AssignedUserId { get; set; }
}

public class CaseNoteDto
{
    public int NoteId { get; set; }
    public int CaseId { get; set; }
    public int UserId { get; set; }
    public string? Username { get; set; }
    public DateTime NoteDate { get; set; }
    public string NoteText { get; set; } = string.Empty;
    public bool IsInternal { get; set; }
}

public class CaseAgingReportDto
{
    public int CaseId { get; set; }
    public string CaseType { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Priority { get; set; } = string.Empty;
    public DateTime OpenedDate { get; set; }
    public int DaysOpen { get; set; }
    public string SLAStatus { get; set; } = string.Empty;
    public string? AssignedUser { get; set; }
    public decimal AmountAtRisk { get; set; }
    public int EffectiveSLA { get; set; }
}

public class SuppressedListingDto
{
    public string SKU { get; set; } = string.Empty;
    public string ASIN { get; set; } = string.Empty;
    public string? ProductTitle { get; set; }
    public string? SuppressedReason { get; set; }
    public string ListingStatus { get; set; } = string.Empty;
    public int DaysSuppressed { get; set; }
    public decimal EstRevLostPerDay { get; set; }
    public string RequiredAction { get; set; } = string.Empty;
    public string Priority { get; set; } = string.Empty;
}
#endregion

#region Reimbursement DTOs
public class ReimbursementAuditDto
{
    public string SKU { get; set; } = string.Empty;
    public string ASIN { get; set; } = string.Empty;
    public string? ProductTitle { get; set; }
    public decimal CostBasis { get; set; }
    public int QtyLost { get; set; }
    public int QtyReimbursed { get; set; }
    public int QtyUnclaimed { get; set; }
    public decimal ClaimableAmount { get; set; }
    public decimal AlreadyRecovered { get; set; }
    public string Status { get; set; } = string.Empty;
    public string Recommendation { get; set; } = string.Empty;
}

public class ReturnlessRefundAuditDto
{
    public long ReturnId { get; set; }
    public string AmazonOrderId { get; set; } = string.Empty;
    public string SKU { get; set; } = string.Empty;
    public string ASIN { get; set; } = string.Empty;
    public string? ProductTitle { get; set; }
    public decimal CostBasis { get; set; }
    public decimal RefundAmount { get; set; }
    public DateTime? ReturnReceivedDate { get; set; }
    public string ReturnStatus { get; set; } = string.Empty;
    public decimal ClaimableAmount { get; set; }
    public string Recommendation { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
}

public class FeeOverchargeDto
{
    public string SKU { get; set; } = string.Empty;
    public string ASIN { get; set; } = string.Empty;
    public decimal ExpectedReferralFee { get; set; }
    public decimal ChargedReferralFee { get; set; }
    public decimal ReferralFeeVariance { get; set; }
    public decimal ExpectedFBAFee { get; set; }
    public decimal ChargedFBAFee { get; set; }
    public decimal FBAFeeVariance { get; set; }
    public decimal ChargedStorageFee { get; set; }
    public decimal TotalFees { get; set; }
    public string Status { get; set; } = string.Empty;
    public string ClaimableReason { get; set; } = string.Empty;
}

public class ReimbursementChecklistItemDto
{
    public string ChecklistItem { get; set; } = string.Empty;
    public int PotentialClaims { get; set; }
    public decimal PotentialAmount { get; set; }
    public string ActionRequired { get; set; } = string.Empty;
    public DateTime Deadline { get; set; }
    public string Priority { get; set; } = string.Empty;
}

public class ReimbursementKPIDashboardDto
{
    public int TotalClaims { get; set; }
    public decimal ApprovedAmount { get; set; }
    public decimal PendingAmount { get; set; }
    public decimal ApprovalRate { get; set; }
    public decimal AvgResolutionDays { get; set; }
    public decimal TotalPotentialRecovery { get; set; }
}

public class COGSImpactDto
{
    public string SKU { get; set; } = string.Empty;
    public string ASIN { get; set; } = string.Empty;
    public string? ProductTitle { get; set; }
    public decimal CurrentCOGS { get; set; }
    public decimal ReimbursablePerUnit { get; set; }
    public decimal TotalPotentialRecovery { get; set; }
    public string COGSStatus { get; set; } = string.Empty;
    public string Recommendation { get; set; } = string.Empty;
}
#endregion

#region PPC DTOs
public class PPCCampaignDto
{
    public int CampaignId { get; set; }
    public int SellerAccountId { get; set; }
    public string? AmazonCampaignId { get; set; }
    public string CampaignName { get; set; } = string.Empty;
    public string? CampaignType { get; set; }
    public string? TargetingType { get; set; }
    public string State { get; set; } = string.Empty;
    public decimal? DailyBudget { get; set; }
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
}

public class PPCKeywordDto
{
    public long KeywordId { get; set; }
    public int CampaignId { get; set; }
    public string? AdGroupId { get; set; }
    public string KeywordText { get; set; } = string.Empty;
    public string MatchType { get; set; } = string.Empty;
    public decimal? Bid { get; set; }
    public int Impressions { get; set; }
    public int Clicks { get; set; }
    public decimal Spend { get; set; }
    public decimal Sales { get; set; }
    public decimal? ACoS { get; set; }
    public decimal? ROAS { get; set; }
    public string Period { get; set; } = string.Empty;
}

public class WastedSpendDto
{
    public string CampaignName { get; set; } = string.Empty;
    public string KeywordText { get; set; } = string.Empty;
    public string MatchType { get; set; } = string.Empty;
    public int Impressions { get; set; }
    public int Clicks { get; set; }
    public decimal Spend { get; set; }
    public decimal Sales { get; set; }
    public decimal? ACoS { get; set; }
    public string IssueType { get; set; } = string.Empty;
    public string Recommendation { get; set; } = string.Empty;
    public string Priority { get; set; } = string.Empty;
}

public class TACoSReportDto
{
    public decimal TotalSales { get; set; }
    public decimal PPCSales { get; set; }
    public decimal OrganicSales { get; set; }
    public decimal PPCSalesRatioPct { get; set; }
    public decimal TotalSpend { get; set; }
    public decimal ACoS { get; set; }
    public decimal TACoS { get; set; }
    public string Interpretation { get; set; } = string.Empty;
}

public class BidAdjustmentDto
{
    public string CampaignName { get; set; } = string.Empty;
    public string KeywordText { get; set; } = string.Empty;
    public string MatchType { get; set; } = string.Empty;
    public decimal CurrentBid { get; set; }
    public decimal Spend { get; set; }
    public decimal Sales { get; set; }
    public decimal? ACoS { get; set; }
    public decimal SuggestedBid { get; set; }
    public string Adjustment { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;
}
#endregion

#region CSV Import DTOs
public class CSVImportDto
{
    public long ImportId { get; set; }
    public int SellerAccountId { get; set; }
    public int UserId { get; set; }
    public DateTime ImportDate { get; set; }
    public string ReportType { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
    public string FilePath { get; set; } = string.Empty;
    public int RowsTotal { get; set; }
    public int RowsImported { get; set; }
    public int RowsErrored { get; set; }
    public string Status { get; set; } = string.Empty;
    public string? ErrorLog { get; set; }
    public DateTime? CompletedDate { get; set; }
}

public class CSVImportResultDto
{
    public int RowsImported { get; set; }
    public int RowsErrored { get; set; }
    public string Message { get; set; } = string.Empty;
}
#endregion

#region Alert DTOs
public class AlertDto
{
    public long AlertId { get; set; }
    public int SellerAccountId { get; set; }
    public string AlertType { get; set; } = string.Empty;
    public int? ProductId { get; set; }
    public int? CaseId { get; set; }
    public DateTime AlertDate { get; set; }
    public string Message { get; set; } = string.Empty;
    public string Severity { get; set; } = string.Empty;
    public bool IsRead { get; set; }
    public DateTime? ResolvedDate { get; set; }
    public int? ResolvedByUserId { get; set; }
}

public class AlertSummaryDto
{
    public int TotalAlerts { get; set; }
    public int UnreadAlerts { get; set; }
    public int CriticalAlerts { get; set; }
    public int HighAlerts { get; set; }
    public int MediumAlerts { get; set; }
    public int LowAlerts { get; set; }
}
#endregion

#region Email Template DTOs
public class EmailTemplateDto
{
    public int TemplateId { get; set; }
    public string TemplateName { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string? SubCategory { get; set; }
    public string SubjectLine { get; set; } = string.Empty;
    public string BodyContent { get; set; } = string.Empty;
    public string? Tips { get; set; }
    public bool IsActive { get; set; }
}

public class EmailComposeDto
{
    public int TemplateId { get; set; }
    public string SendTo { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;
    public Dictionary<string, string> ReplaceableFields { get; set; } = new();
}
#endregion

#region Help Guide DTOs
public class HelpTopicDto
{
    public int TopicId { get; set; }
    public string Section { get; set; } = string.Empty;
    public string TopicName { get; set; } = string.Empty;
    public string WhatItDoes { get; set; } = string.Empty;
    public string WhenToUse { get; set; } = string.Empty;
    public string StepByStep { get; set; } = string.Empty;
    public string? ProTip { get; set; }
    public string? CommonMistake { get; set; }
}

public class HelpSectionDto
{
    public string Section { get; set; } = string.Empty;
    public int TopicCount { get; set; }
    public List<HelpTopicDto> Topics { get; set; } = new();
}
#endregion

#region Return DTOs
public class ReturnDto
{
    public long ReturnId { get; set; }
    public int SellerAccountId { get; set; }
    public string AmazonOrderId { get; set; } = string.Empty;
    public int? ProductId { get; set; }
    public DateTime ReturnDate { get; set; }
    public DateTime? CustomerRefundDate { get; set; }
    public DateTime? ReturnReceivedDate { get; set; }
    public string? ReturnStatus { get; set; }
    public string? ReturnReason { get; set; }
    public int Qty { get; set; }
    public decimal? RefundAmount { get; set; }
    public bool ReturnlessRefund { get; set; }
    public string? DispositionCode { get; set; }
}

public class ReturnRateAnalysisDto
{
    public decimal OverallReturnRatePct { get; set; }
    public decimal TotalRefundAmount { get; set; }
    public int TotalReturns { get; set; }
}

public class ReturnRateBySKUDto
{
    public string SKU { get; set; } = string.Empty;
    public string ASIN { get; set; } = string.Empty;
    public string? ProductTitle { get; set; }
    public int ReturnCount { get; set; }
    public int ReturnedUnits { get; set; }
    public int UnitsSold { get; set; }
    public decimal ReturnRatePct { get; set; }
    public decimal TotalRefunded { get; set; }
    public string? TopReturnReason { get; set; }
    public decimal ReturnlessRefundPct { get; set; }
}
#endregion

#region Fee DTOs
public class FBADebitNoteDto
{
    public long FeeId { get; set; }
    public int ProductId { get; set; }
    public int SellerAccountId { get; set; }
    public DateTime FeeDate { get; set; }
    public string FeeType { get; set; } = string.Empty;
    public decimal FeeAmount { get; set; }
    public string Currency { get; set; } = "USD";
    public string? ReferenceId { get; set; }
    public string? FulfillmentCenterId { get; set; }
}

public class FeeBreakdownDto
{
    public string SKU { get; set; } = string.Empty;
    public string ASIN { get; set; } = string.Empty;
    public string? ProductTitle { get; set; }
    public decimal? COGS { get; set; }
    public decimal Revenue { get; set; }
    public decimal ReferralFee { get; set; }
    public decimal FBAFulfillmentFee { get; set; }
    public decimal StorageFee { get; set; }
    public decimal LongTermStorageFee { get; set; }
    public decimal RemovalFee { get; set; }
    public decimal TotalFees { get; set; }
    public decimal TotalFeePct { get; set; }
    public decimal NetMarginAfterFees { get; set; }
    public decimal NetMarginPct { get; set; }
}
#endregion

#region Settings DTOs
public class AlertThresholdDto
{
    public int ThresholdId { get; set; }
    public int SellerAccountId { get; set; }
    public string AlertType { get; set; } = string.Empty;
    public decimal ThresholdValue { get; set; }
    public bool IsEnabled { get; set; }
}
#endregion

#region Niche Research DTOs
public class OpportunityScoreResult
{
    public string Keyword { get; set; } = "";
    public int EstMonthlySearchVolume { get; set; }
    public int CompetitorCount { get; set; }
    public int AvgReviewCount { get; set; }
    public decimal AvgPrice { get; set; }
    public decimal EstRevenue { get; set; }
    public int OpportunityScore { get; set; }
    public int ReviewGap { get; set; }
}

public class TrendingProduct
{
    public string ASIN { get; set; } = "";
    public string ProductName { get; set; } = "";
    public string Category { get; set; } = "";
    public int BSRVelocityChange { get; set; }
    public int ReviewGrowth { get; set; }
    public decimal PriceStability { get; set; }
    public string TrendSignal { get; set; } = "";
}

public class BundleOpportunity
{
    public string BundleType { get; set; } = "";
    public string MainProductName { get; set; } = "";
    public string MainProductASIN { get; set; } = "";
    public string BundlePartnerName { get; set; } = "";
    public string BundlePartnerASIN { get; set; } = "";
    public decimal SingleMargin { get; set; }
    public decimal BundleMargin { get; set; }
    public int CompetitiveMoatScore { get; set; }
    public string Analysis { get; set; } = "";
}

public class AsinAnalysisResult
{
    public string ASIN { get; set; } = "";
    public string ProductName { get; set; } = "";
    public string Category { get; set; } = "";
    public decimal Price { get; set; }
    public int BSR { get; set; }
    public int ReviewCount { get; set; }
    public decimal Rating { get; set; }
    public decimal PriceGap { get; set; }
    public int ReviewGap { get; set; }
    public int BSRGap { get; set; }
    public int FeatureGap { get; set; }
    public string SellerName { get; set; } = "";
    public bool IsFBA { get; set; }
    public int BuyBoxPercent { get; set; }
    public int TotalOffers { get; set; }
    public List<OpportunityItem> Opportunities { get; set; } = new();
}

public class OpportunityItem
{
    public string Icon { get; set; } = "";
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string Priority { get; set; } = "";
}

public class NicheResearchDto
{
    public int Id { get; set; }
    public int SellerAccountId { get; set; }
    public int UserId { get; set; }
    public DateTime ResearchDate { get; set; }
    public string Keyword { get; set; } = "";
    public int EstMonthlySearchVolume { get; set; }
    public int CompetitorCount { get; set; }
    public int AvgReviewCount { get; set; }
    public decimal AvgPrice { get; set; }
    public decimal EstRevenue { get; set; }
    public int OpportunityScore { get; set; }
    public string? Notes { get; set; }
    public string Status { get; set; } = "";
}
#endregion