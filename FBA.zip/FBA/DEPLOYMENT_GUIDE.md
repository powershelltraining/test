# ============================================================
# DEPLOYMENT_GUIDE.md
# Amazon FBA Manager — Complete Deployment Reference
# On-Premise IIS · SQL Server 2022 · .NET 8
# ============================================================

## Prerequisites

| Component | Minimum Version | Notes |
|---|---|---|
| Windows Server | 2019 or 2022 | IIS role enabled |
| SQL Server | 2022 (Express or higher) | Azure SQL compatible |
| .NET Runtime | .NET 8 Windows Hosting Bundle | From microsoft.com/dotnet |
| IIS | 10.0 | With ASP.NET Core Module v2 |

---

## Step 1 — SQL Server Setup

```sql
-- Run as SA / sysadmin
CREATE DATABASE AmazonFBAManager;
GO

-- Create a dedicated app login (least privilege)
CREATE LOGIN fbamanager_app WITH PASSWORD = 'STRONG_PASSWORD_HERE';
USE AmazonFBAManager;
CREATE USER fbamanager_app FOR LOGIN fbamanager_app;

-- Grant required permissions
GRANT EXECUTE   ON SCHEMA::dbo TO fbamanager_app;
GRANT SELECT    ON SCHEMA::dbo TO fbamanager_app;
GRANT INSERT    ON SCHEMA::dbo TO fbamanager_app;
GRANT UPDATE    ON SCHEMA::dbo TO fbamanager_app;
GRANT DELETE    ON SCHEMA::dbo TO fbamanager_app;
GRANT CREATE TABLE TO fbamanager_app;  -- Hangfire needs this
```

### Run Database Scripts (in order)

```
01_CoreTables.sql
02_TVPs_And_Security.sql
03_SeedData.sql
04_SP_Import.sql
05_SP_Inventory.sql
06_SP_Reimbursement.sql
07_SP_Cases.sql
08_SP_Reports_PPC_Listings_Research.sql
09_Views_COGS_Jobs_Master.sql
10_SeedData_EmailTemplates.sql
11_SeedData_HelpGuide.sql
```

---

## Step 2 — Build & Publish

```powershell
# From solution root
dotnet restore AmazonFBAManager.sln
dotnet build   AmazonFBAManager.sln -c Release

# Publish Web app
dotnet publish AmazonFBAManager.Web `
    -c Release `
    -o "C:\sqlai\web" `
    --self-contained false

# Publish API (optional — desktop app uses this)
dotnet publish AmazonFBAManager.API `
    -c Release `
    -o "C:\inetpub\FBAManager\api" `
    --self-contained false
```

---

## Step 3 — IIS Configuration

### Install .NET 8 Hosting Bundle
Download from: https://dotnet.microsoft.com/download/dotnet/8.0
Run installer, restart IIS: `iisreset`

### Create Application Pool

```powershell
Import-Module WebAdministration

# Web app pool
New-WebAppPool -Name "FBAManagerWebPool"
Set-ItemProperty IIS:\AppPools\FBAManagerWebPool -Name "managedRuntimeVersion" -Value ""
Set-ItemProperty IIS:\AppPools\FBAManagerWebPool -Name "processModel.identityType" -Value "ApplicationPoolIdentity"
Set-ItemProperty IIS:\AppPools\FBAManagerWebPool -Name "startMode" -Value "AlwaysRunning"
Set-ItemProperty IIS:\AppPools\FBAManagerWebPool -Name "autoStart" -Value $true
```

### Create IIS Site

```powershell
# Web frontend
New-Website -Name "FBAManager" `
    -Port 443 `
    -PhysicalPath "C:\inetpub\FBAManager\web" `
    -ApplicationPool "FBAManagerWebPool" `
    -Ssl

# Add HTTP to HTTPS redirect
New-Website -Name "FBAManagerHTTP" -Port 80 -PhysicalPath "C:\inetpub\FBAManager\web" -ApplicationPool "FBAManagerWebPool"
# Configure URL Rewrite to redirect HTTP → HTTPS
```

### File System Permissions

```powershell
# Allow IIS app pool to write uploads
$acl = Get-Acl "C:\inetpub\FBAManager\web"
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    "IIS AppPool\FBAManagerWebPool", "Modify", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.SetAccessRule($rule)
Set-Acl "C:\inetpub\FBAManager\web" $acl

# Create uploads directory
New-Item -ItemType Directory -Path "C:\inetpub\FBAManager\web\wwwroot\uploads" -Force
```

---

## Step 4 — Configure appsettings.Production.json

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR-SQL-SERVER;Database=AmazonFBAManager;User Id=fbamanager_app;Password=STRONG_PASSWORD;Encrypt=True;TrustServerCertificate=False;"
  },
  "Jwt": {
    "Key": "MINIMUM-32-CHARACTER-SECRET-KEY-HERE-CHANGE-ME"
  },
  "AppSettings": {
    "FileUploadPath": "C:\\inetpub\\FBAManager\\web\\wwwroot\\uploads",
    "AesEncryptionKey": "32-CHAR-KEY-FOR-SP-API-CREDS-HERE"
  }
}
```

**Environment variable alternative (more secure):**
```powershell
[System.Environment]::SetEnvironmentVariable(
    "ConnectionStrings__DefaultConnection",
    "Server=...;Database=...;",
    "Machine")
```

---

## Step 5 — SSL Certificate

```powershell
# Self-signed (development only)
New-SelfSignedCertificate -DnsName "fbamanager.yourdomain.com" -CertStoreLocation "cert:\LocalMachine\My"

# Production: use Let's Encrypt via win-acme
# https://www.win-acme.com/
```

---

## Step 6 — First Login & Setup

1. Navigate to `https://your-domain/`
2. Login: `admin` / change password immediately
3. **Settings → Seller Accounts → Add Account** — enter your Amazon marketplace and SP-API credentials
4. Click **Test SP-API** to confirm credentials work
5. **Settings → COGS Manager** — enter cost for all active ASINs
6. **CSV Import Center** — upload last 18 months of:
   - Reimbursements Report
   - Inventory Adjustments Report
   - Customer Returns Report
   - FBA Inventory Report (current)
7. Verify Hangfire jobs are running: `/admin/jobs`

---

## Step 7 — SP-API App Registration (required for live sync)

1. Go to https://developer.amazon.com/
2. Create a new app (or use existing)
3. Under OAuth — add your domain as redirect URI
4. Note your Client ID and Client Secret
5. Authorize your seller account → copy the Refresh Token
6. Enter all three in Settings → Seller Accounts → Edit Account

---

## Environment Variables Reference

| Variable | Required | Description |
|---|---|---|
| `ConnectionStrings__DefaultConnection` | Yes | SQL Server connection string |
| `Jwt__Key` | Yes (API) | 32+ char JWT signing secret |
| `AppSettings__AesEncryptionKey` | Yes | 32-char key for SP-API credential encryption |
| `ASPNETCORE_ENVIRONMENT` | Yes | `Production` or `Development` |

---

## Backup Strategy

```sql
-- Daily full backup (run via SQL Agent)
BACKUP DATABASE AmazonFBAManager
TO DISK = N'D:\Backups\FBAManager_Full_' + CONVERT(VARCHAR, GETDATE(), 112) + '.bak'
WITH COMPRESSION, STATS = 10;

-- Transaction log backup every 4 hours
BACKUP LOG AmazonFBAManager
TO DISK = N'D:\Backups\FBAManager_Log_' + CONVERT(VARCHAR, GETDATE(), 112) + '_' + REPLACE(CONVERT(VARCHAR, GETDATE(), 108), ':', '') + '.bak';
```

---

## Troubleshooting

| Issue | Check |
|---|---|
| 500 error on startup | Check `logs\stdout` in web publish folder. Enable `stdoutLogEnabled="true"` in web.config |
| Hangfire not running jobs | Verify `Hangfire` tables exist in DB. Check job dashboard at `/admin/jobs` |
| SP-API test fails | Verify Client ID, Secret, Refresh Token. Check marketplace region matches |
| Import shows FAILED | Check error log in Import History. Common cause: wrong Report Type selected |
| COGS all showing $0 | No COGS entered. Go to Settings → COGS Manager |
| SignalR not connecting | Ensure WebSockets enabled in IIS: Server Manager → Web Server → Application Development → WebSocket Protocol |
