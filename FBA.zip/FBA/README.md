# Amazon FBA Multi-Seller Management Platform

## Overview

Full-stack .NET 8 application for managing multiple Amazon FBA seller accounts. Consolidates inventory management, case management, reimbursement auditing, sales reporting, PPC analytics, listing health, and niche research into a single platform.

**Architecture principle:** All business logic lives exclusively in SQL Server Stored Procedures. The application layer is a pure UI/transport layer — no calculations, no conditionals, no filtering in C#.

---

## Project Structure

```
AmazonFBAManager/
├── AmazonFBAManager.sln
├── AmazonFBAManager.Shared/          # DTOs, Interfaces, Constants
│   ├── DTOs/AllDtos.cs               # All data transfer objects
│   ├── Interfaces/IRepositories.cs   # All repository contracts
│   └── Constants/AppConstants.cs    # SP names, report types, roles
│
├── AmazonFBAManager.Data/            # Dapper data access
│   ├── Connections/SqlConnectionFactory.cs
│   ├── Repositories/Repositories.cs # All Dapper SP-call implementations
│   └── Services/
│       ├── CsvParsingService.cs      # Maps Amazon CSV files → DataTables
│       └── ImportOrchestrationService.cs  # Coordinates parse→TVP→SP→SignalR
│
├── AmazonFBAManager.Jobs/            # Hangfire background jobs
│   └── FbaJobService.cs             # 4 scheduled jobs → SP calls
│
├── AmazonFBAManager.Web/             # ASP.NET Core MVC frontend
│   ├── Program.cs                   # DI, auth, SignalR, Hangfire bootstrap
│   ├── Controllers/AllControllers.cs # All MVC controllers
│   ├── Infrastructure/Infrastructure.cs  # Hubs, BaseController, auth filter
│   ├── Views/
│   │   ├── Shared/_Layout.cshtml    # Master layout, sidebar, account switcher
│   │   ├── Dashboard/Index.cshtml   # Multi-account overview
│   │   ├── AllViews.cshtml          # Inventory, Cases, Reimbursement, Import
│   │   ├── AdditionalViews.cshtml   # Login, P&L, PPC, Listings, Alerts, Research
│   │   └── RemainingViews.cshtml    # Checklist, COGS, Aged, Stranded, Case Create
│   └── wwwroot/
│       ├── css/app.css              # Complete application stylesheet
│       └── js/app.js               # Account switcher, alerts, SignalR, export
│
├── AmazonFBAManager.API/             # REST API for desktop app
│   ├── Program.cs                   # JWT auth, Swagger, DI bootstrap
│   └── Controllers/ApiControllers.cs # All REST endpoints
│
└── Database/                         # SQL Server scripts (run in order)
    ├── Tables/01_CoreTables.sql      # 21 tables, indexes, FKs
    ├── TVPs/02_TVPs_And_Security.sql # 8 TVPs, security functions
    ├── Seed/03_SeedData.sql         # Reference data, defaults, SOPs
    ├── StoredProcedures/
    │   ├── Import/04_SP_Import.sql   # 6 import SPs with alert triggers
    │   ├── Inventory/05_SP_Inventory.sql   # EOQ, aged, stranded, AWD, FBA/FBM
    │   ├── Reimbursement/06_SP_Reimbursement.sql  # Audit, checklist, COGS, KPI
    │   ├── Cases/07_SP_Cases.sql    # Kanban, create, escalate, resolve, SLA
    │   └── Reports/08_SP_Reports_PPC_Listings_Research.sql
    ├── Views/09_Views_COGS_Jobs_Master.sql  # Views, job SPs, install guide
    ├── Seed/10_SeedData_EmailTemplates.sql  # 20+ email templates
    └── Seed/11_SeedData_HelpGuide.sql       # Full 11-section help guide
```

---

## Technology Stack

| Layer | Technology |
|---|---|
| Web Frontend | ASP.NET Core 8 MVC + Razor Views |
| API | ASP.NET Core 8 Web API (JWT) |
| Data Access | Dapper (SP calls only — no LINQ queries) |
| Database | SQL Server 2022 / Azure SQL |
| Auth (Web) | Cookie Authentication |
| Auth (API) | JWT Bearer |
| Real-time | SignalR (import progress, live alerts) |
| Background Jobs | Hangfire + SQL Server storage |
| CSV Parsing | CsvHelper |
| Frontend JS | Vanilla JS + Bootstrap 5 + Chart.js |

---

## Database Setup (Run in Order)

```sql
-- 1. Create database
CREATE DATABASE AmazonFBAManager;

-- 2-11. Run scripts in order:
-- 01_CoreTables.sql
-- 02_TVPs_And_Security.sql
-- 03_SeedData.sql
-- 04_SP_Import.sql
-- 05_SP_Inventory.sql
-- 06_SP_Reimbursement.sql
-- 07_SP_Cases.sql
-- 08_SP_Reports_PPC_Listings_Research.sql
-- 09_Views_COGS_Jobs_Master.sql
-- 10_SeedData_EmailTemplates.sql
-- 11_SeedData_HelpGuide.sql
```

---

## Local Development Setup

```bash
# 1. Clone / extract solution
# 2. Set connection string in appsettings.json (or use user secrets)
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Server=.;Database=AmazonFBAManager;Trusted_Connection=True;TrustServerCertificate=True;"

# 3. Restore and build
dotnet restore AmazonFBAManager.sln
dotnet build AmazonFBAManager.sln

# 4. Run web app
dotnet run --project AmazonFBAManager.Web

# 5. Run API (separate terminal)
dotnet run --project AmazonFBAManager.API

# Default URL: https://localhost:7001 (Web), https://localhost:7002 (API)
```

---

## First Login

- **URL:** `https://your-domain/Auth/Login`
- **Username:** `admin`
- **Password:** Change immediately — the default hash is a placeholder

After login:
1. Settings → Seller Accounts → Add your first Amazon account
2. Settings → COGS Manager → Enter cost for all active ASINs (**critical for 2025 reimbursement policy**)
3. CSV Import Center → Upload last 18 months of: Reimbursements, Inventory Adjustments, Returns

---

## Background Jobs (Hangfire)

| Job | Schedule | SP Called |
|---|---|---|
| Nightly Reimbursement Audit | Daily 2:00 AM UTC | `usp_Job_NightlyReimbursementAudit` |
| Inventory Alert Check | Every 4 hours | `usp_Job_InventoryAlertCheck` |
| PPC Audit | Every Monday 6:00 AM UTC | `usp_Job_PPCAuditWeekly` |
| Case SLA Monitor | Every 2 hours | `usp_Case_MonitorSLABreaches` |

Hangfire dashboard: `https://your-domain/admin/jobs` (Admin role only)

---

## User Roles

| Role | Permissions |
|---|---|
| Admin | Full access, user management, all accounts, Hangfire dashboard |
| AccountManager | Full access to assigned accounts, create/close cases |
| Analyst | Read + export access, run reports, no case creation |
| VAReadOnly | Read-only, can add case notes, cannot change status or COGS |

---

## IIS Deployment (On-Premise)

```bash
# Publish
dotnet publish AmazonFBAManager.Web -c Release -o ./publish/web
dotnet publish AmazonFBAManager.API -c Release -o ./publish/api

# IIS Requirements:
# - .NET 8 Windows Hosting Bundle installed
# - App Pool: No Managed Code
# - wwwroot/uploads directory writable by IIS AppPool user
# - HTTPS binding with valid SSL certificate
```

---

## Key 2025 Amazon Policy Notes

- **Reimbursements at COGS (March 2025):** Amazon now reimburses lost/damaged inventory at cost basis, not selling price. COGS must be entered for every ASIN or claims are worth $0.
- **18-month filing window:** All reimbursement claims must be filed within 18 months of the loss event. The platform alerts at 60-day and 30-day marks.
- **AWD discrepancies:** Units lost in the AWD → FC pipeline are claimable but require separate case filing. Upload AWD Inventory Report weekly if using AWD.

---

## CSV Report Types Supported

| Report | Amazon Source | Import SP |
|---|---|---|
| FBA Inventory Report | Reports → Fulfillment → All Listings | `usp_ImportCSV_InventorySnapshot` |
| All Orders Report | Orders → Order Reports | `usp_ImportCSV_SalesOrders` |
| Reimbursements Report | Reports → Fulfillment → Payments | `usp_ImportCSV_Reimbursements` |
| Inventory Adjustments | Reports → Fulfillment → Inventory | `usp_ImportCSV_InventoryAdjustments` |
| Customer Returns | Reports → Fulfillment → Returns | `usp_ImportCSV_Returns` |
| PPC Search Term Report | Advertising → Campaign Manager | `usp_ImportCSV_PPCKeywords` |
| Inbound Shipments | Inventory → Shipments | `usp_ImportCSV_InboundShipments` |

---

## SignalR Events

| Hub | Event | Payload |
|---|---|---|
| `/hubs/import` | `ImportUpdate` | `{ importId, message, status }` |
| `/hubs/import` | `ImportComplete` | `{ importId, status, rowsImported, rowsErrored }` |
| `/hubs/alerts` | `NewAlert` | `{ sellerAccountId, severity, message, timestamp }` |

---

## License

Internal use / white-label commercial platform. All rights reserved.
