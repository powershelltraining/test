// ============================================================
// AmazonFBAManager.Data/Repositories/Repositories.cs
// All repository implementations — pure SP calls via Dapper
// Zero business logic — all logic lives in SQL Server
// ============================================================
using AmazonFBAManager.Data.Connections;
using AmazonFBAManager.Shared.Constants;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;
using Dapper;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AmazonFBAManager.Data.Repositories
{
    // --------------------------------------------------------
    // AUTH REPOSITORY
    // --------------------------------------------------------
    public class AuthRepository : IAuthRepository
    {
        private readonly ISqlConnectionFactory _cf;
        public AuthRepository(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<LoginResponseDto> LoginAsync(string username, string password)
        {
            using var conn = _cf.Create();

            // Fetch user by username
            var user = await conn.QueryFirstOrDefaultAsync<UserDto>(
                "SELECT u.UserId, u.Username, u.Email, u.PasswordHash, u.RoleId, r.RoleName, u.IsActive " +
                "FROM dbo.Users u INNER JOIN dbo.Roles r ON r.RoleId = u.RoleId " +
                "WHERE u.Username = @Username AND u.IsActive = 1",
                new { Username = username });

            if (user == null)
                return new LoginResponseDto { Success = false, ErrorMessage = "Invalid username or password." };

            // Validate password (SHA-256 hash for simplicity — use BCrypt in production)
            var hash = await conn.QueryFirstOrDefaultAsync<string>(
                "SELECT PasswordHash FROM dbo.Users WHERE UserId = @UserId", new { user.UserId });

            if (!VerifyPassword(password, hash!))
                return new LoginResponseDto { Success = false, ErrorMessage = "Invalid username or password." };

            // Update last login
            await conn.ExecuteAsync(
                "UPDATE dbo.Users SET LastLoginDate = SYSUTCDATETIME() WHERE UserId = @UserId",
                new { user.UserId });

            // Get accessible accounts
            var accounts = (await conn.QueryAsync<SellerAccountDto>(
                StoredProcedures.Auth_GetUserAccounts,
                new { UserId = user.UserId },
                commandType: CommandType.StoredProcedure)).ToList();

            return new LoginResponseDto { Success = true, User = user, Accounts = accounts };
        }

        public async Task<IEnumerable<SellerAccountDto>> GetUserAccountsAsync(int userId)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<SellerAccountDto>(
                StoredProcedures.Auth_GetUserAccounts,
                new { UserId = userId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<bool> HasAccountAccessAsync(int userId, int sellerAccountId)
        {
            using var conn = _cf.Create();
            var result = await conn.QueryFirstOrDefaultAsync(
                StoredProcedures.Auth_ValidateAccess,
                new { UserId = userId, SellerAccountId = sellerAccountId },
                commandType: CommandType.StoredProcedure);
            return result?.HasAccess == 1;
        }

        public async Task<string> GetPermissionLevelAsync(int userId, int sellerAccountId)
        {
            using var conn = _cf.Create();
            var result = await conn.QueryFirstOrDefaultAsync(
                StoredProcedures.Auth_ValidateAccess,
                new { UserId = userId, SellerAccountId = sellerAccountId },
                commandType: CommandType.StoredProcedure);
            return result?.PermissionLevel ?? "NONE";
        }

        private static bool VerifyPassword(string password, string hash)
        {
            // For production use BCrypt.Net-Next. This is SHA-256 fallback.
            if (hash == "CHANGE_ON_FIRST_LOGIN_PLACEHOLDER") return true;
            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
            var computed = Convert.ToBase64String(bytes);
            return computed == hash;
        }
    }

    // --------------------------------------------------------
    // INVENTORY REPOSITORY
    // --------------------------------------------------------
    public class InventoryRepository : IInventoryRepository
    {
        private readonly ISqlConnectionFactory _cf;
        public InventoryRepository(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<IEnumerable<ReorderSuggestionDto>> GetReorderSuggestionsAsync(
            int sellerAccountId, int userId, int leadTimeDays = 30, decimal serviceLevel = 0.95m)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<ReorderSuggestionDto>(
                StoredProcedures.Inventory_ReorderSuggestions,
                new { SellerAccountId = sellerAccountId, UserId = userId, LeadTimeDays = leadTimeDays, ServiceLevel = serviceLevel },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<OverstockReportDto>> GetOverstockReportAsync(
            int sellerAccountId, int userId, int daysOfSupplyThreshold = 90)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<OverstockReportDto>(
                StoredProcedures.Inventory_OverstockReport,
                new { SellerAccountId = sellerAccountId, UserId = userId, DaysOfSupplyThreshold = daysOfSupplyThreshold },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<AgedInventoryDto>> GetAgedInventoryFeeRiskAsync(
            int sellerAccountId, int userId, DateTime? snapshotDate = null)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<AgedInventoryDto>(
                StoredProcedures.Inventory_AgedInventory,
                new { SellerAccountId = sellerAccountId, UserId = userId, SnapshotDate = snapshotDate },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<StrandedInventoryDto>> GetStrandedInventoryAsync(int sellerAccountId, int userId)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<StrandedInventoryDto>(
                StoredProcedures.Inventory_StrandedInventory,
                new { SellerAccountId = sellerAccountId, UserId = userId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<AWDDiscrepancyDto>> GetAWDDiscrepanciesAsync(
            int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<AWDDiscrepancyDto>(
                StoredProcedures.Inventory_AWDDiscrepancies,
                new { SellerAccountId = sellerAccountId, UserId = userId, DateFrom = dateFrom, DateTo = dateTo },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<FBAFBMComparisonDto?> CompareFBAFBMAsync(
            int productId, int sellerAccountId, int userId,
            decimal fbmShippingCost = 5.00m, decimal fbmPackagingCost = 1.50m)
        {
            using var conn = _cf.Create();
            return await conn.QueryFirstOrDefaultAsync<FBAFBMComparisonDto>(
                StoredProcedures.Inventory_CompareFBAFBM,
                new { ProductId = productId, SellerAccountId = sellerAccountId, UserId = userId, FBMShippingCost = fbmShippingCost, FBMPackagingCost = fbmPackagingCost },
                commandType: CommandType.StoredProcedure);
        }
    }

    // --------------------------------------------------------
    // REIMBURSEMENT REPOSITORY
    // --------------------------------------------------------
    public class ReimbursementRepository : IReimbursementRepository
    {
        private readonly ISqlConnectionFactory _cf;
        public ReimbursementRepository(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<IEnumerable<ReimbursementAuditDto>> AuditLostDamagedInventoryAsync(
            int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<ReimbursementAuditDto>(
                StoredProcedures.Reimb_AuditLostDamaged,
                new { SellerAccountId = sellerAccountId, UserId = userId, DateFrom = dateFrom, DateTo = dateTo },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<FeeOverchargeDto>> DetectFeeOverchargesAsync(
            int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<FeeOverchargeDto>(
                StoredProcedures.Reimb_FeeOvercharges,
                new { SellerAccountId = sellerAccountId, UserId = userId, DateFrom = dateFrom, DateTo = dateTo },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<ReimbursementAuditDto>> AuditReturnlessRefundsAsync(
            int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<ReimbursementAuditDto>(
                StoredProcedures.Reimb_ReturnlessRefunds,
                new { SellerAccountId = sellerAccountId, UserId = userId, DateFrom = dateFrom, DateTo = dateTo },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<MonthlyChecklistItemDto>> GetMonthlyChecklistAsync(
            int sellerAccountId, int userId, int month, int year)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<MonthlyChecklistItemDto>(
                StoredProcedures.Reimb_MonthlyChecklist,
                new { SellerAccountId = sellerAccountId, UserId = userId, Month = month, Year = year },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<ReimbursementKPIDto?> GetKPIDashboardAsync(
            int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null)
        {
            using var conn = _cf.Create();
            // SP returns 2 result sets: summary row + monthly trend
            using var multi = await conn.QueryMultipleAsync(
                StoredProcedures.Reimb_KPIDashboard,
                new { SellerAccountId = sellerAccountId, UserId = userId, DateFrom = dateFrom, DateTo = dateTo },
                commandType: CommandType.StoredProcedure);
            return await multi.ReadFirstOrDefaultAsync<ReimbursementKPIDto>();
        }

        public async Task<IEnumerable<ReimbursementMonthlyTrendDto>> GetMonthlyTrendAsync(
            int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null)
        {
            using var conn = _cf.Create();
            using var multi = await conn.QueryMultipleAsync(
                StoredProcedures.Reimb_KPIDashboard,
                new { SellerAccountId = sellerAccountId, UserId = userId, DateFrom = dateFrom, DateTo = dateTo },
                commandType: CommandType.StoredProcedure);
            await multi.ReadFirstOrDefaultAsync<ReimbursementKPIDto>(); // consume first result set
            return await multi.ReadAsync<ReimbursementMonthlyTrendDto>();
        }

        public async Task<IEnumerable<COGSProductDto>> GetMissingCOGSAsync(int sellerAccountId, int userId)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<COGSProductDto>(
                StoredProcedures.COGS_GetMissing,
                new { SellerAccountId = sellerAccountId, UserId = userId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<int> BulkUpdateCOGSAsync(int sellerAccountId, int userId, IEnumerable<COGSUpdateDto> updates)
        {
            using var conn = _cf.Create();

            // Build TVP
            var tvp = new DataTable();
            tvp.Columns.Add("SKU", typeof(string));
            tvp.Columns.Add("COGS", typeof(decimal));
            foreach (var u in updates)
                tvp.Rows.Add(u.SKU, u.COGS);

            var param = new DynamicParameters();
            param.Add("SellerAccountId", sellerAccountId);
            param.Add("UserId", userId);
            param.Add("Updates", tvp.AsTableValuedParameter("dbo.TVP_COGSUpdate"));

            var result = await conn.QueryFirstOrDefaultAsync(
                StoredProcedures.COGS_BulkUpdate, param, commandType: CommandType.StoredProcedure);
            return result?.ProductsUpdated ?? 0;
        }
    }

    // --------------------------------------------------------
    // CASE REPOSITORY
    // --------------------------------------------------------
    public class CaseRepository : ICaseRepository
    {
        private readonly ISqlConnectionFactory _cf;
        public CaseRepository(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<int> CreateCaseAsync(CreateCaseRequestDto request, int userId)
        {
            using var conn = _cf.Create();
            var param = new DynamicParameters();
            param.Add("SellerAccountId", request.SellerAccountId);
            param.Add("UserId", userId);
            param.Add("CaseTypeCode", request.CaseTypeCode);
            param.Add("Subject", request.Subject);
            param.Add("Description", request.Description);
            param.Add("ASIN", request.ASIN);
            param.Add("Priority", request.Priority);
            param.Add("LinkedAuditId", request.LinkedAuditId);
            param.Add("NewCaseId", dbType: DbType.Int32, direction: ParameterDirection.Output);

            await conn.ExecuteAsync(StoredProcedures.Case_Create, param, commandType: CommandType.StoredProcedure);
            return param.Get<int>("NewCaseId");
        }

        public async Task EscalateCaseAsync(int caseId, int userId, string reason)
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                StoredProcedures.Case_Escalate,
                new { CaseId = caseId, UserId = userId, EscalationReason = reason },
                commandType: CommandType.StoredProcedure);
        }

        public async Task ResolveCaseAsync(ResolveCaseRequestDto request, int userId)
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                StoredProcedures.Case_Resolve,
                new { CaseId = request.CaseId, UserId = userId, ResolvedAmount = request.ResolvedAmount, ResolutionNote = request.ResolutionNote },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<CaseDto?> GetCaseDetailAsync(int caseId, int userId)
        {
            using var conn = _cf.Create();
            using var multi = await conn.QueryMultipleAsync(
                StoredProcedures.Case_GetDetail,
                new { CaseId = caseId, UserId = userId },
                commandType: CommandType.StoredProcedure);
            return await multi.ReadFirstOrDefaultAsync<CaseDto>();
        }

        public async Task<IEnumerable<CaseDto>> GetKanbanBoardAsync(int sellerAccountId, int userId, int? assignedUserId = null)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<CaseDto>(
                StoredProcedures.Case_KanbanBoard,
                new { SellerAccountId = sellerAccountId, UserId = userId, AssignedUserId = assignedUserId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<CaseDto>> GetAgingReportAsync(int sellerAccountId, int userId, int sladays = 7)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<CaseDto>(
                StoredProcedures.Case_AgingReport,
                new { SellerAccountId = sellerAccountId, UserId = userId, SLADays = sladays },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<HijackReportDto?> BuildHijackReportAsync(int productId, int sellerAccountId, int userId, string? hijackerName = null)
        {
            using var conn = _cf.Create();
            return await conn.QueryFirstOrDefaultAsync<HijackReportDto>(
                StoredProcedures.Case_HijackReport,
                new { ProductId = productId, SellerAccountId = sellerAccountId, UserId = userId, HijackerSellerName = hijackerName },
                commandType: CommandType.StoredProcedure);
        }

        public async Task AddCaseNoteAsync(int caseId, int userId, string noteText, bool isInternal = true)
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                "INSERT INTO dbo.CaseNotes (CaseId, UserId, NoteText, IsInternal) VALUES (@CaseId, @UserId, @NoteText, @IsInternal)",
                new { CaseId = caseId, UserId = userId, NoteText = noteText, IsInternal = isInternal });
        }

        public async Task<IEnumerable<CaseNoteDto>> GetCaseNotesAsync(int caseId, int userId)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<CaseNoteDto>(
                "SELECT cn.NoteId, cn.NoteDate, u.Username, cn.NoteText, cn.IsInternal " +
                "FROM dbo.CaseNotes cn INNER JOIN dbo.Users u ON u.UserId = cn.UserId " +
                "WHERE cn.CaseId = @CaseId ORDER BY cn.NoteDate",
                new { CaseId = caseId });
        }

        public async Task<IEnumerable<CaseAttachmentDto>> GetCaseAttachmentsAsync(int caseId, int userId)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<CaseAttachmentDto>(
                "SELECT ca.AttachmentId, ca.FileName, ca.FileSizeBytes, ca.MimeType, ca.UploadDate, u.Username AS UploadedBy " +
                "FROM dbo.CaseAttachments ca LEFT JOIN dbo.Users u ON u.UserId = ca.UploadedByUserId " +
                "WHERE ca.CaseId = @CaseId ORDER BY ca.UploadDate DESC",
                new { CaseId = caseId });
        }

        public async Task<int> SaveCaseAttachmentAsync(int caseId, string fileName, string storagePath, long? fileSize, string? mimeType, int userId)
        {
            using var conn = _cf.Create();
            return await conn.QuerySingleAsync<int>(
                "INSERT INTO dbo.CaseAttachments (CaseId, FileName, StoragePath, FileSizeBytes, MimeType, UploadedByUserId) " +
                "OUTPUT INSERTED.AttachmentId " +
                "VALUES (@CaseId, @FileName, @StoragePath, @FileSizeBytes, @MimeType, @UserId)",
                new { CaseId = caseId, FileName = fileName, StoragePath = storagePath, FileSizeBytes = fileSize, MimeType = mimeType, UserId = userId });
        }
    }

    // --------------------------------------------------------
    // REPORTS REPOSITORY
    // --------------------------------------------------------
    public class ReportsRepository : IReportsRepository
    {
        private readonly ISqlConnectionFactory _cf;
        public ReportsRepository(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<IEnumerable<ProfitLossDto>> GetProfitLossBySKUAsync(
            int sellerAccountId, int userId, DateTime dateFrom, DateTime dateTo, string groupBy = "SKU")
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<ProfitLossDto>(
                StoredProcedures.Reports_PLBySKU,
                new { SellerAccountId = sellerAccountId, UserId = userId, DateFrom = dateFrom, DateTo = dateTo, GroupBy = groupBy },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<MultiAccountSummaryDto>> GetMultiAccountSummaryAsync(int userId, DateTime dateFrom, DateTime dateTo)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<MultiAccountSummaryDto>(
                StoredProcedures.Reports_MultiAccount,
                new { UserId = userId, DateFrom = dateFrom, DateTo = dateTo },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<ReturnRateDto>> GetReturnRateAnalysisAsync(
            int sellerAccountId, int userId, DateTime dateFrom, DateTime dateTo)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<ReturnRateDto>(
                StoredProcedures.Reports_ReturnRate,
                new { SellerAccountId = sellerAccountId, UserId = userId, DateFrom = dateFrom, DateTo = dateTo },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<CashFlowForecastDto>> GetCashFlowForecastAsync(
            int sellerAccountId, int userId, int forecastDays = 90)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<CashFlowForecastDto>(
                StoredProcedures.Reports_CashFlow,
                new { SellerAccountId = sellerAccountId, UserId = userId, ForecastDays = forecastDays },
                commandType: CommandType.StoredProcedure);
        }
    }

    // --------------------------------------------------------
    // PPC REPOSITORY
    // --------------------------------------------------------
    public class PPCRepository : IPPCRepository
    {
        private readonly ISqlConnectionFactory _cf;
        public PPCRepository(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<IEnumerable<PPCAuditItemDto>> AuditCampaignsAsync(
            int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<PPCAuditItemDto>(
                StoredProcedures.PPC_AuditCampaigns,
                new { SellerAccountId = sellerAccountId, UserId = userId, DateFrom = dateFrom, DateTo = dateTo },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<TACosDto?> CalculateTACosAsync(int sellerAccountId, int userId, DateTime dateFrom, DateTime dateTo)
        {
            using var conn = _cf.Create();
            return await conn.QueryFirstOrDefaultAsync<TACosDto>(
                StoredProcedures.PPC_TACoS,
                new { SellerAccountId = sellerAccountId, UserId = userId, DateFrom = dateFrom, DateTo = dateTo },
                commandType: CommandType.StoredProcedure);
        }
    }

    // --------------------------------------------------------
    // LISTING REPOSITORY
    // --------------------------------------------------------
    public class ListingRepository : IListingRepository
    {
        private readonly ISqlConnectionFactory _cf;
        public ListingRepository(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<ListingHealthDto?> GetHealthScoreAsync(int productId, int sellerAccountId, int userId)
        {
            using var conn = _cf.Create();
            return await conn.QueryFirstOrDefaultAsync<ListingHealthDto>(
                StoredProcedures.Listing_HealthScore,
                new { ProductId = productId, SellerAccountId = sellerAccountId, UserId = userId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<ListingHealthDto>> GetAllHealthScoresAsync(int sellerAccountId, int userId)
        {
            using var conn = _cf.Create();
            // Run health score for all active products
            return await conn.QueryAsync<ListingHealthDto>(
                "SELECT p.ProductId, p.SKU, p.ASIN, p.ProductTitle, " +
                "l.ListingStatus, l.ReviewCount, l.StarRating, l.BSR, l.BuyBoxPrice, " +
                "l.ImageCount, l.HasAPlusContent, l.BackendKeywords, l.Title, " +
                "l.BulletPoint1, l.BulletPoint2, l.BulletPoint3, l.BulletPoint4, l.BulletPoint5 " +
                "FROM dbo.Products p " +
                "OUTER APPLY (SELECT TOP 1 * FROM dbo.Listings ls " +
                "  WHERE ls.ProductId = p.ProductId AND ls.SellerAccountId = @SellerAccountId " +
                "  ORDER BY ls.SnapshotDate DESC) l " +
                "WHERE p.SellerAccountId = @SellerAccountId AND p.IsActive = 1 " +
                "ORDER BY p.SKU",
                new { SellerAccountId = sellerAccountId });
        }
    }

    // --------------------------------------------------------
    // ALERT REPOSITORY
    // --------------------------------------------------------
    public class AlertRepository : IAlertRepository
    {
        private readonly ISqlConnectionFactory _cf;
        public AlertRepository(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<IEnumerable<AlertDto>> GetUnreadAlertsAsync(int sellerAccountId, int userId, int pageSize = 50)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<AlertDto>(
                "SELECT TOP (@PageSize) a.AlertId, a.SellerAccountId, sa.AccountName, " +
                "a.AlertTypeCode, at2.AlertTypeName, a.ProductId, p.SKU, a.CaseId, " +
                "a.AlertDate, a.Message, a.Severity, a.IsRead " +
                "FROM dbo.Alerts a " +
                "INNER JOIN dbo.SellerAccounts sa ON sa.SellerAccountId = a.SellerAccountId " +
                "INNER JOIN dbo.AlertTypes at2 ON at2.AlertTypeCode = a.AlertTypeCode " +
                "LEFT JOIN dbo.Products p ON p.ProductId = a.ProductId " +
                "WHERE a.SellerAccountId = @SellerAccountId AND a.IsRead = 0 AND a.IsActive = 1 " +
                "ORDER BY CASE a.Severity WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 ELSE 4 END, a.AlertDate DESC",
                new { SellerAccountId = sellerAccountId, PageSize = pageSize });
        }

        public async Task<IEnumerable<AlertDto>> GetAllAlertsAsync(int sellerAccountId, int userId, int pageSize = 100)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<AlertDto>(
                "SELECT TOP (@PageSize) a.AlertId, a.SellerAccountId, sa.AccountName, " +
                "a.AlertTypeCode, at2.AlertTypeName, a.ProductId, p.SKU, a.CaseId, " +
                "a.AlertDate, a.Message, a.Severity, a.IsRead " +
                "FROM dbo.Alerts a " +
                "INNER JOIN dbo.SellerAccounts sa ON sa.SellerAccountId = a.SellerAccountId " +
                "INNER JOIN dbo.AlertTypes at2 ON at2.AlertTypeCode = a.AlertTypeCode " +
                "LEFT JOIN dbo.Products p ON p.ProductId = a.ProductId " +
                "WHERE a.SellerAccountId = @SellerAccountId AND a.IsActive = 1 " +
                "ORDER BY a.AlertDate DESC",
                new { SellerAccountId = sellerAccountId, PageSize = pageSize });
        }

        public async Task MarkAlertReadAsync(long alertId, int userId)
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                "UPDATE dbo.Alerts SET IsRead = 1, ReadDate = SYSUTCDATETIME(), ReadByUserId = @UserId WHERE AlertId = @AlertId",
                new { AlertId = alertId, UserId = userId });
        }

        public async Task MarkAllReadAsync(int sellerAccountId, int userId)
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                "UPDATE dbo.Alerts SET IsRead = 1, ReadDate = SYSUTCDATETIME(), ReadByUserId = @UserId " +
                "WHERE SellerAccountId = @SellerAccountId AND IsRead = 0",
                new { SellerAccountId = sellerAccountId, UserId = userId });
        }

        public async Task<int> GetUnreadCountAsync(int sellerAccountId, int userId)
        {
            using var conn = _cf.Create();
            return await conn.QuerySingleAsync<int>(
                "SELECT COUNT(*) FROM dbo.Alerts WHERE SellerAccountId = @SellerAccountId AND IsRead = 0 AND IsActive = 1",
                new { SellerAccountId = sellerAccountId });
        }
    }

    // --------------------------------------------------------
    // IMPORT REPOSITORY
    // --------------------------------------------------------
    public class ImportRepository : IImportRepository
    {
        private readonly ISqlConnectionFactory _cf;
        public ImportRepository(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<int> CreateImportRecordAsync(int sellerAccountId, int userId, string reportTypeCode, string fileName, long? fileSize)
        {
            using var conn = _cf.Create();
            return await conn.QuerySingleAsync<int>(
                "INSERT INTO dbo.CSVImports (SellerAccountId, UserId, ReportTypeCode, FileName, FileSizeBytes, Status) " +
                "OUTPUT INSERTED.ImportId " +
                "VALUES (@SellerAccountId, @UserId, @ReportTypeCode, @FileName, @FileSizeBytes, 'PENDING')",
                new { SellerAccountId = sellerAccountId, UserId = userId, ReportTypeCode = reportTypeCode, FileName = fileName, FileSizeBytes = fileSize });
        }

        public async Task<ImportResultDto?> GetImportResultAsync(int importId)
        {
            using var conn = _cf.Create();
            return await conn.QueryFirstOrDefaultAsync<ImportResultDto>(
                "SELECT ImportId, RowsImported, RowsSkipped, RowsErrored, Status, ErrorLog FROM dbo.CSVImports WHERE ImportId = @ImportId",
                new { ImportId = importId });
        }

        public async Task<IEnumerable<ImportHistoryDto>> GetImportHistoryAsync(int sellerAccountId, int userId, int pageSize = 50, int page = 1)
        {
            using var conn = _cf.Create();
            return await conn.QueryAsync<ImportHistoryDto>(
                StoredProcedures.Import_GetHistory,
                new { SellerAccountId = sellerAccountId, UserId = userId, PageSize = pageSize, PageNumber = page },
                commandType: CommandType.StoredProcedure);
        }
    }

    // --------------------------------------------------------
    // RESEARCH REPOSITORY
    // --------------------------------------------------------
    public class ResearchRepository : IResearchRepository
    {
        private readonly ISqlConnectionFactory _cf;
        public ResearchRepository(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<OpportunityScoreDto?> CalculateOpportunityScoreAsync(
            int sellerAccountId, int userId, string keyword,
            int? searchVolume, int? competitorCount, decimal? avgRevenue, int? avgReviews, decimal? avgPrice)
        {
            using var conn = _cf.Create();
            return await conn.QueryFirstOrDefaultAsync<OpportunityScoreDto>(
                StoredProcedures.Research_OpportunityScore,
                new
                {
                    SellerAccountId = sellerAccountId, UserId = userId, Keyword = keyword,
                    EstSearchVolume = searchVolume, CompetitorCount = competitorCount,
                    AvgRevenue = avgRevenue, AvgReviews = avgReviews, AvgPrice = avgPrice
                },
                commandType: CommandType.StoredProcedure);
        }
    }
}
