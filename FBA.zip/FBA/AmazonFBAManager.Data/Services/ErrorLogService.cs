// ============================================================
// AmazonFBAManager.Data/Services/ErrorLogService.cs
// Error logging and configuration service
// ============================================================
using AmazonFBAManager.Data.Connections;
using AmazonFBAManager.Shared.DTOs;
using Dapper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmazonFBAManager.Data.Services
{
    public interface IErrorLogService
    {
        Task LogErrorAsync(LogErrorRequestDto request);
        Task LogExceptionAsync(Exception ex, string source, int? userId = null, int? accountId = null);
        Task<List<ErrorLogDto>> GetRecentErrors(int count = 50, string? level = null);
        Task<List<ErrorLogDto>> GetUnresolvedErrors();
        Task ResolveErrorAsync(long errorLogId, string resolvedBy, string? notes = null);
        Task<DebugConfigDto> GetDebugConfigAsync();
        Task UpdateDebugConfigAsync(DebugConfigDto config);
        Task PurgeOldLogsAsync(int daysToKeep);
    }

    public class ErrorLogService : IErrorLogService
    {
        private readonly ISqlConnectionFactory _cf;
        private readonly ILogger<ErrorLogService> _logger;

        public ErrorLogService(ISqlConnectionFactory cf, ILogger<ErrorLogService> logger)
        {
            _cf = cf;
            _logger = logger;
        }

        /// <summary>
        /// Log an error to the database
        /// </summary>
        public async Task LogErrorAsync(LogErrorRequestDto request)
        {
            try
            {
                var config = await GetDebugConfigAsync();

                // Check if we should log this level
                if (!ShouldLogLevel(request.ErrorLevel, config.DebugLevel))
                    return;

                using var conn = _cf.Create();
                await conn.ExecuteAsync(@"
                    INSERT INTO dbo.ErrorLogs
                        (ErrorLevel, ErrorSource, ErrorMessage, StackTrace, UserId, SellerAccountId,
                         RequestPath, RequestMethod, IpAddress, BrowserInfo)
                    VALUES
                        (@ErrorLevel, @ErrorSource, @ErrorMessage, @StackTrace, @UserId, @SellerAccountId,
                         @RequestPath, @RequestMethod, @IpAddress, @BrowserInfo)",
                    new
                    {
                        request.ErrorLevel,
                        request.ErrorSource,
                        request.ErrorMessage,
                        request.StackTrace,
                        request.UserId,
                        request.SellerAccountId,
                        request.RequestPath,
                        request.RequestMethod,
                        request.IpAddress,
                        request.BrowserInfo
                    });
            }
            catch (Exception ex)
            {
                // Fallback to file logging if DB fails
                _logger.LogError(ex, "Failed to log error to database: {Message}", request.ErrorMessage);
            }
        }

        /// <summary>
        /// Log an exception with stack trace
        /// </summary>
        public async Task LogExceptionAsync(Exception ex, string source, int? userId = null, int? accountId = null)
        {
            var level = ex is System.IO.IOException or InvalidOperationException ? "WARNING" : "ERROR";

            var request = new LogErrorRequestDto
            {
                ErrorLevel = level,
                ErrorSource = source,
                ErrorMessage = ex.Message,
                StackTrace = ex.StackTrace,
                UserId = userId,
                SellerAccountId = accountId
            };

            await LogErrorAsync(request);
        }

        /// <summary>
        /// Get recent errors from the database
        /// </summary>
        public async Task<List<ErrorLogDto>> GetRecentErrors(int count = 50, string? level = null)
        {
            using var conn = _cf.Create();
            var sql = @"
                SELECT TOP (@Count)
                    ErrorLogId, ErrorDate, ErrorLevel, ErrorSource, ErrorMessage,
                    StackTrace, UserId, SellerAccountId, RequestPath, RequestMethod,
                    IpAddress, BrowserInfo, IsResolved, ResolvedDate, ResolvedBy, Notes
                FROM dbo.ErrorLogs
                WHERE 1=1";

            if (!string.IsNullOrEmpty(level))
                sql += " AND ErrorLevel = @Level";

            sql += " ORDER BY ErrorDate DESC";

            var results = await conn.QueryAsync<ErrorLogDto>(sql, new { Count = count, Level = level });
            return results.ToList();
        }

        /// <summary>
        /// Get all unresolved errors
        /// </summary>
        public async Task<List<ErrorLogDto>> GetUnresolvedErrors()
        {
            using var conn = _cf.Create();
            var results = await conn.QueryAsync<ErrorLogDto>(@"
                SELECT ErrorLogId, ErrorDate, ErrorLevel, ErrorSource, ErrorMessage,
                       StackTrace, UserId, SellerAccountId, RequestPath, RequestMethod,
                       IpAddress, BrowserInfo, IsResolved, ResolvedDate, ResolvedBy, Notes
                FROM dbo.ErrorLogs
                WHERE IsResolved = 0
                ORDER BY ErrorDate DESC");
            return results.ToList();
        }

        /// <summary>
        /// Mark an error as resolved
        /// </summary>
        public async Task ResolveErrorAsync(long errorLogId, string resolvedBy, string? notes = null)
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(@"
                UPDATE dbo.ErrorLogs
                SET IsResolved = 1,
                    ResolvedDate = SYSUTCDATETIME(),
                    ResolvedBy = @ResolvedBy,
                    Notes = @Notes
                WHERE ErrorLogId = @ErrorLogId",
                new { ErrorLogId = errorLogId, ResolvedBy = resolvedBy, Notes = notes });
        }

        /// <summary>
        /// Get debug configuration settings
        /// </summary>
        public async Task<DebugConfigDto> GetDebugConfigAsync()
        {
            using var conn = _cf.Create();
            var settings = await conn.QueryAsync<AppSettingDto>(
                "SELECT SettingKey, SettingValue FROM dbo.AppSettings WHERE IsActive = 1");

            var dict = settings.ToDictionary(s => s.SettingKey, s => s.SettingValue ?? "");

            return new DebugConfigDto
            {
                DebugLevel = dict.GetValueOrDefault("DebugLevel", "ERROR"),
                EnableFileLogging = dict.GetValueOrDefault("EnableFileLogging", "false").ToLower() == "true",
                EnableDatabaseLogging = dict.GetValueOrDefault("EnableDatabaseLogging", "true").ToLower() == "true",
                MaxErrorLogDays = int.TryParse(dict.GetValueOrDefault("MaxErrorLogDays", "30"), out var days) ? days : 30,
                EmailOnCriticalErrors = dict.GetValueOrDefault("EmailOnCriticalErrors", "true").ToLower() == "true",
                EmailOnHighErrors = dict.GetValueOrDefault("EmailOnHighErrors", "false").ToLower() == "true"
            };
        }

        /// <summary>
        /// Update debug configuration
        /// </summary>
        public async Task UpdateDebugConfigAsync(DebugConfigDto config)
        {
            using var conn = _cf.Create();

            var settings = new Dictionary<string, string>
            {
                { "DebugLevel", config.DebugLevel },
                { "EnableFileLogging", config.EnableFileLogging.ToString().ToLower() },
                { "EnableDatabaseLogging", config.EnableDatabaseLogging.ToString().ToLower() },
                { "MaxErrorLogDays", config.MaxErrorLogDays.ToString() },
                { "EmailOnCriticalErrors", config.EmailOnCriticalErrors.ToString().ToLower() },
                { "EmailOnHighErrors", config.EmailOnHighErrors.ToString().ToLower() }
            };

            foreach (var kvp in settings)
            {
                await conn.ExecuteAsync(@"
                    UPDATE dbo.AppSettings
                    SET SettingValue = @Value, ModifiedDate = SYSUTCDATETIME()
                    WHERE SettingKey = @Key",
                    new { Key = kvp.Key, Value = kvp.Value });
            }
        }

        /// <summary>
        /// Purge old error logs
        /// </summary>
        public async Task PurgeOldLogsAsync(int daysToKeep)
        {
            using var conn = _cf.Create();
            var deleted = await conn.ExecuteAsync(@"
                DELETE FROM dbo.ErrorLogs
                WHERE IsResolved = 1
                AND ErrorDate < DATEADD(DAY, -@Days, SYSUTCDATETIME())",
                new { Days = daysToKeep });

            if (deleted > 0)
                _logger.LogInformation("Purged {Count} old error logs", deleted);
        }

        // --- Private Helpers ---

        private static bool ShouldLogLevel(string errorLevel, string minLevel)
        {
            var levels = new[] { "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL" };
            var errorIdx = Array.IndexOf(levels, errorLevel.ToUpper());
            var minIdx = Array.IndexOf(levels, minLevel.ToUpper());
            return errorIdx >= 0 && minIdx >= 0 && errorIdx >= minIdx;
        }
    }
}