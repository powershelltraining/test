// ============================================================
// AmazonFBAManager.Data/Services/SpApiService.cs
// Amazon Selling Partner API integration
// Pulls live: inventory, orders, listings, reimbursements, fees
// Credentials decrypted per SellerAccount; results written via SPs
// ============================================================
using AmazonFBAManager.Data.Connections;
using AmazonFBAManager.Shared.Constants;
using AmazonFBAManager.Shared.DTOs;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace AmazonFBAManager.Data.Services
{
    public interface ISpApiService
    {
        Task<SPAPIConnectionTestResult> TestConnectionAsync(int sellerAccountId, int userId);
        Task<SPAPISyncResult> RunSyncJobAsync(int sellerAccountId, int userId, string jobCode);
    }

    public class SPAPISyncResult
    {
        public bool Success { get; set; }
        public string JobCode { get; set; } = "";
        public int RecordsProcessed { get; set; }
        public string? Message { get; set; }
        public DateTime CompletedAt { get; set; } = DateTime.UtcNow;
    }

    public class SpApiService : ISpApiService
    {
        private readonly ISqlConnectionFactory _cf;
        private readonly IHttpClientFactory _httpFactory;
        private readonly IImportOrchestrationService _importOrch;

        // SP-API token endpoint
        private const string TokenUrl = "https://api.amazon.com/auth/o2/token";

        public SpApiService(ISqlConnectionFactory cf, IHttpClientFactory httpFactory, IImportOrchestrationService importOrch)
        {
            _cf = cf; _httpFactory = httpFactory; _importOrch = importOrch;
        }

        // ── Test SP-API connection ────────────────────────────
        public async Task<SPAPIConnectionTestResult> TestConnectionAsync(int sellerAccountId, int userId)
        {
            try
            {
                var creds = await GetCredentialsAsync(sellerAccountId);
                if (creds == null)
                    return new SPAPIConnectionTestResult { Success = false, Message = "No SP-API credentials configured for this account." };

                if (string.IsNullOrEmpty(creds.ClientId) || string.IsNullOrEmpty(creds.ClientSecret) || string.IsNullOrEmpty(creds.RefreshToken))
                    return new SPAPIConnectionTestResult { Success = false, Message = "SP-API credentials are incomplete. Please configure Client ID, Secret, and Refresh Token." };

                var token = await GetAccessTokenAsync(creds.ClientId, creds.ClientSecret, creds.RefreshToken);
                if (token == null)
                    return new SPAPIConnectionTestResult { Success = false, Message = "Failed to obtain access token. Check Client ID, Secret, and Refresh Token." };

                // Call Sellers API to get seller info
                var client = _httpFactory.CreateClient();
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                client.DefaultRequestHeaders.Add("x-amz-access-token", token);

                var endpoint = GetEndpoint(creds.Region);
                var resp = await client.GetAsync($"https://{endpoint}/sellers/v1/marketplaceParticipations");
                if (!resp.IsSuccessStatusCode)
                    return new SPAPIConnectionTestResult { Success = false, Message = $"API returned {(int)resp.StatusCode}: {resp.ReasonPhrase}" };

                var body = await resp.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(body);

                return new SPAPIConnectionTestResult
                {
                    Success = true,
                    Message = "Connection successful.",
                    MarketplaceName = creds.MarketplaceId,
                    SellerId = creds.MerchantToken
                };
            }
            catch (Exception ex)
            {
                return new SPAPIConnectionTestResult { Success = false, Message = ex.Message };
            }
        }

        // ── Run a sync job ────────────────────────────────────
        public async Task<SPAPISyncResult> RunSyncJobAsync(int sellerAccountId, int userId, string jobCode)
        {
            try
            {
                var creds = await GetCredentialsAsync(sellerAccountId);
                if (creds == null) return Fail(jobCode, "No credentials configured.");

                if (string.IsNullOrEmpty(creds.ClientId) || string.IsNullOrEmpty(creds.ClientSecret) || string.IsNullOrEmpty(creds.RefreshToken))
                    return Fail(jobCode, "Incomplete SP-API credentials.");

                var token = await GetAccessTokenAsync(creds.ClientId, creds.ClientSecret, creds.RefreshToken);
                if (token == null) return Fail(jobCode, "Authentication failed.");

                return jobCode switch
                {
                    "INVENTORY" => await SyncInventoryAsync(sellerAccountId, userId, token, creds),
                    "ORDERS"    => await SyncOrdersAsync(sellerAccountId, userId, token, creds),
                    "LISTINGS"  => await SyncListingsAsync(sellerAccountId, userId, token, creds),
                    "REIMBURSEMENTS" => await SyncReimbursementsAsync(sellerAccountId, userId, token, creds),
                    "FBA_FEES"  => await SyncFBAFeesAsync(sellerAccountId, userId, token, creds),
                    _ => Fail(jobCode, $"Unknown job code: {jobCode}")
                };
            }
            catch (Exception ex)
            {
                return Fail(jobCode, ex.Message);
            }
        }

        // ── Sync: Inventory ───────────────────────────────────
        private async Task<SPAPISyncResult> SyncInventoryAsync(int sellerAccountId, int userId, string token, SpApiCredentials creds)
        {
            var client = BuildClient(token);
            var endpoint = GetEndpoint(creds.Region);

            // Request FBA inventory report via Reports API
            var reportReq = new
            {
                reportType = "GET_FBA_MYI_UNSUPPRESSED_INVENTORY_DATA",
                marketplaceIds = new[] { creds.MarketplaceId }
            };

            var postResp = await client.PostAsync(
                $"https://{endpoint}/reports/2021-06-30/reports",
                new StringContent(JsonSerializer.Serialize(reportReq), Encoding.UTF8, "application/json"));

            if (!postResp.IsSuccessStatusCode)
                return Fail("INVENTORY", $"Report request failed: {postResp.StatusCode}");

            var postBody = await postResp.Content.ReadAsStringAsync();
            using var postDoc = JsonDocument.Parse(postBody);
            var reportId = postDoc.RootElement.GetProperty("reportId").GetString();

            // Poll for completion (max 5 minutes)
            string? documentId = null;
            for (int i = 0; i < 30; i++)
            {
                await Task.Delay(10_000);
                var statusResp = await client.GetAsync($"https://{endpoint}/reports/2021-06-30/reports/{reportId}");
                var statusBody = await statusResp.Content.ReadAsStringAsync();
                using var statusDoc = JsonDocument.Parse(statusBody);
                var status = statusDoc.RootElement.GetProperty("processingStatus").GetString();
                if (status == "DONE")
                {
                    documentId = statusDoc.RootElement.GetProperty("reportDocumentId").GetString();
                    break;
                }
                if (status is "FATAL" or "CANCELLED") return Fail("INVENTORY", $"Report processing failed with status: {status}");
            }

            if (documentId == null) return Fail("INVENTORY", "Report did not complete within 5 minutes.");

            // Download report document
            var docResp = await client.GetAsync($"https://{endpoint}/reports/2021-06-30/documents/{documentId}");
            var docBody = await docResp.Content.ReadAsStringAsync();
            using var docDoc = JsonDocument.Parse(docBody);
            var downloadUrl = docDoc.RootElement.GetProperty("url").GetString();

            using var rawClient = _httpFactory.CreateClient();
            var csvBytes = await rawClient.GetByteArrayAsync(downloadUrl);

            // Create import record and process
            using var conn = _cf.Create();
            var importId = await conn.QuerySingleAsync<int>(
                "INSERT INTO dbo.CSVImports (SellerAccountId,UserId,ReportTypeCode,FileName,Status) " +
                "OUTPUT INSERTED.ImportId VALUES (@A,@U,'INVENTORY_SNAPSHOT','SPAPI_Inventory',''PENDING')",
                new { A = sellerAccountId, U = userId });

            using var stream = new System.IO.MemoryStream(csvBytes);
            var result = await _importOrch.ProcessImportAsync(importId, sellerAccountId, userId,
                "INVENTORY_SNAPSHOT", stream, "SPAPI_Inventory.txt");

            return new SPAPISyncResult
            {
                Success = result.Status == "COMPLETE" || result.Status == "PARTIAL",
                JobCode = "INVENTORY",
                RecordsProcessed = result.RowsImported,
                Message = $"Imported {result.RowsImported} inventory records via SP-API."
            };
        }

        // ── Sync: Orders (last 48h via Orders API) ─────────────
        private async Task<SPAPISyncResult> SyncOrdersAsync(int sellerAccountId, int userId, string token, SpApiCredentials creds)
        {
            var client = BuildClient(token);
            var endpoint = GetEndpoint(creds.Region);
            var createdAfter = DateTime.UtcNow.AddHours(-48).ToString("o");

            var resp = await client.GetAsync(
                $"https://{endpoint}/orders/v0/orders?MarketplaceIds={creds.MarketplaceId}&CreatedAfter={createdAfter}&OrderStatuses=Shipped,Unshipped,PartiallyShipped");

            if (!resp.IsSuccessStatusCode) return Fail("ORDERS", $"Orders API returned {resp.StatusCode}");

            var body = await resp.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(body);
            var orders = doc.RootElement.GetProperty("payload").GetProperty("Orders");

            var dt = new DataTable();
            dt.Columns.Add("AmazonOrderId"); dt.Columns.Add("OrderDate", typeof(DateTime));
            dt.Columns.Add("ShipDate", typeof(DateTime)); dt.Columns.Add("FulfillmentChannel");
            dt.Columns.Add("OrderStatus"); dt.Columns.Add("ASIN"); dt.Columns.Add("SKU");
            dt.Columns.Add("QtySold", typeof(int)); dt.Columns.Add("ItemPrice", typeof(decimal));
            dt.Columns.Add("PromotionDiscount", typeof(decimal)); dt.Columns.Add("ShippingPrice", typeof(decimal));
            dt.Columns.Add("Currency");

            int rowCount = 0;
            foreach (var order in orders.EnumerateArray())
            {
                var orderId = order.GetProperty("AmazonOrderId").GetString() ?? "";
                var orderDate = order.TryGetProperty("PurchaseDate", out var pd) ? DateTime.Parse(pd.GetString() ?? "") : DateTime.UtcNow;
                var status = order.GetProperty("OrderStatus").GetString() ?? "Shipped";
                var channel = order.TryGetProperty("FulfillmentChannel", out var fc) ? fc.GetString() ?? "AFN" : "AFN";
                var currency = order.TryGetProperty("OrderTotal", out var ot) &&
                               ot.TryGetProperty("CurrencyCode", out var cc) ? cc.GetString() ?? "USD" : "USD";

                // Get order items
                var itemsResp = await client.GetAsync($"https://{endpoint}/orders/v0/orders/{orderId}/orderItems");
                if (!itemsResp.IsSuccessStatusCode) continue;
                var itemsBody = await itemsResp.Content.ReadAsStringAsync();
                using var itemsDoc = JsonDocument.Parse(itemsBody);
                var items = itemsDoc.RootElement.GetProperty("payload").GetProperty("OrderItems");

                foreach (var item in items.EnumerateArray())
                {
                    var asin = item.TryGetProperty("ASIN", out var a) ? a.GetString() ?? "" : "";
                    var sku  = item.TryGetProperty("SellerSKU", out var s) ? s.GetString() ?? "" : "";
                    var qty  = item.TryGetProperty("QuantityShipped", out var q) ? q.GetInt32() : 1;
                    decimal price = 0, disc = 0, ship = 0;
                    if (item.TryGetProperty("ItemPrice", out var ip) && ip.TryGetProperty("Amount", out var ipa))
                        decimal.TryParse(ipa.GetString(), out price);
                    if (item.TryGetProperty("PromotionDiscount", out var promo) && promo.TryGetProperty("Amount", out var pa))
                        decimal.TryParse(pa.GetString(), out disc);
                    if (item.TryGetProperty("ShippingPrice", out var sp) && sp.TryGetProperty("Amount", out var spa))
                        decimal.TryParse(spa.GetString(), out ship);

                    dt.Rows.Add(orderId, orderDate, DBNull.Value, channel, status, asin, sku, qty, price, disc, ship, currency);
                    rowCount++;
                }
            }

            using var conn = _cf.Create();
            var importId = await conn.QuerySingleAsync<int>(
                "INSERT INTO dbo.CSVImports (SellerAccountId,UserId,ReportTypeCode,FileName,RowsTotal,Status) " +
                "OUTPUT INSERTED.ImportId VALUES (@A,@U,'ORDER_REPORT','SPAPI_Orders',@R,'PENDING')",
                new { A = sellerAccountId, U = userId, R = rowCount });

            var p = new DynamicParameters();
            p.Add("SellerAccountId", sellerAccountId); p.Add("UserId", userId); p.Add("ImportId", importId);
            p.Add("DataTable", dt.AsTableValuedParameter("dbo.TVP_SalesOrder"));
            var res = await conn.QueryFirstAsync(StoredProcedures.Import_SalesOrders, p, commandType: CommandType.StoredProcedure);

            return new SPAPISyncResult { Success = true, JobCode = "ORDERS", RecordsProcessed = rowCount,
                Message = $"Synced {rowCount} order items from last 48 hours." };
        }

        // ── Sync: Listings (BSR, Buy Box, listing status) ─────
        private async Task<SPAPISyncResult> SyncListingsAsync(int sellerAccountId, int userId, string token, SpApiCredentials creds)
        {
            var client = BuildClient(token);
            var endpoint = GetEndpoint(creds.Region);

            using var conn = _cf.Create();
            var skus = await conn.QueryAsync<string>(
                "SELECT TOP 100 SKU FROM dbo.Products WHERE SellerAccountId=@A AND IsActive=1",
                new { A = sellerAccountId });

            int processed = 0;
            foreach (var sku in skus)
            {
                try
                {
                    var resp = await client.GetAsync(
                        $"https://{endpoint}/listings/2021-08-01/items/{creds.MerchantToken}/{Uri.EscapeDataString(sku)}?marketplaceIds={creds.MarketplaceId}&includedData=summaries,attributes,issues");
                    if (!resp.IsSuccessStatusCode) continue;

                    var body = await resp.Content.ReadAsStringAsync();
                    using var doc = JsonDocument.Parse(body);

                    var status = "ACTIVE";
                    if (doc.RootElement.TryGetProperty("issues", out var issues) && issues.GetArrayLength() > 0)
                        status = "SUPPRESSED";

                    await conn.ExecuteAsync(
                        "MERGE dbo.Listings AS t USING (SELECT @ProductId AS ProductId, @AccountId AS SellerAccountId) AS s " +
                        "ON t.ProductId=s.ProductId AND t.SellerAccountId=s.SellerAccountId AND t.SnapshotDate=CAST(SYSUTCDATETIME() AS DATE) " +
                        "WHEN MATCHED THEN UPDATE SET t.ListingStatus=@Status " +
                        "WHEN NOT MATCHED THEN INSERT (ProductId,SellerAccountId,ListingStatus,SnapshotDate) VALUES (@ProductId,@AccountId,@Status,CAST(SYSUTCDATETIME() AS DATE));",
                        new { ProductId = await GetProductIdAsync(conn, sku, sellerAccountId), AccountId = sellerAccountId, Status = status });
                    processed++;
                }
                catch { /* skip individual SKU errors */ }
            }

            return new SPAPISyncResult { Success = true, JobCode = "LISTINGS",
                RecordsProcessed = processed, Message = $"Synced listing status for {processed} SKUs." };
        }

        // ── Sync: Reimbursements ──────────────────────────────
        private async Task<SPAPISyncResult> SyncReimbursementsAsync(int sellerAccountId, int userId, string token, SpApiCredentials creds)
        {
            // Request reimbursements report
            var client = BuildClient(token);
            var endpoint = GetEndpoint(creds.Region);
            var dateFrom = DateTime.UtcNow.AddDays(-30).ToString("yyyy-MM-dd");
            var dateTo   = DateTime.UtcNow.ToString("yyyy-MM-dd");

            var reportReq = new
            {
                reportType = "GET_FBA_REIMBURSEMENTS_DATA",
                dataStartTime = dateFrom,
                dataEndTime   = dateTo,
                marketplaceIds = new[] { creds.MarketplaceId }
            };

            var postResp = await client.PostAsync(
                $"https://{endpoint}/reports/2021-06-30/reports",
                new StringContent(JsonSerializer.Serialize(reportReq), Encoding.UTF8, "application/json"));
            if (!postResp.IsSuccessStatusCode) return Fail("REIMBURSEMENTS", "Report request failed.");

            var body = await postResp.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(body);
            var reportId = doc.RootElement.GetProperty("reportId").GetString();

            // Poll
            string? documentId = null;
            for (int i = 0; i < 20; i++)
            {
                await Task.Delay(15_000);
                var sResp = await client.GetAsync($"https://{endpoint}/reports/2021-06-30/reports/{reportId}");
                var sBody = await sResp.Content.ReadAsStringAsync();
                using var sDoc = JsonDocument.Parse(sBody);
                var s = sDoc.RootElement.GetProperty("processingStatus").GetString();
                if (s == "DONE") { documentId = sDoc.RootElement.GetProperty("reportDocumentId").GetString(); break; }
                if (s is "FATAL" or "CANCELLED") return Fail("REIMBURSEMENTS", $"Report failed: {s}");
            }
            if (documentId == null) return Fail("REIMBURSEMENTS", "Timeout waiting for report.");

            var dResp = await client.GetAsync($"https://{endpoint}/reports/2021-06-30/documents/{documentId}");
            var dBody = await dResp.Content.ReadAsStringAsync();
            using var dDoc = JsonDocument.Parse(dBody);
            var url = dDoc.RootElement.GetProperty("url").GetString()!;

            using var rawClient = _httpFactory.CreateClient();
            var csvBytes = await rawClient.GetByteArrayAsync(url);

            using var conn = _cf.Create();
            var importId = await conn.QuerySingleAsync<int>(
                "INSERT INTO dbo.CSVImports (SellerAccountId,UserId,ReportTypeCode,FileName,Status) " +
                "OUTPUT INSERTED.ImportId VALUES (@A,@U,'REIMBURSEMENTS','SPAPI_Reimb','PENDING')",
                new { A = sellerAccountId, U = userId });

            using var stream = new System.IO.MemoryStream(csvBytes);
            var result = await _importOrch.ProcessImportAsync(importId, sellerAccountId, userId,
                "REIMBURSEMENTS", stream, "SPAPI_Reimbursements.txt");

            return new SPAPISyncResult { Success = true, JobCode = "REIMBURSEMENTS",
                RecordsProcessed = result.RowsImported, Message = $"Synced {result.RowsImported} reimbursement records." };
        }

        // ── Sync: FBA Fee Estimates ───────────────────────────
        private async Task<SPAPISyncResult> SyncFBAFeesAsync(int sellerAccountId, int userId, string token, SpApiCredentials creds)
        {
            var client = BuildClient(token);
            var endpoint = GetEndpoint(creds.Region);
            using var conn = _cf.Create();

            var products = await conn.QueryAsync(
                "SELECT TOP 50 p.ProductId, p.ASIN, " +
                "(SELECT TOP 1 l.BuyBoxPrice FROM dbo.Listings l WHERE l.ProductId=p.ProductId ORDER BY l.SnapshotDate DESC) AS Price " +
                "FROM dbo.Products p WHERE p.SellerAccountId=@A AND p.IsActive=1",
                new { A = sellerAccountId });

            int processed = 0;
            foreach (var p in products)
            {
                if (p.ASIN == null || p.Price == null) continue;
                try
                {
                    var feesResp = await client.GetAsync(
                        $"https://{endpoint}/products/fees/v0/items/{p.ASIN}/feesEstimate?" +
                        $"MarketplaceId={creds.MarketplaceId}&IsAmazonFulfilled=true&PriceToEstimateFees={p.Price}&Identifier={p.ASIN}");
                    if (!feesResp.IsSuccessStatusCode) continue;

                    var feesBody = await feesResp.Content.ReadAsStringAsync();
                    using var doc = JsonDocument.Parse(feesBody);

                    if (doc.RootElement.TryGetProperty("payload", out var payload) &&
                        payload.TryGetProperty("FeesEstimateResult", out var result) &&
                        result.TryGetProperty("FeesEstimate", out var estimate) &&
                        estimate.TryGetProperty("FeeDetailList", out var feeList))
                    {
                        foreach (var fee in feeList.EnumerateArray())
                        {
                            var feeType = fee.TryGetProperty("FeeType", out var ft) ? ft.GetString() : "UNKNOWN";
                            decimal feeAmt = 0;
                            if (fee.TryGetProperty("FeeAmount", out var fa) &&
                                fa.TryGetProperty("Amount", out var faa))
                                decimal.TryParse(faa.GetString(), out feeAmt);

                            await conn.ExecuteAsync(
                                "INSERT INTO dbo.FBAFees (ProductId,SellerAccountId,FeeDate,FeeTypeCode,FeeAmount,ASIN) " +
                                "SELECT TOP 1 @ProductId,@AccountId,CAST(SYSUTCDATETIME() AS DATE),@FeeType,@Amount,@ASIN " +
                                "WHERE NOT EXISTS (SELECT 1 FROM dbo.FBAFees WHERE ProductId=@ProductId AND FeeDate=CAST(SYSUTCDATETIME() AS DATE) AND FeeTypeCode=@FeeType)",
                                new { ProductId = (int)p.ProductId, AccountId = sellerAccountId,
                                      FeeType = feeType, Amount = feeAmt, ASIN = (string)p.ASIN });
                        }
                    }
                    processed++;
                }
                catch { /* skip per-ASIN errors */ }
            }
            return new SPAPISyncResult { Success = true, JobCode = "FBA_FEES",
                RecordsProcessed = processed, Message = $"Synced FBA fee estimates for {processed} ASINs." };
        }

        // ── Helpers ───────────────────────────────────────────
        private async Task<string?> GetAccessTokenAsync(string clientId, string clientSecret, string refreshToken)
        {
            using var client = _httpFactory.CreateClient();
            var body = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["grant_type"]    = "refresh_token",
                ["refresh_token"] = refreshToken,
                ["client_id"]     = clientId,
                ["client_secret"] = clientSecret
            });
            var resp = await client.PostAsync(TokenUrl, body);
            if (!resp.IsSuccessStatusCode) return null;
            var json = await resp.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            return doc.RootElement.TryGetProperty("access_token", out var at) ? at.GetString() : null;
        }

        private async Task<SpApiCredentials?> GetCredentialsAsync(int sellerAccountId)
        {
            using var conn = _cf.Create();
            var row = await conn.QueryFirstOrDefaultAsync(
                "SELECT MarketplaceId, MerchantToken, SPAPIClientId, SPAPIClientSecret_Enc, RefreshToken_Enc, Region " +
                "FROM dbo.SellerAccounts WHERE SellerAccountId=@Id AND IsActive=1", new { Id = sellerAccountId });
            if (row == null) return null;

            string? secret = null, refreshToken = null;
            try
            {
                if (row.SPAPIClientSecret_Enc != null) secret = DecryptValue((byte[])row.SPAPIClientSecret_Enc);
                if (row.RefreshToken_Enc != null) refreshToken = DecryptValue((byte[])row.RefreshToken_Enc);
            }
            catch { return null; }

            return new SpApiCredentials
            {
                MarketplaceId = row.MarketplaceId, MerchantToken = row.MerchantToken,
                ClientId = row.SPAPIClientId, ClientSecret = secret,
                RefreshToken = refreshToken, Region = row.Region
            };
        }

        private static string DecryptValue(byte[] encrypted)
        {
            var key = Encoding.UTF8.GetBytes("FBAManager-AES256-Key-32CharsPad!");
            using var aes = Aes.Create();
            aes.Key = key[..32];
            var iv = encrypted[..16];
            var data = encrypted[16..];
            aes.IV = iv;
            using var dec = aes.CreateDecryptor();
            return Encoding.UTF8.GetString(dec.TransformFinalBlock(data, 0, data.Length));
        }

        private static string GetEndpoint(string region) => region switch
        {
            "EU" => "sellingpartnerapi-eu.amazon.com",
            "FE" => "sellingpartnerapi-fe.amazon.com",
            _    => "sellingpartnerapi-na.amazon.com"
        };

        private HttpClient BuildClient(string token)
        {
            var client = _httpFactory.CreateClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            client.DefaultRequestHeaders.Add("x-amz-access-token", token);
            client.DefaultRequestHeaders.UserAgent.ParseAdd("FBAManager/1.0");
            return client;
        }

        private static async Task<int?> GetProductIdAsync(IDbConnection conn, string sku, int accountId)
        {
            return await conn.QueryFirstOrDefaultAsync<int?>(
                "SELECT ProductId FROM dbo.Products WHERE SKU=@SKU AND SellerAccountId=@A", new { SKU = sku, A = accountId });
        }

        private static SPAPISyncResult Fail(string job, string msg) =>
            new() { Success = false, JobCode = job, Message = msg };

        private class SpApiCredentials
        {
            public string MarketplaceId { get; set; } = "";
            public string? MerchantToken { get; set; }
            public string? ClientId { get; set; }
            public string? ClientSecret { get; set; }
            public string? RefreshToken { get; set; }
            public string Region { get; set; } = "NA";
        }
    }
}
