// ============================================================
// AmazonFBAManager.Data/Services/ImportOrchestrationService.cs
// Coordinates: CSV parse → DataTable → TVP → SP → SignalR push
// This is the only place that knows about all import report types
// ============================================================
using AmazonFBAManager.Data.Connections;
using AmazonFBAManager.Shared.Constants;
using AmazonFBAManager.Shared.DTOs;
using Dapper;
using System;
using System.Data;
using System.IO;
using System.Threading.Tasks;

namespace AmazonFBAManager.Data.Services
{
    public interface IImportOrchestrationService
    {
        Task<ImportResultDto> ProcessImportAsync(
            int importId, int sellerAccountId, int userId,
            string reportTypeCode, Stream fileStream, string fileName,
            IProgress<string>? progress = null);
    }

    public class ImportOrchestrationService : IImportOrchestrationService
    {
        private readonly ISqlConnectionFactory _cf;
        private readonly ICsvParsingService _csvParser;

        public ImportOrchestrationService(ISqlConnectionFactory cf, ICsvParsingService csvParser)
        {
            _cf = cf;
            _csvParser = csvParser;
        }

        public async Task<ImportResultDto> ProcessImportAsync(
            int importId, int sellerAccountId, int userId,
            string reportTypeCode, Stream fileStream, string fileName,
            IProgress<string>? progress = null)
        {
            progress?.Report("Parsing file...");

            // Step 1: Parse CSV to DataTable
            var (dataTable, rowCount, parseErrors) = await _csvParser.ParseAsync(fileStream, reportTypeCode, fileName);

            // Update total rows count
            using (var conn = _cf.Create())
            {
                await conn.ExecuteAsync(
                    "UPDATE dbo.CSVImports SET RowsTotal = @RowsTotal WHERE ImportId = @ImportId",
                    new { RowsTotal = rowCount, ImportId = importId });
            }

            if (rowCount == 0)
            {
                await MarkFailed(importId, "File parsed successfully but contained 0 valid data rows. Check report type selection.");
                return new ImportResultDto { ImportId = importId, Status = ImportStatuses.Failed, ErrorLog = "No data rows found." };
            }

            progress?.Report($"Parsed {rowCount} rows. Importing to database...");

            // Step 2: Route to appropriate SP with TVP
            try
            {
                ImportResultDto result = reportTypeCode switch
                {
                    ReportTypes.InventorySnapshot => await RunInventorySnapshotAsync(importId, sellerAccountId, userId, dataTable),
                    ReportTypes.SalesOrders => await RunSalesOrdersAsync(importId, sellerAccountId, userId, dataTable),
                    ReportTypes.Reimbursements => await RunReimbursementsAsync(importId, sellerAccountId, userId, dataTable),
                    ReportTypes.InventoryAdjustments => await RunInventoryAdjustmentsAsync(importId, sellerAccountId, userId, dataTable),
                    ReportTypes.CustomerReturns => await RunReturnsAsync(importId, sellerAccountId, userId, dataTable),
                    ReportTypes.PPCSearchTerm => await RunPPCKeywordsAsync(importId, sellerAccountId, userId, dataTable),
                    ReportTypes.InboundShipments => await RunInboundShipmentsAsync(importId, sellerAccountId, userId, dataTable),
                    _ => throw new NotSupportedException($"No import SP handler for report type: {reportTypeCode}")
                };

                progress?.Report($"Import complete. {result.RowsImported} rows imported.");

                // Append any parse-level errors to error log
                if (parseErrors.Count > 0)
                {
                    var errSummary = $"Parse warnings ({parseErrors.Count}): " + string.Join("; ", parseErrors.GetRange(0, Math.Min(parseErrors.Count, 10)));
                    using var conn = _cf.Create();
                    await conn.ExecuteAsync(
                        "UPDATE dbo.CSVImports SET ErrorLog = COALESCE(ErrorLog + CHAR(10), '') + @Errs WHERE ImportId = @ImportId",
                        new { Errs = errSummary, ImportId = importId });
                }

                return result;
            }
            catch (Exception ex)
            {
                var errMsg = ex.Message;
                await MarkFailed(importId, errMsg);
                return new ImportResultDto { ImportId = importId, Status = ImportStatuses.Failed, ErrorLog = errMsg };
            }
        }

        // ---- SP ROUTING ----
        private async Task<ImportResultDto> RunInventorySnapshotAsync(int importId, int sellerAccountId, int userId, DataTable dt)
        {
            using var conn = _cf.Create();
            var p = new DynamicParameters();
            p.Add("SellerAccountId", sellerAccountId);
            p.Add("UserId", userId);
            p.Add("ImportId", importId);
            p.Add("DataTable", dt.AsTableValuedParameter("dbo.TVP_InventorySnapshot"));
            return await conn.QueryFirstAsync<ImportResultDto>(
                StoredProcedures.Import_InventorySnapshot, p, commandType: CommandType.StoredProcedure);
        }

        private async Task<ImportResultDto> RunSalesOrdersAsync(int importId, int sellerAccountId, int userId, DataTable dt)
        {
            using var conn = _cf.Create();
            var p = new DynamicParameters();
            p.Add("SellerAccountId", sellerAccountId);
            p.Add("UserId", userId);
            p.Add("ImportId", importId);
            p.Add("DataTable", dt.AsTableValuedParameter("dbo.TVP_SalesOrder"));
            return await conn.QueryFirstAsync<ImportResultDto>(
                StoredProcedures.Import_SalesOrders, p, commandType: CommandType.StoredProcedure);
        }

        private async Task<ImportResultDto> RunReimbursementsAsync(int importId, int sellerAccountId, int userId, DataTable dt)
        {
            using var conn = _cf.Create();
            var p = new DynamicParameters();
            p.Add("SellerAccountId", sellerAccountId);
            p.Add("UserId", userId);
            p.Add("ImportId", importId);
            p.Add("DataTable", dt.AsTableValuedParameter("dbo.TVP_Reimbursement"));
            return await conn.QueryFirstAsync<ImportResultDto>(
                StoredProcedures.Import_Reimbursements, p, commandType: CommandType.StoredProcedure);
        }

        private async Task<ImportResultDto> RunInventoryAdjustmentsAsync(int importId, int sellerAccountId, int userId, DataTable dt)
        {
            using var conn = _cf.Create();
            var p = new DynamicParameters();
            p.Add("SellerAccountId", sellerAccountId);
            p.Add("UserId", userId);
            p.Add("ImportId", importId);
            p.Add("DataTable", dt.AsTableValuedParameter("dbo.TVP_InventoryAdjustment"));
            return await conn.QueryFirstAsync<ImportResultDto>(
                StoredProcedures.Import_Adjustments, p, commandType: CommandType.StoredProcedure);
        }

        private async Task<ImportResultDto> RunReturnsAsync(int importId, int sellerAccountId, int userId, DataTable dt)
        {
            using var conn = _cf.Create();
            var p = new DynamicParameters();
            p.Add("SellerAccountId", sellerAccountId);
            p.Add("UserId", userId);
            p.Add("ImportId", importId);
            p.Add("DataTable", dt.AsTableValuedParameter("dbo.TVP_Return"));
            return await conn.QueryFirstAsync<ImportResultDto>(
                StoredProcedures.Import_Returns, p, commandType: CommandType.StoredProcedure);
        }

        private async Task<ImportResultDto> RunPPCKeywordsAsync(int importId, int sellerAccountId, int userId, DataTable dt)
        {
            using var conn = _cf.Create();
            var p = new DynamicParameters();
            p.Add("SellerAccountId", sellerAccountId);
            p.Add("UserId", userId);
            p.Add("ImportId", importId);
            p.Add("DataTable", dt.AsTableValuedParameter("dbo.TVP_PPCKeyword"));
            return await conn.QueryFirstAsync<ImportResultDto>(
                StoredProcedures.Import_PPCKeywords, p, commandType: CommandType.StoredProcedure);
        }

        private async Task<ImportResultDto> RunInboundShipmentsAsync(int importId, int sellerAccountId, int userId, DataTable dt)
        {
            using var conn = _cf.Create();
            var p = new DynamicParameters();
            p.Add("SellerAccountId", sellerAccountId);
            p.Add("UserId", userId);
            p.Add("ImportId", importId);
            p.Add("DataTable", dt.AsTableValuedParameter("dbo.TVP_InboundShipment"));
            return await conn.QueryFirstAsync<ImportResultDto>(
                StoredProcedures.Import_InboundShipments, p, commandType: CommandType.StoredProcedure);
        }

        private async Task MarkFailed(int importId, string errorMessage)
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                "UPDATE dbo.CSVImports SET Status = 'FAILED', ErrorLog = @Err, ProcessingCompleted = SYSUTCDATETIME() WHERE ImportId = @ImportId",
                new { Err = errorMessage, ImportId = importId });
        }
    }
}
