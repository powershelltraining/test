// ============================================================
// AmazonFBAManager.Data/Services/ExportService.ClosedXML.cs
// Real Excel generation using ClosedXML
// Replace BuildSimpleExcel stub in ExportService.cs with this
// ============================================================
using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace AmazonFBAManager.Data.Services
{
    /// <summary>
    /// Drop-in replacement for BuildSimpleExcel using ClosedXML.
    /// Produces a properly formatted .xlsx with header row styling,
    /// column auto-width, and number formatting.
    /// </summary>
    public static class ExcelBuilder
    {
        public static byte[] Build(string sheetName, string[] headers, IEnumerable<object[]> rows)
        {
            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add(sheetName.Length > 31 ? sheetName[..31] : sheetName);

            // ── Header row ────────────────────────────────────
            for (int c = 0; c < headers.Length; c++)
            {
                var cell = ws.Cell(1, c + 1);
                cell.Value = headers[c];
                cell.Style.Font.Bold = true;
                cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#1F6FEB");
                cell.Style.Font.FontColor = XLColor.White;
                cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                cell.Style.Border.BottomBorder = XLBorderStyleValues.Thin;
            }

            // ── Data rows ─────────────────────────────────────
            int rowIdx = 2;
            foreach (var row in rows)
            {
                for (int c = 0; c < row.Length && c < headers.Length; c++)
                {
                    var cell = ws.Cell(rowIdx, c + 1);
                    var val = row[c];

                    switch (val)
                    {
                        case decimal d:
                            cell.Value = (double)d;
                            // Currency format for columns that look like money
                            var header = headers[c].ToLower();
                            if (header.Contains("$") || header.Contains("usd") ||
                                header.Contains("profit") || header.Contains("fee") ||
                                header.Contains("revenue") || header.Contains("cost") ||
                                header.Contains("amount") || header.Contains("reimb"))
                                cell.Style.NumberFormat.Format = "$#,##0.00";
                            else if (header.Contains("%") || header.Contains("margin") || header.Contains("rate"))
                                cell.Style.NumberFormat.Format = "0.00\"%\"";
                            else
                                cell.Style.NumberFormat.Format = "#,##0.00";
                            break;
                        case int i:
                            cell.Value = i;
                            cell.Style.NumberFormat.Format = "#,##0";
                            break;
                        case long l:
                            cell.Value = l;
                            cell.Style.NumberFormat.Format = "#,##0";
                            break;
                        case double dbl:
                            cell.Value = dbl;
                            cell.Style.NumberFormat.Format = "#,##0.00";
                            break;
                        case DateTime dt:
                            cell.Value = dt;
                            cell.Style.NumberFormat.Format = "yyyy-MM-dd";
                            break;
                        case bool b:
                            cell.Value = b ? "Yes" : "No";
                            break;
                        case null:
                            cell.Value = "";
                            break;
                        default:
                            cell.Value = val.ToString();
                            break;
                    }

                    // Alternating row color
                    if (rowIdx % 2 == 0)
                        cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#F8F9FA");
                }
                rowIdx++;
            }

            // ── Totals row for numeric columns ────────────────
            if (rowIdx > 3)
            {
                for (int c = 0; c < headers.Length; c++)
                {
                    var colLetter = ws.Cell(1, c + 1).Address.ColumnLetter;
                    var firstDataRow = 2;
                    var lastDataRow = rowIdx - 1;

                    // Check if column is numeric by sampling first data cell
                    var sampleCell = ws.Cell(2, c + 1);
                    if (sampleCell.Value.IsNumber)
                    {
                        var totCell = ws.Cell(rowIdx, c + 1);
                        totCell.FormulaA1 = $"=SUM({colLetter}{firstDataRow}:{colLetter}{lastDataRow})";
                        totCell.Style.Font.Bold = true;
                        totCell.Style.Fill.BackgroundColor = XLColor.FromHtml("#E8F0FE");
                        totCell.Style.Border.TopBorder = XLBorderStyleValues.Medium;
                        totCell.Style.NumberFormat.Format = sampleCell.Style.NumberFormat.Format;
                    }
                    else if (c == 0)
                    {
                        var totLabel = ws.Cell(rowIdx, 1);
                        totLabel.Value = "TOTAL";
                        totLabel.Style.Font.Bold = true;
                        totLabel.Style.Fill.BackgroundColor = XLColor.FromHtml("#E8F0FE");
                        totLabel.Style.Border.TopBorder = XLBorderStyleValues.Medium;
                    }
                }
            }

            // ── Freeze header row ─────────────────────────────
            ws.SheetView.FreezeRows(1);

            // ── Auto-fit columns (capped at 60) ───────────────
            ws.Columns().AdjustToContents(8, 60);

            // ── Sheet metadata ────────────────────────────────
            wb.Properties.Author = "FBA Manager";
            wb.Properties.Title = sheetName;
            wb.Properties.Created = DateTime.UtcNow;

            using var ms = new MemoryStream();
            wb.SaveAs(ms);
            return ms.ToArray();
        }

        /// <summary>
        /// Build a multi-sheet workbook (e.g. P&L + Charts on separate sheets)
        /// </summary>
        public static byte[] BuildMultiSheet(IEnumerable<(string SheetName, string[] Headers, IEnumerable<object[]> Rows)> sheets)
        {
            using var wb = new XLWorkbook();
            foreach (var (sheetName, headers, rows) in sheets)
            {
                var ws = wb.Worksheets.Add(sheetName.Length > 31 ? sheetName[..31] : sheetName);
                // Re-use single-sheet logic by creating a temp wb
                var tempBytes = Build(sheetName, headers, rows);
                using var tempMs = new MemoryStream(tempBytes);
                var tempWb = new XLWorkbook(tempMs);
                // Copy rows from temp to target ws
                var tempWs = tempWb.Worksheets.First();
                var lastRow = tempWs.LastRowUsed()?.RowNumber() ?? 1;
                var lastCol = tempWs.LastColumnUsed()?.ColumnNumber() ?? 1;
                for (int r = 1; r <= lastRow; r++)
                    for (int c = 1; c <= lastCol; c++)
                    {
                        var src = tempWs.Cell(r, c);
                        var tgt = ws.Cell(r, c);
                        tgt.Value = src.Value;
                        tgt.Style = src.Style;
                    }
                ws.SheetView.FreezeRows(1);
                ws.Columns().AdjustToContents(8, 60);
            }
            using var ms = new MemoryStream();
            wb.SaveAs(ms);
            return ms.ToArray();
        }
    }
}
