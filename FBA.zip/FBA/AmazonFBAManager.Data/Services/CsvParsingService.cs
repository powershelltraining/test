// AmazonFBAManager.Data/Services/CsvParsingService.cs
using AmazonFBAManager.Shared.Constants;
using CsvHelper;
using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;

namespace AmazonFBAManager.Data.Services
{
    public interface ICsvParsingService
    {
        Task<(DataTable Data, int RowCount, List<string> Errors)> ParseAsync(
            Stream fileStream, string reportTypeCode, string fileName);
    }

    public class CsvParsingService : ICsvParsingService
    {
        public async Task<(DataTable Data, int RowCount, List<string> Errors)> ParseAsync(
            Stream fileStream, string reportTypeCode, string fileName)
        {
            var errors = new List<string>();
            var delimiter = fileName.EndsWith(".txt") || fileName.EndsWith(".tsv") ? "\t" : ",";

            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                Delimiter = delimiter,
                HasHeaderRecord = true,
                MissingFieldFound = null,
                BadDataFound = ctx => errors.Add($"Row {ctx.Context.Parser?.Row}: {ctx.RawRecord}"),
                PrepareHeaderForMatch = args => args.Header.Trim().ToLowerInvariant()
                    .Replace(" ", "_").Replace("-", "_").Replace("/", "_")
            };

            using var reader = new StreamReader(fileStream);
            using var csv = new CsvReader(reader, config);

            DataTable dt = reportTypeCode switch
            {
                ReportTypes.InventorySnapshot    => await ParseInventorySnapshotAsync(csv, errors),
                ReportTypes.SalesOrders          => await ParseSalesOrdersAsync(csv, errors),
                ReportTypes.Reimbursements       => await ParseReimbursementsAsync(csv, errors),
                ReportTypes.InventoryAdjustments => await ParseInventoryAdjustmentsAsync(csv, errors),
                ReportTypes.CustomerReturns      => await ParseReturnsAsync(csv, errors),
                ReportTypes.PPCSearchTerm        => await ParsePPCKeywordsAsync(csv, errors),
                ReportTypes.InboundShipments     => await ParseInboundShipmentsAsync(csv, errors),
                _ => throw new NotSupportedException($"Report type '{reportTypeCode}' not supported.")
            };

            return (dt, dt.Rows.Count, errors);
        }

        // ── Inventory Snapshot ───────────────────────────────
        private async Task<DataTable> ParseInventorySnapshotAsync(CsvReader csv, List<string> errors)
        {
            var dt = MakeTable(("ASIN",typeof(string)),("SKU",typeof(string)),("FNSKU",typeof(string)),
                ("QtyFBA",typeof(int)),("QtyFBM",typeof(int)),("QtyInbound",typeof(int)),
                ("QtyReserved",typeof(int)),("QtyUnfulfillable",typeof(int)),("QtyWarehouseAWD",typeof(int)),
                ("EstStorageCost",typeof(decimal)),("SnapshotDate",typeof(DateTime)));

            await csv.ReadAsync(); csv.ReadHeader();
            var today = DateTime.UtcNow.Date;
            int row = 0;
            while (await csv.ReadAsync())
            {
                row++;
                try { dt.Rows.Add(Get(csv,"asin"),Get(csv,"seller_sku","sku"),Get(csv,"fnsku"),
                    Int(csv,"afn_fulfillable_quantity"),Int(csv,"mfn_fulfillable_quantity"),
                    Int(csv,"afn_inbound_shipped_quantity")+Int(csv,"afn_inbound_receiving_quantity"),
                    Int(csv,"afn_reserved_quantity"),Int(csv,"afn_unsellable_quantity"),
                    Int(csv,"awd_quantity"),Dec(csv,"per_unit_volume"),today); }
                catch (Exception ex) { errors.Add($"Row {row}: {ex.Message}"); }
            }
            return dt;
        }

        // ── Sales Orders ─────────────────────────────────────
        private async Task<DataTable> ParseSalesOrdersAsync(CsvReader csv, List<string> errors)
        {
            var dt = MakeTable(("AmazonOrderId",typeof(string)),("OrderDate",typeof(DateTime)),
                ("ShipDate",typeof(DateTime)),("FulfillmentChannel",typeof(string)),
                ("OrderStatus",typeof(string)),("ASIN",typeof(string)),("SKU",typeof(string)),
                ("QtySold",typeof(int)),("ItemPrice",typeof(decimal)),
                ("PromotionDiscount",typeof(decimal)),("ShippingPrice",typeof(decimal)),
                ("Currency",typeof(string)));

            await csv.ReadAsync(); csv.ReadHeader();
            int row = 0;
            while (await csv.ReadAsync())
            {
                row++;
                try
                {
                    var orderId = Get(csv,"amazon_order_id","order_id");
                    if (string.IsNullOrWhiteSpace(orderId)) continue;
                    dt.Rows.Add(orderId,
                        Dt(csv,"purchase_date","order_date") ?? DateTime.UtcNow,
                        Dt(csv,"last_updated_date"),
                        Get(csv,"fulfillment_channel") ?? "AFN",
                        Get(csv,"order_status") ?? "Shipped",
                        Get(csv,"asin"),Get(csv,"sku"),
                        Int(csv,"quantity_shipped",1),Dec(csv,"item_price"),
                        Dec(csv,"item_promotion_discount"),Dec(csv,"shipping_price"),
                        Get(csv,"currency") ?? "USD");
                }
                catch (Exception ex) { errors.Add($"Row {row}: {ex.Message}"); }
            }
            return dt;
        }

        // ── Reimbursements ───────────────────────────────────
        private async Task<DataTable> ParseReimbursementsAsync(CsvReader csv, List<string> errors)
        {
            var dt = MakeTable(("AmazonReimbId",typeof(string)),("ReimbDate",typeof(DateTime)),
                ("ASIN",typeof(string)),("SKU",typeof(string)),("QtyReimbursed",typeof(int)),
                ("AmountPerUnit",typeof(decimal)),("TotalAmount",typeof(decimal)),("ReimbType",typeof(string)));

            await csv.ReadAsync(); csv.ReadHeader();
            int row = 0;
            while (await csv.ReadAsync())
            {
                row++;
                try
                {
                    var id = Get(csv,"reimbursement_id");
                    if (string.IsNullOrWhiteSpace(id)) continue;
                    var qty = Int(csv,"quantity_reimbursed_cash") + Int(csv,"quantity_reimbursed_inventory");
                    var total = Dec(csv,"amount_total");
                    dt.Rows.Add(id,Dt(csv,"approval_date")??DateTime.UtcNow,
                        Get(csv,"asin"),Get(csv,"sku"),
                        qty, qty>0?total/qty:0, total,
                        Get(csv,"reason")??"UNKNOWN");
                }
                catch (Exception ex) { errors.Add($"Row {row}: {ex.Message}"); }
            }
            return dt;
        }

        // ── Inventory Adjustments ────────────────────────────
        private async Task<DataTable> ParseInventoryAdjustmentsAsync(CsvReader csv, List<string> errors)
        {
            var dt = MakeTable(("ASIN",typeof(string)),("SKU",typeof(string)),
                ("AdjDate",typeof(DateTime)),("AdjReasonCode",typeof(string)),
                ("QtyAdjusted",typeof(int)),("DispositionCode",typeof(string)),
                ("FulfillmentCenterId",typeof(string)),("TransactionItemId",typeof(string)));

            await csv.ReadAsync(); csv.ReadHeader();
            int row = 0;
            while (await csv.ReadAsync())
            {
                row++;
                try { dt.Rows.Add(Get(csv,"asin"),Get(csv,"sku","fnsku"),
                    Dt(csv,"date","adjusted_date")??DateTime.UtcNow,
                    (Get(csv,"reason")??"REVERSAL").ToUpper(),
                    Int(csv,"quantity"),Get(csv,"disposition"),
                    Get(csv,"fulfillment_center_id","fulfillment_center"),
                    Get(csv,"transaction_item_id","reference_id")); }
                catch (Exception ex) { errors.Add($"Row {row}: {ex.Message}"); }
            }
            return dt;
        }

        // ── Customer Returns ─────────────────────────────────
        private async Task<DataTable> ParseReturnsAsync(CsvReader csv, List<string> errors)
        {
            var dt = MakeTable(("AmazonOrderId",typeof(string)),("ASIN",typeof(string)),("SKU",typeof(string)),
                ("ReturnDate",typeof(DateTime)),("CustomerRefundDate",typeof(DateTime)),
                ("ReturnReceivedDate",typeof(DateTime)),("ReturnStatus",typeof(string)),
                ("ReturnReasonCode",typeof(string)),("Qty",typeof(int)),("RefundAmount",typeof(decimal)),
                ("ReturnlessRefund",typeof(bool)),("DispositionCode",typeof(string)),
                ("FulfillmentCenterId",typeof(string)));

            await csv.ReadAsync(); csv.ReadHeader();
            int row = 0;
            while (await csv.ReadAsync())
            {
                row++;
                try
                {
                    var status = Get(csv,"status")??"PENDING";
                    dt.Rows.Add(Get(csv,"order_id"),Get(csv,"asin"),Get(csv,"sku"),
                        Dt(csv,"return_date"),Dt(csv,"refund_date"),Dt(csv,"return_date"),
                        status.ToUpper(),
                        (Get(csv,"detailed_disposition","reason")??"UNKNOWN").ToUpper(),
                        Int(csv,"quantity",1),Dec(csv,"refund_amount"),
                        status.Contains("Returnless",StringComparison.OrdinalIgnoreCase),
                        Get(csv,"disposition"),Get(csv,"fulfillment_center_id"));
                }
                catch (Exception ex) { errors.Add($"Row {row}: {ex.Message}"); }
            }
            return dt;
        }

        // ── PPC Keywords ─────────────────────────────────────
        private async Task<DataTable> ParsePPCKeywordsAsync(CsvReader csv, List<string> errors)
        {
            var dt = MakeTable(("AmazonCampaignId",typeof(string)),("CampaignName",typeof(string)),
                ("AdGroupId",typeof(string)),("AdGroupName",typeof(string)),
                ("KeywordText",typeof(string)),("MatchType",typeof(string)),
                ("ReportDate",typeof(DateTime)),("Impressions",typeof(long)),
                ("Clicks",typeof(int)),("Spend",typeof(decimal)),
                ("Sales",typeof(decimal)),("Orders",typeof(int)),("IsSearchTerm",typeof(bool)));

            await csv.ReadAsync(); csv.ReadHeader();
            var headers = csv.HeaderRecord ?? Array.Empty<string>();
            bool isST = Array.Exists(headers, h => h.Contains("search_term", StringComparison.OrdinalIgnoreCase));
            int row = 0;
            while (await csv.ReadAsync())
            {
                row++;
                try
                {
                    var kw = isST ? Get(csv,"customer_search_term","search_term") : Get(csv,"targeting","keyword");
                    if (string.IsNullOrWhiteSpace(kw)) continue;
                    dt.Rows.Add(Get(csv,"campaign_id")??"UNKNOWN",Get(csv,"campaign_name")??"Unknown",
                        Get(csv,"ad_group_id"),Get(csv,"ad_group_name"),kw,
                        (Get(csv,"match_type")??"BROAD").ToUpper(),
                        Dt(csv,"date","start_date")??DateTime.UtcNow.Date,
                        Long(csv,"impressions"),Int(csv,"clicks"),Dec(csv,"spend"),
                        Dec(csv,"sales_7d")+Dec(csv,"attributed_sales_7d"),
                        Int(csv,"orders")+Int(csv,"orders_7d"),isST);
                }
                catch (Exception ex) { errors.Add($"Row {row}: {ex.Message}"); }
            }
            return dt;
        }

        // ── Inbound Shipments ────────────────────────────────
        private async Task<DataTable> ParseInboundShipmentsAsync(CsvReader csv, List<string> errors)
        {
            var dt = MakeTable(("AmazonShipmentId",typeof(string)),("ShipmentName",typeof(string)),
                ("ShipmentStatus",typeof(string)),("DestinationFC",typeof(string)),
                ("ShippedDate",typeof(DateTime)),("IsAWD",typeof(bool)),
                ("ASIN",typeof(string)),("SKU",typeof(string)),
                ("QtyShipped",typeof(int)),("QtyReceived",typeof(int)));

            await csv.ReadAsync(); csv.ReadHeader();
            int row = 0;
            while (await csv.ReadAsync())
            {
                row++;
                try { dt.Rows.Add(Get(csv,"shipment_id"),Get(csv,"shipment_name"),
                    (Get(csv,"shipment_status")??"CLOSED").ToUpper(),
                    Get(csv,"destination_fulfillment_center_id","fulfillment_center"),
                    Dt(csv,"shipped_date","date_shipped"),false,
                    Get(csv,"asin"),Get(csv,"seller_sku","sku"),
                    Int(csv,"quantity_shipped"),Int(csv,"quantity_received")); }
                catch (Exception ex) { errors.Add($"Row {row}: {ex.Message}"); }
            }
            return dt;
        }

        // ── Helpers ──────────────────────────────────────────
        private DataTable MakeTable(params (string Name, Type Type)[] cols)
        {
            var dt = new DataTable();
            foreach (var (n, t) in cols) dt.Columns.Add(new DataColumn(n, t) { AllowDBNull = true });
            return dt;
        }

        private string? Get(CsvReader csv, params string[] candidates)
        {
            foreach (var c in candidates)
            {
                try { var v = csv.GetField<string?>(c); if (!string.IsNullOrWhiteSpace(v)) return v.Trim(); } catch { }
            }
            return null;
        }

        private int Int(CsvReader csv, string field, int def = 0)
        {
            var v = Get(csv, field)?.Replace(",","");
            return int.TryParse(v, out var i) ? i : def;
        }

        private long Long(CsvReader csv, string field)
        {
            var v = Get(csv, field)?.Replace(",","");
            return long.TryParse(v, out var l) ? l : 0;
        }

        private decimal Dec(CsvReader csv, string field)
        {
            var v = Get(csv, field)?.Replace("$","").Replace(",","");
            return decimal.TryParse(v, NumberStyles.Any, CultureInfo.InvariantCulture, out var d) ? d : 0;
        }

        private DateTime? Dt(CsvReader csv, params string[] fields)
        {
            foreach (var f in fields)
            {
                var v = Get(csv, f);
                if (v != null && DateTime.TryParse(v, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt))
                    return dt;
            }
            return null;
        }
    }
}
