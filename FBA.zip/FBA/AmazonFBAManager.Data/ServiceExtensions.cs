// ============================================================
// AmazonFBAManager.Data/ServiceExtensions.cs
// Clean DI registration — call from both Web and API Program.cs
// Usage: builder.Services.AddFBAManagerDataLayer(connStr);
// ============================================================
using AmazonFBAManager.Data.Connections;
using AmazonFBAManager.Data.Repositories;
using AmazonFBAManager.Data.Services;
using AmazonFBAManager.Shared.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace AmazonFBAManager.Data
{
    public static class ServiceExtensions
    {
        /// <summary>
        /// Registers all Dapper repositories and services.
        /// Call once from both Web and API projects.
        /// </summary>
        public static IServiceCollection AddFBAManagerDataLayer(
            this IServiceCollection services,
            string connectionString)
        {
            // Connection factory (singleton — connection string never changes)
            services.AddSingleton<ISqlConnectionFactory>(
                _ => new SqlConnectionFactory(connectionString));

            // Repositories (scoped — one per request)
            services.AddScoped<IAuthRepository,          AuthRepository>();
            services.AddScoped<IInventoryRepository,     InventoryRepository>();
            services.AddScoped<IReimbursementRepository, ReimbursementRepository>();
            services.AddScoped<ICaseRepository,          CaseRepository>();
            services.AddScoped<IReportsRepository,       ReportsRepository>();
            services.AddScoped<IPPCRepository,           PPCRepository>();
            services.AddScoped<IListingRepository,       ListingRepository>();
            services.AddScoped<IAlertRepository,         AlertRepository>();
            services.AddScoped<IImportRepository,        ImportRepository>();
            services.AddScoped<IResearchRepository,      ResearchRepository>();

            // Services
            services.AddScoped<ICsvParsingService,           CsvParsingService>();
            services.AddScoped<IImportOrchestrationService,  ImportOrchestrationService>();
            services.AddScoped<ISpApiService,                SpApiService>();
            services.AddScoped<IExportService,               ExportService>();
            services.AddScoped<IErrorLogService,             ErrorLogService>();

            return services;
        }
    }
}
