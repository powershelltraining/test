# ============================================================
# Amazon FBA Manager - Build Script
# ============================================================
param(
    [string]$Configuration = "Release",
    [switch]$SkipRestore,
    [switch]$Help
)

$ErrorActionPreference = "Stop"
$ProjectRoot = $PSScriptRoot

function Write-Step { param([string]$Message)
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " $Message" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Success { param([string]$Message)
    Write-Host "[OK] $Message" -ForegroundColor Green
}

function Write-ErrorMsg { param([string]$Message)
    Write-Host "[ERROR] $Message" -ForegroundColor Red
}

if ($Help) {
    Write-Host "Amazon FBA Manager Build Script"
    Write-Host ""
    Write-Host "Usage:"
    Write-Host "  .\build.ps1                    # Build in Release mode"
    Write-Host "  .\build.ps1 -Configuration Debug  # Build in Debug mode"
    Write-Host "  .\build.ps1 -SkipRestore         # Skip restore step"
    exit 0
}

Write-Host "========================================" -ForegroundColor Yellow
Write-Host "  Amazon FBA Manager - Build Script" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "Configuration: $Configuration" -ForegroundColor Gray
Write-Host "Project Root: $ProjectRoot" -ForegroundColor Gray

# Check .NET SDK
Write-Step "Checking .NET SDK"
$dotnetVersion = dotnet --version 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-ErrorMsg ".NET SDK not found. Please install .NET 8 SDK."
    exit 1
}
Write-Host "Found .NET SDK version: $dotnetVersion" -ForegroundColor Gray

# Build projects in order
$projects = @(
    @{Name="Shared"; Path="AmazonFBAManager.Shared"; Desc="Shared DTOs and interfaces"},
    @{Name="Data"; Path="AmazonFBAManager.Data"; Desc="Data access layer"},
    @{Name="Jobs"; Path="AmazonFBAManager.Jobs"; Desc="Background jobs"},
    @{Name="Web"; Path="AmazonFBAManager.Web"; Desc="Web UI (MVC)"},
    @{Name="API"; Path="AmazonFBAManager.API"; Desc="REST API"}
)

foreach ($proj in $projects) {
    Write-Step "Building $($proj.Name) project"
    Push-Location "$ProjectRoot\$($proj.Path)"

    if (-not $SkipRestore) {
        dotnet restore
        if ($LASTEXITCODE -ne 0) {
            Write-ErrorMsg "Restore failed for $($proj.Name)"
            Pop-Location
            exit 1
        }
    }

    dotnet build -c $Configuration --no-restore
    if ($LASTEXITCODE -ne 0) {
        Write-ErrorMsg "Build failed for $($proj.Name)"
        Pop-Location
        exit 1
    }

    Pop-Location
    Write-Success "$($proj.Name) project built successfully"
}

# Default credentials
Write-Step "Default Credentials"
Write-Host "========================================" -ForegroundColor Yellow
Write-Host "  DEFAULT LOGIN CREDENTIALS" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Username: admin" -ForegroundColor White
Write-Host "  Password: ChangeImmediately!" -ForegroundColor White
Write-Host ""
Write-Host "  IMPORTANT: Change the default password" -ForegroundColor Yellow
Write-Host "  immediately after first login!" -ForegroundColor Yellow
Write-Host ""
Write-Host "========================================" -ForegroundColor Yellow
Write-Host ""

# Database setup
Write-Step "Database Setup Required"
Write-Host "To use the application, you need to:"
Write-Host ""
Write-Host "1. Create the database:"
Write-Host "   CREATE DATABASE AmazonFBAManager;"
Write-Host ""
Write-Host "2. Run the SQL scripts in order (in Database folder):"
Write-Host "   - 01_CoreTables.sql"
Write-Host "   - 02_TVPs_And_Security.sql"
Write-Host "   - 03_SeedData.sql"
Write-Host "   - 04_SP_Import.sql"
Write-Host "   - 05_SP_Inventory.sql"
Write-Host "   - 06_SP_Reimbursement.sql"
Write-Host "   - 07_SP_Cases.sql"
Write-Host "   - 08_SP_Reports_PPC_Listings_Research.sql"
Write-Host "   - 09_Views_COGS_Jobs_Master.sql"
Write-Host "   - 10_SeedData_EmailTemplates.sql"
Write-Host "   - 11_SeedData_HelpGuide.sql"
Write-Host ""
Write-Host "3. Update connection string in appsettings.json"
Write-Host ""

# How to run
Write-Step "How to Run"
Write-Host "Web Application: dotnet run --project AmazonFBAManager.Web"
Write-Host "API Server:      dotnet run --project AmazonFBAManager.API"
Write-Host ""
Write-Host "Default URLs:"
Write-Host "  - Web: https://localhost:7001"
Write-Host "  - API: https://localhost:7002"
Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  BUILD COMPLETE!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green

exit 0