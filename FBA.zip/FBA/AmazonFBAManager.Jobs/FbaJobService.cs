// ============================================================
// AmazonFBAManager.Jobs/FbaJobService.cs
// All Hangfire background jobs — call SPs via Dapper
// ============================================================
using AmazonFBAManager.Data.Connections;
using AmazonFBAManager.Shared.Constants;
using Dapper;
using System;
using System.Data;
using System.Threading.Tasks;

namespace AmazonFBAManager.Jobs
{
    public interface IFbaJobService
    {
        Task RunNightlyReimbursementAuditAsync();
        Task RunInventoryAlertCheckAsync();
        Task RunPPCAuditWeeklyAsync();
        Task RunCaseSLAMonitorAsync();
    }

    public class FbaJobService : IFbaJobService
    {
        private readonly ISqlConnectionFactory _cf;

        public FbaJobService(ISqlConnectionFactory cf) => _cf = cf;

        /// <summary>
        /// Daily 2AM: cross-references adjustments vs reimbursements,
        /// creates audit records, fires deadline alerts, flags missing COGS.
        /// </summary>
        public async Task RunNightlyReimbursementAuditAsync()
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                StoredProcedures.Job_NightlyAudit,
                commandType: CommandType.StoredProcedure,
                commandTimeout: 300);
        }

        /// <summary>
        /// Every 4 hours: checks reorder points, stranded inventory, IPI score.
        /// </summary>
        public async Task RunInventoryAlertCheckAsync()
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                StoredProcedures.Job_InventoryAlerts,
                commandType: CommandType.StoredProcedure,
                commandTimeout: 120);
        }

        /// <summary>
        /// Every Monday: flags wasted PPC spend, high TACoS accounts.
        /// </summary>
        public async Task RunPPCAuditWeeklyAsync()
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                StoredProcedures.Job_PPCAudit,
                commandType: CommandType.StoredProcedure,
                commandTimeout: 120);
        }

        /// <summary>
        /// Every 2 hours: escalates SLA-breached cases, fires case alerts.
        /// </summary>
        public async Task RunCaseSLAMonitorAsync()
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                StoredProcedures.Job_SLAMonitor,
                commandType: CommandType.StoredProcedure,
                commandTimeout: 60);
        }
    }
}
