-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 03_SeedData.sql
-- DESC: Seed metadata for all reference/lookup tables
-- ============================================================
SET NOCOUNT ON;
GO

USE AmazonFBAManager;
GO

-- ============================================================
-- MARKETPLACES
-- ============================================================
INSERT INTO dbo.Marketplaces (MarketplaceId, MarketplaceName, CountryCode, CurrencyCode, Region, Endpoint) VALUES
('ATVPDKIKX0DER',  'Amazon.com (US)',         'US', 'USD', 'NA', 'sellingpartnerapi-na.amazon.com'),
('A2EUQ1WTGCTBG2',  'Amazon.ca (Canada)',      'CA', 'CAD', 'NA', 'sellingpartnerapi-na.amazon.com'),
('A1AM78C64UM0Y8',  'Amazon.com.mx (Mexico)',  'MX', 'MXN', 'NA', 'sellingpartnerapi-na.amazon.com'),
('A1F83G8C2ARO7P',  'Amazon.co.uk (UK)',       'GB', 'GBP', 'EU', 'sellingpartnerapi-eu.amazon.com'),
('A1PA6795UKMFR9',  'Amazon.de (Germany)',     'DE', 'EUR', 'EU', 'sellingpartnerapi-eu.amazon.com'),
('A13V1IB3VIYZZH',  'Amazon.fr (France)',      'FR', 'EUR', 'EU', 'sellingpartnerapi-eu.amazon.com'),
('APJ6JRA9NG5V4',   'Amazon.it (Italy)',       'IT', 'EUR', 'EU', 'sellingpartnerapi-eu.amazon.com'),
('A1RKKUPIHCS9HS',  'Amazon.es (Spain)',       'ES', 'EUR', 'EU', 'sellingpartnerapi-eu.amazon.com'),
('A1VC38T7YXB528',  'Amazon.co.jp (Japan)',    'JP', 'JPY', 'FE', 'sellingpartnerapi-fe.amazon.com'),
('A39IBJ37TRP1C6',  'Amazon.com.au (Australia)','AU','AUD', 'FE', 'sellingpartnerapi-fe.amazon.com');
GO

-- ============================================================
-- ROLES
-- ============================================================
INSERT INTO dbo.Roles (RoleId, RoleName, Description) VALUES
(1, 'Admin',           'Full system access; user management; all accounts'),
(2, 'AccountManager',  'Full access to assigned accounts; can open/close cases'),
(3, 'Analyst',         'Read + export access; can run reports; no case creation'),
(4, 'VAReadOnly',      'Read-only access to assigned accounts; daily tasks only');
GO

-- ============================================================
-- ALERT TYPES
-- ============================================================
INSERT INTO dbo.AlertTypes (AlertTypeCode, AlertTypeName, DefaultSeverity, Description) VALUES
('LOW_STOCK',                   'Low Stock Warning',                   'HIGH',     'Product FBA qty has dropped below reorder point'),
('OUT_OF_STOCK',                'Out of Stock',                        'CRITICAL', 'Product FBA qty is zero — missing sales now'),
('OVERSTOCK',                   'Overstock Warning',                   'MEDIUM',   'Days of supply exceeds target threshold'),
('STRANDED_INVENTORY',          'Stranded Inventory Detected',         'HIGH',     'Units in FC with no active listing'),
('AGED_FEE_RISK',               'Aged Inventory Fee Risk',             'MEDIUM',   'Units approaching long-term storage fee threshold'),
('HIJACK_DETECTED',             'Listing Hijack Detected',             'CRITICAL', 'Unauthorized seller added to your listing'),
('BUY_BOX_LOST',                'Buy Box Lost',                        'HIGH',     'Your listing lost the Buy Box'),
('CASE_SLA_BREACH',             'Case SLA Breached',                   'HIGH',     'Open case has exceeded SLA deadline'),
('NEW_REIMBURSEMENT_OPPORTUNITY','New Reimbursement Opportunity Found', 'MEDIUM',   'Audit found unclaimed reimbursement'),
('REIMBURSEMENT_DEADLINE',      'Reimbursement Filing Deadline',       'CRITICAL', 'Claim approaching 18-month filing deadline'),
('FEE_SPIKE',                   'Unusual Fee Spike Detected',          'MEDIUM',   'FBA fees significantly above historical average'),
('LISTING_SUPPRESSED',          'Listing Suppressed',                  'HIGH',     'Amazon has suppressed this listing'),
('AWD_DISCREPANCY',             'AWD Shipment Discrepancy',            'HIGH',     'AWD received quantity does not match shipped qty'),
('INBOUND_DISCREPANCY',         'Inbound Shipment Discrepancy',        'MEDIUM',   'FC received qty does not match shipped qty'),
('COGS_MISSING',                'COGS Not Entered',                    'MEDIUM',   'Product has no COGS — reimbursement calculation inaccurate'),
('ACCOUNT_HEALTH_WARNING',      'Account Health Warning',              'CRITICAL', 'Account Health dashboard shows policy warning'),
('IPI_LOW',                     'IPI Score Below Threshold',           'MEDIUM',   'Inventory Performance Index below 400'),
('REMOVAL_ORDER_READY',         'Removal Order Ready to Ship',         'LOW',      'Removal order shipment is ready'),
('NEW_RETURN',                  'New Product Return',                  'LOW',      'Customer return received at FC');
GO

-- ============================================================
-- CASE TYPES
-- ============================================================
INSERT INTO dbo.CaseTypes (CaseTypeCode, CaseTypeName, Description, DefaultSLADays, RequiresPOA) VALUES
('LOST_INVENTORY',              'Lost Inventory',                    'Units removed from inventory without reimbursement or explanation', 7,  0),
('DAMAGED_INVENTORY',           'Damaged Inventory',                 'Units damaged by Amazon in FC or during fulfillment', 7,  0),
('FEE_OVERCHARGE',              'Fee Overcharge',                    'Amazon charged incorrect FBA fees based on wrong dimensions/weight', 14, 0),
('RETURNLESS_REFUND',           'Returnless Refund Not Reimbursed',  'Amazon refunded buyer but no return received — not reimbursed', 14, 0),
('LISTING_SUPPRESSION',         'Listing Suppression',               'Listing was suppressed by Amazon', 3,  0),
('HIJACK_REPORT',               'Hijack / Unauthorized Seller',      'Unauthorized third party selling on your listing', 5,  0),
('ACCOUNT_SUSPENSION',          'Account Suspension',                'Seller account suspended — requires Plan of Action', 3,  1),
('INBOUND_DISCREPANCY',         'Inbound Shipment Discrepancy',      'Units shipped to Amazon FC but not received in full', 10, 0),
('AWD_LOSS',                    'AWD Shipment Loss',                 'Units lost in Amazon Warehousing & Distribution pipeline', 10, 0),
('IP_COMPLAINT',                'IP / Trademark Complaint',          'Received IP infringement complaint from competitor or brand owner', 5,  1),
('ASIN_REINSTATEMENT',          'ASIN Reinstatement',                'ASIN removed and requires reinstatement', 5,  1),
('REIMBURSEMENT_DISPUTE',       'Reimbursement Amount Dispute',      'Amazon reimbursed incorrect amount (not at correct COGS basis)', 14, 0),
('REVIEW_MANIPULATION_REPORT',  'Report Review Manipulation',        'Competitor engaged in review manipulation', 7,  0),
('CUSTOMER_RETURN_NOT_RECEIVED','Customer Return Not Received',      'Customer was refunded but return never received at FC', 14, 0);
GO

-- ============================================================
-- FEE TYPES
-- ============================================================
INSERT INTO dbo.FeeTypes (FeeTypeCode, FeeTypeName, Description) VALUES
('FBA_FULFILLMENT',         'FBA Fulfillment Fee',              'Per-unit pick, pack, and ship fee'),
('REFERRAL_FEE',            'Referral Fee',                     'Percentage of item price paid to Amazon'),
('MONTHLY_STORAGE',         'Monthly Storage Fee',              'Per-cubic-foot monthly storage charge'),
('LONG_TERM_STORAGE',       'Long-Term Storage Surcharge',      'Additional fee for units stored 181+ days'),
('DISPOSAL_FEE',            'Disposal Fee',                     'Fee to dispose of units at FC'),
('REMOVAL_FEE',             'Removal Order Fee',                'Per-unit fee to return inventory to seller'),
('UNPLANNED_SERVICE_FEE',   'Unplanned Service Fee',            'Fee for unplanned prep or labeling at FC'),
('REFUND_ADMIN_FEE',        'Refund Administration Fee',        'Amazon keeps portion of referral fee on refunds'),
('SUBSCRIPTION_FEE',        'Professional Seller Subscription', 'Monthly $39.99 pro seller fee'),
('INBOUND_TRANSPORT',       'Inbound Transportation Fee',       'Amazon-partnered carrier shipping fee'),
('PLACEMENT_FEE',           'Inbound Placement Service Fee',    'Fee for Amazon to distribute inbound to multiple FCs'),
('LOW_INVENTORY_FEE',       'Low Inventory Level Fee',          'Fee for insufficient inventory relative to sales (2024+)'),
('AGED_181_270',            'Aged Inventory 181-270 Days',      'Surcharge for inventory aged 181-270 days'),
('AGED_271_365',            'Aged Inventory 271-365 Days',      'Surcharge for inventory aged 271-365 days'),
('AGED_365_PLUS',           'Aged Inventory 365+ Days',         'Surcharge for inventory aged over 365 days');
GO

-- ============================================================
-- RETURN REASON CODES
-- ============================================================
INSERT INTO dbo.ReturnReasonCodes (ReasonCode, ReasonDescription) VALUES
('DEFECTIVE',                   'Defective item'),
('NOT_AS_DESCRIBED',            'Item not as described'),
('WRONG_ITEM',                  'Wrong item was sent'),
('DAMAGED_BY_FC',               'Damaged in fulfillment center'),
('DAMAGED_IN_TRANSIT',          'Damaged in shipping'),
('MISSING_PARTS',               'Item arrived missing parts'),
('NO_LONGER_NEEDED',            'No longer needed'),
('ORDERED_WRONG_ITEM',          'Buyer ordered by mistake'),
('BETTER_PRICE_AVAILABLE',      'Found better price elsewhere'),
('ARRIVED_TOO_LATE',            'Arrived after expected date'),
('UNAUTHORIZED_PURCHASE',       'Unauthorized purchase'),
('QUALITY_NOT_ACCEPTABLE',      'Quality did not meet expectations'),
('INCOMPATIBLE',                'Incompatible with device or system'),
('MISSED_ESTIMATED_DELIVERY',   'Package arrived after estimated delivery date'),
('SWITCHEROO',                  'Buyer returned different item (fraud)');
GO

-- ============================================================
-- DISPOSITION CODES
-- ============================================================
INSERT INTO dbo.DispositionCodes (DispositionCode, Description) VALUES
('SELLABLE',            'Item is in sellable condition — returned to active inventory'),
('DAMAGED',             'Item is damaged — moved to unsellable/unfulfillable inventory'),
('CUSTOMER_DAMAGED',    'Item damaged by customer'),
('DEFECTIVE',           'Item is defective'),
('EXPIRED',             'Item has passed expiration date'),
('CARRIER_DAMAGED',     'Item damaged by carrier during shipment'),
('DISPOSED',            'Item disposed of at FC'),
('RETURNED_TO_SELLER',  'Item shipped back to seller');
GO

-- ============================================================
-- INVENTORY ADJUSTMENT REASONS
-- ============================================================
INSERT INTO dbo.InventoryAdjustmentReasons (ReasonCode, ReasonDescription, IsLossEvent) VALUES
('LOST',                        'Lost in warehouse',                            1),
('DAMAGED',                     'Damaged in warehouse',                         1),
('DAMAGED_WAREHOUSE',           'Damaged in warehouse (alternate code)',         1),
('CUSTOMER_RETURN',             'Returned by customer',                         0),
('FC_TRANSFER',                 'Transferred to another FC',                    0),
('FC_PROCESSING',               'Being processed at FC',                        0),
('FOUND',                       'Previously lost unit found',                   0),
('DISPOSED',                    'Disposed at seller request',                   1),
('VENDOR_RETURN',               'Returned to vendor',                           1),
('WAREHOUSE_DAMAGE',            'Damaged by warehouse operations',              1),
('INBOUND_RECEIVING',           'Received from inbound shipment',               0),
('REMOVAL_ORDER',               'Removed via removal order',                    0),
('REVERSAL',                    'Adjustment reversal',                          0),
('SELLABLE_DEFECT',             'Item found to have defect post-sale',          1),
('RAIN_DAMAGE',                 'Environmental damage in storage',              1),
('EXPIRATION',                  'Expired and disposed',                         1),
('REIMBURSED',                  'Amazon reimbursed seller for units',           0);
GO

-- ============================================================
-- REPORT TYPES
-- ============================================================
INSERT INTO dbo.ReportTypes (ReportTypeCode, ReportTypeName, Description, AmazonReportId, ExpectedFileFormat, MaxDateRangeDays, Notes) VALUES
('INVENTORY_SNAPSHOT',      'FBA All Inventory Report',           'Current FBA inventory quantities and status',   'GET_FBA_MYI_UNSUPPRESSED_INVENTORY_DATA',              'TSV',  NULL, 'No date range — current snapshot only. Takes ~10 min to generate.'),
('SALES_TRAFFIC',           'Sales & Traffic Report',             'Sessions, page views, units, revenue, CVR',     'GET_SALES_AND_TRAFFIC_REPORT',                         'JSON', 31,   'Max 31 days per request. Must request via Reports > Business Reports.'),
('FBA_FEE_PREVIEW',         'FBA Estimated Fee Preview',          'Per-unit fee estimate by ASIN/SKU',             'GET_FBA_ESTIMATED_FBA_FEES_TXT_DATA',                  'TSV',  NULL, 'Not all marketplaces support this report.'),
('REIMBURSEMENTS',          'FBA Reimbursements Report',          'All reimbursements issued by Amazon',           'GET_FBA_REIMBURSEMENTS_DATA',                          'CSV',  180,  'Max 180-day range. Download from Reports > Fulfillment > Payments.'),
('CUSTOMER_RETURNS',        'FBA Customer Returns Report',        'All customer returns and dispositions',         'GET_FBA_FULFILLMENT_CUSTOMER_RETURNS_DATA',            'TSV',  NULL, 'Available up to 18 months. File named fba-customer-returns.txt'),
('INVENTORY_ADJUSTMENTS',   'FBA Inventory Adjustments Report',   'All inventory add/remove events by reason',     'GET_FBA_FULFILLMENT_INVENTORY_ADJUSTMENTS_DATA',       'TSV',  NULL, 'Critical for lost/damaged audit. Up to 18 months.'),
('ORDER_REPORT',            'All Orders Report (Flat File)',       'Complete order history with all fields',        'GET_FLAT_FILE_ALL_ORDERS_DATA_BY_LAST_UPDATE_GENERAL', 'TSV',  NULL, 'Request via Orders > Order Reports. 30-day max per batch recommended.'),
('PPC_SEARCH_TERM',         'Sponsored Products Search Term',     'Keyword-level PPC performance data',            NULL,                                                   'CSV',  NULL, 'Download from Advertising > Campaign Manager > Reports.'),
('SETTLEMENT',              'Settlement Report V2',               'Itemized settlement: orders, fees, refunds',    NULL,                                                   'TSV',  NULL, 'One file per settlement period. Download from Reports > Payments.'),
('STRANDED_INVENTORY',      'Stranded Inventory Report',          'Units at FC with no active listing',            NULL,                                                   'CSV',  NULL, 'Download from Inventory > Fix Stranded Inventory > Download.'),
('AGED_INVENTORY',          'FBA Inventory Age Report',           'Units by age tier + estimated surcharges',      NULL,                                                   'CSV',  NULL, 'Download from Inventory > Manage Inventory > Inventory Age.'),
('INBOUND_SHIPMENTS',       'Inbound Shipment Report',            'Shipped vs received by shipment',               NULL,                                                   'CSV',  NULL, 'Download from Inventory > Shipments > Shipment Reports.'),
('REMOVAL_ORDERS',          'Removal Order Detail Report',        'All removal orders and their status',           NULL,                                                   'TSV',  NULL, 'Download from Reports > Fulfillment > Removals.'),
('AWD_INVENTORY',           'AWD Inventory Report',               'Amazon Warehousing & Distribution quantities',  NULL,                                                   'CSV',  NULL, 'Download from Inventory > AWD > Inventory. Not all accounts have AWD.');
GO

-- ============================================================
-- SOP TEMPLATES (VA daily/weekly workflows)
-- ============================================================
INSERT INTO dbo.SOPTemplates (TemplateCode, TemplateName, Category, Body) VALUES
('VA_DAILY_MORNING',
 'VA Daily Morning Routine',
 'DAILY',
 N'DAILY MORNING ROUTINE — Amazon FBA Platform
================================================
Estimated Time: 30-45 minutes
Perform every business day before 10:00 AM.

STEP 1: LOG IN
1. Open the FBA Management Platform in your browser.
2. Log in with your VA credentials.
3. Click [Account Switcher] at top left and verify the correct seller account is selected.

STEP 2: CHECK ALERT CENTER
1. Click [Alert Center] in the left navigation.
2. Review all CRITICAL and HIGH alerts first.
3. For each unresolved CRITICAL alert, note it in your daily report to the Account Manager.
4. Mark LOW/MEDIUM alerts as Read if they require no action today.
5. Do NOT close or resolve alerts — only the Account Manager may resolve alerts.

STEP 3: DOWNLOAD REPORTS FROM SELLER CENTRAL
Download the following reports (see Section 2 of the Help Guide for exact steps):
  - FBA Inventory Report (if day is Monday or inventory alert exists)
  - Order Report (daily — select yesterday''s date)
  - Returns Report (Monday only)

STEP 4: UPLOAD REPORTS TO THE PLATFORM
1. Click [CSV Import Center] in the left navigation.
2. For each downloaded file:
   a. Select the correct Seller Account from the dropdown.
   b. Drag and drop the file, or click [Browse].
   c. Select the correct Report Type from the dropdown.
   d. Click [Upload & Import].
   e. Wait for Status to change to COMPLETE.
   f. If Status shows FAILED or PARTIAL, copy the Error Log and include in daily report.

STEP 5: CHECK INVENTORY REORDER SUGGESTIONS
1. Click [Inventory Manager] > [Reorder Suggestions].
2. Filter by Urgency Score = HIGH or CRITICAL.
3. Note all flagged SKUs in your daily report.
4. Do NOT place orders — notify the Account Manager with the list.

STEP 6: SUBMIT DAILY REPORT
Send daily report to Account Manager with:
- Any CRITICAL/HIGH alerts found
- Import results (what was uploaded, any failures)
- Reorder SKUs needing attention
- Any unusual observations'),

('VA_WEEKLY_REIMB',
 'Weekly Reimbursement Audit Routine',
 'WEEKLY',
 N'WEEKLY REIMBURSEMENT AUDIT — Every Monday
==========================================
Estimated Time: 45-60 minutes

STEP 1: DOWNLOAD REQUIRED REPORTS FROM SELLER CENTRAL
  - Reimbursements Report (last 30 days)
  - Inventory Adjustments Report (last 30 days)
  - Customer Returns Report (last 30 days)

STEP 2: UPLOAD ALL THREE REPORTS
Upload each to the platform via CSV Import Center.
Wait for all three to reach COMPLETE status before proceeding.

STEP 3: RUN REIMBURSEMENT CHECKLIST
1. Click [Refund Auditor] > [Monthly Checklist].
2. Select current month and year.
3. Click [Run Checklist].
4. Screenshot or export the results.

STEP 4: NOTE ALL OPEN ITEMS
For any checklist item marked ACTION REQUIRED:
  - Note the item type, ASIN, and claimable amount.
  - Do NOT open cases yourself unless specifically authorized.
  - Include all open items in your weekly report.

STEP 5: CHECK REIMBURSEMENT DEADLINES
1. Click [Refund Auditor] > [KPI Dashboard].
2. Look for any items in the DEADLINE WARNING section.
3. Flag any item with deadline within 60 days as URGENT in your report.'),

('VA_CASE_NOTES',
 'Adding Notes to an Existing Case',
 'CASE',
 N'ADDING NOTES TO A CASE
========================
Estimated Time: 5 minutes per case

1. Click [Case Manager] in the left navigation.
2. Locate the case using the search bar or filter by Status = OPEN.
3. Click on the Case ID to open the case detail view.
4. Scroll down to the [Case Notes] section.
5. Click [+ Add Note].
6. Type your update clearly. Include:
   - Date and time of the update
   - What you did (e.g., "Called Amazon Seller Support — ref# 12345678")
   - What Amazon said or what happened
   - Any next steps
7. Leave [Internal Note] checked (this note is for team use only).
8. Click [Save Note].

IMPORTANT: Do NOT change Case Status, Priority, or Resolved Amount.
Only Account Managers may update these fields.');
GO

-- ============================================================
-- DEFAULT ADMIN USER (password should be changed on first login)
-- Password hash shown is placeholder — app sets this on install
-- ============================================================
INSERT INTO dbo.Users (Username, Email, PasswordHash, RoleId, FirstName, LastName, IsActive)
VALUES ('admin', 'admin@yourcompany.com', 'CHANGE_ON_FIRST_LOGIN_PLACEHOLDER', 1, 'System', 'Administrator', 1);
GO

-- ============================================================
-- DEFAULT ALERT THRESHOLDS (account-level defaults)
-- ProductId = NULL means applies to all products as default
-- These are inserted for SellerAccountId = NULL (template)
-- Application seeds per-account during onboarding
-- ============================================================

-- NOTE: Per-account thresholds are inserted by usp_SellerAccount_Onboard
-- which copies these defaults and customizes per account.

CREATE TABLE dbo.DefaultAlertThresholds (
    AlertTypeCode       VARCHAR(50)     NOT NULL,
    DefaultValue        DECIMAL(18,4)   NOT NULL,
    Unit                VARCHAR(30)     NOT NULL,
    Description         VARCHAR(300)    NULL,
    CONSTRAINT PK_DefaultAlertThresholds PRIMARY KEY (AlertTypeCode)
);

INSERT INTO dbo.DefaultAlertThresholds (AlertTypeCode, DefaultValue, Unit, Description) VALUES
('LOW_STOCK',           14,     'DAYS',    'Alert when days of supply drops below 14 days'),
('OUT_OF_STOCK',        0,      'UNITS',   'Alert when FBA qty = 0'),
('OVERSTOCK',           90,     'DAYS',    'Alert when days of supply exceeds 90 days'),
('AGED_FEE_RISK',       150,    'DAYS',    'Alert when oldest unit age exceeds 150 days (30 days before surcharge at 181)'),
('IPI_LOW',             400,    'SCORE',   'Alert when IPI drops below 400'),
('FEE_SPIKE',           25,     'PERCENT', 'Alert when fees increase more than 25% vs prior 30-day average'),
('CASE_SLA_BREACH',     1,      'DAYS',    'Alert when case breaches SLA by more than 1 day'),
('REIMBURSEMENT_DEADLINE', 60,  'DAYS',    'Alert when reimbursement claim deadline is within 60 days');
GO
