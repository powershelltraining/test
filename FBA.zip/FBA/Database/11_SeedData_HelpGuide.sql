-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 11_SeedData_HelpGuide.sql
-- DESC: Full Help & User Guide seeded to database
--       Stored in HelpTopics table, retrievable by the app
--       All 11 sections, every topic complete
-- ============================================================
SET NOCOUNT ON;
GO

USE AmazonFBAManager;
GO

-- Create HelpTopics table
CREATE TABLE dbo.HelpTopics (
    TopicId         INT             NOT NULL    IDENTITY(1,1),
    SectionNumber   TINYINT         NOT NULL,
    SectionName     NVARCHAR(200)   NOT NULL,
    TopicCode       VARCHAR(80)     NOT NULL,
    TopicName       NVARCHAR(200)   NOT NULL,
    WhatItDoes      NVARCHAR(MAX)   NOT NULL,
    WhenToUseIt     NVARCHAR(MAX)   NOT NULL,
    StepByStep      NVARCHAR(MAX)   NOT NULL,
    ProTip          NVARCHAR(MAX)   NULL,
    CommonMistake   NVARCHAR(MAX)   NULL,
    SortOrder       INT             NOT NULL    DEFAULT 0,
    IsActive        BIT             NOT NULL    DEFAULT 1,
    CONSTRAINT PK_HelpTopics PRIMARY KEY (TopicId),
    CONSTRAINT UQ_HelpTopics_Code UNIQUE (TopicCode)
);
GO

-- ============================================================
-- SECTION 1: GETTING STARTED
-- ============================================================
INSERT INTO dbo.HelpTopics (SectionNumber, SectionName, TopicCode, TopicName, WhatItDoes, WhenToUseIt, StepByStep, ProTip, CommonMistake, SortOrder) VALUES

(1, 'Getting Started', 'S1_FIRST_LOGIN',
 'Creating Your Account and First Login',
 N'The login screen is your entry point to the FBA Management Platform. On first login you will be prompted to change your temporary password and configure your security preferences. The platform uses role-based access, so what you see after logging in depends on the role assigned to you by your administrator.',
 N'Use this guide when you are logging in for the first time with credentials provided by your administrator, or when you need to reset your password.',
 N'1. Open your web browser and navigate to [YOUR_PLATFORM_URL].
2. Enter the Username and Temporary Password provided to you by your administrator in the email titled "Welcome to the Team."
3. Click the blue [Sign In] button.
4. The system will immediately prompt you to change your password. Enter your temporary password in the "Current Password" field.
5. Enter a new strong password (minimum 12 characters, at least one uppercase letter, one number, and one special character) in the "New Password" field.
6. Re-enter the same new password in the "Confirm Password" field.
7. Click [Save Password].
8. You will be taken to the main Dashboard. You will see the accounts you have access to in the top-left account switcher.
9. If you see "No accounts assigned," contact your administrator to assign seller accounts to your user profile.',
 N'Use a password manager to store your credentials securely. Never write your password in a spreadsheet or share it via email or chat.',
 N'The most common mistake is trying to use the temporary password again after the first login. Temporary passwords expire after first use. If you are locked out, ask your administrator to reset your password via User Management.',
 10),

(1, 'Getting Started', 'S1_ADD_SELLER_ACCOUNT',
 'Adding Your First Amazon Seller Account',
 N'Before you can import any data or view reports, you must connect at least one Amazon Seller Account to the platform. This involves entering your Amazon SP-API credentials (Client ID, Client Secret, and Refresh Token) which allow the platform to pull live data directly from Amazon, and selecting your marketplace.',
 N'Use this when setting up the platform for the first time, or when adding a new Amazon seller account to an existing platform installation.',
 N'1. Log in as Admin.
2. Click [Settings] in the left navigation menu.
3. Click [Seller Accounts] in the Settings sub-menu.
4. Click the green [+ Add Seller Account] button in the top right.
5. Fill in the Account Name field — use a descriptive name such as "Main US Account" or "Brand Name — Amazon US."
6. Select the Marketplace from the dropdown (e.g., Amazon.com US, Amazon.co.uk, etc.).
7. Enter your Merchant Token (found in Seller Central > Account Info > Merchant Token).
8. Enter your SP-API Client ID (from your Developer Central app).
9. Enter your SP-API Client Secret (from your Developer Central app).
10. Enter your SP-API Refresh Token (generated during SP-API authorization flow).
11. Select your Region (NA for US/CA/MX, EU for UK/DE/FR/IT/ES, FE for JP/AU).
12. Click [Test Connection]. A green checkmark will confirm the credentials are valid.
13. Click [Save Account].
14. The system will automatically run the onboarding routine, seeding default alert thresholds for your account.
15. You will be returned to the Seller Accounts list and see your new account with status "Active."',
 N'Keep your SP-API Refresh Token in a secure location separate from the platform. If your Refresh Token is ever compromised, revoke it immediately in Amazon Developer Central and generate a new one.',
 N'The most common error is entering the Client Secret with leading or trailing spaces copied from the Developer Central page. Always click directly into the field and type or paste carefully. If the connection test fails, check that you have granted all required permissions to your SP-API application (particularly Seller Central reports and inventory permissions).',
 20),

(1, 'Getting Started', 'S1_COGS_SETUP',
 'Configuring COGS (Cost of Goods) Per ASIN',
 N'COGS (Cost of Goods Sold) is the amount you paid per unit to your supplier or manufacturer. As of March 10, 2025, Amazon reimburses sellers for lost and damaged inventory at cost basis — meaning the reimbursement equals your COGS, not your selling price. Without COGS entered, the platform calculates all reimbursement opportunities as $0, which means you could be filing claims for nothing and leaving real money on the table.',
 N'Complete this setup immediately after adding your seller account. It is the single most financially important configuration step in the entire platform. Update COGS any time your supplier pricing changes.',
 N'1. Click [Settings] in the left navigation.
2. Click [COGS Manager].
3. You will see a list of all your active ASINs. ASINs without COGS are highlighted in red with the label "MISSING."
4. To enter COGS for a single product: click the pencil icon next to the SKU, enter the COGS amount in US dollars (e.g., 4.75), and click [Save].
5. To enter COGS for multiple products at once (recommended): click [Bulk Upload COGS]. Download the template CSV. Fill in the SKU and COGS columns. Save the file. Drag and drop it onto the upload area. Click [Import COGS].
6. The system will immediately recalculate all open reimbursement audit amounts using your entered COGS.
7. Check the "COGS Coverage %" indicator at the top of the page. Aim for 100%.
8. Any product with COGS entered will show a green checkmark. Missing COGS will generate a COGS_MISSING alert in the Alert Center.',
 N'Your COGS should match the per-unit cost on your supplier invoice, NOT including shipping to Amazon. Shipping to FBA is a separate cost and is not factored into Amazon''s reimbursement calculation. If you have landed cost COGS (including freight), use that figure — it is more defensible.',
 N'Entering $0 or leaving COGS blank is treated the same way by the system and by Amazon — your reimbursement will be $0. Some sellers mistakenly enter their selling price instead of their cost price. Your COGS should always be significantly lower than your selling price.',
 30),

(1, 'Getting Started', 'S1_ALERT_THRESHOLDS',
 'Setting Alert Thresholds',
 N'Alert thresholds control when the platform generates warning notifications. For example, you can set the low stock alert to fire when a product drops below 21 days of supply, or set the aged inventory alert to warn you at 150 days (30 days before Amazon charges the 181-day surcharge). Default thresholds are pre-seeded when your account is created, but you should customize them to match your business.',
 N'Configure alert thresholds during initial setup, or any time your business model changes (e.g., you move to a supplier with shorter lead times and can tolerate lower reorder points).',
 N'1. Click [Settings] > [Alert Thresholds].
2. You will see a table of all alert types with their current threshold values.
3. To change a threshold: click the value in the "Threshold" column, type the new value, and press Enter or click away to save.
4. To set a SKU-specific threshold (overrides account default): click [+ Add SKU Override], search for the SKU, select the alert type, and enter the threshold value. This is useful for hero SKUs that need tighter monitoring.
5. The most important thresholds to configure:
   - LOW_STOCK: Set to your lead time + safety stock in days (e.g., 21 days for a 30-day lead time supplier)
   - AGED_FEE_RISK: Set to 150 days (warns you 31 days before the 181-day surcharge kicks in)
   - REIMBURSEMENT_DEADLINE: Leave at 60 days — this is a critical safety net
6. Click [Save All Thresholds] when done.',
 N'Set your LOW_STOCK threshold to your supplier lead time plus a safety buffer. If your supplier takes 30 days and you want 7 days of safety stock, set your threshold to 37 days of supply.',
 N'Many sellers leave all thresholds at the system defaults and never customize them. A product with a 60-day supplier lead time needs a much higher low stock threshold than a product with a 7-day domestic supplier.',
 40);

-- ============================================================
-- SECTION 2: DOWNLOADING REPORTS FROM SELLER CENTRAL
-- ============================================================
INSERT INTO dbo.HelpTopics (SectionNumber, SectionName, TopicCode, TopicName, WhatItDoes, WhenToUseIt, StepByStep, ProTip, CommonMistake, SortOrder) VALUES

(2, 'Downloading Reports from Amazon Seller Central', 'S2_INVENTORY_REPORT',
 'FBA Inventory Report',
 N'The FBA Inventory Report (also called the All Listings Report) shows you the current quantity of every SKU you have stored in Amazon''s fulfillment centers, including FBA quantity, inbound quantity, reserved units, and unfulfillable units. It is a snapshot of your inventory at the time of generation.',
 N'Download this report every weekday morning and upload it to the platform. It is the foundation of all inventory management features including reorder suggestions, overstock reports, and stranded inventory detection.',
 N'1. Log into Seller Central at sellercentral.amazon.com.
2. Hover over [Reports] in the top navigation bar.
3. Click [Fulfillment] in the dropdown.
4. In the left sidebar under "Inventory," click [All Listings].
5. On the report page, click [Request Download].
6. Wait 5-15 minutes. The page will refresh automatically, or press F5 to refresh.
7. When the report status changes to "Ready," click [Download].
8. The file will download as a .txt file (tab-delimited) named something like "FulfillmentInventoryReport_[DATE].txt."
9. Save this file to your designated downloads folder.
10. Upload to the FBA Platform: CSV Import Center > Select Account > Report Type: FBA Inventory Report > Upload.',
 N'This report reflects current inventory at the moment you generate it. Download it at the same time every day for consistent trend tracking.',
 N'Do not confuse this report with the "Manage FBA Inventory" page in Seller Central, which shows the same data but cannot be exported in a usable format for import. Always download via Reports > Fulfillment > All Listings.',
 10),

(2, 'Downloading Reports from Amazon Seller Central', 'S2_REIMBURSEMENTS_REPORT',
 'FBA Reimbursements Report',
 N'The Reimbursements Report lists every reimbursement Amazon has issued to your account, including the type (lost, damaged, customer return, fee adjustment), the ASIN, quantity, and amount. It is critical for the reimbursement audit feature because the platform cross-references this report against inventory adjustment losses to find unclaimed amounts.',
 N'Download this report every Monday as part of your weekly reimbursement audit routine. When first setting up, download the full 18-month history.',
 N'1. Log into Seller Central.
2. Hover over [Reports] > click [Fulfillment].
3. In the left sidebar under "Payments," click [Reimbursements].
4. Set the Date Range: select a custom range. For weekly use, select the last 30 days. For initial setup, select the maximum allowed range (180 days).
5. Click [Request Download].
6. Wait up to 20 minutes for large date ranges.
7. Download the .txt file when ready.
8. File will be named something like "FBAReimbursements_[DATE].txt."
9. Upload to FBA Platform: Report Type: Reimbursements.

IMPORTANT NOTES:
- Maximum date range: 180 days per request
- For 18-month history: download two separate 180-day periods
- Not all reimbursement types appear in this report — fee adjustments may appear in the Settlement Report only',
 N'After downloading the first 18 months of history, set a calendar reminder to download this report every Monday. Reimbursement data older than 18 months cannot be claimed.',
 N'The most common mistake is downloading only recent data and missing older unclaimed losses. Amazon''s 18-month filing window means losses from 17 months ago are still claimable but will expire soon. Always audit the full 18-month window on first setup.',
 70),

(2, 'Downloading Reports from Amazon Seller Central', 'S2_AWD_REPORT',
 'AWD (Amazon Warehousing & Distribution) Inventory Report',
 N'The AWD Inventory Report shows the current quantity of your products stored in Amazon Warehousing and Distribution centers, separate from your FBA fulfillment center inventory. AWD was a major source of seller losses in 2024-2025 due to unit discrepancies during transfers from AWD to FBA. This report is essential for the AWD Discrepancy Tracker.',
 N'Download weekly if you use the AWD program. Download immediately if you notice your FBA inventory is lower than expected after an AWD transfer.',
 N'1. Log into Seller Central.
2. Hover over [Inventory] in the top navigation.
3. Click [Manage AWD] or [Amazon Warehousing & Distribution] (the exact label may vary by account).
4. Click on the [Inventory] tab within the AWD dashboard.
5. Look for an [Export] or [Download] button — this varies by marketplace.
6. If no download button is visible, click [Reports] within the AWD section.
7. Select date range and click [Request Report].
8. Download the CSV file when ready.
9. Upload to FBA Platform: Report Type: AWD Inventory Report.

NOTE: The AWD report is not available in all marketplaces. If you do not see the AWD section in Seller Central, your account does not have AWD enabled.',
 N'If you use AWD and notice a persistent gap between units you sent to AWD and units appearing in FBA, download both the AWD report and the Inbound Shipments report. Upload both to the platform and run the AWD Discrepancy Audit immediately.',
 N'Many sellers do not realize AWD and FBA are separate inventory pools. If you only download the FBA inventory report, you will miss units sitting in AWD that may never have been transferred to FBA.',
 140);

-- ============================================================
-- SECTION 3: UPLOADING CSV FILES
-- ============================================================
INSERT INTO dbo.HelpTopics (SectionNumber, SectionName, TopicCode, TopicName, WhatItDoes, WhenToUseIt, StepByStep, ProTip, CommonMistake, SortOrder) VALUES

(3, 'Uploading CSV Files', 'S3_UPLOAD_PROCESS',
 'How to Upload CSV Files to the Platform',
 N'The CSV Import Center is the hub for all data uploads. Every report you download from Amazon Seller Central is uploaded here. The platform automatically parses the file, maps the columns to the correct database fields, deduplicates records, and runs any relevant audit logic (such as detecting new loss events or reimbursement opportunities).',
 N'Use the CSV Import Center every time you download a new report from Amazon Seller Central. Uploads are the primary way data flows into the platform unless you have SP-API live pulls enabled.',
 N'1. Click [CSV Import Center] in the left navigation menu.
2. At the top right, click [+ New Import].
3. In the "Seller Account" dropdown, select the account this file belongs to (critical — do not mix files from different accounts).
4. In the "Report Type" dropdown, select the type of report you are uploading (e.g., FBA Inventory Report, Reimbursements, Returns).
5. To upload the file: either drag and drop the file from your computer onto the dashed upload area, OR click [Browse Files] and navigate to the file on your computer.
6. The platform will show a file preview: filename, size, and a preview of the first 5 rows. Verify this looks correct.
7. Click [Start Import].
8. The Status will change: Pending → Processing → Complete (or Failed/Partial).
9. Do not close the browser tab while importing — the process takes 10 seconds to 3 minutes depending on file size.
10. When complete, you will see: Rows Imported, Rows Skipped, Rows Errored.
11. If Status shows COMPLETE with 0 errors, the import was successful.
12. If Status shows FAILED or PARTIAL, click [View Error Log] to see what went wrong.',
 N'You can upload multiple files at once by selecting multiple files in the Browse dialog (hold Ctrl/Cmd while clicking). The platform will process them in sequence.',
 N'The single most common mistake is selecting the wrong Report Type for the file being uploaded. For example, uploading a Returns file but selecting "FBA Inventory Report" as the type. The platform will fail to map the columns correctly. Always verify the Report Type matches your file before clicking Import.',
 10),

(3, 'Uploading CSV Files', 'S3_IMPORT_STATUS',
 'Understanding Import Status Codes',
 N'Each import in the Import History has a Status field that tells you exactly what happened during processing. Understanding these statuses helps you quickly identify and fix issues.',
 N'Check import statuses whenever you upload a file, and review the Import History weekly to confirm all uploads completed successfully.',
 N'Status meanings:

PENDING: The file has been received by the platform and is waiting to be processed by the background worker. Typically transitions to PROCESSING within 30 seconds.

PROCESSING: The platform is actively reading and importing the file. Do not upload the same file again while this status is showing.

COMPLETE: All rows were successfully imported with no errors. Green checkmark. No action needed.

PARTIAL: Some rows were imported successfully, but some rows encountered errors (e.g., unknown SKU, invalid date format, duplicate record). Click [View Error Log] to see which rows failed and why. The successfully imported rows ARE saved — only the failed rows need attention.

FAILED: The entire import failed, usually due to the wrong Report Type being selected (column mismatch), a corrupt file, or a system error. No rows were saved. Click [View Error Log] for the error message, then re-upload with the correct settings.

ERROR LOG: When you click "View Error Log," you will see a list of row numbers and error descriptions. Common errors include "SKU not found in Products table" (upload the inventory report first to register SKUs), "Invalid date format" (file may have been saved in the wrong locale), and "Duplicate record" (this file was already imported — safe to ignore).',
 N'PARTIAL imports are normal and expected for large files with new SKUs. The platform only errors on rows where the SKU doesn''t exist yet. After a PARTIAL import, upload your Inventory Report first to register all SKUs, then re-import the failed file.',
 N'Do not repeatedly upload the same file when you see a PARTIAL status. Check the error log first. Most PARTIAL imports are caused by a handful of unknown SKUs, not a systemic problem.',
 20);

-- ============================================================
-- SECTION 4: INVENTORY MANAGEMENT
-- ============================================================
INSERT INTO dbo.HelpTopics (SectionNumber, SectionName, TopicCode, TopicName, WhatItDoes, WhenToUseIt, StepByStep, ProTip, CommonMistake, SortOrder) VALUES

(4, 'Inventory Management Features', 'S4_REORDER_SUGGESTIONS',
 'Understanding the Reorder Suggestions Grid',
 N'The Reorder Suggestions grid shows you every active SKU ranked by urgency, with calculated reorder points, suggested order quantities, and days of supply remaining. All calculations are done entirely in SQL using your actual sales history and lead times — there is no manual configuration required beyond entering lead times and reorder points in Settings.',
 N'Check this grid every morning as part of your daily routine. It is your primary tool for preventing stockouts.',
 N'1. Click [Inventory Manager] in the left navigation.
2. Click [Reorder Suggestions].
3. The grid loads with all active SKUs sorted by Urgency Score (highest first).

UNDERSTANDING THE COLUMNS:
- Current FBA Qty: Units currently in Amazon fulfillment centers available to ship.
- Qty Inbound: Units already shipped to Amazon but not yet received. These are "on the way."
- Total Available: FBA + Inbound combined. This is your real available supply.
- Daily Sales Velocity: Average units sold per day over the last 90 days.
- Days of Supply Remaining: Total Available ÷ Daily Sales Velocity. How many days until you run out.
- Reorder Point: The quantity at which you should place your next order. Calculated as (Daily Velocity × Lead Time) + Safety Stock.
- Suggested Order Qty: The recommended quantity to order, covering 30 days of projected demand plus safety stock.
- Urgency Score: 0-100 scale. 100 = out of stock now. 90+ = critically low, order immediately. 50-89 = reorder needed. Under 50 = monitor.

4. Filter by Urgency Score: click the [Urgency Score] column header to sort descending, or use the filter icon to show only HIGH urgency items.
5. For any SKU you want to act on: click the row to expand it and see the full calculation breakdown.',
 N'Focus on the "Days of Supply Remaining" column, not just the Urgency Score. A SKU with a 21-day lead time that has 22 days of supply needs an order placed TODAY — even though the Urgency Score may not show as critical yet.',
 N'Sellers often look only at "Current FBA Qty" and ignore "Qty Inbound." If you have 500 units inbound and 50 in FBA, your actual supply is 550 units, not 50. Always use "Total Available" when assessing whether to order.',
 10),

(4, 'Inventory Management Features', 'S4_AGED_INVENTORY',
 'Aged Inventory Fee Risk Table',
 N'Amazon charges storage surcharges for inventory that has been in fulfillment centers for extended periods. As of 2024-2025, these surcharges apply at 181 days, 271 days, and 365+ days. The Aged Inventory Fee Risk table shows you which SKUs are approaching these thresholds and calculates the estimated surcharge cost vs. the cost of creating a removal order — so you can make an informed financial decision.',
 N'Check this report at least once per month. Set a recurring calendar reminder for the 1st of each month.',
 N'1. Click [Inventory Manager] > [Aged Inventory Fee Risk].
2. The table shows all SKUs with units that have been in FBA for 90+ days.

AGE TIER MEANINGS:
- UNDER_90: Normal — no surcharges. No action needed.
- 91_TO_180: Monitor. These units will hit the first surcharge threshold in 91-180 days.
- 181_TO_270: ACTIVE SURCHARGE of $0.50/unit/month. If you have 500 units in this tier, you are paying ~$250/month extra.
- 271_TO_365: ACTIVE SURCHARGE of $1.00/unit/month. 500 units = $500/month extra storage fees.
- 365_PLUS: HIGHEST SURCHARGE — $6.90/cubic foot or $0.15/unit minimum (whichever is greater).

3. Review the "Recommended Action" column:
   - CREATE_REMOVAL_ORDER: The platform calculated that the removal cost is less than 3 months of surcharges. Create a removal order.
   - MONITOR — WILL_SELL_THROUGH: At current sales velocity, units will sell before major surcharges accrue.
   - REVIEW_AND_DECIDE: Neither clearly better — use your judgment.

4. To create a removal order based on this report: note the SKU and quantity, then log into Seller Central > Inventory > Create Removal Order.',
 N'The 181-day threshold is based on the date the unit was received at the FC, not the date you created the shipment. Download the FBA Inventory Age report from Seller Central monthly and upload it to get accurate age data in the platform.',
 N'Many sellers wait until they receive a notification from Amazon about upcoming surcharges. By then it is often too late to create a removal order in time. The platform''s 150-day alert threshold gives you 31 days of lead time before the first surcharge hits.',
 30);

-- ============================================================
-- SECTION 5-11: Key topics (condensed for database storage, full content)
-- ============================================================
INSERT INTO dbo.HelpTopics (SectionNumber, SectionName, TopicCode, TopicName, WhatItDoes, WhenToUseIt, StepByStep, ProTip, CommonMistake, SortOrder) VALUES

(5, 'Case Management', 'S5_CREATE_CASE',
 'How to Open a New Case',
 N'The Case Manager lets you track every claim, dispute, or appeal you have with Amazon Seller Support from inside the platform. Opening a case here creates a record linked to the relevant product, audit finding, and timeline — so you never lose track of a claim or miss a deadline.',
 N'Open a case any time you identify a reimbursement opportunity, a listing issue, a hijack, a discrepancy, or an account problem. Always open the case in the platform first, then file the corresponding case in Amazon Seller Support, and enter the Amazon Case ID here for tracking.',
 N'1. Click [Case Manager] in the left navigation.
2. Click [+ New Case] in the top right.
3. In the "Case Type" dropdown, select the appropriate type:
   - LOST_INVENTORY: Units removed from inventory without explanation
   - DAMAGED_INVENTORY: Units damaged by Amazon
   - FEE_OVERCHARGE: Incorrect FBA fees charged
   - RETURNLESS_REFUND: Refund issued to customer, no return received
   - LISTING_SUPPRESSION: Your listing was suppressed
   - HIJACK_REPORT: Unauthorized seller on your listing
   - ACCOUNT_SUSPENSION: Account suspended — requires POA
   - INBOUND_DISCREPANCY: FC received fewer units than you shipped
   - AWD_LOSS: Units lost in AWD pipeline
4. Enter the Subject line — be descriptive (e.g., "Lost Inventory — ASIN B0XXXXX — 47 units — Jan 2025").
5. Enter the ASIN in the ASIN field.
6. Set Priority: LOW / MEDIUM / HIGH / CRITICAL.
7. If this case came from a Refund Audit finding, click [Link to Audit Finding] and select the audit record.
8. Click [Create Case].
9. The system assigns an SLA due date based on the case type''s default SLA.
10. Go to Amazon Seller Support and file the corresponding case. Copy the Amazon Case ID.
11. Return to your case in the platform, click [Edit], enter the Amazon Case ID, and click [Save].',
 N'Always link your platform case to the relevant audit finding before creating. This auto-updates the audit record status to CASE_FILED and ensures the reimbursement deadline is tracked correctly.',
 N'The most common mistake is filing a case in Amazon Seller Support but never creating a corresponding record in the platform. Without a platform record, there is no SLA tracking, no deadline alert, and no way to report on recovery amounts.',
 10),

(6, 'Refund & Reimbursement Auditor', 'S6_MONTHLY_CHECKLIST',
 'Running the Monthly Reimbursement Checklist',
 N'The Monthly Reimbursement Checklist is a comprehensive audit that runs automatically across all reimbursement categories — lost inventory, returnless refunds, fee overcharges, inbound discrepancies, and COGS completeness — for a selected month. It returns a prioritized action list with the dollar amount at stake for each item.',
 N'Run this checklist on the first Monday of every month after uploading all reports for the prior month (Reimbursements, Inventory Adjustments, Returns, and Inbound Shipments).',
 N'1. Ensure all four reports have been uploaded for the period you are auditing:
   - Reimbursements Report (last 30 days)
   - Inventory Adjustments Report (last 30 days)
   - Customer Returns Report (last 30 days)
   - Inbound Shipments Report (last 30 days)
2. Click [Refund Auditor] > [Monthly Checklist].
3. Select the Month and Year from the dropdowns.
4. Click [Run Checklist].
5. The checklist will display rows for each audit category with:
   - ChecklistItem: the audit type
   - StatusDetail: a summary of what was found
   - PotentialAmountUSD: the total claimable amount
   - ActionRequired: FILE_CASE, UPDATE_COGS, REVIEW, or NO_ACTION
   - ActionInstructions: exactly what to do

6. Work through each ACTION REQUIRED item from top to bottom.
7. For FILE_CASE items: go to Case Manager > New Case, select the case type, and file the claim.
8. For UPDATE_COGS items: go to Settings > COGS Manager and enter the missing COGS values first, then re-run the checklist.
9. Export the checklist results using the [Export to PDF] or [Export to Excel] button for your records.',
 N'The COGS completeness check at the bottom of the checklist is just as important as the loss audits. If you have ASINs with missing COGS, all loss calculations for those ASINs show $0, meaning you could be underfiling claims significantly.',
 N'Do not run the checklist before uploading all four required reports. If you run it with only the Reimbursements report uploaded, it will show no discrepancies — because it has nothing to cross-reference against.',
 10),

(6, 'Refund & Reimbursement Auditor', 'S6_2025_COGS_POLICY',
 'How the 2025 Amazon Reimbursement Policy Works (COGS Basis)',
 N'On March 10, 2025, Amazon changed how it calculates reimbursements for lost and damaged FBA inventory. Under the old policy, Amazon reimbursed at approximately the selling price (or Amazon''s own estimate of fair market value). Under the new 2025 policy, Amazon reimburses at the seller''s documented cost of goods (COGS). This means a product you sell for $30 but paid $8 for will now be reimbursed at $8, not $25. This change has significant financial implications for all FBA sellers.',
 N'Understand this policy change before filing any reimbursement claims. The ClaimableAmount in every audit report in this platform now reflects the 2025 cost-basis calculation.',
 N'HOW THE PLATFORM CALCULATES YOUR CLAIMABLE AMOUNT:

ClaimableAmount = Quantity Variance × COGS per Unit

Example:
- ASIN: B0EXAMPLE
- Units Lost: 10
- Your COGS entered in platform: $8.50 per unit
- ClaimableAmount: 10 × $8.50 = $85.00

WHAT THIS MEANS FOR YOU:
1. Entering accurate COGS is now more critical than ever. Previously, Amazon estimated value independently. Now, YOUR documented cost is the basis.
2. You must be able to prove your COGS with supplier invoices. Amazon may ask for documentation.
3. If your COGS is $0 or missing, your reimbursement will be $0 regardless of the quantity lost.
4. Keep supplier invoices organized and accessible — store them in Google Drive or attach them to cases.

HOW TO CHECK YOUR COGS ACCURACY:
1. Go to Settings > COGS Manager.
2. Review the "COGS vs. Buy Box Price" column. Your COGS should be 20-60% of your selling price for most products.
3. If COGS shows as more than 80% of your selling price, double-check — you may have entered selling price by mistake.',
 N'Store a PDF of every supplier invoice in a designated cloud folder organized by ASIN or SKU. When filing a reimbursement case, you can attach these directly as evidence. Amazon is increasingly requesting COGS documentation before approving claims.',
 N'Entering your selling price as COGS is the most damaging error. Amazon will only pay your cost, and if your "COGS" is $25 and your actual cost is $8, you have correctly documented $25 as your cost — Amazon may hold you to that. Enter only what you actually paid your supplier.',
 20),

(7, 'Sales & Financial Reports', 'S7_PL_REPORT',
 'How to Run a P&L Report by SKU',
 N'The P&L (Profit and Loss) Report by SKU is the most important financial report in the platform. It shows you — for any date range you select — your revenue, COGS, FBA fees, referral fees, storage fees, PPC spend, refunds, reimbursements, net profit, and margin percentage for every individual SKU. It is the complete financial picture for your business broken down to the product level.',
 N'Run this report monthly as your primary business review, before reordering inventory, when evaluating whether to discontinue a product, and when presenting financial summaries to clients or partners.',
 N'1. Click [Sales Reports] > [P&L by SKU].
2. Select the Seller Account from the dropdown.
3. Set the Date From and Date To fields. Common ranges: Last 30 days, Last 90 days, Last 12 months, Year to date.
4. Choose Group By: SKU (default), Brand, or Category for aggregated views.
5. Click [Run Report].
6. The report loads showing all SKUs sorted by Net Profit (highest first).

READING THE FEE WATERFALL:
Revenue
  − Referral Fee (Amazon''s commission, typically 8-15%)
  − FBA Fulfillment Fee (pick, pack, ship)
  − Storage Fees (monthly + any surcharges)
  − PPC Spend (advertising cost)
  − COGS (what you paid for the product)
  − Returns/Refunds issued
  + Reimbursements received
  = NET PROFIT

7. Click any SKU row to expand the full fee waterfall chart for that product.
8. Use the [Export to Excel] button to download the full dataset for further analysis.
9. Red net profit figures indicate unprofitable SKUs — investigate the largest negative margins first.',
 N'Filter by Net Margin % descending to find your most efficient SKUs (highest profit relative to revenue). A SKU with $5,000 revenue but 45% net margin is more valuable than one with $20,000 revenue and 8% margin.',
 N'The P&L report is only as accurate as your COGS data. A SKU with no COGS entered will show an artificially high net profit because the cost of inventory is missing. Always check the "COGS Warning" column — any SKU flagged there has unreliable profit figures.',
 10),

(8, 'PPC Analyzer', 'S8_WASTED_SPEND',
 'Reading the Wasted Spend Report',
 N'The Wasted Spend report identifies keywords and search terms in your PPC campaigns that are spending money without generating orders or sales. These are dollars being burned with no return. The report shows you exactly which keywords to pause, reduce bids on, or add as negative keywords.',
 N'Review this report every week after uploading your PPC Search Term CSV. Focus on the highest-spend, zero-conversion keywords first.',
 N'1. Upload your PPC Search Term Report CSV via CSV Import Center first.
2. Click [PPC Analyzer] > [Campaign Audit].
3. Set the date range to match your uploaded report period.
4. Click [Run Audit].
5. The Wasted Spend section shows all keywords flagged as:
   - "PAUSE — Zero conversions with $X spent": This keyword has cost you money but generated zero orders. Pause it immediately.
   - "REVIEW — ACoS > 50%": This keyword is converting but at an unsustainably high advertising cost. Reduce bid or add bid cap.

6. For each PAUSE recommendation:
   a. Note the Campaign Name and Keyword.
   b. Log into Amazon Campaign Manager.
   c. Navigate to the campaign and ad group.
   d. Find the keyword and change its status to PAUSED.
   e. Consider adding it as a NEGATIVE keyword to prevent it from triggering future ads.

7. For each REVIEW recommendation:
   a. Reduce the bid by 20-30%.
   b. Check if the keyword matches broad, phrase, or exact — broad match generates the most wasted spend.',
 N'Before pausing any keyword, check its lifetime performance, not just the selected period. A keyword that spent $50 last month with no sales might have generated $500 in sales the month before. Use a 90-day view for high-conviction pauses.',
 N'Do not pause a keyword the same day you see it underperforming. Advertising data has a 48-hour attribution window — sales from today may not appear in the report until the day after tomorrow. Always wait at least 7 days of data before pausing.',
 10),

(9, 'Listing Health Manager', 'S9_HEALTH_SCORE',
 'Reading the Listing Health Score',
 N'The Listing Health Score gives every ASIN a score out of 100 based on five factors: Title quality (25 points), Bullet points (20 points), Images (20 points), A+ Content (15 points), and Backend Keywords (20 points). Each factor is scored based on best practices for Amazon listings that maximize conversion rates and search rank.',
 N'Review listing health scores when onboarding new products, after any listing changes, monthly as part of your account health review, and any time sales velocity drops unexpectedly.',
 N'1. Click [Listing Health] in the left navigation.
2. Select the Seller Account.
3. Click [Run Health Scan].
4. The grid shows all active ASINs with their overall score and component scores.

SCORE BREAKDOWN:
Title (0-25 points):
- 25 points: 150-200 characters including brand, primary keyword, key features
- 18 points: 100-149 characters — good but could be expanded
- 12 points: 50-99 characters — needs improvement
- 0 points: Missing or under 50 characters — critical issue

Bullets (0-20 points):
- 20 points: All 5 bullet points present
- Each missing bullet costs 4 points

Images (0-20 points):
- 20 points: 7+ images
- 15 points: 5-6 images (Amazon''s minimum for sponsored ads eligibility)
- Under 3 images: critical — conversion rates plummet

A+ Content (0-15 points):
- 15 points: A+ Content present — estimated 3-10% conversion rate lift
- 0 points: No A+ Content — major opportunity

Backend Keywords (0-20 points):
- 20 points: 200+ characters of search terms
- Fill all 250 bytes with relevant keywords not already in title or bullets

5. Click any ASIN to see specific recommendations for improvement.',
 N'The fastest ROI improvement in listing health is usually A+ Content for products that don''t have it. It takes 2-3 hours to create and Amazon studies show it lifts conversion rates by 3-10%, which compounds directly into more sales every day.',
 N'Do not repeat keywords in the backend search terms that already appear in your title, bullet points, or description. Amazon''s algorithm already indexes those. Use backend keywords exclusively for secondary keywords, alternate spellings, common misspellings, and related terms.',
 10),

(10, 'Alerts & Notifications', 'S10_ALERT_TYPES',
 'Understanding Every Alert Type and What to Do',
 N'The Alert Center is the real-time notification hub for everything that requires your attention across all seller accounts. Alerts are generated automatically by the platform''s background jobs every 2-4 hours. Each alert type has a specific severity level and recommended action.',
 N'Check the Alert Center every morning as the first step of your daily routine. Never end a work day with unread CRITICAL or HIGH alerts.',
 N'ALERT TYPE REFERENCE:

LOW_STOCK (HIGH severity):
What it means: A product''s FBA quantity has dropped below the reorder point threshold.
Action: Go to Inventory Manager > Reorder Suggestions and place a purchase order immediately.

OUT_OF_STOCK (CRITICAL severity):
What it means: FBA quantity is 0. You are currently losing sales.
Action: Place an emergency order with your supplier. Consider FBM as a bridge if possible.

OVERSTOCK (MEDIUM severity):
What it means: Days of supply exceeds your threshold (default 90 days).
Action: Run Overstock Report. Consider price reduction, removal order, or pausing inbound shipments.

STRANDED_INVENTORY (HIGH severity):
What it means: Units are at an FBA fulfillment center but have no active listing to sell from.
Action: Go to Seller Central > Inventory > Fix Stranded Inventory and follow the fix instructions.

AGED_FEE_RISK (MEDIUM severity):
What it means: Units are approaching the 181-day long-term storage fee threshold.
Action: Go to Inventory Manager > Aged Inventory Report and evaluate removal vs. surcharge cost.

HIJACK_DETECTED (CRITICAL severity):
What it means: An unauthorized seller has added an offer to your listing or taken your Buy Box.
Action: Go to Case Manager > New Case > HIJACK_REPORT. Use the Hijack Report Builder to prepare evidence. File via Amazon Brand Registry.

BUY_BOX_LOST (HIGH severity):
What it means: Your listing is no longer winning the Buy Box, meaning customers clicking "Add to Cart" are buying from a competitor.
Action: Check your current price vs. competitor prices in Listing Health > Buy Box Loss Report.

CASE_SLA_BREACH (HIGH severity):
What it means: An open case has exceeded its SLA deadline without resolution.
Action: Go to Case Manager, find the case, and escalate using the escalation template.

NEW_REIMBURSEMENT_OPPORTUNITY (MEDIUM severity):
What it means: The nightly audit found a new unclaimed reimbursement opportunity.
Action: Go to Refund Auditor > Monthly Checklist and review the new finding.

REIMBURSEMENT_DEADLINE (CRITICAL severity):
What it means: A reimbursement claim is approaching its 18-month filing deadline.
Action: File a case in Amazon Seller Support immediately. Do not wait.

FEE_SPIKE (MEDIUM severity):
What it means: FBA fees for a product increased significantly vs. historical average.
Action: Check if Amazon re-measured the product dimensions and changed the fee tier.

LISTING_SUPPRESSED (HIGH severity):
What it means: Amazon has suppressed a listing, removing it from search results.
Action: Log into Seller Central > Inventory > Fix Stranded Inventory to see the suppression reason and fix it.

AWD_DISCREPANCY (HIGH severity):
What it means: Units sent to AWD did not all appear in FBA.
Action: Go to Inventory Manager > AWD Discrepancies and file an inbound discrepancy case.

COGS_MISSING (MEDIUM severity):
What it means: One or more active ASINs have no COGS entered.
Action: Go to Settings > COGS Manager and enter cost for all flagged ASINs immediately.',
 N'Use the Alert Center as your daily "single pane of glass." Start with CRITICAL alerts, then HIGH, then MEDIUM. If your Alert Center has more than 10 unread CRITICAL alerts, you need to increase the frequency of your daily check-in routine.',
 N'The most common mistake is reading alerts but not acting on them. An alert is not resolved by marking it "Read" — it is resolved by taking the recommended action. REIMBURSEMENT_DEADLINE alerts in particular must be acted on the same day they appear.',
 10),

(11, 'VA (Virtual Assistant) Guide', 'S11_VA_GUIDE',
 'Complete VA Guide — Daily, Weekly, and Monthly Routines',
 N'This guide is written specifically for Virtual Assistants (VAs) who support Amazon FBA operations. It covers your daily responsibilities, what you are authorized to do, and most importantly, what you must never do without manager approval. Your role is to keep data flowing into the platform and flag issues — not to make decisions.',
 N'Read this entire section before your first day of work. Refer back to it any time you are unsure about a task.',
 N'=== YOUR DAILY MORNING ROUTINE (Every Weekday by 10:00 AM) ===

STEP 1 — Log into the FBA Platform
1. Open the platform URL in your browser.
2. Log in with your credentials (never share your password).
3. Confirm the correct Seller Account is selected in the top-left dropdown.

STEP 2 — Download Reports from Amazon Seller Central
1. Log into Seller Central at sellercentral.amazon.com.
2. Download the FBA Inventory Report: Reports > Fulfillment > All Listings > Request Download.
3. Download the Order Report: Orders > Order Reports > New Report > select yesterday as date range.
4. Save both files to your computer.

STEP 3 — Upload Reports to the Platform
1. Click CSV Import Center in the left menu.
2. For each file: click + New Import, select the Seller Account, select the Report Type, drag and drop the file, click Start Import.
3. Wait for Status = COMPLETE.
4. If Status = FAILED or PARTIAL: copy the error message and include in your daily report. Do not try to fix it yourself.

STEP 4 — Check the Alert Center
1. Click Alert Center.
2. Look at all CRITICAL and HIGH alerts.
3. Write down every alert in your daily report.
4. Mark LOW and MEDIUM alerts as Read if no action is needed.
5. Do NOT resolve or close any alert — this is for managers only.

STEP 5 — Check Reorder Suggestions
1. Click Inventory Manager > Reorder Suggestions.
2. Sort or filter by Urgency Score = HIGH or CRITICAL.
3. Write down every flagged SKU, its current FBA qty, and days of supply.
4. Do NOT place orders — include the list in your daily report for the manager.

STEP 6 — Send Your Daily Report
Send to your manager by the agreed time using this format:
--- DAILY FBA REPORT [DATE] ---
REPORTS UPLOADED: [list each report with status]
ALERTS FOUND: [list critical/high alerts]
REORDER SKUs: [list flagged SKUs with days of supply]
CASES UPDATED: [any case note updates added]
ISSUES / QUESTIONS: [anything unusual]
--- END REPORT ---

=== WEEKLY ROUTINE (Every Monday) ===
1. Download: Reimbursements Report (last 30 days), Inventory Adjustments (last 30 days), Returns Report (last 30 days)
2. Upload all three via CSV Import Center
3. Go to Refund Auditor > Monthly Checklist — if it is the first Monday of the month, run the checklist and include results in your weekly report

=== WHAT YOU MUST NEVER DO ===
1. NEVER change COGS values for any product — only managers update COGS
2. NEVER delete any import records
3. NEVER close, resolve, or change the status of any case without written manager instruction
4. NEVER share your login credentials
5. NEVER contact Amazon Seller Support directly
6. NEVER make changes to product listings, prices, or account settings
7. NEVER open reimbursement cases with Amazon without manager approval
8. NEVER export and share any data outside the team without manager approval',
 N'If you are ever unsure whether you are allowed to do something, the answer is: do not do it, and ask your manager. It is always better to ask than to make an irreversible change.',
 N'The most common VA mistake is trying to be helpful by acting on alerts or fixing issues without authorization. Your job is to report and document, not to act. Every action that changes data or files claims with Amazon has financial and legal implications. Always defer to your manager.',
 10);

GO

-- Verify help topics seeded
SELECT SectionNumber, SectionName, COUNT(*) AS TopicCount
FROM dbo.HelpTopics
GROUP BY SectionNumber, SectionName
ORDER BY SectionNumber;
GO
