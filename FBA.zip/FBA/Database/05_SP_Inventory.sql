-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 05_SP_Inventory.sql
-- DESC: All inventory management stored procedures
-- ============================================================
SET NOCOUNT ON;
GO

USE AmazonFBAManager;
GO

-- ============================================================
-- SP: Reorder Suggestions (EOQ + Safety Stock model)
-- ============================================================
CREATE PROCEDURE dbo.usp_Inventory_GetReorderSuggestions
    @SellerAccountId    INT,
    @UserId             INT,
    @LeadTimeDays       INT     = 30,
    @ServiceLevel       DECIMAL(5,4) = 0.95   -- 95% service level
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    -- Z-score for service level: 95% = 1.645, 99% = 2.326
    DECLARE @ZScore DECIMAL(5,3) =
        CASE
            WHEN @ServiceLevel >= 0.99 THEN 2.326
            WHEN @ServiceLevel >= 0.95 THEN 1.645
            WHEN @ServiceLevel >= 0.90 THEN 1.282
            ELSE 1.000
        END;

    ;WITH SalesVelocity AS (
        -- Daily sales velocity: average units/day over last 90 days
        SELECT
            soi.ProductId,
            SUM(soi.QtySold) AS TotalUnitsSold90Days,
            CAST(SUM(soi.QtySold) AS DECIMAL(18,4)) / 90.0 AS DailySalesVelocity,
            STDEV(DailyQty.DailyUnits) AS StdDevDailySales
        FROM dbo.SalesOrderItems soi
        INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
        INNER JOIN (
            -- Daily aggregation for std dev
            SELECT
                soi2.ProductId,
                CAST(so2.OrderDate AS DATE) AS OrderDay,
                SUM(soi2.QtySold) AS DailyUnits
            FROM dbo.SalesOrderItems soi2
            INNER JOIN dbo.SalesOrders so2 ON so2.OrderId = soi2.OrderId
            WHERE so2.SellerAccountId = @SellerAccountId
              AND so2.OrderDate >= DATEADD(DAY, -90, SYSUTCDATETIME())
            GROUP BY soi2.ProductId, CAST(so2.OrderDate AS DATE)
        ) AS DailyQty ON DailyQty.ProductId = soi.ProductId
        WHERE so.SellerAccountId = @SellerAccountId
          AND so.OrderDate >= DATEADD(DAY, -90, SYSUTCDATETIME())
        GROUP BY soi.ProductId
    ),
    LatestSnapshot AS (
        SELECT
            sn.ProductId,
            sn.QtyFBA,
            sn.QtyInbound,
            sn.SnapshotDate,
            ROW_NUMBER() OVER (PARTITION BY sn.ProductId ORDER BY sn.SnapshotDate DESC) AS rn
        FROM dbo.InventorySnapshots sn
        WHERE sn.SellerAccountId = @SellerAccountId
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        ls.QtyFBA                                                   AS CurrentFBAQty,
        ls.QtyInbound                                               AS QtyInbound,
        ls.QtyFBA + ls.QtyInbound                                   AS TotalAvailable,
        ROUND(sv.DailySalesVelocity, 2)                             AS DailySalesVelocity,
        sv.TotalUnitsSold90Days,
        COALESCE(p.LeadTimeDays, @LeadTimeDays)                     AS LeadTimeDays,

        -- Reorder Point = (Daily Velocity × Lead Time) + Safety Stock
        -- Safety Stock = Z × StdDev × SQRT(LeadTime)
        ROUND(
            sv.DailySalesVelocity * COALESCE(p.LeadTimeDays, @LeadTimeDays)
            + @ZScore * COALESCE(sv.StdDevDailySales, sv.DailySalesVelocity * 0.2)
                      * SQRT(COALESCE(p.LeadTimeDays, @LeadTimeDays))
        , 0)                                                        AS CalculatedReorderPoint,

        COALESCE(p.ReorderPoint,
            ROUND(
                sv.DailySalesVelocity * COALESCE(p.LeadTimeDays, @LeadTimeDays)
                + @ZScore * COALESCE(sv.StdDevDailySales, sv.DailySalesVelocity * 0.2)
                          * SQRT(COALESCE(p.LeadTimeDays, @LeadTimeDays))
            , 0)
        )                                                           AS ActiveReorderPoint,

        -- Suggested order quantity (EOQ-style: 30-day demand + safety stock)
        ROUND(
            sv.DailySalesVelocity * 30
            + @ZScore * COALESCE(sv.StdDevDailySales, sv.DailySalesVelocity * 0.2)
                      * SQRT(COALESCE(p.LeadTimeDays, @LeadTimeDays))
        , 0)                                                        AS SuggestedOrderQty,

        -- Days of supply remaining
        CASE WHEN sv.DailySalesVelocity > 0
            THEN ROUND((ls.QtyFBA + ls.QtyInbound) / sv.DailySalesVelocity, 0)
            ELSE 9999
        END                                                         AS DaysOfSupplyRemaining,

        -- Urgency Score: 0-100 (100 = out of stock, higher = more urgent)
        CASE
            WHEN ls.QtyFBA = 0 THEN 100
            WHEN sv.DailySalesVelocity > 0 AND
                 ROUND((ls.QtyFBA) / sv.DailySalesVelocity, 0) <= 7 THEN 90
            WHEN sv.DailySalesVelocity > 0 AND
                 ROUND((ls.QtyFBA + ls.QtyInbound) / sv.DailySalesVelocity, 0)
                     <= COALESCE(p.LeadTimeDays, @LeadTimeDays) + 7 THEN 75
            WHEN sv.DailySalesVelocity > 0 AND
                 ls.QtyFBA <= COALESCE(p.ReorderPoint, 0) THEN 50
            ELSE CAST(
                GREATEST(0, 30 - ROUND((ls.QtyFBA + ls.QtyInbound) / NULLIF(sv.DailySalesVelocity, 0) - COALESCE(p.LeadTimeDays, @LeadTimeDays), 0))
                AS INT)
        END                                                         AS UrgencyScore,

        p.COGS,
        p.COGS * ROUND(sv.DailySalesVelocity * 30, 0)              AS EstOrderCOGS

    FROM dbo.Products p
    INNER JOIN SalesVelocity sv ON sv.ProductId = p.ProductId
    INNER JOIN LatestSnapshot ls ON ls.ProductId = p.ProductId AND ls.rn = 1
    WHERE p.SellerAccountId = @SellerAccountId
      AND p.IsActive = 1
    ORDER BY
        UrgencyScore DESC,
        DaysOfSupplyRemaining ASC;
END;
GO

-- ============================================================
-- SP: Overstock Report
-- ============================================================
CREATE PROCEDURE dbo.usp_Inventory_GetOverstockReport
    @SellerAccountId        INT,
    @UserId                 INT,
    @DaysOfSupplyThreshold  INT = 90
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    ;WITH SalesVelocity AS (
        SELECT
            soi.ProductId,
            CAST(SUM(soi.QtySold) AS DECIMAL(18,4)) / 90.0 AS DailySalesVelocity
        FROM dbo.SalesOrderItems soi
        INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
        WHERE so.SellerAccountId = @SellerAccountId
          AND so.OrderDate >= DATEADD(DAY, -90, SYSUTCDATETIME())
        GROUP BY soi.ProductId
    ),
    LatestSnapshot AS (
        SELECT ProductId, QtyFBA, SnapshotDate,
               ROW_NUMBER() OVER (PARTITION BY ProductId ORDER BY SnapshotDate DESC) AS rn
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        ls.QtyFBA,
        ROUND(sv.DailySalesVelocity, 2)                     AS DailySalesVelocity,
        CASE WHEN sv.DailySalesVelocity > 0
            THEN ROUND(ls.QtyFBA / sv.DailySalesVelocity, 0)
            ELSE 9999
        END                                                 AS DaysOfSupply,
        -- Est storage cost next 90 days (standard size ~$0.87/cu ft/month, estimate)
        ROUND(ls.QtyFBA * 0.03, 2)                          AS EstStorageCost90Days,
        -- Excess units beyond 60-day target
        CASE WHEN sv.DailySalesVelocity > 0
            THEN GREATEST(0, ROUND(ls.QtyFBA - sv.DailySalesVelocity * 60, 0))
            ELSE ls.QtyFBA
        END                                                 AS ExcessUnits,
        -- Liquidation savings vs long-term storage risk
        CASE WHEN sv.DailySalesVelocity > 0
            THEN ROUND(
                GREATEST(0, ls.QtyFBA - sv.DailySalesVelocity * 60) * 0.03 * 3
                , 2)
            ELSE 0
        END                                                 AS PotentialStorageSavings,
        -- Markdown suggestion: price to move in 30 days
        -- If velocity doubled at X% discount, suggests 10-20% markdown
        CASE WHEN sv.DailySalesVelocity > 0 AND
             ROUND(ls.QtyFBA / sv.DailySalesVelocity, 0) > @DaysOfSupplyThreshold
            THEN 'Consider 10-15% price reduction or removal order for excess units.'
            ELSE NULL
        END                                                 AS MarkdownSuggestion,
        ls.SnapshotDate
    FROM dbo.Products p
    INNER JOIN SalesVelocity sv ON sv.ProductId = p.ProductId
    INNER JOIN LatestSnapshot ls ON ls.ProductId = p.ProductId AND ls.rn = 1
    WHERE p.SellerAccountId = @SellerAccountId
      AND p.IsActive = 1
      AND (
            sv.DailySalesVelocity = 0
            OR ROUND(ls.QtyFBA / NULLIF(sv.DailySalesVelocity, 0), 0) > @DaysOfSupplyThreshold
          )
    ORDER BY DaysOfSupply DESC;
END;
GO

-- ============================================================
-- SP: Aged Inventory Fee Risk
-- ============================================================
CREATE PROCEDURE dbo.usp_Inventory_GetAgedInventoryFeeRisk
    @SellerAccountId    INT,
    @UserId             INT,
    @SnapshotDate       DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF @SnapshotDate IS NULL
        SET @SnapshotDate = CAST(SYSUTCDATETIME() AS DATE);

    -- Amazon long-term storage fee rates (2024-2025):
    -- 181-270 days: $0.50/unit/month surcharge
    -- 271-365 days: $1.00/unit/month surcharge
    -- 365+ days:    $6.90/cu ft or $0.15/unit minimum (whichever is greater)

    ;WITH LatestSnapshot AS (
        SELECT ProductId, QtyFBA,
               ROW_NUMBER() OVER (PARTITION BY ProductId ORDER BY SnapshotDate DESC) AS rn
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId
    ),
    SalesVelocity AS (
        SELECT soi.ProductId,
               CAST(SUM(soi.QtySold) AS DECIMAL(18,4)) / 90.0 AS DailySalesVelocity
        FROM dbo.SalesOrderItems soi
        INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
        WHERE so.SellerAccountId = @SellerAccountId
          AND so.OrderDate >= DATEADD(DAY, -90, SYSUTCDATETIME())
        GROUP BY soi.ProductId
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        ls.QtyFBA,
        ROUND(COALESCE(sv.DailySalesVelocity, 0), 2)   AS DailySalesVelocity,
        -- Estimated oldest unit age based on inbound history
        -- Without unit-level age data, we model using inbound shipment dates
        DATEDIFF(DAY,
            COALESCE(
                (SELECT MIN(s.ArrivedDate)
                 FROM dbo.InboundShipmentItems si
                 INNER JOIN dbo.InboundShipments s ON s.ShipmentId = si.ShipmentId
                 WHERE si.ProductId = p.ProductId AND s.SellerAccountId = @SellerAccountId),
                @SnapshotDate
            ),
            @SnapshotDate
        )                                               AS EstOldestUnitAgeDays,
        -- Categorize into age tiers
        CASE
            WHEN DATEDIFF(DAY, COALESCE(
                    (SELECT MIN(ish.ArrivedDate) FROM dbo.InboundShipments ish
                     INNER JOIN dbo.InboundShipmentItems isit ON isit.ShipmentId = ish.ShipmentId
                     WHERE isit.ProductId = p.ProductId AND ish.SellerAccountId = @SellerAccountId),
                    @SnapshotDate), @SnapshotDate) > 365 THEN '365_PLUS'
            WHEN DATEDIFF(DAY, COALESCE(
                    (SELECT MIN(ish.ArrivedDate) FROM dbo.InboundShipments ish
                     INNER JOIN dbo.InboundShipmentItems isit ON isit.ShipmentId = ish.ShipmentId
                     WHERE isit.ProductId = p.ProductId AND ish.SellerAccountId = @SellerAccountId),
                    @SnapshotDate), @SnapshotDate) > 270 THEN '271_TO_365'
            WHEN DATEDIFF(DAY, COALESCE(
                    (SELECT MIN(ish.ArrivedDate) FROM dbo.InboundShipments ish
                     INNER JOIN dbo.InboundShipmentItems isit ON isit.ShipmentId = ish.ShipmentId
                     WHERE isit.ProductId = p.ProductId AND ish.SellerAccountId = @SellerAccountId),
                    @SnapshotDate), @SnapshotDate) > 180 THEN '181_TO_270'
            WHEN DATEDIFF(DAY, COALESCE(
                    (SELECT MIN(ish.ArrivedDate) FROM dbo.InboundShipments ish
                     INNER JOIN dbo.InboundShipmentItems isit ON isit.ShipmentId = ish.ShipmentId
                     WHERE isit.ProductId = p.ProductId AND ish.SellerAccountId = @SellerAccountId),
                    @SnapshotDate), @SnapshotDate) > 90 THEN '91_TO_180'
            ELSE 'UNDER_90'
        END                                             AS AgeTier,
        -- Est monthly surcharge based on age tier
        CASE
            WHEN ls.QtyFBA > 0 THEN
                ls.QtyFBA *
                CASE
                    WHEN DATEDIFF(DAY, COALESCE(
                            (SELECT MIN(ish2.ArrivedDate) FROM dbo.InboundShipments ish2
                             INNER JOIN dbo.InboundShipmentItems isit2 ON isit2.ShipmentId = ish2.ShipmentId
                             WHERE isit2.ProductId = p.ProductId AND ish2.SellerAccountId = @SellerAccountId),
                            @SnapshotDate), @SnapshotDate) > 365 THEN 0.15
                    WHEN DATEDIFF(DAY, COALESCE(
                            (SELECT MIN(ish2.ArrivedDate) FROM dbo.InboundShipments ish2
                             INNER JOIN dbo.InboundShipmentItems isit2 ON isit2.ShipmentId = ish2.ShipmentId
                             WHERE isit2.ProductId = p.ProductId AND ish2.SellerAccountId = @SellerAccountId),
                            @SnapshotDate), @SnapshotDate) > 270 THEN 1.00
                    WHEN DATEDIFF(DAY, COALESCE(
                            (SELECT MIN(ish2.ArrivedDate) FROM dbo.InboundShipments ish2
                             INNER JOIN dbo.InboundShipmentItems isit2 ON isit2.ShipmentId = ish2.ShipmentId
                             WHERE isit2.ProductId = p.ProductId AND ish2.SellerAccountId = @SellerAccountId),
                            @SnapshotDate), @SnapshotDate) > 180 THEN 0.50
                    ELSE 0
                END
            ELSE 0
        END                                             AS EstMonthlySurchargeUSD,
        -- Removal cost estimate: $0.97/unit standard size
        ROUND(ls.QtyFBA * 0.97, 2)                      AS EstRemovalCostUSD,
        -- Recommendation: is it cheaper to remove now vs pay surcharges?
        CASE
            WHEN ls.QtyFBA * 0.97 <
                 ls.QtyFBA *
                 CASE
                     WHEN DATEDIFF(DAY, COALESCE(
                             (SELECT MIN(ish3.ArrivedDate) FROM dbo.InboundShipments ish3
                              INNER JOIN dbo.InboundShipmentItems isit3 ON isit3.ShipmentId = ish3.ShipmentId
                              WHERE isit3.ProductId = p.ProductId AND ish3.SellerAccountId = @SellerAccountId),
                             @SnapshotDate), @SnapshotDate) > 365 THEN 0.45  -- 3 months at $0.15
                     WHEN DATEDIFF(DAY, COALESCE(
                             (SELECT MIN(ish3.ArrivedDate) FROM dbo.InboundShipments ish3
                              INNER JOIN dbo.InboundShipmentItems isit3 ON isit3.ShipmentId = ish3.ShipmentId
                              WHERE isit3.ProductId = p.ProductId AND ish3.SellerAccountId = @SellerAccountId),
                             @SnapshotDate), @SnapshotDate) > 270 THEN 3.00  -- 3 months at $1.00
                     WHEN DATEDIFF(DAY, COALESCE(
                             (SELECT MIN(ish3.ArrivedDate) FROM dbo.InboundShipments ish3
                              INNER JOIN dbo.InboundShipmentItems isit3 ON isit3.ShipmentId = ish3.ShipmentId
                              WHERE isit3.ProductId = p.ProductId AND ish3.SellerAccountId = @SellerAccountId),
                             @SnapshotDate), @SnapshotDate) > 150 THEN 1.50
                     ELSE 0
                 END
                THEN 'CREATE_REMOVAL_ORDER'
            WHEN COALESCE(sv.DailySalesVelocity, 0) > 0 AND
                 ROUND(ls.QtyFBA / sv.DailySalesVelocity, 0) < 90
                THEN 'MONITOR — WILL_SELL_THROUGH'
            ELSE 'REVIEW_AND_DECIDE'
        END                                             AS RecommendedAction
    FROM dbo.Products p
    INNER JOIN LatestSnapshot ls ON ls.ProductId = p.ProductId AND ls.rn = 1
    LEFT JOIN SalesVelocity sv ON sv.ProductId = p.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
      AND p.IsActive = 1
      AND ls.QtyFBA > 0
    ORDER BY EstMonthlySurchargeUSD DESC;
END;
GO

-- ============================================================
-- SP: Get Stranded Inventory
-- ============================================================
CREATE PROCEDURE dbo.usp_Inventory_GetStrandedInventory
    @SellerAccountId    INT,
    @UserId             INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    ;WITH LatestSnapshot AS (
        SELECT ProductId, QtyFBA, SnapshotDate,
               ROW_NUMBER() OVER (PARTITION BY ProductId ORDER BY SnapshotDate DESC) AS rn
        FROM dbo.InventorySnapshots
        WHERE SellerAccountId = @SellerAccountId
    ),
    LatestListing AS (
        SELECT ProductId, ListingStatus, SuppressedReason, BuyBoxPrice, SnapshotDate,
               ROW_NUMBER() OVER (PARTITION BY ProductId ORDER BY SnapshotDate DESC) AS rn
        FROM dbo.Listings
        WHERE SellerAccountId = @SellerAccountId
    ),
    SalesVelocity AS (
        SELECT soi.ProductId,
               CAST(SUM(soi.QtySold) AS DECIMAL(18,4)) / 30.0 AS DailySalesVelocity30
        FROM dbo.SalesOrderItems soi
        INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
        WHERE so.SellerAccountId = @SellerAccountId
          AND so.OrderDate >= DATEADD(DAY, -30, SYSUTCDATETIME())
        GROUP BY soi.ProductId
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        ls.QtyFBA                                               AS QtyStranded,
        ll.ListingStatus,
        ll.SuppressedReason                                     AS StrandReason,
        ROUND(COALESCE(sv.DailySalesVelocity30, 0), 2)         AS DailySalesVelocity,
        -- Daily storage cost estimate (standard $0.87/cu ft/mo ÷ 30 × estimated 0.5 cu ft)
        ROUND(ls.QtyFBA * 0.87 / 30 * 0.5, 4)                 AS DailyStorageCostEst,
        CASE ll.ListingStatus
            WHEN 'STRANDED'     THEN 'Fix listing issue in Seller Central > Inventory > Fix Stranded Inventory'
            WHEN 'SUPPRESSED'   THEN 'Resolve suppression: ' + COALESCE(ll.SuppressedReason, 'Check Seller Central')
            WHEN 'INACTIVE'     THEN 'Relist product or check pricing policy compliance'
            ELSE 'Review listing status'
        END                                                     AS RecommendedAction,
        ll.SnapshotDate                                         AS ListingSnapshotDate
    FROM dbo.Products p
    INNER JOIN LatestSnapshot ls ON ls.ProductId = p.ProductId AND ls.rn = 1
    LEFT JOIN LatestListing ll ON ll.ProductId = p.ProductId AND ll.rn = 1
    LEFT JOIN SalesVelocity sv ON sv.ProductId = p.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
      AND p.IsActive = 1
      AND ls.QtyFBA > 0
      AND (
            ll.ListingStatus IN ('STRANDED','SUPPRESSED','INACTIVE')
            OR ll.ProductId IS NULL    -- Snapshot has units but no listing record at all
          )
    ORDER BY ls.QtyFBA DESC;
END;
GO

-- ============================================================
-- SP: IPI Improvement Actions
-- ============================================================
CREATE PROCEDURE dbo.usp_Inventory_GetIPIImprovementActions
    @SellerAccountId    INT,
    @UserId             INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    -- IPI is driven by 4 factors Amazon weights:
    -- 1. Excess inventory ratio (aim < 0.15)
    -- 2. FBA sell-through rate (aim > 0.1)
    -- 3. Stranded inventory % (aim = 0)
    -- 4. In-stock rate for restock-eligible items (aim > 0.95)

    ;WITH Metrics AS (
        SELECT
            sn.SellerAccountId,
            SUM(sn.QtyFBA)                                              AS TotalFBAUnits,
            SUM(CASE WHEN l.ListingStatus IN ('STRANDED','SUPPRESSED') THEN sn.QtyFBA ELSE 0 END) AS StrandedUnits,
            SUM(CASE WHEN p.ReorderPoint IS NOT NULL AND sn.QtyFBA <= p.ReorderPoint THEN 1 ELSE 0 END) AS LowStockASINs,
            COUNT(DISTINCT sn.ProductId)                                AS TotalASINs,
            MAX(sn.IPI_Score)                                           AS CurrentIPI
        FROM dbo.InventorySnapshots sn
        INNER JOIN dbo.Products p ON p.ProductId = sn.ProductId
        LEFT JOIN (
            SELECT ProductId, ListingStatus,
                   ROW_NUMBER() OVER (PARTITION BY ProductId ORDER BY SnapshotDate DESC) AS rn
            FROM dbo.Listings
            WHERE SellerAccountId = @SellerAccountId
        ) l ON l.ProductId = sn.ProductId AND l.rn = 1
        WHERE sn.SellerAccountId = @SellerAccountId
          AND sn.SnapshotDate = (
              SELECT MAX(SnapshotDate) FROM dbo.InventorySnapshots
              WHERE SellerAccountId = @SellerAccountId
          )
    ),
    OverstockASINs AS (
        SELECT COUNT(*) AS OverstockCount
        FROM dbo.Products p
        INNER JOIN (
            SELECT ProductId, QtyFBA,
                   ROW_NUMBER() OVER (PARTITION BY ProductId ORDER BY SnapshotDate DESC) AS rn
            FROM dbo.InventorySnapshots WHERE SellerAccountId = @SellerAccountId
        ) sn ON sn.ProductId = p.ProductId AND sn.rn = 1
        LEFT JOIN (
            SELECT soi.ProductId,
                   CAST(SUM(soi.QtySold) AS DECIMAL) / 90.0 AS Velocity
            FROM dbo.SalesOrderItems soi
            INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
            WHERE so.SellerAccountId = @SellerAccountId
              AND so.OrderDate >= DATEADD(DAY, -90, SYSUTCDATETIME())
            GROUP BY soi.ProductId
        ) v ON v.ProductId = p.ProductId
        WHERE p.SellerAccountId = @SellerAccountId
          AND (v.Velocity IS NULL OR sn.QtyFBA / NULLIF(v.Velocity, 0) > 90)
    )
    SELECT
        'REDUCE_EXCESS_INVENTORY'   AS ActionType,
        m.TotalFBAUnits,
        oa.OverstockCount           AS AffectedASINCount,
        ROUND(CAST(oa.OverstockCount AS DECIMAL) / NULLIF(m.TotalASINs, 0) * 100, 1) AS ExcessRatioPct,
        CASE WHEN oa.OverstockCount > 0 THEN
            ROUND(CAST(oa.OverstockCount AS DECIMAL) / NULLIF(m.TotalASINs, 0) * 20, 1)
            ELSE 0 END              AS PotentialIPIGain,
        1                           AS Priority,
        N'Create removal orders or markdown promotions for ' + CAST(oa.OverstockCount AS NVARCHAR)
            + N' ASINs with 90+ days of supply. Excess inventory ratio is the highest IPI driver.' AS ActionDescription,
        m.CurrentIPI
    FROM Metrics m
    CROSS JOIN OverstockASINs oa
    WHERE oa.OverstockCount > 0

    UNION ALL

    SELECT
        'FIX_STRANDED_INVENTORY',
        m.TotalFBAUnits,
        m.StrandedUnits,
        ROUND(CAST(m.StrandedUnits AS DECIMAL) / NULLIF(m.TotalFBAUnits, 0) * 100, 1),
        CASE WHEN m.StrandedUnits > 0 THEN 15.0 ELSE 0 END,
        2,
        N'Fix or relist ' + CAST(m.StrandedUnits AS NVARCHAR)
            + N' stranded units. Stranded inventory directly reduces IPI score. Target: 0 stranded units.',
        m.CurrentIPI
    FROM Metrics m
    WHERE m.StrandedUnits > 0

    UNION ALL

    SELECT
        'IMPROVE_SELL_THROUGH',
        m.TotalFBAUnits,
        m.TotalASINs,
        NULL,
        10.0,
        3,
        N'Increase PPC spend on slow-moving ASINs or run Lightning Deals to improve sell-through rate above 0.1 (10 units/13 weeks).',
        m.CurrentIPI
    FROM Metrics m

    ORDER BY Priority;
END;
GO

-- ============================================================
-- SP: FBA vs FBM Comparison
-- ============================================================
CREATE PROCEDURE dbo.usp_Inventory_CompareFBAFBM
    @ProductId          INT,
    @SellerAccountId    INT,
    @UserId             INT,
    @FBMShippingCost    DECIMAL(18,4) = 5.00,   -- default FBM ship cost
    @FBMPackagingCost   DECIMAL(18,4) = 1.50
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    ;WITH ProductData AS (
        SELECT
            p.ProductId,
            p.SKU,
            p.ASIN,
            p.ProductTitle,
            p.COGS,
            p.WeightLbs,
            -- Latest Buy Box price
            (SELECT TOP 1 l.BuyBoxPrice FROM dbo.Listings l
             WHERE l.ProductId = p.ProductId AND l.SellerAccountId = @SellerAccountId
             ORDER BY l.SnapshotDate DESC) AS BuyBoxPrice,
            -- Latest FBA fulfillment fee (most recent actual charge)
            (SELECT TOP 1 ABS(f.FeeAmount) FROM dbo.FBAFees f
             WHERE f.ProductId = p.ProductId AND f.FeeTypeCode = 'FBA_FULFILLMENT'
             ORDER BY f.FeeDate DESC) AS FBAFulfillmentFee,
            -- Latest referral fee (approx)
            (SELECT TOP 1 ABS(f.FeeAmount) FROM dbo.FBAFees f
             WHERE f.ProductId = p.ProductId AND f.FeeTypeCode = 'REFERRAL_FEE'
             ORDER BY f.FeeDate DESC) AS ReferralFee
        FROM dbo.Products p
        WHERE p.ProductId = @ProductId
          AND p.SellerAccountId = @SellerAccountId
    )
    SELECT
        pd.ProductId,
        pd.SKU,
        pd.ASIN,
        pd.BuyBoxPrice,
        pd.COGS,

        -- FBA CALCULATION
        pd.BuyBoxPrice                                  AS FBA_Revenue,
        COALESCE(pd.ReferralFee, pd.BuyBoxPrice * 0.15) AS FBA_ReferralFee,
        COALESCE(pd.FBAFulfillmentFee, 3.50)            AS FBA_FulfillmentFee,
        pd.COGS                                         AS FBA_COGS,
        pd.BuyBoxPrice
            - COALESCE(pd.ReferralFee, pd.BuyBoxPrice * 0.15)
            - COALESCE(pd.FBAFulfillmentFee, 3.50)
            - pd.COGS                                   AS FBA_NetProfit,
        ROUND((pd.BuyBoxPrice
            - COALESCE(pd.ReferralFee, pd.BuyBoxPrice * 0.15)
            - COALESCE(pd.FBAFulfillmentFee, 3.50)
            - pd.COGS) / NULLIF(pd.BuyBoxPrice, 0) * 100, 2) AS FBA_MarginPct,

        -- FBM CALCULATION
        pd.BuyBoxPrice                                  AS FBM_Revenue,
        COALESCE(pd.ReferralFee, pd.BuyBoxPrice * 0.15) AS FBM_ReferralFee,
        @FBMShippingCost                                AS FBM_ShippingCost,
        @FBMPackagingCost                               AS FBM_PackagingCost,
        pd.COGS                                         AS FBM_COGS,
        pd.BuyBoxPrice
            - COALESCE(pd.ReferralFee, pd.BuyBoxPrice * 0.15)
            - @FBMShippingCost
            - @FBMPackagingCost
            - pd.COGS                                   AS FBM_NetProfit,
        ROUND((pd.BuyBoxPrice
            - COALESCE(pd.ReferralFee, pd.BuyBoxPrice * 0.15)
            - @FBMShippingCost
            - @FBMPackagingCost
            - pd.COGS) / NULLIF(pd.BuyBoxPrice, 0) * 100, 2) AS FBM_MarginPct,

        -- RECOMMENDATION
        CASE
            WHEN (pd.BuyBoxPrice
                - COALESCE(pd.ReferralFee, pd.BuyBoxPrice * 0.15)
                - COALESCE(pd.FBAFulfillmentFee, 3.50)
                - pd.COGS) >
                 (pd.BuyBoxPrice
                - COALESCE(pd.ReferralFee, pd.BuyBoxPrice * 0.15)
                - @FBMShippingCost - @FBMPackagingCost
                - pd.COGS)
                THEN 'FBA'
            ELSE 'FBM'
        END AS RecommendedChannel,

        -- Break-even sales rank (where FBA and FBM margin equalize)
        -- FBA wins at high velocity due to Prime badge; FBM wins at low volume
        'FBA preferred above ~50 units/month due to Prime badge and search rank boost.' AS BreakevenNote

    FROM ProductData pd;
END;
GO

-- ============================================================
-- SP: AWD Discrepancies
-- ============================================================
CREATE PROCEDURE dbo.usp_Inventory_GetAWDDiscrepancies
    @SellerAccountId    INT,
    @UserId             INT,
    @DateFrom           DATE = NULL,
    @DateTo             DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF @DateFrom IS NULL SET @DateFrom = DATEADD(MONTH, -6, CAST(SYSUTCDATETIME() AS DATE));
    IF @DateTo IS NULL SET @DateTo = CAST(SYSUTCDATETIME() AS DATE);

    SELECT
        s.AmazonShipmentId,
        s.ShipmentName,
        s.ShippedDate,
        s.ArrivedDate,
        s.DestinationFC,
        si.ASIN,
        si.SKU,
        p.ProductTitle,
        si.QtyShipped,
        si.QtyReceived,
        si.QtyShipped - si.QtyReceived          AS QtyVariance,
        p.COGS,
        (si.QtyShipped - si.QtyReceived) * COALESCE(p.COGS, 0) AS EstClaimableAmount,
        -- Link to any existing case for this shipment
        c.CaseId,
        c.Status                                AS CaseStatus,
        CASE
            WHEN c.CaseId IS NOT NULL THEN 'CASE_FILED'
            WHEN (si.QtyShipped - si.QtyReceived) > 0 THEN 'CLAIM_ELIGIBLE'
            ELSE 'NO_DISCREPANCY'
        END AS DispositionStatus,
        DATEADD(MONTH, 18, s.ShippedDate)       AS FilingDeadline
    FROM dbo.InboundShipments s
    INNER JOIN dbo.InboundShipmentItems si ON si.ShipmentId = s.ShipmentId
    INNER JOIN dbo.Products p ON p.ProductId = si.ProductId
    LEFT JOIN dbo.Cases c
        ON c.SellerAccountId = @SellerAccountId
       AND c.CaseTypeCode IN ('AWD_LOSS','INBOUND_DISCREPANCY')
       AND c.AmazonCaseId LIKE '%' + s.AmazonShipmentId + '%'
    WHERE s.SellerAccountId = @SellerAccountId
      AND s.IsAWD = 1
      AND (s.ShippedDate >= @DateFrom OR @DateFrom IS NULL)
      AND (s.ShippedDate <= @DateTo OR @DateTo IS NULL)
      AND si.QtyShipped > si.QtyReceived
    ORDER BY EstClaimableAmount DESC, s.ShippedDate DESC;
END;
GO
