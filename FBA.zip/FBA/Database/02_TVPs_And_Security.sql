-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 02_TVPs_And_Security.sql
-- DESC: Table-Valued Parameters, Security function, RLS
-- ============================================================
SET NOCOUNT ON;
GO

USE AmazonFBAManager;
GO

-- ============================================================
-- TABLE-VALUED PARAMETERS (TVPs)
-- Used to pass bulk CSV data from application to SPs
-- ============================================================

-- Inventory Snapshot TVP
CREATE TYPE dbo.TVP_InventorySnapshot AS TABLE (
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NOT NULL,
    FNSKU               VARCHAR(20)     NULL,
    QtyFBA              INT             NOT NULL DEFAULT 0,
    QtyFBM              INT             NOT NULL DEFAULT 0,
    QtyInbound          INT             NOT NULL DEFAULT 0,
    QtyReserved         INT             NOT NULL DEFAULT 0,
    QtyUnfulfillable    INT             NOT NULL DEFAULT 0,
    QtyWarehouseAWD     INT             NOT NULL DEFAULT 0,
    EstStorageCost      DECIMAL(18,4)   NULL,
    SnapshotDate        DATE            NOT NULL
);
GO

-- Sales Order TVP
CREATE TYPE dbo.TVP_SalesOrder AS TABLE (
    AmazonOrderId       VARCHAR(50)     NOT NULL,
    OrderDate           DATETIME2       NOT NULL,
    ShipDate            DATETIME2       NULL,
    FulfillmentChannel  VARCHAR(10)     NOT NULL DEFAULT 'AFN',
    OrderStatus         VARCHAR(30)     NOT NULL,
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NOT NULL,
    QtySold             INT             NOT NULL DEFAULT 1,
    ItemPrice           DECIMAL(18,4)   NOT NULL DEFAULT 0,
    PromotionDiscount   DECIMAL(18,4)   NOT NULL DEFAULT 0,
    ShippingPrice       DECIMAL(18,4)   NOT NULL DEFAULT 0,
    Currency            CHAR(3)         NOT NULL DEFAULT 'USD'
);
GO

-- FBA Fee TVP
CREATE TYPE dbo.TVP_FBAFee AS TABLE (
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NOT NULL,
    FeeDate             DATE            NOT NULL,
    FeeTypeCode         VARCHAR(50)     NOT NULL,
    FeeAmount           DECIMAL(18,4)   NOT NULL,
    ReferenceId         VARCHAR(100)    NULL,
    FulfillmentCenterId VARCHAR(20)     NULL
);
GO

-- Reimbursement TVP
CREATE TYPE dbo.TVP_Reimbursement AS TABLE (
    AmazonReimbId       VARCHAR(100)    NOT NULL,
    ReimbDate           DATE            NOT NULL,
    ASIN                VARCHAR(20)     NULL,
    SKU                 VARCHAR(100)    NULL,
    QtyReimbursed       INT             NOT NULL DEFAULT 0,
    AmountPerUnit       DECIMAL(18,4)   NOT NULL DEFAULT 0,
    TotalAmount         DECIMAL(18,4)   NOT NULL DEFAULT 0,
    ReimbType           VARCHAR(50)     NOT NULL
);
GO

-- Return TVP
CREATE TYPE dbo.TVP_Return AS TABLE (
    AmazonOrderId       VARCHAR(50)     NOT NULL,
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NULL,
    ReturnDate          DATE            NULL,
    CustomerRefundDate  DATE            NULL,
    ReturnReceivedDate  DATE            NULL,
    ReturnStatus        VARCHAR(30)     NOT NULL DEFAULT 'PENDING',
    ReturnReasonCode    VARCHAR(50)     NULL,
    Qty                 INT             NOT NULL DEFAULT 1,
    RefundAmount        DECIMAL(18,4)   NOT NULL DEFAULT 0,
    ReturnlessRefund    BIT             NOT NULL DEFAULT 0,
    DispositionCode     VARCHAR(30)     NULL,
    FulfillmentCenterId VARCHAR(20)     NULL
);
GO

-- Inventory Adjustment TVP
CREATE TYPE dbo.TVP_InventoryAdjustment AS TABLE (
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NOT NULL,
    AdjDate             DATETIME2       NOT NULL,
    AdjReasonCode       VARCHAR(50)     NOT NULL,
    QtyAdjusted         INT             NOT NULL,
    DispositionCode     VARCHAR(30)     NULL,
    FulfillmentCenterId VARCHAR(20)     NULL,
    TransactionItemId   VARCHAR(100)    NULL
);
GO

-- PPC Keyword TVP
CREATE TYPE dbo.TVP_PPCKeyword AS TABLE (
    AmazonCampaignId    VARCHAR(100)    NOT NULL,
    CampaignName        NVARCHAR(500)   NOT NULL,
    AdGroupId           VARCHAR(100)    NULL,
    AdGroupName         NVARCHAR(300)   NULL,
    KeywordText         NVARCHAR(500)   NOT NULL,
    MatchType           VARCHAR(20)     NOT NULL DEFAULT 'BROAD',
    ReportDate          DATE            NOT NULL,
    Impressions         BIGINT          NOT NULL DEFAULT 0,
    Clicks              INT             NOT NULL DEFAULT 0,
    Spend               DECIMAL(18,4)   NOT NULL DEFAULT 0,
    Sales               DECIMAL(18,4)   NOT NULL DEFAULT 0,
    Orders              INT             NOT NULL DEFAULT 0,
    IsSearchTerm        BIT             NOT NULL DEFAULT 0
);
GO

-- Inbound Shipment TVP
CREATE TYPE dbo.TVP_InboundShipment AS TABLE (
    AmazonShipmentId    VARCHAR(50)     NOT NULL,
    ShipmentName        NVARCHAR(300)   NULL,
    ShipmentStatus      VARCHAR(30)     NOT NULL,
    DestinationFC       VARCHAR(20)     NULL,
    ShippedDate         DATE            NULL,
    IsAWD               BIT             NOT NULL DEFAULT 0,
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NOT NULL,
    QtyShipped          INT             NOT NULL DEFAULT 0,
    QtyReceived         INT             NOT NULL DEFAULT 0
);
GO

-- ============================================================
-- ROW-LEVEL SECURITY HELPER FUNCTION
-- All SPs call this before executing any DML or SELECT
-- ============================================================

CREATE FUNCTION dbo.fn_UserHasAccountAccess
(
    @UserId             INT,
    @SellerAccountId    INT
)
RETURNS BIT
AS
BEGIN
    DECLARE @HasAccess BIT = 0;

    -- Admin role (RoleId=1) has access to everything
    IF EXISTS (
        SELECT 1
        FROM dbo.Users u
        WHERE u.UserId = @UserId
          AND u.RoleId = 1
          AND u.IsActive = 1
    )
        SET @HasAccess = 1;
    ELSE
    -- Check UserSellerAccounts mapping
    IF EXISTS (
        SELECT 1
        FROM dbo.UserSellerAccounts usa
        INNER JOIN dbo.Users u ON u.UserId = usa.UserId
        WHERE usa.UserId = @UserId
          AND usa.SellerAccountId = @SellerAccountId
          AND u.IsActive = 1
    )
        SET @HasAccess = 1;

    RETURN @HasAccess;
END;
GO

-- ============================================================
-- FUNCTION: Get user permission level for account
-- ============================================================

CREATE FUNCTION dbo.fn_GetUserPermissionLevel
(
    @UserId             INT,
    @SellerAccountId    INT
)
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @Level VARCHAR(20) = 'NONE';

    -- Admin always gets ADMIN level
    IF EXISTS (
        SELECT 1 FROM dbo.Users WHERE UserId = @UserId AND RoleId = 1 AND IsActive = 1
    )
    BEGIN
        SET @Level = 'ADMIN';
        RETURN @Level;
    END;

    SELECT @Level = COALESCE(usa.PermissionLevel, 'NONE')
    FROM dbo.UserSellerAccounts usa
    WHERE usa.UserId = @UserId
      AND usa.SellerAccountId = @SellerAccountId;

    RETURN @Level;
END;
GO

-- ============================================================
-- AUTH: Validate user access (used by API layer)
-- ============================================================

CREATE PROCEDURE dbo.usp_Auth_ValidateUserAccountAccess
    @UserId             INT,
    @SellerAccountId    INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SELECT
        dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId)      AS HasAccess,
        dbo.fn_GetUserPermissionLevel(@UserId, @SellerAccountId)     AS PermissionLevel,
        u.RoleId,
        r.RoleName,
        u.IsActive
    FROM dbo.Users u
    INNER JOIN dbo.Roles r ON r.RoleId = u.RoleId
    WHERE u.UserId = @UserId;
END;
GO

-- ============================================================
-- AUTH: Get all accounts accessible by a user
-- ============================================================

CREATE PROCEDURE dbo.usp_Auth_GetUserAccounts
    @UserId             INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE UserId = @UserId AND IsActive = 1)
    BEGIN
        RAISERROR('User not found or inactive.', 16, 1);
        RETURN;
    END;

    DECLARE @RoleId TINYINT;
    SELECT @RoleId = RoleId FROM dbo.Users WHERE UserId = @UserId;

    IF @RoleId = 1  -- Admin: return all active accounts
    BEGIN
        SELECT
            sa.SellerAccountId,
            sa.AccountName,
            sa.MarketplaceId,
            m.MarketplaceName,
            sa.Region,
            sa.DefaultCurrency,
            sa.IsActive,
            sa.OnboardingComplete,
            'ADMIN' AS PermissionLevel
        FROM dbo.SellerAccounts sa
        INNER JOIN dbo.Marketplaces m ON m.MarketplaceId = sa.MarketplaceId
        WHERE sa.IsActive = 1
        ORDER BY sa.AccountName;
    END
    ELSE
    BEGIN
        SELECT
            sa.SellerAccountId,
            sa.AccountName,
            sa.MarketplaceId,
            m.MarketplaceName,
            sa.Region,
            sa.DefaultCurrency,
            sa.IsActive,
            sa.OnboardingComplete,
            usa.PermissionLevel
        FROM dbo.UserSellerAccounts usa
        INNER JOIN dbo.SellerAccounts sa ON sa.SellerAccountId = usa.SellerAccountId
        INNER JOIN dbo.Marketplaces m ON m.MarketplaceId = sa.MarketplaceId
        WHERE usa.UserId = @UserId
          AND sa.IsActive = 1
        ORDER BY sa.AccountName;
    END
END;
GO
