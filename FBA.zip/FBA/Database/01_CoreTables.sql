-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 01_CoreTables.sql
-- DESC: All core tables with constraints, indexes, and FKs
-- SQL Server 2022 / Azure SQL compatible
-- ============================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

-- ============================================================
-- SECTION 1: DATABASE SETUP
-- ============================================================
USE AmazonFBAManager;
GO

-- Enable Read Committed Snapshot Isolation (avoid NOLOCK hacks)
ALTER DATABASE AmazonFBAManager
    SET READ_COMMITTED_SNAPSHOT ON;
GO

-- ============================================================
-- SECTION 2: LOOKUP / REFERENCE TABLES
-- ============================================================

CREATE TABLE dbo.Marketplaces (
    MarketplaceId       VARCHAR(20)     NOT NULL,
    MarketplaceName     VARCHAR(100)    NOT NULL,
    CountryCode         CHAR(2)         NOT NULL,
    CurrencyCode        CHAR(3)         NOT NULL,
    Region              VARCHAR(20)     NOT NULL,  -- NA, EU, FE
    Endpoint            VARCHAR(200)    NOT NULL,
    IsActive            BIT             NOT NULL    DEFAULT 1,
    CONSTRAINT PK_Marketplaces PRIMARY KEY (MarketplaceId)
);
GO

CREATE TABLE dbo.Roles (
    RoleId              TINYINT         NOT NULL,
    RoleName            VARCHAR(50)     NOT NULL,
    Description         VARCHAR(200)    NULL,
    CONSTRAINT PK_Roles PRIMARY KEY (RoleId)
);
GO

CREATE TABLE dbo.AlertTypes (
    AlertTypeCode       VARCHAR(50)     NOT NULL,
    AlertTypeName       VARCHAR(100)    NOT NULL,
    DefaultSeverity     VARCHAR(10)     NOT NULL    DEFAULT 'MEDIUM',  -- LOW,MEDIUM,HIGH,CRITICAL
    Description         VARCHAR(500)    NULL,
    CONSTRAINT PK_AlertTypes PRIMARY KEY (AlertTypeCode),
    CONSTRAINT CK_AlertTypes_Severity CHECK (DefaultSeverity IN ('LOW','MEDIUM','HIGH','CRITICAL'))
);
GO

CREATE TABLE dbo.CaseTypes (
    CaseTypeCode        VARCHAR(50)     NOT NULL,
    CaseTypeName        VARCHAR(100)    NOT NULL,
    Description         VARCHAR(500)    NULL,
    DefaultSLADays      TINYINT         NOT NULL    DEFAULT 7,
    RequiresPOA         BIT             NOT NULL    DEFAULT 0,
    CONSTRAINT PK_CaseTypes PRIMARY KEY (CaseTypeCode)
);
GO

CREATE TABLE dbo.FeeTypes (
    FeeTypeCode         VARCHAR(50)     NOT NULL,
    FeeTypeName         VARCHAR(100)    NOT NULL,
    Description         VARCHAR(300)    NULL,
    CONSTRAINT PK_FeeTypes PRIMARY KEY (FeeTypeCode)
);
GO

CREATE TABLE dbo.ReturnReasonCodes (
    ReasonCode          VARCHAR(50)     NOT NULL,
    ReasonDescription   VARCHAR(200)    NOT NULL,
    CONSTRAINT PK_ReturnReasonCodes PRIMARY KEY (ReasonCode)
);
GO

CREATE TABLE dbo.DispositionCodes (
    DispositionCode     VARCHAR(30)     NOT NULL,
    Description         VARCHAR(200)    NOT NULL,
    CONSTRAINT PK_DispositionCodes PRIMARY KEY (DispositionCode)
);
GO

CREATE TABLE dbo.InventoryAdjustmentReasons (
    ReasonCode          VARCHAR(50)     NOT NULL,
    ReasonDescription   VARCHAR(200)    NOT NULL,
    IsLossEvent         BIT             NOT NULL    DEFAULT 0,
    CONSTRAINT PK_InventoryAdjustmentReasons PRIMARY KEY (ReasonCode)
);
GO

CREATE TABLE dbo.ReportTypes (
    ReportTypeCode      VARCHAR(80)     NOT NULL,
    ReportTypeName      VARCHAR(150)    NOT NULL,
    Description         VARCHAR(500)    NULL,
    AmazonReportId      VARCHAR(100)    NULL,
    ExpectedFileFormat  VARCHAR(10)     NOT NULL    DEFAULT 'TSV',
    MaxDateRangeDays    INT             NULL,
    Notes               VARCHAR(500)    NULL,
    CONSTRAINT PK_ReportTypes PRIMARY KEY (ReportTypeCode)
);
GO

-- ============================================================
-- SECTION 3: USERS & SELLER ACCOUNTS
-- ============================================================

CREATE TABLE dbo.Users (
    UserId              INT             NOT NULL    IDENTITY(1,1),
    Username            VARCHAR(100)    NOT NULL,
    Email               VARCHAR(255)    NOT NULL,
    PasswordHash        VARCHAR(500)    NOT NULL,
    RoleId              TINYINT         NOT NULL    DEFAULT 3,
    FirstName           VARCHAR(100)    NULL,
    LastName            VARCHAR(100)    NULL,
    IsActive            BIT             NOT NULL    DEFAULT 1,
    LastLoginDate       DATETIME2       NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    ModifiedDate        DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_Users PRIMARY KEY (UserId),
    CONSTRAINT UQ_Users_Username UNIQUE (Username),
    CONSTRAINT UQ_Users_Email UNIQUE (Email),
    CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleId) REFERENCES dbo.Roles (RoleId)
);
GO

CREATE TABLE dbo.SellerAccounts (
    SellerAccountId         INT             NOT NULL    IDENTITY(1,1),
    AccountName             VARCHAR(200)    NOT NULL,
    MarketplaceId           VARCHAR(20)     NOT NULL,
    MerchantToken           VARCHAR(200)    NULL,
    SPAPIClientId           VARCHAR(200)    NULL,
    SPAPIClientSecret_Enc   VARBINARY(500)  NULL,   -- AES encrypted at rest
    RefreshToken_Enc        VARBINARY(1000) NULL,   -- AES encrypted at rest
    Region                  VARCHAR(20)     NOT NULL    DEFAULT 'NA',
    DefaultCurrency         CHAR(3)         NOT NULL    DEFAULT 'USD',
    TimeZone                VARCHAR(60)     NOT NULL    DEFAULT 'UTC',
    IsActive                BIT             NOT NULL    DEFAULT 1,
    OnboardingComplete      BIT             NOT NULL    DEFAULT 0,
    Notes                   NVARCHAR(1000)  NULL,
    CreatedDate             DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    ModifiedDate            DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_SellerAccounts PRIMARY KEY (SellerAccountId),
    CONSTRAINT FK_SellerAccounts_Marketplace FOREIGN KEY (MarketplaceId)
        REFERENCES dbo.Marketplaces (MarketplaceId)
);
GO

CREATE TABLE dbo.UserSellerAccounts (
    UserId              INT             NOT NULL,
    SellerAccountId     INT             NOT NULL,
    PermissionLevel     VARCHAR(20)     NOT NULL    DEFAULT 'READ',  -- READ,WRITE,ADMIN
    AssignedDate        DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    AssignedByUserId    INT             NULL,
    CONSTRAINT PK_UserSellerAccounts PRIMARY KEY (UserId, SellerAccountId),
    CONSTRAINT FK_USA_Users FOREIGN KEY (UserId) REFERENCES dbo.Users (UserId),
    CONSTRAINT FK_USA_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT CK_USA_Permission CHECK (PermissionLevel IN ('READ','WRITE','ADMIN'))
);
GO

-- ============================================================
-- SECTION 4: PRODUCTS
-- ============================================================

CREATE TABLE dbo.Products (
    ProductId           INT             NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NOT NULL,
    FNSKU               VARCHAR(20)     NULL,
    ProductTitle        NVARCHAR(500)   NOT NULL,
    Brand               NVARCHAR(200)   NULL,
    Category            NVARCHAR(200)   NULL,
    Subcategory         NVARCHAR(200)   NULL,
    UPC                 VARCHAR(20)     NULL,
    EAN                 VARCHAR(20)     NULL,
    WeightLbs           DECIMAL(10,4)   NULL,
    LengthIn            DECIMAL(10,4)   NULL,
    WidthIn             DECIMAL(10,4)   NULL,
    HeightIn            DECIMAL(10,4)   NULL,
    COGS                DECIMAL(18,4)   NULL,       -- Cost of Goods Sold per unit (USD)
    COGSEnteredDate     DATETIME2       NULL,
    TargetMarginPct     DECIMAL(5,2)    NULL,
    ReorderPoint        INT             NULL,
    ReorderQty          INT             NULL,
    LeadTimeDays        INT             NULL        DEFAULT 30,
    MinimumOrderQty     INT             NULL        DEFAULT 1,
    IsActive            BIT             NOT NULL    DEFAULT 1,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    ModifiedDate        DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_Products PRIMARY KEY (ProductId),
    CONSTRAINT FK_Products_SellerAccounts FOREIGN KEY (SellerAccountId)
        REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT UQ_Products_SellerSKU UNIQUE (SellerAccountId, SKU)
);
GO

CREATE INDEX IX_Products_SellerAccount ON dbo.Products (SellerAccountId) INCLUDE (ASIN, SKU, ProductTitle, IsActive);
CREATE INDEX IX_Products_ASIN ON dbo.Products (ASIN, SellerAccountId);
GO

-- ============================================================
-- SECTION 5: INVENTORY
-- ============================================================

CREATE TABLE dbo.InventorySnapshots (
    SnapshotId          BIGINT          NOT NULL    IDENTITY(1,1),
    ProductId           INT             NOT NULL,
    SellerAccountId     INT             NOT NULL,
    SnapshotDate        DATE            NOT NULL,
    QtyFBA              INT             NOT NULL    DEFAULT 0,
    QtyFBM              INT             NOT NULL    DEFAULT 0,
    QtyInbound          INT             NOT NULL    DEFAULT 0,
    QtyReserved         INT             NOT NULL    DEFAULT 0,
    QtyUnfulfillable    INT             NOT NULL    DEFAULT 0,
    QtyWarehouseAWD     INT             NOT NULL    DEFAULT 0,
    QtyResearchListed   INT             NOT NULL    DEFAULT 0,
    EstStorageCostMTD   DECIMAL(18,4)   NULL,
    IPI_Score           DECIMAL(5,2)    NULL,
    DataSource          VARCHAR(20)     NOT NULL    DEFAULT 'CSV',   -- CSV, SPAPI
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_InventorySnapshots PRIMARY KEY (SnapshotId),
    CONSTRAINT FK_IS_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId),
    CONSTRAINT FK_IS_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT UQ_IS_ProductDate UNIQUE (ProductId, SnapshotDate, DataSource)
);
GO

CREATE INDEX IX_InventorySnapshots_Account_Date ON dbo.InventorySnapshots (SellerAccountId, SnapshotDate DESC) INCLUDE (ProductId, QtyFBA, QtyInbound);
GO

CREATE TABLE dbo.InventoryAdjustments (
    AdjustmentId        BIGINT          NOT NULL    IDENTITY(1,1),
    ProductId           INT             NOT NULL,
    SellerAccountId     INT             NOT NULL,
    AdjDate             DATETIME2       NOT NULL,
    AdjReasonCode       VARCHAR(50)     NOT NULL,
    QtyAdjusted         INT             NOT NULL,
    DispositionCode     VARCHAR(30)     NULL,
    FulfillmentCenterId VARCHAR(20)     NULL,
    TransactionItemId   VARCHAR(100)    NULL,       -- Amazon's reference
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_InventoryAdjustments PRIMARY KEY (AdjustmentId),
    CONSTRAINT FK_IA_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId),
    CONSTRAINT FK_IA_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT FK_IA_Reasons FOREIGN KEY (AdjReasonCode) REFERENCES dbo.InventoryAdjustmentReasons (ReasonCode)
);
GO

CREATE INDEX IX_InventoryAdjustments_Product_Date ON dbo.InventoryAdjustments (ProductId, AdjDate DESC);
CREATE INDEX IX_InventoryAdjustments_Account_Date ON dbo.InventoryAdjustments (SellerAccountId, AdjDate DESC);
GO

-- ============================================================
-- SECTION 6: SALES ORDERS
-- ============================================================

CREATE TABLE dbo.SalesOrders (
    OrderId             BIGINT          NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    AmazonOrderId       VARCHAR(50)     NOT NULL,
    OrderDate           DATETIME2       NOT NULL,
    ShipDate            DATETIME2       NULL,
    FulfillmentChannel  VARCHAR(10)     NOT NULL    DEFAULT 'AFN',   -- AFN=FBA, MFN=FBM
    OrderStatus         VARCHAR(30)     NOT NULL,
    TotalAmount         DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    Currency            CHAR(3)         NOT NULL    DEFAULT 'USD',
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_SalesOrders PRIMARY KEY (OrderId),
    CONSTRAINT FK_SO_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT UQ_SO_AmazonOrderId UNIQUE (SellerAccountId, AmazonOrderId)
);
GO

CREATE INDEX IX_SalesOrders_Account_Date ON dbo.SalesOrders (SellerAccountId, OrderDate DESC);
GO

CREATE TABLE dbo.SalesOrderItems (
    OrderItemId         BIGINT          NOT NULL    IDENTITY(1,1),
    OrderId             BIGINT          NOT NULL,
    ProductId           INT             NULL,       -- NULL if unmatched ASIN
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NOT NULL,
    QtySold             INT             NOT NULL    DEFAULT 1,
    ItemPrice           DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    PromotionDiscount   DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    ShippingPrice       DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    GiftWrapPrice       DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    CONSTRAINT PK_SalesOrderItems PRIMARY KEY (OrderItemId),
    CONSTRAINT FK_SOI_Orders FOREIGN KEY (OrderId) REFERENCES dbo.SalesOrders (OrderId),
    CONSTRAINT FK_SOI_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId)
);
GO

CREATE INDEX IX_SalesOrderItems_Order ON dbo.SalesOrderItems (OrderId);
CREATE INDEX IX_SalesOrderItems_Product ON dbo.SalesOrderItems (ProductId, OrderItemId);
GO

-- ============================================================
-- SECTION 7: FEES & FINANCIALS
-- ============================================================

CREATE TABLE dbo.FBAFees (
    FeeId               BIGINT          NOT NULL    IDENTITY(1,1),
    ProductId           INT             NULL,
    SellerAccountId     INT             NOT NULL,
    FeeDate             DATE            NOT NULL,
    FeeTypeCode         VARCHAR(50)     NOT NULL,
    FeeAmount           DECIMAL(18,4)   NOT NULL,
    Currency            CHAR(3)         NOT NULL    DEFAULT 'USD',
    ReferenceId         VARCHAR(100)    NULL,
    FulfillmentCenterId VARCHAR(20)     NULL,
    ASIN                VARCHAR(20)     NULL,
    SKU                 VARCHAR(100)    NULL,
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_FBAFees PRIMARY KEY (FeeId),
    CONSTRAINT FK_Fees_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId),
    CONSTRAINT FK_Fees_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId)
);
GO

CREATE INDEX IX_FBAFees_Account_Date ON dbo.FBAFees (SellerAccountId, FeeDate DESC);
CREATE INDEX IX_FBAFees_Product_Date ON dbo.FBAFees (ProductId, FeeDate DESC);
GO

CREATE TABLE dbo.ProfitLoss (
    PLID                BIGINT          NOT NULL    IDENTITY(1,1),
    ProductId           INT             NOT NULL,
    SellerAccountId     INT             NOT NULL,
    PeriodStart         DATE            NOT NULL,
    PeriodEnd           DATE            NOT NULL,
    PeriodType          VARCHAR(10)     NOT NULL    DEFAULT 'MONTH',  -- DAY,WEEK,MONTH,QUARTER,YEAR
    Revenue             DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    COGS_Total          DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    FBAFees_Total       DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    ReferralFees_Total  DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    StorageFees_Total   DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    PPC_Spend           DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    RefundsIssued       DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    ReimbReceived       DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    NetProfit           DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    GrossMarginPct      DECIMAL(7,4)    NOT NULL    DEFAULT 0,
    NetMarginPct        DECIMAL(7,4)    NOT NULL    DEFAULT 0,
    ACoS                DECIMAL(7,4)    NULL,
    TACoS               DECIMAL(7,4)    NULL,
    ROI                 DECIMAL(7,4)    NULL,
    UnitsSold           INT             NOT NULL    DEFAULT 0,
    RecomputedDate      DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_ProfitLoss PRIMARY KEY (PLID),
    CONSTRAINT FK_PL_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId),
    CONSTRAINT FK_PL_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT UQ_PL_ProductPeriod UNIQUE (ProductId, PeriodStart, PeriodEnd, PeriodType)
);
GO

CREATE INDEX IX_PL_Account_Period ON dbo.ProfitLoss (SellerAccountId, PeriodStart DESC, PeriodType);
GO

-- ============================================================
-- SECTION 8: CASE MANAGEMENT
-- ============================================================

CREATE TABLE dbo.Cases (
    CaseId              INT             NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    AmazonCaseId        VARCHAR(50)     NULL,
    CaseTypeCode        VARCHAR(50)     NOT NULL,
    Status              VARCHAR(20)     NOT NULL    DEFAULT 'OPEN',
        -- OPEN, PENDING_AMAZON, ESCALATED, RESOLVED, CLOSED, ON_HOLD
    Priority            VARCHAR(10)     NOT NULL    DEFAULT 'MEDIUM',
        -- LOW, MEDIUM, HIGH, CRITICAL
    Subject             NVARCHAR(500)   NOT NULL,
    Description         NVARCHAR(MAX)   NULL,
    ProductId           INT             NULL,
    ASIN                VARCHAR(20)     NULL,
    OpenedDate          DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    SLADueDate          DATETIME2       NULL,
    ResolvedDate        DATETIME2       NULL,
    ResolvedAmount      DECIMAL(18,4)   NULL,
    AssignedUserId      INT             NULL,
    EscalationLevel     TINYINT         NOT NULL    DEFAULT 0,
    POARequired         BIT             NOT NULL    DEFAULT 0,
    LinkedAuditId       INT             NULL,
    CreatedByUserId     INT             NULL,
    ModifiedDate        DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_Cases PRIMARY KEY (CaseId),
    CONSTRAINT FK_Cases_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT FK_Cases_CaseTypes FOREIGN KEY (CaseTypeCode) REFERENCES dbo.CaseTypes (CaseTypeCode),
    CONSTRAINT FK_Cases_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId),
    CONSTRAINT FK_Cases_AssignedUser FOREIGN KEY (AssignedUserId) REFERENCES dbo.Users (UserId),
    CONSTRAINT CK_Cases_Status CHECK (Status IN ('OPEN','PENDING_AMAZON','ESCALATED','RESOLVED','CLOSED','ON_HOLD')),
    CONSTRAINT CK_Cases_Priority CHECK (Priority IN ('LOW','MEDIUM','HIGH','CRITICAL'))
);
GO

CREATE INDEX IX_Cases_Account_Status ON dbo.Cases (SellerAccountId, Status, OpenedDate DESC);
CREATE INDEX IX_Cases_AssignedUser ON dbo.Cases (AssignedUserId, Status);
GO

CREATE TABLE dbo.CaseNotes (
    NoteId              INT             NOT NULL    IDENTITY(1,1),
    CaseId              INT             NOT NULL,
    UserId              INT             NOT NULL,
    NoteDate            DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    NoteText            NVARCHAR(MAX)   NOT NULL,
    IsInternal          BIT             NOT NULL    DEFAULT 1,
    CONSTRAINT PK_CaseNotes PRIMARY KEY (NoteId),
    CONSTRAINT FK_CaseNotes_Cases FOREIGN KEY (CaseId) REFERENCES dbo.Cases (CaseId),
    CONSTRAINT FK_CaseNotes_Users FOREIGN KEY (UserId) REFERENCES dbo.Users (UserId)
);
GO

CREATE TABLE dbo.CaseAttachments (
    AttachmentId        INT             NOT NULL    IDENTITY(1,1),
    CaseId              INT             NOT NULL,
    FileName            NVARCHAR(500)   NOT NULL,
    StoragePath         NVARCHAR(1000)  NOT NULL,
    FileSizeBytes       BIGINT          NULL,
    MimeType            VARCHAR(100)    NULL,
    UploadedByUserId    INT             NULL,
    UploadDate          DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_CaseAttachments PRIMARY KEY (AttachmentId),
    CONSTRAINT FK_CA_Cases FOREIGN KEY (CaseId) REFERENCES dbo.Cases (CaseId)
);
GO

-- ============================================================
-- SECTION 9: REIMBURSEMENTS & AUDIT
-- ============================================================

CREATE TABLE dbo.ReimbursementAudit (
    AuditId             INT             NOT NULL    IDENTITY(1,1),
    ProductId           INT             NOT NULL,
    SellerAccountId     INT             NOT NULL,
    AuditDate           DATE            NOT NULL,
    AuditType           VARCHAR(50)     NOT NULL,
        -- LOST_INVENTORY, DAMAGED_INVENTORY, FEE_OVERCHARGE, RETURNLESS_REFUND,
        -- INBOUND_DISCREPANCY, AWD_LOSS, CUSTOMER_RETURN_NOT_RECEIVED
    QtyExpected         INT             NULL,
    QtyAmazonReported   INT             NULL,
    QtyVariance         INT             NULL,
    COGS_PerUnit        DECIMAL(18,4)   NULL,   -- snapshot of COGS at audit time
    ClaimableAmount     DECIMAL(18,4)   NULL,   -- QtyVariance * COGS_PerUnit (2025 policy)
    Status              VARCHAR(20)     NOT NULL    DEFAULT 'OPEN',
        -- OPEN, CASE_FILED, REIMBURSED, DENIED, DEADLINE_MISSED
    LinkedCaseId        INT             NULL,
    Notes               NVARCHAR(1000)  NULL,
    DeadlineDate        DATE            NULL,   -- 18-month filing window
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    ModifiedDate        DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_ReimbursementAudit PRIMARY KEY (AuditId),
    CONSTRAINT FK_RA_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId),
    CONSTRAINT FK_RA_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT FK_RA_Cases FOREIGN KEY (LinkedCaseId) REFERENCES dbo.Cases (CaseId)
);
GO

CREATE INDEX IX_ReimbAudit_Account_Status ON dbo.ReimbursementAudit (SellerAccountId, Status, AuditDate DESC);
CREATE INDEX IX_ReimbAudit_Deadline ON dbo.ReimbursementAudit (DeadlineDate) WHERE Status = 'OPEN';
GO

CREATE TABLE dbo.Reimbursements (
    ReimbId             INT             NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    AmazonReimbId       VARCHAR(100)    NOT NULL,
    ReimbDate           DATE            NOT NULL,
    ProductId           INT             NULL,
    ASIN                VARCHAR(20)     NULL,
    SKU                 VARCHAR(100)    NULL,
    QtyReimbursed       INT             NOT NULL    DEFAULT 0,
    AmountPerUnit       DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    TotalAmount         DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    ReimbType           VARCHAR(50)     NOT NULL,
    CaseId              INT             NULL,
    ApprovalStatus      VARCHAR(20)     NOT NULL    DEFAULT 'APPROVED',
    AuditId             INT             NULL,
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_Reimbursements PRIMARY KEY (ReimbId),
    CONSTRAINT FK_Reimb_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT FK_Reimb_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId),
    CONSTRAINT FK_Reimb_Cases FOREIGN KEY (CaseId) REFERENCES dbo.Cases (CaseId),
    CONSTRAINT UQ_Reimb_AmazonId UNIQUE (SellerAccountId, AmazonReimbId)
);
GO

CREATE INDEX IX_Reimbursements_Account_Date ON dbo.Reimbursements (SellerAccountId, ReimbDate DESC);
GO

-- ============================================================
-- SECTION 10: PPC / ADVERTISING
-- ============================================================

CREATE TABLE dbo.PPCCampaigns (
    CampaignId          INT             NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    AmazonCampaignId    VARCHAR(100)    NOT NULL,
    CampaignName        NVARCHAR(500)   NOT NULL,
    CampaignType        VARCHAR(30)     NOT NULL    DEFAULT 'SP',  -- SP, SB, SD
    TargetingType       VARCHAR(20)     NOT NULL    DEFAULT 'MANUAL',
    State               VARCHAR(20)     NOT NULL    DEFAULT 'ENABLED',
    DailyBudget         DECIMAL(18,4)   NULL,
    StartDate           DATE            NULL,
    EndDate             DATE            NULL,
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_PPCCampaigns PRIMARY KEY (CampaignId),
    CONSTRAINT FK_PPC_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT UQ_PPC_AmazonCampaignId UNIQUE (SellerAccountId, AmazonCampaignId)
);
GO

CREATE TABLE dbo.PPCKeywords (
    KeywordId           BIGINT          NOT NULL    IDENTITY(1,1),
    CampaignId          INT             NOT NULL,
    SellerAccountId     INT             NOT NULL,
    AdGroupId           VARCHAR(100)    NULL,
    AdGroupName         NVARCHAR(300)   NULL,
    KeywordText         NVARCHAR(500)   NOT NULL,
    MatchType           VARCHAR(20)     NOT NULL    DEFAULT 'BROAD',  -- BROAD,PHRASE,EXACT
    Bid                 DECIMAL(18,4)   NULL,
    ReportDate          DATE            NOT NULL,
    Impressions         BIGINT          NOT NULL    DEFAULT 0,
    Clicks              INT             NOT NULL    DEFAULT 0,
    Spend               DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    Sales               DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    Orders              INT             NOT NULL    DEFAULT 0,
    ACoS                DECIMAL(7,4)    NULL,
    ROAS                DECIMAL(10,4)   NULL,
    CTR                 DECIMAL(7,4)    NULL,
    CVR                 DECIMAL(7,4)    NULL,
    IsSearchTerm        BIT             NOT NULL    DEFAULT 0,  -- 1 = from search term report
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_PPCKeywords PRIMARY KEY (KeywordId),
    CONSTRAINT FK_PPCK_Campaigns FOREIGN KEY (CampaignId) REFERENCES dbo.PPCCampaigns (CampaignId)
);
GO

CREATE INDEX IX_PPCKeywords_Campaign_Date ON dbo.PPCKeywords (CampaignId, ReportDate DESC);
CREATE INDEX IX_PPCKeywords_Account_Date ON dbo.PPCKeywords (SellerAccountId, ReportDate DESC);
GO

-- ============================================================
-- SECTION 11: LISTINGS
-- ============================================================

CREATE TABLE dbo.Listings (
    ListingId           INT             NOT NULL    IDENTITY(1,1),
    ProductId           INT             NOT NULL,
    SellerAccountId     INT             NOT NULL,
    Title               NVARCHAR(500)   NULL,
    BulletPoint1        NVARCHAR(1000)  NULL,
    BulletPoint2        NVARCHAR(1000)  NULL,
    BulletPoint3        NVARCHAR(1000)  NULL,
    BulletPoint4        NVARCHAR(1000)  NULL,
    BulletPoint5        NVARCHAR(1000)  NULL,
    Description         NVARCHAR(MAX)   NULL,
    APlusContent        NVARCHAR(MAX)   NULL,
    BackendKeywords     NVARCHAR(1000)  NULL,
    SearchTerms         NVARCHAR(1000)  NULL,
    BuyBoxPrice         DECIMAL(18,4)   NULL,
    LowestOfferPrice    DECIMAL(18,4)   NULL,
    BSR                 INT             NULL,
    CategoryBSR         INT             NULL,
    BSRCategory         NVARCHAR(200)   NULL,
    ReviewCount         INT             NOT NULL    DEFAULT 0,
    StarRating          DECIMAL(3,2)    NULL,
    ListingStatus       VARCHAR(20)     NOT NULL    DEFAULT 'ACTIVE',
        -- ACTIVE, INACTIVE, SUPPRESSED, STRANDED, DELETED
    SuppressedReason    NVARCHAR(500)   NULL,
    IsIndexed           BIT             NULL,
    HasAPlusContent     BIT             NOT NULL    DEFAULT 0,
    ImageCount          TINYINT         NOT NULL    DEFAULT 0,
    SnapshotDate        DATE            NOT NULL    DEFAULT CAST(SYSUTCDATETIME() AS DATE),
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_Listings PRIMARY KEY (ListingId),
    CONSTRAINT FK_Listings_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId),
    CONSTRAINT FK_Listings_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId)
);
GO

CREATE INDEX IX_Listings_Account_Status ON dbo.Listings (SellerAccountId, ListingStatus, SnapshotDate DESC);
GO

-- ============================================================
-- SECTION 12: RETURNS
-- ============================================================

CREATE TABLE dbo.Returns (
    ReturnId            BIGINT          NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    AmazonOrderId       VARCHAR(50)     NOT NULL,
    ProductId           INT             NULL,
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NULL,
    ReturnDate          DATE            NULL,
    CustomerRefundDate  DATE            NULL,
    ReturnReceivedDate  DATE            NULL,
    ReturnStatus        VARCHAR(30)     NOT NULL    DEFAULT 'PENDING',
    ReturnReasonCode    VARCHAR(50)     NULL,
    Qty                 INT             NOT NULL    DEFAULT 1,
    RefundAmount        DECIMAL(18,4)   NOT NULL    DEFAULT 0,
    ReturnlessRefund    BIT             NOT NULL    DEFAULT 0,  -- Amazon refunded w/o requiring return
    DispositionCode     VARCHAR(30)     NULL,
    FulfillmentCenterId VARCHAR(20)     NULL,
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_Returns PRIMARY KEY (ReturnId),
    CONSTRAINT FK_Returns_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT FK_Returns_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId)
);
GO

CREATE INDEX IX_Returns_Account_Date ON dbo.Returns (SellerAccountId, ReturnDate DESC);
CREATE INDEX IX_Returns_Returnless ON dbo.Returns (SellerAccountId, ReturnlessRefund) WHERE ReturnlessRefund = 1;
GO

-- ============================================================
-- SECTION 13: INBOUND SHIPMENTS
-- ============================================================

CREATE TABLE dbo.InboundShipments (
    ShipmentId          INT             NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    AmazonShipmentId    VARCHAR(50)     NOT NULL,
    ShipmentName        NVARCHAR(300)   NULL,
    ShipmentStatus      VARCHAR(30)     NOT NULL    DEFAULT 'WORKING',
    DestinationFC       VARCHAR(20)     NULL,
    ShippedDate         DATE            NULL,
    ArrivedDate         DATE            NULL,
    IsAWD               BIT             NOT NULL    DEFAULT 0,
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_InboundShipments PRIMARY KEY (ShipmentId),
    CONSTRAINT FK_IS2_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT UQ_InboundShipments_AmazonId UNIQUE (SellerAccountId, AmazonShipmentId)
);
GO

CREATE TABLE dbo.InboundShipmentItems (
    ShipmentItemId      INT             NOT NULL    IDENTITY(1,1),
    ShipmentId          INT             NOT NULL,
    ProductId           INT             NULL,
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NOT NULL,
    QtyShipped          INT             NOT NULL    DEFAULT 0,
    QtyReceived         INT             NOT NULL    DEFAULT 0,
    QtyInCase           INT             NULL,
    Variance            AS              (QtyShipped - QtyReceived),
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_InboundShipmentItems PRIMARY KEY (ShipmentItemId),
    CONSTRAINT FK_ISI_Shipments FOREIGN KEY (ShipmentId) REFERENCES dbo.InboundShipments (ShipmentId),
    CONSTRAINT FK_ISI_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId)
);
GO

-- ============================================================
-- SECTION 14: CSV IMPORTS
-- ============================================================

CREATE TABLE dbo.CSVImports (
    ImportId            INT             NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    UserId              INT             NOT NULL,
    ImportDate          DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    ReportTypeCode      VARCHAR(80)     NOT NULL,
    FileName            NVARCHAR(500)   NOT NULL,
    FileSizeBytes       BIGINT          NULL,
    RowsTotal           INT             NOT NULL    DEFAULT 0,
    RowsImported        INT             NOT NULL    DEFAULT 0,
    RowsSkipped         INT             NOT NULL    DEFAULT 0,
    RowsErrored         INT             NOT NULL    DEFAULT 0,
    Status              VARCHAR(20)     NOT NULL    DEFAULT 'PENDING',
        -- PENDING, PROCESSING, COMPLETE, FAILED, PARTIAL
    ErrorLog            NVARCHAR(MAX)   NULL,
    ProcessingStarted   DATETIME2       NULL,
    ProcessingCompleted DATETIME2       NULL,
    CONSTRAINT PK_CSVImports PRIMARY KEY (ImportId),
    CONSTRAINT FK_CI_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT FK_CI_Users FOREIGN KEY (UserId) REFERENCES dbo.Users (UserId)
);
GO

CREATE INDEX IX_CSVImports_Account_Date ON dbo.CSVImports (SellerAccountId, ImportDate DESC);
GO

-- ============================================================
-- SECTION 15: ALERTS
-- ============================================================

CREATE TABLE dbo.Alerts (
    AlertId             BIGINT          NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    AlertTypeCode       VARCHAR(50)     NOT NULL,
    ProductId           INT             NULL,
    CaseId              INT             NULL,
    AlertDate           DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    Message             NVARCHAR(1000)  NOT NULL,
    Severity            VARCHAR(10)     NOT NULL    DEFAULT 'MEDIUM',
    IsRead              BIT             NOT NULL    DEFAULT 0,
    ReadDate            DATETIME2       NULL,
    ReadByUserId        INT             NULL,
    ResolvedDate        DATETIME2       NULL,
    ResolvedByUserId    INT             NULL,
    IsActive            BIT             NOT NULL    DEFAULT 1,
    CONSTRAINT PK_Alerts PRIMARY KEY (AlertId),
    CONSTRAINT FK_Alerts_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT FK_Alerts_AlertTypes FOREIGN KEY (AlertTypeCode) REFERENCES dbo.AlertTypes (AlertTypeCode),
    CONSTRAINT FK_Alerts_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId),
    CONSTRAINT CK_Alerts_Severity CHECK (Severity IN ('LOW','MEDIUM','HIGH','CRITICAL'))
);
GO

CREATE INDEX IX_Alerts_Account_Unread ON dbo.Alerts (SellerAccountId, IsRead, AlertDate DESC);
GO

-- ============================================================
-- SECTION 16: ALERT THRESHOLDS (per seller account / per SKU)
-- ============================================================

CREATE TABLE dbo.AlertThresholds (
    ThresholdId         INT             NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    ProductId           INT             NULL,       -- NULL = account-level default
    AlertTypeCode       VARCHAR(50)     NOT NULL,
    ThresholdValue      DECIMAL(18,4)   NOT NULL,
    ThresholdUnit       VARCHAR(30)     NULL,       -- DAYS, UNITS, PERCENT, DOLLARS
    IsActive            BIT             NOT NULL    DEFAULT 1,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_AlertThresholds PRIMARY KEY (ThresholdId),
    CONSTRAINT FK_AT_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT FK_AT_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId),
    CONSTRAINT UQ_AT_AccountProductType UNIQUE (SellerAccountId, ProductId, AlertTypeCode)
);
GO

-- ============================================================
-- SECTION 17: NICHE RESEARCH
-- ============================================================

CREATE TABLE dbo.NicheResearch (
    NicheId             INT             NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    UserId              INT             NOT NULL,
    ResearchDate        DATE            NOT NULL    DEFAULT CAST(SYSUTCDATETIME() AS DATE),
    Keyword             NVARCHAR(300)   NOT NULL,
    EstMonthlySearchVol INT             NULL,
    CompetitorCount     INT             NULL,
    AvgReviewCount      INT             NULL,
    AvgPrice            DECIMAL(18,4)   NULL,
    EstRevenue          DECIMAL(18,4)   NULL,
    OpportunityScore    DECIMAL(5,2)    NULL,       -- 0-100
    Notes               NVARCHAR(MAX)   NULL,
    Status              VARCHAR(20)     NOT NULL    DEFAULT 'RESEARCHING',
        -- RESEARCHING, QUALIFIED, PURSUING, LAUNCHED, REJECTED
    CONSTRAINT PK_NicheResearch PRIMARY KEY (NicheId),
    CONSTRAINT FK_NR_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId),
    CONSTRAINT FK_NR_Users FOREIGN KEY (UserId) REFERENCES dbo.Users (UserId)
);
GO

-- ============================================================
-- SECTION 18: VA SOP BUILDER
-- ============================================================

CREATE TABLE dbo.SOPTemplates (
    TemplateId          INT             NOT NULL    IDENTITY(1,1),
    TemplateCode        VARCHAR(50)     NOT NULL,
    TemplateName        NVARCHAR(200)   NOT NULL,
    Category            VARCHAR(50)     NOT NULL,   -- DAILY, WEEKLY, MONTHLY, CASE, REIMBURSEMENT
    Body                NVARCHAR(MAX)   NOT NULL,
    IsActive            BIT             NOT NULL    DEFAULT 1,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_SOPTemplates PRIMARY KEY (TemplateId),
    CONSTRAINT UQ_SOPTemplates_Code UNIQUE (TemplateCode)
);
GO

CREATE TABLE dbo.SOPAssignments (
    AssignmentId        INT             NOT NULL    IDENTITY(1,1),
    TemplateId          INT             NOT NULL,
    AssignedToUserId    INT             NOT NULL,
    SellerAccountId     INT             NOT NULL,
    AssignedDate        DATE            NOT NULL    DEFAULT CAST(SYSUTCDATETIME() AS DATE),
    DueDate             DATE            NULL,
    CompletedDate       DATE            NULL,
    Status              VARCHAR(20)     NOT NULL    DEFAULT 'PENDING',
    Notes               NVARCHAR(1000)  NULL,
    CONSTRAINT PK_SOPAssignments PRIMARY KEY (AssignmentId),
    CONSTRAINT FK_SOPA_Templates FOREIGN KEY (TemplateId) REFERENCES dbo.SOPTemplates (TemplateId),
    CONSTRAINT FK_SOPA_Users FOREIGN KEY (AssignedToUserId) REFERENCES dbo.Users (UserId)
);
GO

-- ============================================================
-- SECTION 19: EMAIL TEMPLATES
-- ============================================================

CREATE TABLE dbo.EmailTemplates (
    TemplateId          INT             NOT NULL    IDENTITY(1,1),
    TemplateCode        VARCHAR(80)     NOT NULL,
    TemplateName        NVARCHAR(200)   NOT NULL,
    Category            VARCHAR(50)     NOT NULL,
        -- CASE_MANAGEMENT, BUYER_MESSAGE, BRAND_IP, INTERNAL_OPS
    SubCategory         VARCHAR(80)     NULL,
    SubjectLine         NVARCHAR(500)   NOT NULL,
    BodyHtml            NVARCHAR(MAX)   NOT NULL,
    BodyText            NVARCHAR(MAX)   NOT NULL,
    Tags                VARCHAR(500)    NULL,       -- comma-delimited tags
    IsActive            BIT             NOT NULL    DEFAULT 1,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_EmailTemplates PRIMARY KEY (TemplateId),
    CONSTRAINT UQ_EmailTemplates_Code UNIQUE (TemplateCode)
);
GO

-- ============================================================
-- SECTION 20: FBA NEW SELECTION & REMOVAL ORDERS
-- ============================================================

CREATE TABLE dbo.RemovalOrders (
    RemovalOrderId      INT             NOT NULL    IDENTITY(1,1),
    SellerAccountId     INT             NOT NULL,
    AmazonRemovalOrderId VARCHAR(50)    NOT NULL,
    ProductId           INT             NULL,
    ASIN                VARCHAR(20)     NOT NULL,
    SKU                 VARCHAR(100)    NULL,
    OrderDate           DATE            NULL,
    RemovalType         VARCHAR(20)     NOT NULL    DEFAULT 'RETURN',  -- RETURN, DISPOSAL
    Status              VARCHAR(30)     NOT NULL,
    QtyRequested        INT             NOT NULL    DEFAULT 0,
    QtyShipped          INT             NOT NULL    DEFAULT 0,
    RemovalFee          DECIMAL(18,4)   NULL,
    ImportId            INT             NULL,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_RemovalOrders PRIMARY KEY (RemovalOrderId),
    CONSTRAINT FK_RO_SellerAccounts FOREIGN KEY (SellerAccountId) REFERENCES dbo.SellerAccounts (SellerAccountId)
);
GO

-- ============================================================
-- SECTION 21: COMPETITOR PRICE MONITORING
-- ============================================================

CREATE TABLE dbo.CompetitorPriceHistory (
    PriceHistoryId      BIGINT          NOT NULL    IDENTITY(1,1),
    ProductId           INT             NOT NULL,
    SellerAccountId     INT             NOT NULL,
    SnapshotDate        DATE            NOT NULL,
    OurBuyBoxPrice      DECIMAL(18,4)   NULL,
    OurListingPrice     DECIMAL(18,4)   NULL,
    LowestCompetitorPrice DECIMAL(18,4) NULL,
    BuyBoxOwner         VARCHAR(100)    NULL,       -- Seller name or 'Amazon'
    BuyBoxOwnedByUs     BIT             NULL,
    CompetitorCount     INT             NULL,
    DataSource          VARCHAR(20)     NOT NULL    DEFAULT 'SPAPI',
    CONSTRAINT PK_CompPriceHistory PRIMARY KEY (PriceHistoryId),
    CONSTRAINT FK_CPH_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products (ProductId)
);
GO

CREATE INDEX IX_CompPriceHistory_Product_Date ON dbo.CompetitorPriceHistory (ProductId, SnapshotDate DESC);
GO
