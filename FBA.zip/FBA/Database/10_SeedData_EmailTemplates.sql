-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 10_SeedData_EmailTemplates.sql
-- DESC: Complete Email & Message Template Library
--       All 4 categories seeded to EmailTemplates table
--       Ready to use with [BRACKET] merge fields
-- ============================================================
SET NOCOUNT ON;
GO

USE AmazonFBAManager;
GO

-- ============================================================
-- CATEGORY 1: AMAZON CASE MANAGEMENT EMAILS
-- ============================================================

INSERT INTO dbo.EmailTemplates (TemplateCode, TemplateName, Category, SubCategory, SubjectLine, BodyText, BodyHtml, Tags) VALUES

('CASE_1_1_LOST_INVENTORY',
 'Opening a Lost Inventory Case',
 'CASE_MANAGEMENT',
 'LOST_INVENTORY',
 'Lost Inventory Reimbursement Request – ASIN [ASIN] – [SELLER_NAME]',
 N'Dear Amazon Seller Support,

I am writing to request a reimbursement for inventory that was lost within the Amazon fulfillment network and has not been reimbursed.

Account Information:
Seller Name: [SELLER_NAME]
Merchant Token: [MERCHANT_TOKEN]
Marketplace: [MARKETPLACE]

Lost Inventory Details:
ASIN: [ASIN]
SKU: [SKU]
FNSKU: [FNSKU]
Quantity Lost: [QTY_LOST] units
Date(s) of Loss: [DATE_FROM] through [DATE_TO]
Fulfillment Center: [FC_ID] (if known)
Cost of Goods Per Unit: $[COGS_PER_UNIT]
Total Claimable Amount: $[TOTAL_CLAIMABLE]

Supporting Documentation:
I have attached the following to support this claim:
1. FBA Inventory Adjustments Report (date range: [DATE_FROM] to [DATE_TO]) showing the units removed with reason code LOST
2. Reimbursements Report confirming no reimbursement was issued for these units
3. Inventory Reconciliation Summary

Per Amazon''s reimbursement policy, sellers are entitled to reimbursement for units lost within the fulfillment network. As of March 10, 2025, reimbursements are calculated at the cost of goods value. My COGS per unit is $[COGS_PER_UNIT], making the total claimable amount $[TOTAL_CLAIMABLE] for [QTY_LOST] units.

I respectfully request that Amazon review this claim and issue the appropriate reimbursement.

Please confirm receipt of this case and provide a case reference number.

Sincerely,
[YOUR_NAME]
[SELLER_NAME]
[EMAIL]
[PHONE]',
 N'<p>Dear Amazon Seller Support,</p><p>I am writing to request a reimbursement for inventory that was lost within the Amazon fulfillment network and has not been reimbursed.</p><p><strong>Account Information:</strong><br>Seller Name: [SELLER_NAME]<br>Merchant Token: [MERCHANT_TOKEN]<br>Marketplace: [MARKETPLACE]</p><p><strong>Lost Inventory Details:</strong><br>ASIN: [ASIN]<br>SKU: [SKU]<br>FNSKU: [FNSKU]<br>Quantity Lost: [QTY_LOST] units<br>Date(s) of Loss: [DATE_FROM] through [DATE_TO]<br>Cost of Goods Per Unit: $[COGS_PER_UNIT]<br>Total Claimable Amount: $[TOTAL_CLAIMABLE]</p><p>Please confirm receipt and provide a case reference number.</p><p>Sincerely,<br>[YOUR_NAME]</p>',
 'lost,inventory,reimbursement,fba'),

('CASE_1_2_DAMAGED_INVENTORY',
 'Opening a Damaged Inventory Case',
 'CASE_MANAGEMENT',
 'DAMAGED_INVENTORY',
 'Damaged Inventory Reimbursement Request – ASIN [ASIN] – [SELLER_NAME]',
 N'Dear Amazon Seller Support,

I am contacting you to request reimbursement for inventory that was damaged while in Amazon''s custody within the fulfillment network.

Account Information:
Seller Name: [SELLER_NAME]
Merchant Token: [MERCHANT_TOKEN]

Damaged Inventory Details:
ASIN: [ASIN]
SKU: [SKU]
FNSKU: [FNSKU]
Quantity Damaged: [QTY_DAMAGED] units
Date(s) of Damage: [DATE_FROM] through [DATE_TO]
Damage Reason Code(s): [REASON_CODE] (e.g., DAMAGED_WAREHOUSE)
Fulfillment Center: [FC_ID]
Cost of Goods Per Unit: $[COGS_PER_UNIT]
Total Claimable Amount: $[TOTAL_CLAIMABLE]

Evidence Attached:
1. FBA Inventory Adjustments Report showing units removed with damage reason codes
2. Reimbursements Report confirming no reimbursement was issued
3. Original supplier invoice confirming COGS of $[COGS_PER_UNIT] per unit

Under Amazon''s fulfillment agreement, Amazon assumes responsibility for inventory damaged in its fulfillment centers. Per the updated March 2025 reimbursement policy, the reimbursement value is calculated at cost of goods sold. My documented COGS is $[COGS_PER_UNIT] per unit.

I request a reimbursement of $[TOTAL_CLAIMABLE] for [QTY_DAMAGED] damaged units.

Thank you for your prompt attention to this matter.

Sincerely,
[YOUR_NAME]
[SELLER_NAME]',
 N'<p>Dear Amazon Seller Support,</p><p>I am contacting you to request reimbursement for inventory damaged while in Amazon''s custody.</p><p><strong>Damaged Inventory Details:</strong><br>ASIN: [ASIN] | SKU: [SKU] | Qty: [QTY_DAMAGED] | COGS/unit: $[COGS_PER_UNIT] | Total: $[TOTAL_CLAIMABLE]</p><p>Sincerely,<br>[YOUR_NAME]</p>',
 'damaged,inventory,reimbursement,warehouse'),

('CASE_1_3_INBOUND_DISCREPANCY',
 'Opening an Inbound Shipment Discrepancy Case',
 'CASE_MANAGEMENT',
 'INBOUND_DISCREPANCY',
 'Inbound Shipment Discrepancy – Shipment ID [SHIPMENT_ID] – Units Not Received',
 N'Dear Amazon Seller Support,

I am writing regarding a discrepancy between the quantity I shipped to Amazon''s fulfillment center and the quantity Amazon recorded as received.

Account Information:
Seller Name: [SELLER_NAME]
Merchant Token: [MERCHANT_TOKEN]

Shipment Details:
Amazon Shipment ID: [SHIPMENT_ID]
Destination Fulfillment Center: [FC_ID]
Ship Date: [SHIP_DATE]
Carrier: [CARRIER_NAME]
Tracking Number: [TRACKING_NUMBER]

Discrepancy Summary:
ASIN: [ASIN]
SKU: [SKU]
Quantity Shipped: [QTY_SHIPPED] units
Quantity Received by Amazon: [QTY_RECEIVED] units
Quantity Missing: [QTY_MISSING] units
Cost of Goods Per Unit: $[COGS_PER_UNIT]
Total Claimable Amount: $[TOTAL_CLAIMABLE]

Supporting Documentation Attached:
1. Packing slip / box content list confirming [QTY_SHIPPED] units were prepared
2. Carrier pickup confirmation / Bill of Lading
3. Carrier weight receipt confirming shipment weight consistent with [QTY_SHIPPED] units
4. Inbound Shipment Report from Seller Central showing the discrepancy
5. Supplier invoice confirming COGS of $[COGS_PER_UNIT] per unit

I have confirmed with my carrier that all [QTY_SHIPPED] units were handed over for delivery. The missing [QTY_MISSING] units were not received by Amazon but were also not returned to me.

I respectfully request that Amazon investigate this discrepancy and reimburse me for the [QTY_MISSING] missing units at my documented cost of goods of $[COGS_PER_UNIT] per unit, totaling $[TOTAL_CLAIMABLE].

Please confirm receipt and provide a case number.

Sincerely,
[YOUR_NAME]
[SELLER_NAME]',
 N'<p>Dear Amazon Seller Support,</p><p>I am writing regarding a discrepancy between units shipped and units received for Shipment ID: [SHIPMENT_ID].</p><p><strong>Missing:</strong> [QTY_MISSING] units of ASIN [ASIN] | Claimable: $[TOTAL_CLAIMABLE]</p><p>Documentation attached. Please investigate and reimburse.</p><p>Sincerely, [YOUR_NAME]</p>',
 'inbound,shipment,discrepancy,receiving'),

('CASE_1_4_AWD_LOSS',
 'Opening an AWD Shipment Loss Case',
 'CASE_MANAGEMENT',
 'AWD_LOSS',
 'AWD Inventory Loss – Shipment [SHIPMENT_ID] – Amazon Warehousing & Distribution',
 N'Dear Amazon Seller Support,

I am writing to report a loss of inventory within the Amazon Warehousing and Distribution (AWD) program that has not been received at the fulfillment center or reimbursed.

Account Information:
Seller Name: [SELLER_NAME]
Merchant Token: [MERCHANT_TOKEN]
AWD Customer ID: [AWD_CUSTOMER_ID]

AWD Shipment Details:
AWD Shipment ID: [SHIPMENT_ID]
Origin Warehouse / Ship Date: [SHIP_DATE]
Destination FC: [FC_ID]
Expected Arrival Date: [EXPECTED_DATE]

Loss Details:
ASIN: [ASIN]
SKU: [SKU]
Quantity Sent to AWD: [QTY_TO_AWD] units
Quantity Received at AWD: [QTY_RECEIVED_AWD] units
Quantity Transferred to FC: [QTY_TO_FC] units
Quantity Unaccounted For: [QTY_MISSING] units
Cost of Goods Per Unit: $[COGS_PER_UNIT]
Total Claimable Amount: $[TOTAL_CLAIMABLE]

I have reviewed my AWD Inventory Report and FBA Inventory Report in Seller Central. The [QTY_MISSING] units cannot be located in either the AWD warehouse or in my FBA available/inbound inventory. These units were not returned to me and no reimbursement has been issued.

Attached Documentation:
1. AWD Inventory Report showing quantities sent and received
2. FBA Inventory Report confirming units did not arrive at FC
3. Removal confirmation showing no removal order was created for these units
4. Supplier invoice confirming COGS of $[COGS_PER_UNIT] per unit

I request a reimbursement of $[TOTAL_CLAIMABLE] for the [QTY_MISSING] units unaccounted for within the AWD pipeline.

Sincerely,
[YOUR_NAME]
[SELLER_NAME]',
 N'<p>Dear Amazon Seller Support,</p><p>I am writing to report a loss within AWD for Shipment [SHIPMENT_ID]. <strong>[QTY_MISSING] units</strong> of ASIN [ASIN] are unaccounted for. Claimable: $[TOTAL_CLAIMABLE]. Documentation attached.</p><p>Sincerely, [YOUR_NAME]</p>',
 'awd,warehousing,distribution,loss,shipment'),

('CASE_1_5_FEE_OVERCHARGE',
 'Disputing a Fee Overcharge',
 'CASE_MANAGEMENT',
 'FEE_OVERCHARGE',
 'FBA Fee Overcharge Dispute – ASIN [ASIN] – Incorrect Dimensions/Weight on File',
 N'Dear Amazon Seller Support,

I am writing to dispute FBA fulfillment fees that have been incorrectly charged for the following ASIN due to inaccurate product dimensions and/or weight recorded in Amazon''s system.

Account Information:
Seller Name: [SELLER_NAME]
Merchant Token: [MERCHANT_TOKEN]

Product Details:
ASIN: [ASIN]
SKU: [SKU]
Product Name: [PRODUCT_TITLE]

Fee Discrepancy:
Amazon''s Recorded Dimensions: [AMAZON_LENGTH]" x [AMAZON_WIDTH]" x [AMAZON_HEIGHT]" | Weight: [AMAZON_WEIGHT] lbs
Actual Dimensions: [ACTUAL_LENGTH]" x [ACTUAL_WIDTH]" x [ACTUAL_HEIGHT]" | Weight: [ACTUAL_WEIGHT] lbs
Fee Amazon Charged Per Unit: $[FEE_CHARGED]
Correct Fee Based on Actual Dimensions: $[FEE_EXPECTED]
Overcharge Per Unit: $[FEE_VARIANCE]
Number of Units Charged at Wrong Rate: [UNIT_COUNT]
Total Overcharged Amount: $[TOTAL_OVERCHARGE]
Period: [DATE_FROM] through [DATE_TO]

I am requesting:
1. Correction of the product dimensions and weight in Amazon''s system to the accurate measurements listed above
2. Reimbursement of $[TOTAL_OVERCHARGE] for fees incorrectly charged during the period [DATE_FROM] through [DATE_TO]

Supporting Documentation Attached:
1. Third-party measurement report / manufacturer spec sheet confirming actual dimensions and weight
2. Physical measurement photos with ruler/scale visible
3. FBA Fee Preview report showing expected fee at correct dimensions
4. FBA Fees report showing actual fees charged during the disputed period

I request that Amazon update the product dimensions on file and issue a reimbursement for the overcharged fees.

Sincerely,
[YOUR_NAME]
[SELLER_NAME]',
 N'<p>Dear Amazon Seller Support,</p><p>I am disputing FBA fee overcharges for ASIN [ASIN] due to incorrect dimensions on file.</p><p>Overcharge: $[FEE_VARIANCE]/unit × [UNIT_COUNT] units = <strong>$[TOTAL_OVERCHARGE]</strong>. Documentation attached.</p><p>Sincerely, [YOUR_NAME]</p>',
 'fee,overcharge,dimensions,weight,fba'),

('CASE_1_6_RETURNLESS_REFUND',
 'Claiming a Returnless Refund Not Reimbursed',
 'CASE_MANAGEMENT',
 'RETURNLESS_REFUND',
 'Returnless Refund Reimbursement Request – Order [ORDER_ID] – Return Not Received',
 N'Dear Amazon Seller Support,

I am writing to request reimbursement for a returnless refund that was issued to a customer but for which I have not received compensation, and the item was never returned to the fulfillment center.

Account Information:
Seller Name: [SELLER_NAME]
Merchant Token: [MERCHANT_TOKEN]

Order and Refund Details:
Amazon Order ID: [ORDER_ID]
ASIN: [ASIN]
SKU: [SKU]
Customer Refund Date: [REFUND_DATE]
Refund Amount Issued to Customer: $[REFUND_AMOUNT]
Quantity: [QTY] unit(s)
Return Status: No return received at fulfillment center as of [TODAY_DATE]
Cost of Goods Per Unit: $[COGS_PER_UNIT]
Claimable Amount: $[CLAIMABLE_AMOUNT]

Under Amazon''s FBA service terms, when Amazon issues a returnless refund on behalf of a seller and the item is not returned to inventory, the seller is entitled to reimbursement. As of the date of this claim, no return has been received at any fulfillment center, and no reimbursement has been issued to my account.

Evidence Attached:
1. FBA Customer Returns Report showing no return received for Order ID [ORDER_ID]
2. Reimbursements Report confirming no reimbursement was issued
3. Order details screenshot confirming refund amount of $[REFUND_AMOUNT]

I request reimbursement of $[CLAIMABLE_AMOUNT] for this uncompensated returnless refund.

Sincerely,
[YOUR_NAME]
[SELLER_NAME]',
 N'<p>Dear Amazon Seller Support,</p><p>I am requesting reimbursement for returnless refund on Order [ORDER_ID]. Customer was refunded $[REFUND_AMOUNT] but no return was received. Claimable: $[CLAIMABLE_AMOUNT].</p><p>Sincerely, [YOUR_NAME]</p>',
 'returnless,refund,reimbursement,return'),

('CASE_1_7_ESCALATION_7DAY',
 'Escalating a Case After No Response (7 Days)',
 'CASE_MANAGEMENT',
 'ESCALATION',
 'ESCALATION – No Response in 7 Days – Case [AMAZON_CASE_ID] – [CASE_TYPE]',
 N'Dear Amazon Seller Support,

I am following up on Case ID [AMAZON_CASE_ID], which was opened on [OPEN_DATE] regarding [CASE_SUBJECT]. It has now been 7 days with no substantive response or resolution.

Original Case Summary:
Case ID: [AMAZON_CASE_ID]
Opened: [OPEN_DATE]
Issue: [CASE_SUBJECT]
Amount at Stake: $[AMOUNT_AT_RISK]
ASIN/SKU: [ASIN] / [SKU]

I understand that Seller Support handles a high volume of cases. However, this matter has a direct and measurable impact on my business, and the delay is causing ongoing financial harm.

I respectfully request:
1. An immediate acknowledgment of this case
2. Assignment to a specialist with authority to resolve this type of claim
3. A resolution or clear timeline within 48 hours

If this case is not resolved at the standard support level, I will need to escalate further to Seller Performance and, if necessary, to executive seller relations.

I have attached all previously submitted documentation for reference.

Case ID: [AMAZON_CASE_ID]
Original Submission Date: [OPEN_DATE]

Thank you for your urgent attention.

Sincerely,
[YOUR_NAME]
[SELLER_NAME]
[EMAIL]',
 N'<p>Dear Amazon Seller Support,</p><p>I am escalating Case [AMAZON_CASE_ID] (opened [OPEN_DATE]) with no response after 7 days. Amount at risk: <strong>$[AMOUNT_AT_RISK]</strong>. I request resolution within 48 hours.</p><p>Sincerely, [YOUR_NAME]</p>',
 'escalation,follow-up,no-response,case'),

('CASE_1_8_ESCALATION_14DAY',
 'Escalating a Case After First Escalation Fails (14 Days)',
 'CASE_MANAGEMENT',
 'ESCALATION',
 'SECOND ESCALATION – 14 Days Unresolved – Case [AMAZON_CASE_ID] – Requesting Senior Review',
 N'Dear Amazon Seller Support / Escalations Team,

I am filing a second escalation for Case ID [AMAZON_CASE_ID]. This case has been open for 14 days without resolution. I previously escalated on [FIRST_ESCALATION_DATE] and received only an auto-acknowledgment with no substantive action.

Timeline:
[OPEN_DATE]: Original case filed
[FIRST_ESCALATION_DATE]: First escalation submitted
[TODAY_DATE]: Second escalation — 14 days open, no resolution

Case Details:
Case ID: [AMAZON_CASE_ID]
Issue: [CASE_SUBJECT]
Amount at Stake: $[AMOUNT_AT_RISK]
ASIN: [ASIN] | SKU: [SKU]

This situation is unacceptable. I am a legitimate seller who has followed all required processes and submitted all required documentation. The continued delay without resolution is a breach of Amazon''s own seller support commitments.

I am requesting:
1. Immediate escalation to a Senior Seller Support Specialist or Escalations Manager
2. A binding resolution or formal denial within 5 business days
3. If denied, a clear, detailed written explanation citing the specific policy reason for denial

I intend to document this interaction and, if necessary, contact Amazon''s executive seller relations team and the Better Business Bureau if this is not resolved promptly.

All supporting documentation remains attached.

Sincerely,
[YOUR_NAME]
[SELLER_NAME]
[EMAIL]
[PHONE]',
 N'<p>Dear Escalations Team,</p><p>Second escalation for Case [AMAZON_CASE_ID] — 14 days open, no resolution. Amount at stake: <strong>$[AMOUNT_AT_RISK]</strong>. Requesting Senior Specialist review within 5 business days.</p><p>Sincerely, [YOUR_NAME]</p>',
 'escalation,second,14-day,senior'),

('CASE_1_9_SENIOR_REVIEW',
 'Requesting Senior Specialist Review',
 'CASE_MANAGEMENT',
 'ESCALATION',
 'Request for Senior Specialist Review – Case [AMAZON_CASE_ID]',
 N'Dear Amazon Seller Support,

I am writing to formally request that Case ID [AMAZON_CASE_ID] be reviewed by a Senior Specialist with the authority to issue reimbursements and resolve complex seller disputes.

This case involves [CASE_SUBJECT] with a financial impact of $[AMOUNT_AT_RISK]. The case has been reviewed by standard support agents who have been unable to resolve it due to [REASON_STANDARD_FAILED — e.g., "requiring verification of cost basis documentation" / "requiring cross-department review"].

I have submitted comprehensive documentation including:
[LIST_DOCUMENTATION_ITEMS]

I am a long-standing seller on Amazon with [YEARS_SELLING] years of selling history and [TOTAL_ORDERS] lifetime orders. My account health metrics are within policy guidelines. This claim is legitimate and well-documented.

I request:
1. Assignment of this case to a Senior Specialist or Account Manager
2. A thorough review of all attached documentation
3. A resolution within 5 business days

Case ID: [AMAZON_CASE_ID]

Thank you for your consideration.

Sincerely,
[YOUR_NAME]
[SELLER_NAME]',
 N'<p>Dear Amazon Seller Support,</p><p>I formally request Senior Specialist review of Case [AMAZON_CASE_ID] — $[AMOUNT_AT_RISK] at stake. Standard support has been unable to resolve. Please assign to a Senior Specialist within 5 business days.</p><p>Sincerely, [YOUR_NAME]</p>',
 'senior,specialist,review,escalation'),

('CASE_1_11_DISPUTE_REIMB_AMOUNT',
 'Disputing Amazon Reimbursement Amount (Wrong Cost Basis)',
 'CASE_MANAGEMENT',
 'REIMBURSEMENT_DISPUTE',
 'Reimbursement Amount Dispute – Case [AMAZON_CASE_ID] – Incorrect Cost Basis Applied',
 N'Dear Amazon Seller Support,

I am writing to dispute the reimbursement amount issued under Case ID [AMAZON_CASE_ID]. Amazon has reimbursed me at a rate that does not reflect my actual cost of goods, which is contrary to Amazon''s reimbursement policy effective March 10, 2025.

Reimbursement Details:
Case ID: [AMAZON_CASE_ID]
Amazon Reimbursement ID: [REIMB_ID]
ASIN: [ASIN]
SKU: [SKU]
Quantity Reimbursed: [QTY_REIMBURSED] units
Amount Amazon Reimbursed: $[AMAZON_PAID]
My Documented COGS Per Unit: $[COGS_PER_UNIT]
Amount I Should Have Received: $[CORRECT_AMOUNT]
Underpayment: $[UNDERPAYMENT]

Per Amazon''s updated reimbursement policy (effective March 10, 2025), lost and damaged inventory is reimbursed at the seller''s cost of goods. I provided my COGS documentation when the case was filed. The amount issued ($[AMAZON_PAID]) does not align with my cost basis of $[COGS_PER_UNIT] per unit × [QTY_REIMBURSED] units = $[CORRECT_AMOUNT].

Attached Documentation:
1. Original supplier invoice confirming COGS of $[COGS_PER_UNIT] per unit
2. Wire transfer / payment records confirming this cost
3. Amazon''s reimbursement notification showing $[AMAZON_PAID] paid
4. Amazon''s policy documentation showing COGS-based reimbursement

I request a supplemental reimbursement of $[UNDERPAYMENT] to bring the total to my correct COGS-based entitlement of $[CORRECT_AMOUNT].

Sincerely,
[YOUR_NAME]
[SELLER_NAME]',
 N'<p>Dear Amazon Seller Support,</p><p>I am disputing reimbursement under Case [AMAZON_CASE_ID]. Amazon paid $[AMAZON_PAID] but correct amount at COGS basis is $[CORRECT_AMOUNT]. Underpayment: <strong>$[UNDERPAYMENT]</strong>. COGS documentation attached.</p><p>Sincerely, [YOUR_NAME]</p>',
 'dispute,reimbursement,cogs,cost-basis,2025'),

('CASE_1_17_SUSPENSION_POA',
 'Account Suspension Plan of Action (Full POA)',
 'CASE_MANAGEMENT',
 'SUSPENSION_POA',
 'Plan of Action – Account Reinstatement Appeal – [SELLER_NAME] – [VIOLATION_TYPE]',
 N'Dear Amazon Seller Performance Team,

I am writing to submit a formal Plan of Action (POA) in response to the suspension of my selling account ([SELLER_NAME] / Merchant Token: [MERCHANT_TOKEN]) due to [VIOLATION_TYPE / POLICY_CITED].

I take full responsibility for the issues that led to this action. I understand Amazon''s policies and the high standards required of sellers, and I am committed to meeting those standards going forward.

---

SECTION 1: ROOT CAUSE ANALYSIS

After a thorough review of my account, orders, and customer feedback, I have identified the following root cause(s):

[ROOT_CAUSE_1 — Be specific. Example: "We were selling ASIN [ASIN] which received multiple customer complaints regarding [ISSUE]. Upon investigation, we determined the issue was caused by [MANUFACTURING_DEFECT / WRONG_ITEM_SHIPPED / LISTING_INACCURACY]."]

[ROOT_CAUSE_2 — if applicable]

[ROOT_CAUSE_3 — if applicable]

I take full responsibility for these issues and understand how they negatively impacted customer experience and violated Amazon''s policies.

---

SECTION 2: CORRECTIVE ACTIONS TAKEN

I have already taken the following corrective actions:

1. [CORRECTIVE_ACTION_1 — Be specific and past tense. Example: "I have removed ASIN [ASIN] from my active inventory and initiated a quality review with my supplier on [DATE]."]
2. [CORRECTIVE_ACTION_2 — Example: "I have updated my listing descriptions and images to accurately reflect the product as of [DATE]."]
3. [CORRECTIVE_ACTION_3 — Example: "I have contacted all customers who reported issues and offered full refunds or replacements."]
4. [CORRECTIVE_ACTION_4 — Example: "I have reviewed all my active ASINs for similar issues and confirmed compliance."]

---

SECTION 3: PREVENTIVE ACTIONS (GOING FORWARD)

To prevent these issues from recurring, I have implemented the following permanent process changes:

1. [PREVENTIVE_ACTION_1 — Example: "I have implemented a pre-shipment quality inspection process with my supplier for all new inventory, requiring sign-off on a quality checklist before items are shipped to Amazon."]
2. [PREVENTIVE_ACTION_2 — Example: "I have enrolled in a monthly account health review process where I will personally audit all active listings, ODR, late shipment rate, and cancellation rate."]
3. [PREVENTIVE_ACTION_3 — Example: "I have appointed [NAME] as our dedicated Amazon compliance manager, responsible for monitoring policy updates and ensuring ongoing adherence."]
4. [PREVENTIVE_ACTION_4 — Example: "I have subscribed to Amazon''s policy update notifications and will review all communications from Seller Performance within 24 hours."]

---

CONCLUSION

I deeply value my relationship with Amazon and its customers. The actions above reflect my genuine commitment to operating a compliant, customer-focused business. I respectfully request that Amazon reinstate my selling privileges so that I may continue to serve customers at the highest standard.

I am available to provide any additional information or documentation you may require.

Sincerely,
[YOUR_NAME]
[SELLER_NAME]
[EMAIL]
[PHONE]
Submitted: [TODAY_DATE]',
 N'<p>Dear Amazon Seller Performance Team,</p><h3>PLAN OF ACTION — [SELLER_NAME]</h3><p><strong>Root Cause:</strong> [ROOT_CAUSE_SUMMARY]</p><p><strong>Corrective Actions:</strong> [CORRECTIVE_ACTIONS_SUMMARY]</p><p><strong>Preventive Actions:</strong> [PREVENTIVE_ACTIONS_SUMMARY]</p><p>I respectfully request reinstatement of my selling privileges.</p><p>Sincerely, [YOUR_NAME]</p>',
 'suspension,POA,plan-of-action,reinstatement,appeal'),

('CASE_1_19_IP_COUNTER_NOTICE',
 'IP Complaint Counter-Notice (False Complaint from Competitor)',
 'CASE_MANAGEMENT',
 'IP_COMPLAINT',
 'Intellectual Property Complaint Counter-Notice – Case [AMAZON_CASE_ID] – [ASIN]',
 N'Dear Amazon Brand Registry / Seller Performance,

I am submitting a formal counter-notice in response to the intellectual property complaint filed against my listing for ASIN [ASIN] under Case ID [AMAZON_CASE_ID].

My Information:
Seller Name: [SELLER_NAME]
Merchant Token: [MERCHANT_TOKEN]
ASIN: [ASIN]
SKU: [SKU]

Complainant (as listed by Amazon): [COMPLAINANT_NAME / UNKNOWN]

COUNTER-NOTICE:

I have a good faith belief that the intellectual property complaint filed against my listing is incorrect and has been filed in error or bad faith. Specifically:

1. I am the legitimate seller of this product and have the legal right to sell it.
2. [CHOOSE APPLICABLE:
   OPTION A: "I am the brand owner and hold registered trademark [TRADEMARK_REG_NO] for [BRAND_NAME], registered with [USPTO / IPO / OTHER]. My Brand Registry enrollment is under [BRAND_REGISTRY_CASE_NUMBER]."
   OPTION B: "I am an authorized reseller of [BRAND_NAME] products. My authorized reseller agreement with [SUPPLIER_NAME] is attached."
   OPTION C: "I purchased this product legitimately from [SUPPLIER_NAME] with a valid invoice, and I have the right of first sale under applicable law."]
3. I did not infringe on any valid intellectual property rights held by the complainant.
4. I believe this complaint was filed by a competitor attempting to remove my legitimate listing from the marketplace.

Supporting Documentation Attached:
1. [Trademark certificate / Brand Registry proof / Authorized reseller agreement / Purchase invoice]
2. [Additional evidence as applicable]

Under 17 U.S.C. § 512(g) (DMCA counter-notification provisions) and Amazon''s IP complaint policy, I formally request that Amazon:
1. Restore my listing for ASIN [ASIN] immediately
2. Forward this counter-notice to the complainant
3. Investigate the complainant for potential abuse of the IP complaint system

I declare under penalty of perjury that the information in this counter-notice is accurate and that I have a good faith belief that the material was removed or disabled as a result of mistake or misidentification.

Sincerely,
[YOUR_NAME]
[YOUR_ADDRESS]
[EMAIL]
[PHONE]
[DATE]',
 N'<p>Dear Amazon Brand Registry,</p><p>I submit this counter-notice for IP complaint Case [AMAZON_CASE_ID] against ASIN [ASIN]. This complaint is incorrect. I am a legitimate seller with documentation attached. I request immediate listing restoration.</p><p>Sincerely, [YOUR_NAME]</p>',
 'IP,trademark,counter-notice,complaint,brand');

-- ============================================================
-- CATEGORY 2: BUYER / CUSTOMER MESSAGE TEMPLATES
-- ============================================================

INSERT INTO dbo.EmailTemplates (TemplateCode, TemplateName, Category, SubCategory, SubjectLine, BodyText, BodyHtml, Tags) VALUES

('BUYER_2_1_LATE_DELIVERY',
 'Late Delivery Apology + Resolution Offer',
 'BUYER_MESSAGE',
 'DELIVERY',
 'Your Order [ORDER_ID] — Delivery Update and Our Apology',
 N'Hello [BUYER_FIRST_NAME],

Thank you for your order (Order ID: [ORDER_ID]).

I want to sincerely apologize that your order has not arrived within the expected delivery window. I understand how frustrating a delayed delivery can be, and I take full responsibility for ensuring your experience is made right.

Here is what I know about your order:
Order Date: [ORDER_DATE]
Expected Delivery: [EXPECTED_DELIVERY]
Current Status: [CURRENT_STATUS]
Tracking Number: [TRACKING_NUMBER] ([CARRIER])

What I am doing:
I have contacted [CARRIER] to investigate the delay and get an updated estimated delivery date. I will follow up with you as soon as I have more information.

What I can offer you right now:
If your order does not arrive within [X] additional business days, I will:
[CHOOSE ONE: issue you a full refund / send a replacement immediately / provide a [X]% discount on your next order]

Please reply to this message if you would like to take any of these steps now, or if you have any additional questions.

Again, I sincerely apologize for this inconvenience.

Best regards,
[SELLER_NAME] Customer Service',
 N'<p>Hello [BUYER_FIRST_NAME],</p><p>I sincerely apologize that your order [ORDER_ID] has been delayed. Tracking: [TRACKING_NUMBER] via [CARRIER]. I will make this right — please reply if you would like a refund or replacement now.</p><p>Best regards,<br>[SELLER_NAME] Customer Service</p>',
 'late,delivery,apology,delay'),

('BUYER_2_6_WRONG_ITEM',
 'Wrong Item Sent — Apology + Resolution',
 'BUYER_MESSAGE',
 'ORDER_ISSUE',
 'We Sent the Wrong Item — Order [ORDER_ID] — We Will Fix This Immediately',
 N'Hello [BUYER_FIRST_NAME],

I am so sorry — we made a mistake with your order (Order ID: [ORDER_ID]) and sent you the wrong item. This is entirely our error, and I want to make it right for you immediately.

What happened:
You ordered: [CORRECT_ITEM]
You received: [WRONG_ITEM]

Here is what I will do:

Option 1 — Replacement (Recommended):
I will ship the correct item [CORRECT_ITEM] to you right away at no additional charge. You do not need to return the wrong item — please keep it, donate it, or dispose of it as you see fit.

Option 2 — Full Refund:
If you prefer, I will issue a full refund of $[REFUND_AMOUNT] to your original payment method. No return is necessary.

Please reply to this message letting me know which option you prefer, and I will take action within 24 hours.

Again, I sincerely apologize for this error. We are reviewing our packing and fulfillment procedures to ensure this does not happen again.

Best regards,
[SELLER_NAME] Customer Service',
 N'<p>Hello [BUYER_FIRST_NAME],</p><p>I''m so sorry — we sent the wrong item for Order [ORDER_ID]. You ordered <strong>[CORRECT_ITEM]</strong> but received [WRONG_ITEM]. I will send the correct item immediately or issue a full refund — your choice. No return needed. Please reply with your preference.</p><p>Best regards, [SELLER_NAME]</p>',
 'wrong-item,error,replacement,refund'),

('BUYER_2_15_FEEDBACK_REMOVAL',
 'Negative Feedback Removal Request',
 'BUYER_MESSAGE',
 'FEEDBACK',
 'Regarding Your Recent Feedback — Order [ORDER_ID]',
 N'Hello [BUYER_FIRST_NAME],

Thank you for taking the time to share your feedback about your order (Order ID: [ORDER_ID]).

I read your feedback carefully and I completely understand your frustration. [ACKNOWLEDGE_SPECIFIC_ISSUE — Example: "The delay you experienced was unacceptable, and I take full responsibility."]

I want to make this right for you. I have [DESCRIBE_ACTION_TAKEN — Example: "already processed a full refund of $[AMOUNT]" / "shipped a replacement" / "arranged a free return"].

If I have successfully resolved your concern, I would genuinely appreciate it if you would consider updating or removing your feedback. Feedback on our seller account has a significant impact on small businesses like ours, and we are committed to earning a positive rating through excellent service.

To update your feedback:
1. Go to Amazon.com and log into your account
2. Click "Returns & Orders" in the top right
3. Find Order ID [ORDER_ID]
4. Select "Leave seller feedback" and you will have the option to update your previous rating

Of course, updating feedback is entirely your choice and I respect whatever you decide. My priority is that you are completely satisfied with your purchase.

Is there anything else I can do for you?

Best regards,
[YOUR_NAME]
[SELLER_NAME] Customer Service',
 N'<p>Hello [BUYER_FIRST_NAME],</p><p>Thank you for your feedback on Order [ORDER_ID]. I''ve [RESOLVED_ACTION]. If your concern has been addressed, I''d truly appreciate if you''d consider updating your feedback — but that is entirely your choice. My priority is your satisfaction.</p><p>Best regards, [SELLER_NAME]</p>',
 'feedback,negative,removal,request'),

('BUYER_2_8_DEFECTIVE_TROUBLESHOOT',
 'Defective Product — Troubleshooting First Response',
 'BUYER_MESSAGE',
 'PRODUCT_ISSUE',
 'We Want to Help — Troubleshooting Your [PRODUCT_NAME] — Order [ORDER_ID]',
 N'Hello [BUYER_FIRST_NAME],

Thank you for reaching out about your [PRODUCT_NAME] (Order ID: [ORDER_ID]). I''m sorry to hear it''s not working as expected, and I want to help resolve this for you right away.

Before we proceed with a replacement or refund, may I ask you to try a few quick troubleshooting steps? Many issues can be resolved in just a minute or two:

[TROUBLESHOOTING_STEPS — customize per product type]

Common steps for [PRODUCT_CATEGORY]:
Step 1: [STEP_1 — e.g., "Ensure the device is fully charged for at least 30 minutes before first use"]
Step 2: [STEP_2 — e.g., "Press and hold the power button for 5 seconds to perform a hard reset"]
Step 3: [STEP_3 — e.g., "Check that all connections are firmly seated and no pins are bent"]
Step 4: [STEP_4 — e.g., "Try using on a different power source or with a different compatible cable"]

If these steps do not resolve the issue, please reply with:
1. A description of what happens when you try to use the product
2. A photo or short video showing the issue (if possible)

I want to make sure we find the right solution for you — whether that is troubleshooting guidance, a replacement, or a refund.

Best regards,
[SELLER_NAME] Customer Service',
 N'<p>Hello [BUYER_FIRST_NAME],</p><p>I''m sorry your [PRODUCT_NAME] isn''t working as expected. Please try these quick steps: [TROUBLESHOOTING_STEPS]. If this doesn''t resolve it, please reply with a description and photo. I''ll make sure we find the right solution.</p><p>Best regards, [SELLER_NAME]</p>',
 'defective,troubleshooting,product,support');

-- ============================================================
-- CATEGORY 3: BRAND & IP PROTECTION EMAILS
-- ============================================================

INSERT INTO dbo.EmailTemplates (TemplateCode, TemplateName, Category, SubCategory, SubjectLine, BodyText, BodyHtml, Tags) VALUES

('BRAND_3_1_CEASE_DESIST_UNAUTHORIZED',
 'Cease and Desist — Unauthorized Seller on Your Listing',
 'BRAND_IP',
 'CEASE_DESIST',
 'CEASE AND DESIST — Unauthorized Sale of [BRAND_NAME] Products — Immediate Action Required',
 N'[DATE]

Via Email: [RECIPIENT_EMAIL]

RE: CEASE AND DESIST — Unauthorized Sale of [BRAND_NAME] Products on Amazon ASIN [ASIN]

Dear [RECIPIENT_NAME / "Sir or Madam"],

This letter serves as formal legal notice that you are selling [BRAND_NAME] branded products on Amazon (ASIN: [ASIN]) without authorization from [YOUR_COMPANY_NAME], the exclusive owner and authorized distributor of [BRAND_NAME] products in [TERRITORY].

We are the brand owner of [BRAND_NAME], protected under:
Trademark Registration No.: [TRADEMARK_NUMBER]
Registered with: [USPTO / IPO / relevant authority]
Amazon Brand Registry Enrollment: [BRAND_REGISTRY_ID]

Your unauthorized sale of our products constitutes:
1. Trademark infringement under [15 U.S.C. § 1114 / applicable law]
2. Violation of Amazon''s Intellectual Property Policy
3. Breach of our brand''s authorized reseller agreement
4. Potential violation of consumer protection laws (if products are not genuine or not properly warranted)

WE DEMAND THAT YOU IMMEDIATELY:
1. Remove all listings for [BRAND_NAME] products from your Amazon seller account
2. Cease and desist from offering, selling, or advertising [BRAND_NAME] products on any platform without written authorization
3. Confirm in writing within 5 business days that you have complied with these demands
4. Provide documentation of the source from which you obtained [BRAND_NAME] inventory

If you do not comply within 5 business days, we will have no alternative but to:
1. File an official IP infringement complaint through Amazon Brand Registry
2. Report your account to Amazon Seller Performance for policy violations
3. Pursue all available legal remedies, including injunctive relief and monetary damages

This letter is written without prejudice to our rights and remedies, all of which are expressly reserved.

Sincerely,
[YOUR_NAME]
[YOUR_TITLE]
[COMPANY_NAME]
[ADDRESS]
[EMAIL]
[PHONE]
[DATE]',
 N'<p><strong>CEASE AND DESIST NOTICE</strong></p><p>You are selling [BRAND_NAME] products (ASIN: [ASIN]) without authorization. This constitutes trademark infringement. You must <strong>immediately remove all listings and confirm compliance within 5 business days</strong> or we will file Amazon IP complaints and pursue legal remedies.</p><p>[YOUR_NAME], [COMPANY_NAME]</p>',
 'cease-desist,unauthorized,seller,trademark,brand'),

('BRAND_3_6_MAP_VIOLATION_FIRST',
 'MAP Policy Violation — First Warning',
 'BRAND_IP',
 'MAP',
 'MAP Policy Violation Notice — [BRAND_NAME] Products — Action Required Within 48 Hours',
 N'[DATE]

RE: Minimum Advertised Price (MAP) Policy Violation — [BRAND_NAME]

Dear [SELLER_NAME / "Valued Reseller"],

It has come to our attention that you are currently advertising [BRAND_NAME] product(s) below our established Minimum Advertised Price (MAP) policy.

Violation Details:
Platform: Amazon.com
ASIN(s): [ASIN]
Your Current Advertised Price: $[YOUR_PRICE]
MAP Policy Price: $[MAP_PRICE]
Violation Amount: $[VIOLATION_AMOUNT] below MAP
Date Identified: [DATE]

Our MAP Policy:
All authorized resellers of [BRAND_NAME] products are required to advertise and sell our products at or above the MAP of $[MAP_PRICE] per unit. This policy applies to all online and offline channels and was communicated to you in your authorized reseller agreement dated [AGREEMENT_DATE].

Required Action:
Please update your advertised price to $[MAP_PRICE] or higher within 48 hours of receiving this notice.

This is your first and informal notification. We are providing this opportunity to correct the violation before formal action is taken.

Please reply to confirm that you have corrected the pricing and provide a screenshot of the updated listing.

If you have questions about our MAP policy, please contact us at [CONTACT_EMAIL].

Sincerely,
[YOUR_NAME]
[BRAND_NAME] Brand Team
[COMPANY_NAME]',
 N'<p>Dear [SELLER_NAME],</p><p>You are advertising [BRAND_NAME] (ASIN: [ASIN]) at <strong>$[YOUR_PRICE]</strong>, below our MAP of <strong>$[MAP_PRICE]</strong>. Please update your price within 48 hours and confirm via reply. This is your first notice.</p><p>Sincerely, [BRAND_NAME] Brand Team</p>',
 'MAP,pricing,policy,violation,first-warning'),

('BRAND_3_7_MAP_VIOLATION_SECOND',
 'MAP Policy Violation — Second Warning (Escalation)',
 'BRAND_IP',
 'MAP',
 'SECOND NOTICE — MAP Policy Violation — [BRAND_NAME] — Reseller Agreement at Risk',
 N'[DATE]

RE: SECOND NOTICE — MAP Policy Violation — [BRAND_NAME] — Reseller Agreement Termination Warning

Dear [SELLER_NAME],

On [FIRST_NOTICE_DATE], we sent you a MAP violation notice regarding ASIN [ASIN]. As of today ([TODAY_DATE]), your listed price of $[YOUR_PRICE] remains below our MAP of $[MAP_PRICE]. You have not corrected the violation or responded to our notice.

This is your formal second and final warning.

Non-compliance with our MAP policy is a material breach of your authorized reseller agreement with [COMPANY_NAME]. Continued violation will result in:

1. Immediate termination of your authorized reseller agreement
2. Removal of your ability to purchase [BRAND_NAME] products from our distribution network
3. Filing of an Amazon IP complaint to have your listings removed
4. Potential legal action for damages caused by MAP violations

Required Action:
Update your price to $[MAP_PRICE] or higher within 24 hours and reply to this email with a screenshot confirming the price change.

If we do not receive confirmation of compliance within 24 hours, we will proceed with termination of your reseller agreement and initiation of Amazon Brand Registry complaints.

Sincerely,
[YOUR_NAME]
[YOUR_TITLE]
[COMPANY_NAME]
[EMAIL]
[PHONE]',
 N'<p>Dear [SELLER_NAME],</p><p><strong>SECOND AND FINAL NOTICE.</strong> Your price ($[YOUR_PRICE]) remains below MAP ($[MAP_PRICE]) despite our first notice on [FIRST_NOTICE_DATE]. Correct within 24 hours or face reseller agreement termination and Amazon IP complaints.</p><p>[YOUR_NAME], [COMPANY_NAME]</p>',
 'MAP,second-notice,warning,termination,escalation');

-- ============================================================
-- CATEGORY 4: INTERNAL OPERATIONS EMAILS
-- ============================================================

INSERT INTO dbo.EmailTemplates (TemplateCode, TemplateName, Category, SubCategory, SubjectLine, BodyText, BodyHtml, Tags) VALUES

('INTERNAL_4_1_VA_DAILY_BRIEFING',
 'Daily Morning Briefing Template for VA',
 'INTERNAL_OPS',
 'VA_MANAGEMENT',
 'Daily FBA Task Assignment — [DATE] — [SELLER_ACCOUNT_NAME]',
 N'Hi [VA_NAME],

Good morning. Here are your tasks for today, [DATE], for the [SELLER_ACCOUNT_NAME] account.

PRIORITY 1 — REPORTS TO DOWNLOAD AND UPLOAD (Complete by 10:00 AM)
Please download the following reports from Seller Central and upload them to the FBA platform:

[ ] FBA Inventory Report — download today, select "All Active Listings"
[ ] Order Report — select date range: [YESTERDAY] to [TODAY]
[ ] [ADDITIONAL_REPORT_IF_NEEDED]

Upload steps: Go to FBA Platform > CSV Import Center > Select Account: [SELLER_ACCOUNT_NAME] > Select Report Type > Upload.
Status should show COMPLETE. If it shows FAILED or PARTIAL, copy the error and include in your end-of-day report.

PRIORITY 2 — CHECK ALERTS (Complete by 10:30 AM)
[ ] Log into FBA Platform > Alert Center
[ ] List all CRITICAL and HIGH alerts in your report
[ ] DO NOT close or resolve any alerts — note them only

PRIORITY 3 — INVENTORY REVIEW (Complete by 11:00 AM)
[ ] Go to Inventory Manager > Reorder Suggestions
[ ] Filter: Urgency Score = HIGH or CRITICAL
[ ] List all flagged SKUs, current qty, and days of supply in your report

PRIORITY 4 — CASE NOTES (if assigned)
[ ] Check Case Manager for any open cases assigned to you
[ ] Add a note to each open case with any updates from Amazon
[ ] DO NOT change case status or resolved amount

END OF DAY REPORT
Please send your report by [EOD_TIME] using this format:
1. Reports uploaded: [list with status]
2. Critical/High alerts found: [list]
3. Reorder SKUs flagged: [list]
4. Case updates: [summary]
5. Any issues or questions: [notes]

Thank you,
[MANAGER_NAME]
[COMPANY_NAME]',
 N'<p>Hi [VA_NAME],</p><p><strong>Tasks for [DATE] — [SELLER_ACCOUNT_NAME]</strong></p><ol><li>Download and upload FBA reports by 10:00 AM</li><li>Check Alert Center and note all CRITICAL/HIGH alerts</li><li>Review Reorder Suggestions — note HIGH/CRITICAL urgency SKUs</li><li>Add case notes to assigned cases (do not change status)</li></ol><p>Send EOD report by [EOD_TIME].</p><p>Thanks, [MANAGER_NAME]</p>',
 'VA,daily,briefing,tasks,internal'),

('INTERNAL_4_5_CLIENT_MONTHLY_REPORT',
 'Monthly FBA Performance Report to Client',
 'INTERNAL_OPS',
 'CLIENT_REPORTING',
 '[SELLER_ACCOUNT_NAME] — FBA Performance Report — [MONTH] [YEAR]',
 N'Dear [CLIENT_NAME],

Please find below your Amazon FBA performance summary for [MONTH] [YEAR].

EXECUTIVE SUMMARY
Account: [SELLER_ACCOUNT_NAME]
Report Period: [DATE_FROM] – [DATE_TO]

SALES PERFORMANCE
Total Revenue: $[TOTAL_REVENUE]
Total Units Sold: [TOTAL_UNITS]
Average Order Value: $[AVG_ORDER_VALUE]
Month-Over-Month Revenue Change: [MOM_CHANGE]%
Year-Over-Year Revenue Change: [YOY_CHANGE]%

TOP PERFORMING ASINs:
1. [ASIN_1] — [TITLE_1] — $[REVENUE_1] — [UNITS_1] units
2. [ASIN_2] — [TITLE_2] — $[REVENUE_2] — [UNITS_2] units
3. [ASIN_3] — [TITLE_3] — $[REVENUE_3] — [UNITS_3] units

PROFITABILITY
Gross Revenue: $[GROSS_REVENUE]
FBA Fees: ($[FBA_FEES])
Referral Fees: ($[REFERRAL_FEES])
PPC Spend: ($[PPC_SPEND])
COGS: ($[COGS_TOTAL])
Returns/Refunds: ($[REFUNDS])
Reimbursements Received: $[REIMBURSEMENTS]
Net Profit: $[NET_PROFIT]
Net Margin: [NET_MARGIN]%

INVENTORY STATUS
ASINs at Risk of Stockout: [STOCKOUT_COUNT]
Overstock ASINs: [OVERSTOCK_COUNT]
Stranded Units: [STRANDED_COUNT]
Current IPI Score: [IPI_SCORE]

CASE MANAGEMENT
Cases Opened This Month: [CASES_OPENED]
Cases Resolved This Month: [CASES_RESOLVED]
Amount Recovered via Cases: $[AMOUNT_RECOVERED]
Open Cases: [OPEN_CASES]

REIMBURSEMENTS
New Opportunities Identified: $[NEW_REIMB_OPPORTUNITIES]
Reimbursements Received: $[REIMB_RECEIVED]
Pending Claims: $[PENDING_CLAIMS]

KEY ACTIONS THIS MONTH:
[ACTION_1]
[ACTION_2]
[ACTION_3]

RECOMMENDED ACTIONS FOR NEXT MONTH:
[RECOMMENDATION_1]
[RECOMMENDATION_2]
[RECOMMENDATION_3]

Please review the attached detailed reports. Our next review call is scheduled for [NEXT_CALL_DATE] at [NEXT_CALL_TIME].

If you have any questions, please do not hesitate to contact us.

Best regards,
[YOUR_NAME]
[YOUR_COMPANY]
[EMAIL]
[PHONE]',
 N'<p>Dear [CLIENT_NAME],</p><h3>[SELLER_ACCOUNT_NAME] — FBA Report — [MONTH] [YEAR]</h3><p><strong>Revenue:</strong> $[TOTAL_REVENUE] | <strong>Net Profit:</strong> $[NET_PROFIT] ([NET_MARGIN]%)<br><strong>Cases Recovered:</strong> $[AMOUNT_RECOVERED] | <strong>Open Opportunities:</strong> $[NEW_REIMB_OPPORTUNITIES]</p><p>Detailed reports attached. Next call: [NEXT_CALL_DATE].</p><p>Best regards, [YOUR_NAME]</p>',
 'client,monthly,report,performance,internal'),

('INTERNAL_4_6_VA_ONBOARDING',
 'VA Onboarding Email',
 'INTERNAL_OPS',
 'VA_MANAGEMENT',
 'Welcome to the Team — Your Access, Tools, and Daily Responsibilities — [VA_NAME]',
 N'Hi [VA_NAME],

Welcome to the team! We are excited to have you supporting our Amazon FBA operations. This email contains everything you need to get started.

YOUR ACCESS CREDENTIALS
FBA Management Platform: [PLATFORM_URL]
Username: [VA_USERNAME]
Temporary Password: [TEMP_PASSWORD] (Please change immediately upon first login)
Your Permission Level: VA Read-Only (you can view and add notes — you cannot delete records, change case status, or modify settings)

Amazon Seller Central: You will receive a separate invitation to our Seller Central account with restricted VA access.

YOUR DAILY RESPONSIBILITIES
Every business day by 10:00 AM:
1. Download assigned reports from Amazon Seller Central (see SOP: VA Daily Report Downloads)
2. Upload reports to the FBA Platform (see SOP: CSV Upload Process)
3. Check Alert Center and note all CRITICAL and HIGH alerts
4. Check Case Manager for assigned cases and add updates
5. Send your Daily Report to [MANAGER_NAME] at [MANAGER_EMAIL] using the daily report template

Every Monday:
6. Download and upload the Reimbursements Report (last 30 days)
7. Download and upload the Inventory Adjustments Report (last 30 days)
8. Run the Monthly Reimbursement Checklist if it is the first Monday of the month
9. Send a Weekly Summary report

WHAT YOU MUST NEVER DO
The following actions are STRICTLY off-limits for your role:
1. NEVER change COGS values for any product — only managers update COGS
2. NEVER delete imported files or import records
3. NEVER close, resolve, or change the status of any case without manager approval
4. NEVER share your login credentials with anyone
5. NEVER contact Amazon Seller Support directly without manager instruction
6. NEVER make any changes to product listings or prices

GETTING HELP
If you are unsure about any task, please ask before acting.
Your manager: [MANAGER_NAME] — [MANAGER_EMAIL] — [MANAGER_PHONE]
Team Slack / [COMMUNICATION_CHANNEL]: [CHANNEL_LINK]

Please reply to this email confirming you have:
[ ] Logged into the FBA Platform and changed your password
[ ] Read and understood your daily responsibilities
[ ] Read and understood the "What You Must Never Do" list

Welcome aboard. We look forward to working with you!

Best regards,
[YOUR_NAME]
[COMPANY_NAME]',
 N'<p>Hi [VA_NAME],</p><p><strong>Welcome to the team!</strong> Your platform access: [PLATFORM_URL] | Username: [VA_USERNAME] | Temp Password: [TEMP_PASSWORD]</p><p><strong>Daily duties:</strong> Download/upload reports, check alerts, add case notes, send EOD report.</p><p><strong>Never do:</strong> Change COGS, delete imports, close cases, contact Amazon without approval.</p><p>Please confirm receipt. Best regards, [YOUR_NAME]</p>',
 'VA,onboarding,welcome,access,responsibilities');

GO

-- Verify all templates were inserted
SELECT
    Category,
    COUNT(*) AS TemplateCount
FROM dbo.EmailTemplates
GROUP BY Category
ORDER BY Category;
GO
