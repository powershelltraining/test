-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 08_SP_Reports_PPC_Listings_Research.sql
-- DESC: Sales/P&L reports, PPC analytics, listing health,
--       niche research, multi-account dashboard SPs
-- ============================================================
SET NOCOUNT ON;
GO

USE AmazonFBAManager;
GO

-- ============================================================
-- SP: P&L by SKU
-- ============================================================
CREATE PROCEDURE dbo.usp_Reports_ProfitLossBySKU
    @SellerAccountId    INT,
    @UserId             INT,
    @DateFrom           DATE,
    @DateTo             DATE,
    @GroupBy            VARCHAR(10) = 'SKU'   -- SKU, BRAND, CATEGORY
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        COALESCE(p.Brand, 'Unbranded')                  AS Brand,
        COALESCE(p.Category, 'Uncategorized')           AS Category,

        -- Revenue
        SUM(soi.ItemPrice - soi.PromotionDiscount)      AS Revenue,
        SUM(soi.QtySold)                                AS UnitsSold,
        ROUND(SUM(soi.ItemPrice - soi.PromotionDiscount) / NULLIF(SUM(soi.QtySold), 0), 2) AS AvgSellingPrice,

        -- COGS
        SUM(soi.QtySold * COALESCE(p.COGS, 0))         AS COGS_Total,

        -- FBA Fees
        COALESCE((
            SELECT SUM(ABS(f.FeeAmount))
            FROM dbo.FBAFees f
            WHERE f.ProductId = p.ProductId
              AND f.FeeDate BETWEEN @DateFrom AND @DateTo
              AND f.FeeTypeCode = 'FBA_FULFILLMENT'
        ), 0)                                           AS FBAFulfillmentFees,

        COALESCE((
            SELECT SUM(ABS(f.FeeAmount))
            FROM dbo.FBAFees f
            WHERE f.ProductId = p.ProductId
              AND f.FeeDate BETWEEN @DateFrom AND @DateTo
              AND f.FeeTypeCode = 'REFERRAL_FEE'
        ), 0)                                           AS ReferralFees,

        COALESCE((
            SELECT SUM(ABS(f.FeeAmount))
            FROM dbo.FBAFees f
            WHERE f.ProductId = p.ProductId
              AND f.FeeDate BETWEEN @DateFrom AND @DateTo
              AND f.FeeTypeCode IN ('MONTHLY_STORAGE','LONG_TERM_STORAGE','AGED_181_270','AGED_271_365','AGED_365_PLUS')
        ), 0)                                           AS StorageFees,

        -- PPC
        COALESCE((
            SELECT SUM(k.Spend)
            FROM dbo.PPCKeywords k
            INNER JOIN dbo.PPCCampaigns c ON c.CampaignId = k.CampaignId
            WHERE c.SellerAccountId = @SellerAccountId
              AND k.ReportDate BETWEEN @DateFrom AND @DateTo
            -- Note: PPC spend not always linkable to single ASIN; use account-level spend
        ), 0)                                           AS PPC_Spend_AccountLevel,

        -- Refunds issued
        COALESCE((
            SELECT SUM(r.RefundAmount)
            FROM dbo.Returns r
            WHERE r.ProductId = p.ProductId
              AND r.SellerAccountId = @SellerAccountId
              AND r.CustomerRefundDate BETWEEN @DateFrom AND @DateTo
        ), 0)                                           AS RefundsIssued,

        -- Reimbursements received
        COALESCE((
            SELECT SUM(reimb.TotalAmount)
            FROM dbo.Reimbursements reimb
            WHERE reimb.ProductId = p.ProductId
              AND reimb.SellerAccountId = @SellerAccountId
              AND reimb.ReimbDate BETWEEN @DateFrom AND @DateTo
        ), 0)                                           AS ReimbReceived,

        -- NET PROFIT CALCULATION
        SUM(soi.ItemPrice - soi.PromotionDiscount)
            - SUM(soi.QtySold * COALESCE(p.COGS, 0))
            - COALESCE((SELECT SUM(ABS(f2.FeeAmount)) FROM dbo.FBAFees f2
                        WHERE f2.ProductId = p.ProductId
                          AND f2.FeeDate BETWEEN @DateFrom AND @DateTo), 0)
            - COALESCE((SELECT SUM(r2.RefundAmount) FROM dbo.Returns r2
                        WHERE r2.ProductId = p.ProductId
                          AND r2.SellerAccountId = @SellerAccountId
                          AND r2.CustomerRefundDate BETWEEN @DateFrom AND @DateTo), 0)
            + COALESCE((SELECT SUM(reimb2.TotalAmount) FROM dbo.Reimbursements reimb2
                        WHERE reimb2.ProductId = p.ProductId
                          AND reimb2.SellerAccountId = @SellerAccountId
                          AND reimb2.ReimbDate BETWEEN @DateFrom AND @DateTo), 0)
                                                        AS NetProfit,

        -- MARGINS
        ROUND(
            (SUM(soi.ItemPrice - soi.PromotionDiscount)
                - SUM(soi.QtySold * COALESCE(p.COGS, 0))
                - COALESCE((SELECT SUM(ABS(f3.FeeAmount)) FROM dbo.FBAFees f3
                            WHERE f3.ProductId = p.ProductId AND f3.FeeDate BETWEEN @DateFrom AND @DateTo), 0))
            / NULLIF(SUM(soi.ItemPrice - soi.PromotionDiscount), 0) * 100
        , 2)                                            AS NetMarginPct,

        ROUND(
            SUM(soi.QtySold * COALESCE(p.COGS, 0)) /
            NULLIF(SUM(soi.ItemPrice - soi.PromotionDiscount), 0) * 100
        , 2)                                            AS COGSPct,

        p.COGS                                          AS COGSPerUnit,
        CASE WHEN p.COGS IS NULL THEN 'COGS_MISSING — profits overstated' ELSE NULL END AS DataWarning

    FROM dbo.SalesOrderItems soi
    INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
    INNER JOIN dbo.Products p ON p.ProductId = soi.ProductId
    WHERE so.SellerAccountId = @SellerAccountId
      AND so.OrderDate BETWEEN @DateFrom AND @DateTo
    GROUP BY
        p.ProductId, p.SKU, p.ASIN, p.ProductTitle,
        p.Brand, p.Category, p.COGS
    ORDER BY NetProfit DESC;
END;
GO

-- ============================================================
-- SP: Sales Velocity & Trend
-- ============================================================
CREATE PROCEDURE dbo.usp_Reports_SalesVelocity
    @SellerAccountId    INT,
    @UserId             INT,
    @ASIN               VARCHAR(20) = NULL,   -- NULL = all ASINs
    @Periods            INT = 12              -- months to show
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    ;WITH MonthlySales AS (
        SELECT
            p.ProductId,
            p.SKU,
            p.ASIN,
            YEAR(so.OrderDate)                  AS SaleYear,
            MONTH(so.OrderDate)                 AS SaleMonth,
            DATENAME(MONTH, so.OrderDate) + ' ' + CAST(YEAR(so.OrderDate) AS VARCHAR) AS PeriodLabel,
            SUM(soi.QtySold)                    AS UnitsSold,
            SUM(soi.ItemPrice - soi.PromotionDiscount) AS Revenue
        FROM dbo.SalesOrderItems soi
        INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
        INNER JOIN dbo.Products p ON p.ProductId = soi.ProductId
        WHERE so.SellerAccountId = @SellerAccountId
          AND so.OrderDate >= DATEADD(MONTH, -@Periods, SYSUTCDATETIME())
          AND (@ASIN IS NULL OR p.ASIN = @ASIN)
        GROUP BY p.ProductId, p.SKU, p.ASIN, YEAR(so.OrderDate), MONTH(so.OrderDate), DATENAME(MONTH, so.OrderDate)
    )
    SELECT
        ms.ProductId,
        ms.SKU,
        ms.ASIN,
        ms.PeriodLabel,
        ms.SaleYear,
        ms.SaleMonth,
        ms.UnitsSold,
        ms.Revenue,
        -- MoM growth
        LAG(ms.UnitsSold, 1, 0) OVER (
            PARTITION BY ms.ProductId
            ORDER BY ms.SaleYear, ms.SaleMonth
        )                                               AS PrevMonthUnits,
        ROUND(
            (CAST(ms.UnitsSold AS DECIMAL) - LAG(ms.UnitsSold, 1, 0) OVER (
                PARTITION BY ms.ProductId ORDER BY ms.SaleYear, ms.SaleMonth))
            / NULLIF(LAG(ms.UnitsSold, 1, 0) OVER (
                PARTITION BY ms.ProductId ORDER BY ms.SaleYear, ms.SaleMonth), 0) * 100
        , 1)                                            AS MoM_GrowthPct,
        -- YoY comparison
        LAG(ms.UnitsSold, 12, NULL) OVER (
            PARTITION BY ms.ProductId
            ORDER BY ms.SaleYear, ms.SaleMonth
        )                                               AS SameMonthPriorYearUnits,
        -- Daily velocity for this period (units/day)
        ROUND(CAST(ms.UnitsSold AS DECIMAL) /
            DAY(EOMONTH(DATEFROMPARTS(ms.SaleYear, ms.SaleMonth, 1))), 2) AS DailyVelocity
    FROM MonthlySales ms
    ORDER BY ms.ProductId, ms.SaleYear, ms.SaleMonth;
END;
GO

-- ============================================================
-- SP: Fee Breakdown Analysis
-- ============================================================
CREATE PROCEDURE dbo.usp_Reports_FeeBreakdownByASIN
    @SellerAccountId    INT,
    @UserId             INT,
    @DateFrom           DATE,
    @DateTo             DATE
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    ;WITH FeesByProduct AS (
        SELECT
            f.ProductId,
            SUM(CASE WHEN f.FeeTypeCode = 'FBA_FULFILLMENT' THEN ABS(f.FeeAmount) ELSE 0 END) AS FBAFee,
            SUM(CASE WHEN f.FeeTypeCode = 'REFERRAL_FEE'    THEN ABS(f.FeeAmount) ELSE 0 END) AS ReferralFee,
            SUM(CASE WHEN f.FeeTypeCode IN ('MONTHLY_STORAGE','LONG_TERM_STORAGE',
                'AGED_181_270','AGED_271_365','AGED_365_PLUS') THEN ABS(f.FeeAmount) ELSE 0 END) AS StorageFee,
            SUM(CASE WHEN f.FeeTypeCode NOT IN ('FBA_FULFILLMENT','REFERRAL_FEE','MONTHLY_STORAGE',
                'LONG_TERM_STORAGE','AGED_181_270','AGED_271_365','AGED_365_PLUS')
                THEN ABS(f.FeeAmount) ELSE 0 END) AS OtherFees,
            SUM(ABS(f.FeeAmount)) AS TotalFees
        FROM dbo.FBAFees f
        WHERE f.SellerAccountId = @SellerAccountId
          AND f.FeeDate BETWEEN @DateFrom AND @DateTo
        GROUP BY f.ProductId
    ),
    RevenueByProduct AS (
        SELECT
            soi.ProductId,
            SUM(soi.ItemPrice - soi.PromotionDiscount) AS Revenue,
            SUM(soi.QtySold) AS UnitsSold
        FROM dbo.SalesOrderItems soi
        INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
        WHERE so.SellerAccountId = @SellerAccountId
          AND so.OrderDate BETWEEN @DateFrom AND @DateTo
        GROUP BY soi.ProductId
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        rev.Revenue,
        rev.UnitsSold,
        f.FBAFee,
        f.ReferralFee,
        f.StorageFee,
        f.OtherFees,
        f.TotalFees,
        ROUND(f.TotalFees / NULLIF(rev.Revenue, 0) * 100, 2)      AS TotalFeePct,
        ROUND(f.FBAFee / NULLIF(rev.Revenue, 0) * 100, 2)          AS FBAFeePct,
        ROUND(f.ReferralFee / NULLIF(rev.Revenue, 0) * 100, 2)     AS ReferralFeePct,
        ROUND(f.StorageFee / NULLIF(rev.Revenue, 0) * 100, 2)      AS StorageFeePct,
        -- Net margin after all fees (before COGS and PPC)
        ROUND((rev.Revenue - f.TotalFees - rev.UnitsSold * COALESCE(p.COGS, 0))
              / NULLIF(rev.Revenue, 0) * 100, 2)                    AS NetMarginAfterFeesCOGS,
        p.COGS
    FROM dbo.Products p
    INNER JOIN FeesByProduct f ON f.ProductId = p.ProductId
    LEFT JOIN RevenueByProduct rev ON rev.ProductId = p.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
    ORDER BY f.TotalFees DESC;
END;
GO

-- ============================================================
-- SP: Multi-Account Summary Dashboard
-- ============================================================
CREATE PROCEDURE dbo.usp_Reports_MultiAccountSummary
    @UserId             INT,
    @DateFrom           DATE,
    @DateTo             DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Get all accounts accessible to this user
    ;WITH UserAccounts AS (
        SELECT sa.SellerAccountId, sa.AccountName, m.MarketplaceName
        FROM dbo.SellerAccounts sa
        INNER JOIN dbo.Marketplaces m ON m.MarketplaceId = sa.MarketplaceId
        WHERE sa.IsActive = 1
          AND dbo.fn_UserHasAccountAccess(@UserId, sa.SellerAccountId) = 1
    )
    SELECT
        ua.SellerAccountId,
        ua.AccountName,
        ua.MarketplaceName,

        -- Revenue
        ROUND(COALESCE((
            SELECT SUM(soi.ItemPrice - soi.PromotionDiscount)
            FROM dbo.SalesOrderItems soi
            INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
            WHERE so.SellerAccountId = ua.SellerAccountId
              AND so.OrderDate BETWEEN @DateFrom AND @DateTo
        ), 0), 2)                                       AS TotalRevenue,

        -- Units sold
        COALESCE((
            SELECT SUM(soi.QtySold)
            FROM dbo.SalesOrderItems soi
            INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
            WHERE so.SellerAccountId = ua.SellerAccountId
              AND so.OrderDate BETWEEN @DateFrom AND @DateTo
        ), 0)                                           AS TotalUnitsSold,

        -- Open cases
        (SELECT COUNT(*) FROM dbo.Cases c
         WHERE c.SellerAccountId = ua.SellerAccountId
           AND c.Status NOT IN ('RESOLVED','CLOSED'))   AS OpenCaseCount,

        -- Open reimbursement opportunities
        ROUND(COALESCE((
            SELECT SUM(ra.ClaimableAmount)
            FROM dbo.ReimbursementAudit ra
            WHERE ra.SellerAccountId = ua.SellerAccountId
              AND ra.Status = 'OPEN'
        ), 0), 2)                                       AS OpenReimbursementOpportunity,

        -- Unread critical alerts
        (SELECT COUNT(*) FROM dbo.Alerts a
         WHERE a.SellerAccountId = ua.SellerAccountId
           AND a.IsRead = 0
           AND a.Severity IN ('HIGH','CRITICAL')
           AND a.IsActive = 1)                          AS UnreadCriticalAlerts,

        -- IPI Score (latest)
        (SELECT TOP 1 sn.IPI_Score
         FROM dbo.InventorySnapshots sn
         WHERE sn.SellerAccountId = ua.SellerAccountId
           AND sn.IPI_Score IS NOT NULL
         ORDER BY sn.SnapshotDate DESC)                 AS LatestIPIScore,

        -- ASINs with COGS missing
        (SELECT COUNT(*) FROM dbo.Products p
         WHERE p.SellerAccountId = ua.SellerAccountId
           AND p.IsActive = 1
           AND (p.COGS IS NULL OR p.COGS = 0))         AS MissingCOGSCount

    FROM UserAccounts ua
    ORDER BY TotalRevenue DESC;
END;
GO

-- ============================================================
-- SP: Return Rate Analysis
-- ============================================================
CREATE PROCEDURE dbo.usp_Reports_ReturnRateAnalysis
    @SellerAccountId    INT,
    @UserId             INT,
    @DateFrom           DATE,
    @DateTo             DATE
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    ;WITH SalesData AS (
        SELECT soi.ProductId, SUM(soi.QtySold) AS UnitsSold
        FROM dbo.SalesOrderItems soi
        INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
        WHERE so.SellerAccountId = @SellerAccountId
          AND so.OrderDate BETWEEN @DateFrom AND @DateTo
        GROUP BY soi.ProductId
    ),
    ReturnData AS (
        SELECT
            r.ProductId,
            COUNT(*) AS ReturnCount,
            SUM(r.Qty) AS QtyReturned,
            SUM(r.RefundAmount) AS TotalRefunded,
            COUNT(CASE WHEN r.ReturnlessRefund = 1 THEN 1 END) AS ReturnlessCount,
            -- Top return reason (mode)
            (SELECT TOP 1 r2.ReturnReasonCode
             FROM dbo.Returns r2
             WHERE r2.ProductId = r.ProductId AND r2.SellerAccountId = @SellerAccountId
               AND r2.ReturnDate BETWEEN @DateFrom AND @DateTo
             GROUP BY r2.ReturnReasonCode
             ORDER BY COUNT(*) DESC) AS TopReturnReason
        FROM dbo.Returns r
        WHERE r.SellerAccountId = @SellerAccountId
          AND r.ReturnDate BETWEEN @DateFrom AND @DateTo
        GROUP BY r.ProductId
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        COALESCE(sd.UnitsSold, 0)               AS UnitsSold,
        COALESCE(rd.QtyReturned, 0)             AS QtyReturned,
        ROUND(
            CAST(COALESCE(rd.QtyReturned, 0) AS DECIMAL) /
            NULLIF(sd.UnitsSold, 0) * 100
        , 2)                                    AS ReturnRatePct,
        ROUND(COALESCE(rd.TotalRefunded, 0), 2) AS TotalRefundedUSD,
        COALESCE(rd.ReturnlessCount, 0)         AS ReturnlessRefundCount,
        ROUND(
            CAST(COALESCE(rd.ReturnlessCount, 0) AS DECIMAL) /
            NULLIF(COALESCE(rd.ReturnCount, 0), 0) * 100
        , 1)                                    AS ReturnlessRefundPct,
        rd.TopReturnReason,
        rrc.ReasonDescription                   AS TopReturnReasonDescription,
        -- Flag high return rate ASINs (>8% is concerning)
        CASE
            WHEN CAST(COALESCE(rd.QtyReturned, 0) AS DECIMAL) / NULLIF(sd.UnitsSold, 0) > 0.15
                THEN 'CRITICAL — Return rate > 15%. Amazon may suppress listing.'
            WHEN CAST(COALESCE(rd.QtyReturned, 0) AS DECIMAL) / NULLIF(sd.UnitsSold, 0) > 0.08
                THEN 'HIGH — Return rate > 8%. Investigate product quality.'
            WHEN CAST(COALESCE(rd.QtyReturned, 0) AS DECIMAL) / NULLIF(sd.UnitsSold, 0) > 0.05
                THEN 'MONITOR — Return rate above average.'
            ELSE 'NORMAL'
        END                                     AS ReturnRateFlag
    FROM dbo.Products p
    INNER JOIN SalesData sd ON sd.ProductId = p.ProductId
    LEFT JOIN ReturnData rd ON rd.ProductId = p.ProductId
    LEFT JOIN dbo.ReturnReasonCodes rrc ON rrc.ReasonCode = rd.TopReturnReason
    WHERE p.SellerAccountId = @SellerAccountId
    ORDER BY ReturnRatePct DESC;
END;
GO

-- ============================================================
-- SP: Cash Flow Forecast
-- ============================================================
CREATE PROCEDURE dbo.usp_Reports_CashFlowForecast
    @SellerAccountId    INT,
    @UserId             INT,
    @ForecastDays       INT = 90
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    -- Base forecasts on 30-day trailing averages
    DECLARE
        @AvgDailyRevenue    DECIMAL(18,4),
        @AvgDailyCOGS       DECIMAL(18,4),
        @AvgDailyFees       DECIMAL(18,4),
        @AvgDailyPPC        DECIMAL(18,4),
        @AvgDailyRefunds    DECIMAL(18,4),
        @AvgDailyReimb      DECIMAL(18,4);

    SELECT @AvgDailyRevenue = SUM(soi.ItemPrice - soi.PromotionDiscount) / 30.0
    FROM dbo.SalesOrderItems soi
    INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
    WHERE so.SellerAccountId = @SellerAccountId
      AND so.OrderDate >= DATEADD(DAY, -30, SYSUTCDATETIME());

    SELECT @AvgDailyCOGS = SUM(soi.QtySold * COALESCE(p.COGS, 0)) / 30.0
    FROM dbo.SalesOrderItems soi
    INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
    INNER JOIN dbo.Products p ON p.ProductId = soi.ProductId
    WHERE so.SellerAccountId = @SellerAccountId
      AND so.OrderDate >= DATEADD(DAY, -30, SYSUTCDATETIME());

    SELECT @AvgDailyFees = SUM(ABS(f.FeeAmount)) / 30.0
    FROM dbo.FBAFees f
    WHERE f.SellerAccountId = @SellerAccountId
      AND f.FeeDate >= DATEADD(DAY, -30, CAST(SYSUTCDATETIME() AS DATE));

    SELECT @AvgDailyPPC = SUM(k.Spend) / 30.0
    FROM dbo.PPCKeywords k
    INNER JOIN dbo.PPCCampaigns c ON c.CampaignId = k.CampaignId
    WHERE c.SellerAccountId = @SellerAccountId
      AND k.ReportDate >= DATEADD(DAY, -30, CAST(SYSUTCDATETIME() AS DATE));

    SELECT @AvgDailyRefunds = SUM(r.RefundAmount) / 30.0
    FROM dbo.Returns r
    WHERE r.SellerAccountId = @SellerAccountId
      AND r.CustomerRefundDate >= DATEADD(DAY, -30, CAST(SYSUTCDATETIME() AS DATE));

    SELECT @AvgDailyReimb = SUM(reimb.TotalAmount) / 30.0
    FROM dbo.Reimbursements reimb
    WHERE reimb.SellerAccountId = @SellerAccountId
      AND reimb.ReimbDate >= DATEADD(DAY, -30, CAST(SYSUTCDATETIME() AS DATE));

    -- Generate daily forecast using tally approach
    ;WITH Days AS (
        SELECT TOP (@ForecastDays)
            ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS DayNum
        FROM sys.all_objects a CROSS JOIN sys.all_objects b
    )
    SELECT
        CAST(DATEADD(DAY, d.DayNum, CAST(SYSUTCDATETIME() AS DATE)) AS DATE) AS ForecastDate,
        d.DayNum                                            AS DayNumber,
        ROUND(COALESCE(@AvgDailyRevenue, 0), 2)            AS ProjectedRevenue,
        ROUND(COALESCE(@AvgDailyCOGS, 0), 2)               AS ProjectedCOGS,
        ROUND(COALESCE(@AvgDailyFees, 0), 2)               AS ProjectedFees,
        ROUND(COALESCE(@AvgDailyPPC, 0), 2)                AS ProjectedPPCSpend,
        ROUND(COALESCE(@AvgDailyRefunds, 0), 2)            AS ProjectedRefunds,
        ROUND(COALESCE(@AvgDailyReimb, 0), 2)              AS ProjectedReimb,
        ROUND(
            COALESCE(@AvgDailyRevenue, 0)
            - COALESCE(@AvgDailyCOGS, 0)
            - COALESCE(@AvgDailyFees, 0)
            - COALESCE(@AvgDailyPPC, 0)
            - COALESCE(@AvgDailyRefunds, 0)
            + COALESCE(@AvgDailyReimb, 0)
        , 2)                                               AS ProjectedNetCash,
        -- Cumulative
        ROUND(d.DayNum * (
            COALESCE(@AvgDailyRevenue, 0)
            - COALESCE(@AvgDailyCOGS, 0)
            - COALESCE(@AvgDailyFees, 0)
            - COALESCE(@AvgDailyPPC, 0)
            - COALESCE(@AvgDailyRefunds, 0)
            + COALESCE(@AvgDailyReimb, 0)
        ), 2)                                              AS CumulativeNetCash
    FROM Days d
    ORDER BY d.DayNum;
END;
GO

-- ============================================================
-- SP: PPC Audit — Wasted Spend + Harvest Opportunities
-- ============================================================
CREATE PROCEDURE dbo.usp_PPC_AuditCampaigns
    @SellerAccountId    INT,
    @UserId             INT,
    @DateFrom           DATE = NULL,
    @DateTo             DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF @DateFrom IS NULL SET @DateFrom = DATEADD(DAY, -30, CAST(SYSUTCDATETIME() AS DATE));
    IF @DateTo   IS NULL SET @DateTo   = CAST(SYSUTCDATETIME() AS DATE);

    -- WASTED SPEND: High spend keywords with zero or minimal conversions
    SELECT
        'WASTED_SPEND'                              AS AuditCategory,
        c.CampaignName,
        k.AdGroupName,
        k.KeywordText,
        k.MatchType,
        SUM(k.Spend)                                AS TotalSpend,
        SUM(k.Clicks)                               AS TotalClicks,
        SUM(k.Orders)                               AS TotalOrders,
        SUM(k.Sales)                                AS TotalSales,
        ROUND(SUM(k.Spend) / NULLIF(SUM(k.Clicks), 0), 2) AS CostPerClick,
        CASE WHEN SUM(k.Orders) = 0
            THEN 'PAUSE — Zero conversions with $' + CAST(ROUND(SUM(k.Spend), 2) AS NVARCHAR) + ' spent'
            WHEN ROUND(SUM(k.Spend) / NULLIF(SUM(k.Sales), 0), 2) > 0.50
            THEN 'REVIEW — ACoS > 50%: $' + CAST(ROUND(SUM(k.Spend) / SUM(k.Sales) * 100, 1) AS NVARCHAR) + '%'
            ELSE 'MONITOR'
        END                                         AS Recommendation
    FROM dbo.PPCKeywords k
    INNER JOIN dbo.PPCCampaigns c ON c.CampaignId = k.CampaignId
    WHERE c.SellerAccountId = @SellerAccountId
      AND k.ReportDate BETWEEN @DateFrom AND @DateTo
      AND k.IsSearchTerm = 0   -- Targeting keywords, not search terms
    GROUP BY c.CampaignName, k.AdGroupName, k.KeywordText, k.MatchType
    HAVING SUM(k.Spend) > 5 AND (SUM(k.Orders) = 0 OR SUM(k.Spend) / NULLIF(SUM(k.Sales), 0) > 0.50)

    UNION ALL

    -- HARVEST OPPORTUNITIES: Search terms converting well not yet in exact match
    SELECT
        'HARVEST_OPPORTUNITY',
        c.CampaignName,
        k.AdGroupName,
        k.KeywordText,
        k.MatchType,
        SUM(k.Spend),
        SUM(k.Clicks),
        SUM(k.Orders),
        SUM(k.Sales),
        ROUND(SUM(k.Spend) / NULLIF(SUM(k.Clicks), 0), 2),
        'ADD AS EXACT MATCH — Converting search term with ACoS: '
            + CAST(ROUND(SUM(k.Spend) / NULLIF(SUM(k.Sales), 0) * 100, 1) AS NVARCHAR) + '%'
    FROM dbo.PPCKeywords k
    INNER JOIN dbo.PPCCampaigns c ON c.CampaignId = k.CampaignId
    WHERE c.SellerAccountId = @SellerAccountId
      AND k.ReportDate BETWEEN @DateFrom AND @DateTo
      AND k.IsSearchTerm = 1       -- From search term report
      AND k.MatchType != 'EXACT'   -- Not already in exact
      AND k.Orders >= 2            -- Minimum 2 conversions
      AND k.Spend / NULLIF(k.Sales, 0) < 0.30   -- ACoS under 30%
      -- Not already added as exact keyword
      AND NOT EXISTS (
          SELECT 1 FROM dbo.PPCKeywords k2
          INNER JOIN dbo.PPCCampaigns c2 ON c2.CampaignId = k2.CampaignId
          WHERE c2.SellerAccountId = @SellerAccountId
            AND k2.KeywordText = k.KeywordText
            AND k2.MatchType = 'EXACT'
            AND k2.IsSearchTerm = 0
      )
    GROUP BY c.CampaignName, k.AdGroupName, k.KeywordText, k.MatchType

    ORDER BY AuditCategory, TotalSpend DESC;
END;
GO

-- ============================================================
-- SP: TACoS Calculator
-- ============================================================
CREATE PROCEDURE dbo.usp_PPC_CalculateTACoS
    @SellerAccountId    INT,
    @UserId             INT,
    @DateFrom           DATE,
    @DateTo             DATE
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    DECLARE
        @TotalRevenue   DECIMAL(18,4),
        @PPCRevenue     DECIMAL(18,4),
        @TotalSpend     DECIMAL(18,4);

    SELECT @TotalRevenue = SUM(soi.ItemPrice - soi.PromotionDiscount)
    FROM dbo.SalesOrderItems soi
    INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
    WHERE so.SellerAccountId = @SellerAccountId
      AND so.OrderDate BETWEEN @DateFrom AND @DateTo;

    SELECT @PPCRevenue = SUM(k.Sales), @TotalSpend = SUM(k.Spend)
    FROM dbo.PPCKeywords k
    INNER JOIN dbo.PPCCampaigns c ON c.CampaignId = k.CampaignId
    WHERE c.SellerAccountId = @SellerAccountId
      AND k.ReportDate BETWEEN @DateFrom AND @DateTo;

    SELECT
        @TotalRevenue           AS TotalRevenue,
        @PPCRevenue             AS PPCAttributedSales,
        @TotalRevenue - COALESCE(@PPCRevenue, 0) AS OrganicRevenue,
        @TotalSpend             AS TotalPPCSpend,
        -- ACoS = PPC Spend / PPC Sales (efficiency of ad spend on ad-attributed orders)
        ROUND(@TotalSpend / NULLIF(@PPCRevenue, 0) * 100, 2)    AS ACoS_Pct,
        -- TACoS = PPC Spend / Total Revenue (true business efficiency metric)
        ROUND(@TotalSpend / NULLIF(@TotalRevenue, 0) * 100, 2)  AS TACoS_Pct,
        ROUND(COALESCE(@PPCRevenue, 0) / NULLIF(@TotalRevenue, 0) * 100, 2) AS PPCSalesSharePct,
        ROUND((1 - COALESCE(@PPCRevenue, 0) / NULLIF(@TotalRevenue, 0)) * 100, 2) AS OrganicSalesSharePct,
        -- Benchmark guidance
        'Target TACoS: <10% healthy, 10-20% acceptable growth phase, >20% review campaigns.' AS Benchmark;
END;
GO

-- ============================================================
-- SP: Listing Health Score
-- ============================================================
CREATE PROCEDURE dbo.usp_Listing_GetHealthScore
    @ProductId          INT,
    @SellerAccountId    INT,
    @UserId             INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    ;WITH LatestListing AS (
        SELECT TOP 1 l.*
        FROM dbo.Listings l
        WHERE l.ProductId = @ProductId AND l.SellerAccountId = @SellerAccountId
        ORDER BY l.SnapshotDate DESC
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        l.ListingStatus,

        -- TITLE SCORE (0-25): length 150-200 chars, brand, main keyword
        CASE
            WHEN LEN(l.Title) BETWEEN 150 AND 200 THEN 25
            WHEN LEN(l.Title) BETWEEN 100 AND 150 THEN 18
            WHEN LEN(l.Title) BETWEEN 50 AND 100  THEN 12
            WHEN l.Title IS NULL OR LEN(l.Title) < 50 THEN 0
            ELSE 10
        END                                                 AS TitleScore,

        -- BULLETS SCORE (0-20): 5 bullets, 200+ chars each
        CASE
            WHEN l.BulletPoint5 IS NOT NULL THEN 20
            WHEN l.BulletPoint4 IS NOT NULL THEN 16
            WHEN l.BulletPoint3 IS NOT NULL THEN 12
            WHEN l.BulletPoint2 IS NOT NULL THEN 8
            WHEN l.BulletPoint1 IS NOT NULL THEN 4
            ELSE 0
        END                                                 AS BulletsScore,

        -- IMAGES SCORE (0-20): 7+ images = full score
        CASE
            WHEN l.ImageCount >= 7 THEN 20
            WHEN l.ImageCount >= 5 THEN 15
            WHEN l.ImageCount >= 3 THEN 10
            WHEN l.ImageCount >= 1 THEN 5
            ELSE 0
        END                                                 AS ImagesScore,

        -- A+ CONTENT SCORE (0-15)
        CASE WHEN l.HasAPlusContent = 1 THEN 15 ELSE 0 END AS APlusScore,

        -- KEYWORDS SCORE (0-20): backend keywords populated
        CASE
            WHEN LEN(COALESCE(l.BackendKeywords, '')) > 200 THEN 20
            WHEN LEN(COALESCE(l.BackendKeywords, '')) > 100 THEN 12
            WHEN LEN(COALESCE(l.BackendKeywords, '')) > 0   THEN 6
            ELSE 0
        END                                                 AS KeywordsScore,

        -- TOTAL SCORE (0-100)
        CASE WHEN LEN(l.Title) BETWEEN 150 AND 200 THEN 25
             WHEN LEN(l.Title) BETWEEN 100 AND 150 THEN 18
             WHEN LEN(l.Title) BETWEEN 50 AND 100  THEN 12
             WHEN l.Title IS NULL OR LEN(l.Title) < 50 THEN 0
             ELSE 10 END
        + CASE WHEN l.BulletPoint5 IS NOT NULL THEN 20
               WHEN l.BulletPoint4 IS NOT NULL THEN 16
               WHEN l.BulletPoint3 IS NOT NULL THEN 12
               WHEN l.BulletPoint2 IS NOT NULL THEN 8
               WHEN l.BulletPoint1 IS NOT NULL THEN 4
               ELSE 0 END
        + CASE WHEN l.ImageCount >= 7 THEN 20 WHEN l.ImageCount >= 5 THEN 15
               WHEN l.ImageCount >= 3 THEN 10 WHEN l.ImageCount >= 1 THEN 5 ELSE 0 END
        + CASE WHEN l.HasAPlusContent = 1 THEN 15 ELSE 0 END
        + CASE WHEN LEN(COALESCE(l.BackendKeywords,'')) > 200 THEN 20
               WHEN LEN(COALESCE(l.BackendKeywords,'')) > 100 THEN 12
               WHEN LEN(COALESCE(l.BackendKeywords,'')) > 0   THEN 6
               ELSE 0 END                                   AS OverallScore,

        -- Recommendations
        CASE WHEN l.Title IS NULL OR LEN(l.Title) < 150
            THEN 'Expand title to 150-200 characters with primary keyword and brand.' ELSE NULL END AS TitleRec,
        CASE WHEN l.BulletPoint5 IS NULL
            THEN 'Add all 5 bullet points. Target 200+ characters per bullet highlighting key features and benefits.' ELSE NULL END AS BulletsRec,
        CASE WHEN l.ImageCount < 7
            THEN 'Add ' + CAST(7 - l.ImageCount AS NVARCHAR) + ' more images. Include lifestyle, infographic, and size chart.' ELSE NULL END AS ImagesRec,
        CASE WHEN l.HasAPlusContent = 0
            THEN 'Add A+ Content (Enhanced Brand Content) for estimated 3-10% conversion rate lift.' ELSE NULL END AS APlusRec,
        CASE WHEN LEN(COALESCE(l.BackendKeywords, '')) < 250
            THEN 'Fill all 250 bytes of backend search terms with relevant keywords not already in title/bullets.' ELSE NULL END AS KeywordsRec,

        l.ReviewCount,
        l.StarRating,
        l.BSR,
        l.BuyBoxPrice,
        l.SnapshotDate
    FROM dbo.Products p
    INNER JOIN LatestListing l ON 1=1
    WHERE p.ProductId = @ProductId AND p.SellerAccountId = @SellerAccountId;
END;
GO

-- ============================================================
-- SP: Opportunity Score for Niche Research
-- ============================================================
CREATE PROCEDURE dbo.usp_Research_CalculateOpportunityScore
    @SellerAccountId    INT,
    @UserId             INT,
    @Keyword            NVARCHAR(300),
    @EstSearchVolume    INT             = NULL,
    @CompetitorCount    INT             = NULL,
    @AvgRevenue         DECIMAL(18,4)   = NULL,
    @AvgReviews         INT             = NULL,
    @AvgPrice           DECIMAL(18,4)   = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    -- Opportunity score algorithm (0-100)
    -- Higher search vol = more opportunity
    -- Lower competitor count = more opportunity
    -- Lower avg review count = lower barrier to entry
    -- Higher avg revenue = more prize worth winning

    DECLARE
        @SearchVolumeScore  DECIMAL(5,2),
        @CompetitionScore   DECIMAL(5,2),
        @RevenueScore       DECIMAL(5,2),
        @BarrierScore       DECIMAL(5,2),
        @OpportunityScore   DECIMAL(5,2);

    -- Search volume score: 0-25
    SET @SearchVolumeScore =
        CASE
            WHEN @EstSearchVolume >= 50000 THEN 25
            WHEN @EstSearchVolume >= 20000 THEN 20
            WHEN @EstSearchVolume >= 10000 THEN 15
            WHEN @EstSearchVolume >= 5000  THEN 10
            WHEN @EstSearchVolume >= 1000  THEN 5
            ELSE 2
        END;

    -- Competition score: 0-25 (fewer competitors = higher score)
    SET @CompetitionScore =
        CASE
            WHEN @CompetitorCount IS NULL THEN 12
            WHEN @CompetitorCount <= 50   THEN 25
            WHEN @CompetitorCount <= 100  THEN 20
            WHEN @CompetitorCount <= 200  THEN 15
            WHEN @CompetitorCount <= 500  THEN 8
            ELSE 3
        END;

    -- Revenue score: 0-25
    SET @RevenueScore =
        CASE
            WHEN @AvgRevenue >= 50000 THEN 25
            WHEN @AvgRevenue >= 20000 THEN 20
            WHEN @AvgRevenue >= 10000 THEN 15
            WHEN @AvgRevenue >= 5000  THEN 10
            ELSE 5
        END;

    -- Barrier to entry: 0-25 (fewer reviews = lower barrier = higher opportunity)
    SET @BarrierScore =
        CASE
            WHEN @AvgReviews IS NULL    THEN 12
            WHEN @AvgReviews <= 50      THEN 25
            WHEN @AvgReviews <= 100     THEN 20
            WHEN @AvgReviews <= 300     THEN 15
            WHEN @AvgReviews <= 500     THEN 10
            WHEN @AvgReviews <= 1000    THEN 5
            ELSE 2
        END;

    SET @OpportunityScore = COALESCE(@SearchVolumeScore, 0)
                          + COALESCE(@CompetitionScore, 0)
                          + COALESCE(@RevenueScore, 0)
                          + COALESCE(@BarrierScore, 0);

    -- Save to NicheResearch table
    INSERT INTO dbo.NicheResearch (
        SellerAccountId, UserId, ResearchDate, Keyword,
        EstMonthlySearchVol, CompetitorCount, AvgReviewCount,
        AvgPrice, EstRevenue, OpportunityScore, Status
    ) VALUES (
        @SellerAccountId, @UserId, CAST(SYSUTCDATETIME() AS DATE),
        @Keyword, @EstSearchVolume, @CompetitorCount, @AvgReviews,
        @AvgPrice, @AvgRevenue, @OpportunityScore, 'RESEARCHING'
    );

    SELECT
        SCOPE_IDENTITY()            AS NicheId,
        @Keyword                    AS Keyword,
        @EstSearchVolume            AS EstMonthlySearchVolume,
        @CompetitorCount            AS CompetitorCount,
        @AvgRevenue                 AS AvgMonthlyRevenue,
        @AvgReviews                 AS AvgReviewCount,
        @AvgPrice                   AS AvgPrice,
        @SearchVolumeScore          AS SearchVolumeScore,
        @CompetitionScore           AS CompetitionScore,
        @RevenueScore               AS RevenueScore,
        @BarrierScore               AS BarrierToEntryScore,
        @OpportunityScore           AS OpportunityScore,
        CASE
            WHEN @OpportunityScore >= 80 THEN 'EXCELLENT — Strongly consider entering this niche'
            WHEN @OpportunityScore >= 65 THEN 'GOOD — Solid opportunity worth deeper research'
            WHEN @OpportunityScore >= 50 THEN 'MODERATE — Viable but competitive'
            WHEN @OpportunityScore >= 35 THEN 'LOW — Difficult market conditions'
            ELSE 'POOR — Not recommended'
        END AS OpportunityRating;
END;
GO
