-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 07_SP_Cases.sql
-- DESC: Case management stored procedures
-- ============================================================
SET NOCOUNT ON;
GO

USE AmazonFBAManager;
GO

-- ============================================================
-- SP: Create Case
-- ============================================================
CREATE PROCEDURE dbo.usp_Case_Create
    @SellerAccountId    INT,
    @UserId             INT,
    @CaseTypeCode       VARCHAR(50),
    @Subject            NVARCHAR(500),
    @Description        NVARCHAR(MAX)   = NULL,
    @ASIN               VARCHAR(20)     = NULL,
    @Priority           VARCHAR(10)     = 'MEDIUM',
    @LinkedAuditId      INT             = NULL,
    @NewCaseId          INT             = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF dbo.fn_GetUserPermissionLevel(@UserId, @SellerAccountId) = 'READ'
        RAISERROR('Read-only users cannot create cases.', 16, 1);

    -- Validate case type
    IF NOT EXISTS (SELECT 1 FROM dbo.CaseTypes WHERE CaseTypeCode = @CaseTypeCode)
        RAISERROR('Invalid case type code.', 16, 1);

    DECLARE
        @ProductId      INT = NULL,
        @SLADays        TINYINT,
        @POARequired    BIT;

    SELECT @SLADays = DefaultSLADays, @POARequired = RequiresPOA
    FROM dbo.CaseTypes
    WHERE CaseTypeCode = @CaseTypeCode;

    -- Resolve ProductId from ASIN
    IF @ASIN IS NOT NULL
        SELECT @ProductId = ProductId
        FROM dbo.Products
        WHERE SellerAccountId = @SellerAccountId AND ASIN = @ASIN;

    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO dbo.Cases (
            SellerAccountId, CaseTypeCode, Status, Priority, Subject, Description,
            ProductId, ASIN, SLADueDate, AssignedUserId,
            POARequired, LinkedAuditId, CreatedByUserId
        ) VALUES (
            @SellerAccountId, @CaseTypeCode, 'OPEN', @Priority, @Subject, @Description,
            @ProductId, @ASIN, DATEADD(DAY, @SLADays, SYSUTCDATETIME()), @UserId,
            @POARequired, @LinkedAuditId, @UserId
        );

        SET @NewCaseId = SCOPE_IDENTITY();

        -- Auto-link to audit record if provided
        IF @LinkedAuditId IS NOT NULL
        BEGIN
            UPDATE dbo.ReimbursementAudit
            SET LinkedCaseId = @NewCaseId,
                Status = 'CASE_FILED',
                ModifiedDate = SYSUTCDATETIME()
            WHERE AuditId = @LinkedAuditId
              AND SellerAccountId = @SellerAccountId;
        END;

        -- Add opening note
        INSERT INTO dbo.CaseNotes (CaseId, UserId, NoteText, IsInternal)
        VALUES (@NewCaseId, @UserId, N'Case created by ' +
            (SELECT Username FROM dbo.Users WHERE UserId = @UserId) + N'.', 1);

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;

    -- Return new case details
    SELECT
        c.CaseId,
        c.Status,
        c.SLADueDate,
        c.POARequired,
        ct.CaseTypeName
    FROM dbo.Cases c
    INNER JOIN dbo.CaseTypes ct ON ct.CaseTypeCode = c.CaseTypeCode
    WHERE c.CaseId = @NewCaseId;
END;
GO

-- ============================================================
-- SP: Escalate Case
-- ============================================================
CREATE PROCEDURE dbo.usp_Case_Escalate
    @CaseId             INT,
    @UserId             INT,
    @EscalationReason   NVARCHAR(1000)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SellerAccountId INT;
    SELECT @SellerAccountId = SellerAccountId FROM dbo.Cases WHERE CaseId = @CaseId;

    IF @SellerAccountId IS NULL
        RAISERROR('Case not found.', 16, 1);

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    BEGIN TRY
        BEGIN TRANSACTION;

        UPDATE dbo.Cases
        SET
            EscalationLevel = EscalationLevel + 1,
            Status          = 'ESCALATED',
            Priority        = CASE WHEN Priority = 'LOW' THEN 'MEDIUM'
                                   WHEN Priority = 'MEDIUM' THEN 'HIGH'
                                   WHEN Priority = 'HIGH' THEN 'CRITICAL'
                                   ELSE Priority END,
            ModifiedDate    = SYSUTCDATETIME()
        WHERE CaseId = @CaseId;

        -- Add escalation note
        INSERT INTO dbo.CaseNotes (CaseId, UserId, NoteText, IsInternal)
        VALUES (
            @CaseId, @UserId,
            N'ESCALATION (Level ' +
                CAST((SELECT EscalationLevel FROM dbo.Cases WHERE CaseId = @CaseId) AS NVARCHAR)
                + N'): ' + @EscalationReason,
            1
        );

        -- Create CASE_SLA_BREACH alert for the account manager
        INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, ProductId, CaseId, Message, Severity)
        SELECT
            c.SellerAccountId,
            'CASE_SLA_BREACH',
            c.ProductId,
            c.CaseId,
            N'Case #' + CAST(c.CaseId AS NVARCHAR) + N' escalated to level '
                + CAST(c.EscalationLevel AS NVARCHAR)
                + N'. Reason: ' + @EscalationReason,
            'HIGH'
        FROM dbo.Cases c
        WHERE c.CaseId = @CaseId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;

    SELECT CaseId, Status, EscalationLevel, Priority
    FROM dbo.Cases
    WHERE CaseId = @CaseId;
END;
GO

-- ============================================================
-- SP: Resolve Case
-- ============================================================
CREATE PROCEDURE dbo.usp_Case_Resolve
    @CaseId             INT,
    @UserId             INT,
    @ResolvedAmount     DECIMAL(18,4)   = NULL,
    @ResolutionNote     NVARCHAR(1000)  = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SellerAccountId INT;
    SELECT @SellerAccountId = SellerAccountId FROM dbo.Cases WHERE CaseId = @CaseId;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF dbo.fn_GetUserPermissionLevel(@UserId, @SellerAccountId) = 'READ'
        RAISERROR('Read-only users cannot resolve cases.', 16, 1);

    BEGIN TRY
        BEGIN TRANSACTION;

        UPDATE dbo.Cases
        SET
            Status          = 'RESOLVED',
            ResolvedDate    = SYSUTCDATETIME(),
            ResolvedAmount  = @ResolvedAmount,
            ModifiedDate    = SYSUTCDATETIME()
        WHERE CaseId = @CaseId;

        INSERT INTO dbo.CaseNotes (CaseId, UserId, NoteText, IsInternal)
        VALUES (
            @CaseId, @UserId,
            N'Case RESOLVED by ' + (SELECT Username FROM dbo.Users WHERE UserId = @UserId)
            + CASE WHEN @ResolvedAmount IS NOT NULL
                THEN N'. Amount recovered: $' + CAST(@ResolvedAmount AS NVARCHAR(20))
                ELSE N'. No amount recovered.' END
            + COALESCE(N' Note: ' + @ResolutionNote, N''),
            1
        );

        -- If case was linked to an audit, update audit status
        UPDATE dbo.ReimbursementAudit
        SET Status = CASE WHEN @ResolvedAmount > 0 THEN 'REIMBURSED' ELSE 'DENIED' END,
            ModifiedDate = SYSUTCDATETIME()
        FROM dbo.ReimbursementAudit ra
        INNER JOIN dbo.Cases c ON c.LinkedAuditId = ra.AuditId
        WHERE c.CaseId = @CaseId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

-- ============================================================
-- SP: Get Case Detail (full view with notes and attachments)
-- ============================================================
CREATE PROCEDURE dbo.usp_Case_GetDetail
    @CaseId             INT,
    @UserId             INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @SellerAccountId INT;
    SELECT @SellerAccountId = SellerAccountId FROM dbo.Cases WHERE CaseId = @CaseId;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    -- Case header
    SELECT
        c.CaseId,
        c.SellerAccountId,
        sa.AccountName,
        c.AmazonCaseId,
        c.CaseTypeCode,
        ct.CaseTypeName,
        c.Status,
        c.Priority,
        c.Subject,
        c.Description,
        c.ASIN,
        p.SKU,
        p.ProductTitle,
        c.OpenedDate,
        c.SLADueDate,
        DATEDIFF(DAY, SYSUTCDATETIME(), c.SLADueDate)   AS DaysUntilSLA,
        c.ResolvedDate,
        c.ResolvedAmount,
        c.EscalationLevel,
        c.POARequired,
        c.LinkedAuditId,
        assignedUser.Username                           AS AssignedTo,
        createdUser.Username                            AS CreatedBy,
        c.ModifiedDate
    FROM dbo.Cases c
    INNER JOIN dbo.CaseTypes ct ON ct.CaseTypeCode = c.CaseTypeCode
    INNER JOIN dbo.SellerAccounts sa ON sa.SellerAccountId = c.SellerAccountId
    LEFT JOIN dbo.Products p ON p.ProductId = c.ProductId
    LEFT JOIN dbo.Users assignedUser ON assignedUser.UserId = c.AssignedUserId
    LEFT JOIN dbo.Users createdUser ON createdUser.UserId = c.CreatedByUserId
    WHERE c.CaseId = @CaseId;

    -- Case notes (chronological)
    SELECT
        cn.NoteId,
        cn.NoteDate,
        u.Username,
        cn.NoteText,
        cn.IsInternal
    FROM dbo.CaseNotes cn
    INNER JOIN dbo.Users u ON u.UserId = cn.UserId
    WHERE cn.CaseId = @CaseId
    ORDER BY cn.NoteDate ASC;

    -- Attachments
    SELECT
        ca.AttachmentId,
        ca.FileName,
        ca.FileSizeBytes,
        ca.MimeType,
        ca.UploadDate,
        u.Username AS UploadedBy
    FROM dbo.CaseAttachments ca
    LEFT JOIN dbo.Users u ON u.UserId = ca.UploadedByUserId
    WHERE ca.CaseId = @CaseId
    ORDER BY ca.UploadDate DESC;
END;
GO

-- ============================================================
-- SP: Case Kanban Board (for dashboard)
-- ============================================================
CREATE PROCEDURE dbo.usp_Case_GetKanbanBoard
    @SellerAccountId    INT,
    @UserId             INT,
    @AssignedUserId     INT = NULL   -- NULL = all users
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    SELECT
        c.CaseId,
        c.Status,
        c.Priority,
        c.CaseTypeCode,
        ct.CaseTypeName,
        c.Subject,
        c.ASIN,
        p.SKU,
        c.OpenedDate,
        c.SLADueDate,
        DATEDIFF(DAY, SYSUTCDATETIME(), c.SLADueDate)   AS DaysUntilSLA,
        CASE
            WHEN c.SLADueDate < SYSUTCDATETIME() THEN 'BREACHED'
            WHEN DATEDIFF(DAY, SYSUTCDATETIME(), c.SLADueDate) <= 1 THEN 'CRITICAL'
            WHEN DATEDIFF(DAY, SYSUTCDATETIME(), c.SLADueDate) <= 3 THEN 'WARNING'
            ELSE 'ON_TRACK'
        END                                             AS SLAStatus,
        c.EscalationLevel,
        u.Username                                      AS AssignedTo,
        -- Any linked audit claimable amount
        ra.ClaimableAmount                              AS LinkedClaimAmount
    FROM dbo.Cases c
    INNER JOIN dbo.CaseTypes ct ON ct.CaseTypeCode = c.CaseTypeCode
    LEFT JOIN dbo.Products p ON p.ProductId = c.ProductId
    LEFT JOIN dbo.Users u ON u.UserId = c.AssignedUserId
    LEFT JOIN dbo.ReimbursementAudit ra ON ra.AuditId = c.LinkedAuditId
    WHERE c.SellerAccountId = @SellerAccountId
      AND c.Status NOT IN ('RESOLVED','CLOSED')
      AND (@AssignedUserId IS NULL OR c.AssignedUserId = @AssignedUserId)
    ORDER BY
        CASE c.Status
            WHEN 'ESCALATED'        THEN 1
            WHEN 'OPEN'             THEN 2
            WHEN 'PENDING_AMAZON'   THEN 3
            WHEN 'ON_HOLD'          THEN 4
            ELSE 5
        END,
        CASE c.Priority
            WHEN 'CRITICAL' THEN 1
            WHEN 'HIGH'     THEN 2
            WHEN 'MEDIUM'   THEN 3
            ELSE 4
        END,
        c.SLADueDate ASC;
END;
GO

-- ============================================================
-- SP: Case Aging Report
-- ============================================================
CREATE PROCEDURE dbo.usp_Case_GetAgingReport
    @SellerAccountId    INT,
    @UserId             INT,
    @SLADays            INT = 7
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    SELECT
        c.CaseId,
        c.CaseTypeCode,
        ct.CaseTypeName,
        c.Status,
        c.Priority,
        c.Subject,
        c.ASIN,
        p.SKU,
        c.OpenedDate,
        DATEDIFF(DAY, c.OpenedDate, SYSUTCDATETIME())   AS DaysOpen,
        c.SLADueDate,
        CASE
            WHEN c.SLADueDate < SYSUTCDATETIME() THEN 'SLA_BREACHED'
            WHEN DATEDIFF(DAY, SYSUTCDATETIME(), c.SLADueDate) <= 1 THEN 'DUE_TOMORROW'
            ELSE 'WITHIN_SLA'
        END                                             AS SLAStatus,
        u.Username                                      AS AssignedUser,
        ra.ClaimableAmount                              AS AmountAtRisk,
        c.EscalationLevel
    FROM dbo.Cases c
    INNER JOIN dbo.CaseTypes ct ON ct.CaseTypeCode = c.CaseTypeCode
    LEFT JOIN dbo.Products p ON p.ProductId = c.ProductId
    LEFT JOIN dbo.Users u ON u.UserId = c.AssignedUserId
    LEFT JOIN dbo.ReimbursementAudit ra ON ra.AuditId = c.LinkedAuditId
    WHERE c.SellerAccountId = @SellerAccountId
      AND c.Status NOT IN ('RESOLVED','CLOSED')
      AND DATEDIFF(DAY, c.OpenedDate, SYSUTCDATETIME()) >= @SLADays
    ORDER BY DaysOpen DESC, AmountAtRisk DESC;
END;
GO

-- ============================================================
-- SP: Hijack Report Builder
-- ============================================================
CREATE PROCEDURE dbo.usp_Case_BuildHijackReport
    @ProductId          INT,
    @SellerAccountId    INT,
    @UserId             INT,
    @HijackerSellerName NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    ;WITH LatestListing AS (
        SELECT TOP 1 l.*
        FROM dbo.Listings l
        WHERE l.ProductId = @ProductId AND l.SellerAccountId = @SellerAccountId
        ORDER BY l.SnapshotDate DESC
    ),
    LatestPrice AS (
        SELECT TOP 1 cph.*
        FROM dbo.CompetitorPriceHistory cph
        WHERE cph.ProductId = @ProductId AND cph.SellerAccountId = @SellerAccountId
        ORDER BY cph.SnapshotDate DESC
    ),
    SalesImpact AS (
        SELECT
            ROUND(AVG(daily_sales.DailySales), 2) AS AvgDailySales,
            ROUND(AVG(daily_sales.DailySales) * 30, 2) AS Est30DayRevLost
        FROM (
            SELECT
                CAST(so.OrderDate AS DATE) AS SaleDay,
                SUM(soi.ItemPrice) AS DailySales
            FROM dbo.SalesOrderItems soi
            INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
            WHERE soi.ProductId = @ProductId
              AND so.OrderDate >= DATEADD(DAY, -90, SYSUTCDATETIME())
            GROUP BY CAST(so.OrderDate AS DATE)
        ) daily_sales
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        p.Brand,
        ll.BuyBoxPrice                                      AS OurListingPrice,
        ll.ReviewCount,
        ll.StarRating,
        ll.BSR,
        lp.LowestCompetitorPrice                            AS HijackerPrice,
        lp.CompetitorCount                                  AS TotalOffersOnListing,
        lp.BuyBoxOwnedByUs,
        lp.BuyBoxOwner,
        si.AvgDailySales,
        si.Est30DayRevLost                                  AS EstRevenueLostIf30Days,
        @HijackerSellerName                                 AS HijackerSellerName,
        -- Evidence checklist for report
        N'1. Screenshot of competing offer on your listing' AS Evidence1,
        N'2. Proof of brand ownership or exclusive rights (Brand Registry cert, trademark, invoice)' AS Evidence2,
        N'3. Test buy receipt if purchased from hijacker' AS Evidence3,
        N'4. Side-by-side comparison showing counterfeit/unauthorized product differences' AS Evidence4,
        -- Draft report text
        N'ASIN: ' + p.ASIN + N' | Title: ' + p.ProductTitle
            + N' | Brand: ' + COALESCE(p.Brand, N'[Your Brand]')
            + N'. An unauthorized seller (' + COALESCE(@HijackerSellerName, N'[Seller Name]')
            + N') is offering this product on our listing at $'
            + CAST(COALESCE(lp.LowestCompetitorPrice, 0) AS NVARCHAR)
            + N'. We are the brand owner and only authorized seller. '
            + N'We request immediate removal of this unauthorized offer. '
            + N'Supporting documentation attached.'                 AS DraftReportText
    FROM dbo.Products p
    LEFT JOIN LatestListing ll ON 1=1
    LEFT JOIN LatestPrice lp ON 1=1
    LEFT JOIN SalesImpact si ON 1=1
    WHERE p.ProductId = @ProductId
      AND p.SellerAccountId = @SellerAccountId;
END;
GO

-- ============================================================
-- SP: Suspension POA Data Collector
-- ============================================================
CREATE PROCEDURE dbo.usp_Case_GetSuspensionPOAData
    @SellerAccountId    INT,
    @CaseId             INT,
    @UserId             INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    -- Case info
    SELECT c.*, ct.CaseTypeName, sa.AccountName
    FROM dbo.Cases c
    INNER JOIN dbo.CaseTypes ct ON ct.CaseTypeCode = c.CaseTypeCode
    INNER JOIN dbo.SellerAccounts sa ON sa.SellerAccountId = c.SellerAccountId
    WHERE c.CaseId = @CaseId AND c.SellerAccountId = @SellerAccountId;

    -- Account performance metrics (last 90 days)
    SELECT
        COUNT(DISTINCT so.OrderId)          AS TotalOrders,
        SUM(soi.QtySold)                    AS TotalUnitsSold,
        SUM(soi.ItemPrice)                  AS TotalRevenue,
        COUNT(DISTINCT r.ReturnId)          AS TotalReturns,
        ROUND(
            CAST(COUNT(DISTINCT r.ReturnId) AS DECIMAL) /
            NULLIF(COUNT(DISTINCT so.OrderId), 0) * 100
        , 2)                                AS ReturnRatePct,
        '90 days prior to case'             AS Period
    FROM dbo.SalesOrders so
    INNER JOIN dbo.SalesOrderItems soi ON soi.OrderId = so.OrderId
    LEFT JOIN dbo.Returns r ON r.AmazonOrderId = so.AmazonOrderId
    WHERE so.SellerAccountId = @SellerAccountId
      AND so.OrderDate >= DATEADD(DAY, -90, SYSUTCDATETIME());

    -- Open cases that may be related (listing issues, complaints)
    SELECT c2.CaseId, c2.CaseTypeCode, c2.Subject, c2.Status, c2.OpenedDate
    FROM dbo.Cases c2
    WHERE c2.SellerAccountId = @SellerAccountId
      AND c2.CaseTypeCode IN ('LISTING_SUPPRESSION','IP_COMPLAINT','HIJACK_REPORT','ACCOUNT_SUSPENSION')
      AND c2.CaseId != @CaseId
    ORDER BY c2.OpenedDate DESC;

    -- Suppressed/stranded listings (evidence of proactive compliance)
    SELECT COUNT(*) AS SuppressedListingCount,
           COUNT(CASE WHEN ListingStatus = 'ACTIVE' THEN 1 END) AS ActiveListingCount
    FROM (
        SELECT ProductId, ListingStatus,
               ROW_NUMBER() OVER (PARTITION BY ProductId ORDER BY SnapshotDate DESC) AS rn
        FROM dbo.Listings WHERE SellerAccountId = @SellerAccountId
    ) l WHERE rn = 1;
END;
GO

-- ============================================================
-- SP: SLA Monitor (called by Hangfire every 2 hours)
-- ============================================================
CREATE PROCEDURE dbo.usp_Case_MonitorSLABreaches
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- Find all cases that have breached SLA and not yet escalated
    INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, ProductId, CaseId, Message, Severity)
    SELECT
        c.SellerAccountId,
        'CASE_SLA_BREACH',
        c.ProductId,
        c.CaseId,
        N'Case #' + CAST(c.CaseId AS NVARCHAR) + N' (' + ct.CaseTypeName + N') — SLA breached by '
            + CAST(ABS(DATEDIFF(DAY, c.SLADueDate, SYSUTCDATETIME())) AS NVARCHAR) + N' days. '
            + N'Priority: ' + c.Priority,
        'HIGH'
    FROM dbo.Cases c
    INNER JOIN dbo.CaseTypes ct ON ct.CaseTypeCode = c.CaseTypeCode
    WHERE c.Status NOT IN ('RESOLVED','CLOSED')
      AND c.SLADueDate < SYSUTCDATETIME()
      -- Don't create duplicate alert if one exists in last 24 hours
      AND NOT EXISTS (
          SELECT 1 FROM dbo.Alerts a
          WHERE a.CaseId = c.CaseId
            AND a.AlertTypeCode = 'CASE_SLA_BREACH'
            AND a.AlertDate >= DATEADD(HOUR, -24, SYSUTCDATETIME())
      );

    -- Auto-escalate cases that have been SLA-breached for 3+ days without escalation
    UPDATE dbo.Cases
    SET
        EscalationLevel = EscalationLevel + 1,
        Status          = 'ESCALATED',
        ModifiedDate    = SYSUTCDATETIME()
    WHERE Status NOT IN ('RESOLVED','CLOSED','ESCALATED')
      AND SLADueDate < DATEADD(DAY, -3, SYSUTCDATETIME())
      AND EscalationLevel = 0;

    SELECT @@ROWCOUNT AS CasesAutoEscalated;
END;
GO
