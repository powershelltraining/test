-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 04_SP_Import.sql
-- DESC: CSV Import stored procedures for all report types
-- All use TVPs passed from the application layer
-- ============================================================
SET NOCOUNT ON;
GO

USE AmazonFBAManager;
GO

-- ============================================================
-- SP: Import Inventory Snapshot
-- ============================================================
CREATE PROCEDURE dbo.usp_ImportCSV_InventorySnapshot
    @SellerAccountId    INT,
    @UserId             INT,
    @ImportId           INT,
    @DataTable          dbo.TVP_InventorySnapshot READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- Access check
    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
    BEGIN
        RAISERROR('Access denied to seller account.', 16, 1);
        RETURN;
    END;

    DECLARE
        @SnapshotDate   DATE = CAST(SYSUTCDATETIME() AS DATE),
        @RowsImported   INT  = 0,
        @RowsSkipped    INT  = 0,
        @RowsErrored    INT  = 0,
        @ErrorLog       NVARCHAR(MAX) = N'';

    -- Update import status to PROCESSING
    UPDATE dbo.CSVImports
    SET Status = 'PROCESSING', ProcessingStarted = SYSUTCDATETIME()
    WHERE ImportId = @ImportId;

    -- Derive SnapshotDate from the data (use MAX date in batch)
    SELECT @SnapshotDate = MAX(SnapshotDate) FROM @DataTable;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- UPSERT products not yet in the system
        INSERT INTO dbo.Products (SellerAccountId, ASIN, SKU, FNSKU, ProductTitle, IsActive)
        SELECT
            @SellerAccountId,
            d.ASIN,
            d.SKU,
            d.FNSKU,
            d.SKU,   -- Title unknown from inventory report — will be updated from listings
            1
        FROM @DataTable d
        WHERE NOT EXISTS (
            SELECT 1 FROM dbo.Products p
            WHERE p.SellerAccountId = @SellerAccountId
              AND p.SKU = d.SKU
        );

        -- Update FNSKU if changed
        UPDATE p
        SET p.FNSKU = d.FNSKU,
            p.ModifiedDate = SYSUTCDATETIME()
        FROM dbo.Products p
        INNER JOIN @DataTable d ON d.SKU = p.SKU
        WHERE p.SellerAccountId = @SellerAccountId
          AND d.FNSKU IS NOT NULL
          AND p.FNSKU != d.FNSKU;

        -- UPSERT inventory snapshots
        MERGE dbo.InventorySnapshots AS tgt
        USING (
            SELECT
                p.ProductId,
                @SellerAccountId AS SellerAccountId,
                d.SnapshotDate,
                d.QtyFBA,
                d.QtyFBM,
                d.QtyInbound,
                d.QtyReserved,
                d.QtyUnfulfillable,
                d.QtyWarehouseAWD,
                d.EstStorageCost,
                'CSV'       AS DataSource,
                @ImportId   AS ImportId
            FROM @DataTable d
            INNER JOIN dbo.Products p
                ON p.SellerAccountId = @SellerAccountId
               AND p.SKU = d.SKU
        ) AS src
        ON  tgt.ProductId = src.ProductId
        AND tgt.SnapshotDate = src.SnapshotDate
        AND tgt.DataSource = 'CSV'
        WHEN MATCHED THEN UPDATE SET
            tgt.QtyFBA              = src.QtyFBA,
            tgt.QtyFBM              = src.QtyFBM,
            tgt.QtyInbound          = src.QtyInbound,
            tgt.QtyReserved         = src.QtyReserved,
            tgt.QtyUnfulfillable    = src.QtyUnfulfillable,
            tgt.QtyWarehouseAWD     = src.QtyWarehouseAWD,
            tgt.EstStorageCostMTD   = src.EstStorageCost,
            tgt.ImportId            = src.ImportId
        WHEN NOT MATCHED THEN INSERT (
            ProductId, SellerAccountId, SnapshotDate, QtyFBA, QtyFBM,
            QtyInbound, QtyReserved, QtyUnfulfillable, QtyWarehouseAWD,
            EstStorageCostMTD, DataSource, ImportId
        ) VALUES (
            src.ProductId, src.SellerAccountId, src.SnapshotDate, src.QtyFBA, src.QtyFBM,
            src.QtyInbound, src.QtyReserved, src.QtyUnfulfillable, src.QtyWarehouseAWD,
            src.EstStorageCost, src.DataSource, src.ImportId
        );

        SET @RowsImported = @@ROWCOUNT;

        -- -------------------------------------------------------
        -- TRIGGER ALERTS: Low Stock / Out of Stock
        -- Compare current FBA qty against reorder points
        -- -------------------------------------------------------
        INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, ProductId, Message, Severity)
        SELECT
            @SellerAccountId,
            CASE WHEN sn.QtyFBA = 0 THEN 'OUT_OF_STOCK' ELSE 'LOW_STOCK' END,
            sn.ProductId,
            N'SKU: ' + p.SKU + N' | FBA Qty: ' + CAST(sn.QtyFBA AS NVARCHAR)
                + N' | Reorder Point: ' + CAST(COALESCE(p.ReorderPoint, 0) AS NVARCHAR),
            CASE WHEN sn.QtyFBA = 0 THEN 'CRITICAL' ELSE 'HIGH' END
        FROM dbo.InventorySnapshots sn
        INNER JOIN dbo.Products p ON p.ProductId = sn.ProductId
        WHERE sn.SellerAccountId = @SellerAccountId
          AND sn.SnapshotDate = @SnapshotDate
          AND p.IsActive = 1
          AND p.ReorderPoint IS NOT NULL
          AND sn.QtyFBA <= COALESCE(p.ReorderPoint, 0)
          -- Don't create duplicate alert if one exists for today unread
          AND NOT EXISTS (
              SELECT 1 FROM dbo.Alerts a
              WHERE a.SellerAccountId = @SellerAccountId
                AND a.ProductId = sn.ProductId
                AND a.AlertTypeCode IN ('LOW_STOCK','OUT_OF_STOCK')
                AND a.IsRead = 0
                AND CAST(a.AlertDate AS DATE) = @SnapshotDate
          );

        -- Stranded inventory alert: flag products with QtyFBA > 0 but listing is STRANDED
        INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, ProductId, Message, Severity)
        SELECT
            @SellerAccountId,
            'STRANDED_INVENTORY',
            sn.ProductId,
            N'Stranded inventory detected for SKU: ' + p.SKU
                + N' — ' + CAST(sn.QtyFBA AS NVARCHAR) + N' units at FC.',
            'HIGH'
        FROM dbo.InventorySnapshots sn
        INNER JOIN dbo.Products p ON p.ProductId = sn.ProductId
        LEFT JOIN dbo.Listings l
            ON l.ProductId = sn.ProductId
           AND l.SellerAccountId = @SellerAccountId
           AND l.ListingStatus = 'STRANDED'
        WHERE sn.SellerAccountId = @SellerAccountId
          AND sn.SnapshotDate = @SnapshotDate
          AND sn.QtyUnfulfillable > 0
          AND NOT EXISTS (
              SELECT 1 FROM dbo.Alerts a
              WHERE a.ProductId = sn.ProductId
                AND a.AlertTypeCode = 'STRANDED_INVENTORY'
                AND a.IsRead = 0
                AND CAST(a.AlertDate AS DATE) = @SnapshotDate
          );

        -- Update import stats
        UPDATE dbo.CSVImports
        SET RowsImported = @RowsImported,
            RowsSkipped  = @RowsSkipped,
            RowsErrored  = @RowsErrored,
            Status       = 'COMPLETE',
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;

        SET @ErrorLog = ERROR_MESSAGE();

        UPDATE dbo.CSVImports
        SET Status   = 'FAILED',
            ErrorLog = @ErrorLog,
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;

        THROW;
    END CATCH;

    -- Return result to application
    SELECT
        @ImportId       AS ImportId,
        @RowsImported   AS RowsImported,
        @RowsSkipped    AS RowsSkipped,
        @RowsErrored    AS RowsErrored,
        'COMPLETE'      AS Status;
END;
GO

-- ============================================================
-- SP: Import Sales Orders
-- ============================================================
CREATE PROCEDURE dbo.usp_ImportCSV_SalesOrders
    @SellerAccountId    INT,
    @UserId             INT,
    @ImportId           INT,
    @DataTable          dbo.TVP_SalesOrder READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    DECLARE @RowsImported INT = 0;

    UPDATE dbo.CSVImports
    SET Status = 'PROCESSING', ProcessingStarted = SYSUTCDATETIME()
    WHERE ImportId = @ImportId;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Upsert orders (idempotent — re-import safe)
        MERGE dbo.SalesOrders AS tgt
        USING (
            SELECT DISTINCT
                @SellerAccountId        AS SellerAccountId,
                d.AmazonOrderId,
                d.OrderDate,
                d.ShipDate,
                d.FulfillmentChannel,
                d.OrderStatus,
                SUM(d.ItemPrice - d.PromotionDiscount) OVER (PARTITION BY d.AmazonOrderId) AS TotalAmount,
                d.Currency,
                @ImportId               AS ImportId
            FROM @DataTable d
        ) AS src
        ON  tgt.SellerAccountId = src.SellerAccountId
        AND tgt.AmazonOrderId   = src.AmazonOrderId
        WHEN MATCHED THEN UPDATE SET
            tgt.OrderStatus     = src.OrderStatus,
            tgt.ShipDate        = src.ShipDate,
            tgt.TotalAmount     = src.TotalAmount
        WHEN NOT MATCHED THEN INSERT (
            SellerAccountId, AmazonOrderId, OrderDate, ShipDate,
            FulfillmentChannel, OrderStatus, TotalAmount, Currency, ImportId
        ) VALUES (
            src.SellerAccountId, src.AmazonOrderId, src.OrderDate, src.ShipDate,
            src.FulfillmentChannel, src.OrderStatus, src.TotalAmount, src.Currency, src.ImportId
        );

        -- Insert order items (delete + reinsert for idempotency)
        DELETE soi
        FROM dbo.SalesOrderItems soi
        INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
        WHERE so.SellerAccountId = @SellerAccountId
          AND so.AmazonOrderId IN (SELECT DISTINCT AmazonOrderId FROM @DataTable);

        INSERT INTO dbo.SalesOrderItems (
            OrderId, ProductId, ASIN, SKU, QtySold, ItemPrice,
            PromotionDiscount, ShippingPrice, GiftWrapPrice
        )
        SELECT
            so.OrderId,
            p.ProductId,
            d.ASIN,
            d.SKU,
            d.QtySold,
            d.ItemPrice,
            d.PromotionDiscount,
            d.ShippingPrice,
            0   -- GiftWrapPrice not in standard order report
        FROM @DataTable d
        INNER JOIN dbo.SalesOrders so
            ON so.SellerAccountId = @SellerAccountId
           AND so.AmazonOrderId = d.AmazonOrderId
        LEFT JOIN dbo.Products p
            ON p.SellerAccountId = @SellerAccountId
           AND p.SKU = d.SKU;

        SET @RowsImported = @@ROWCOUNT;

        UPDATE dbo.CSVImports
        SET RowsImported = @RowsImported, Status = 'COMPLETE',
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        UPDATE dbo.CSVImports
        SET Status = 'FAILED', ErrorLog = ERROR_MESSAGE(),
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;
        THROW;
    END CATCH;

    SELECT @ImportId AS ImportId, @RowsImported AS RowsImported, 'COMPLETE' AS Status;
END;
GO

-- ============================================================
-- SP: Import Reimbursements
-- ============================================================
CREATE PROCEDURE dbo.usp_ImportCSV_Reimbursements
    @SellerAccountId    INT,
    @UserId             INT,
    @ImportId           INT,
    @DataTable          dbo.TVP_Reimbursement READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    DECLARE @RowsImported INT = 0;

    UPDATE dbo.CSVImports SET Status = 'PROCESSING', ProcessingStarted = SYSUTCDATETIME()
    WHERE ImportId = @ImportId;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Insert new reimbursements, skip duplicates
        INSERT INTO dbo.Reimbursements (
            SellerAccountId, AmazonReimbId, ReimbDate, ProductId, ASIN, SKU,
            QtyReimbursed, AmountPerUnit, TotalAmount, ReimbType, ImportId
        )
        SELECT
            @SellerAccountId,
            d.AmazonReimbId,
            d.ReimbDate,
            p.ProductId,
            d.ASIN,
            d.SKU,
            d.QtyReimbursed,
            d.AmountPerUnit,
            d.TotalAmount,
            d.ReimbType,
            @ImportId
        FROM @DataTable d
        LEFT JOIN dbo.Products p
            ON p.SellerAccountId = @SellerAccountId
           AND p.SKU = d.SKU
        WHERE NOT EXISTS (
            SELECT 1 FROM dbo.Reimbursements r
            WHERE r.SellerAccountId = @SellerAccountId
              AND r.AmazonReimbId = d.AmazonReimbId
        );

        SET @RowsImported = @@ROWCOUNT;

        -- Mark matching audit items as REIMBURSED
        UPDATE ra
        SET ra.Status = 'REIMBURSED',
            ra.ModifiedDate = SYSUTCDATETIME()
        FROM dbo.ReimbursementAudit ra
        INNER JOIN dbo.Reimbursements r
            ON r.SellerAccountId = @SellerAccountId
           AND r.ProductId = ra.ProductId
        WHERE ra.SellerAccountId = @SellerAccountId
          AND ra.Status = 'OPEN';

        UPDATE dbo.CSVImports
        SET RowsImported = @RowsImported, Status = 'COMPLETE',
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        UPDATE dbo.CSVImports SET Status = 'FAILED', ErrorLog = ERROR_MESSAGE(),
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;
        THROW;
    END CATCH;

    SELECT @ImportId AS ImportId, @RowsImported AS RowsImported, 'COMPLETE' AS Status;
END;
GO

-- ============================================================
-- SP: Import Inventory Adjustments
-- ============================================================
CREATE PROCEDURE dbo.usp_ImportCSV_InventoryAdjustments
    @SellerAccountId    INT,
    @UserId             INT,
    @ImportId           INT,
    @DataTable          dbo.TVP_InventoryAdjustment READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    DECLARE @RowsImported INT = 0;

    UPDATE dbo.CSVImports SET Status = 'PROCESSING', ProcessingStarted = SYSUTCDATETIME()
    WHERE ImportId = @ImportId;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Normalize reason codes to our lookup (best-effort match)
        INSERT INTO dbo.InventoryAdjustments (
            ProductId, SellerAccountId, AdjDate, AdjReasonCode,
            QtyAdjusted, DispositionCode, FulfillmentCenterId,
            TransactionItemId, ImportId
        )
        SELECT
            p.ProductId,
            @SellerAccountId,
            d.AdjDate,
            CASE
                WHEN EXISTS (SELECT 1 FROM dbo.InventoryAdjustmentReasons r WHERE r.ReasonCode = d.AdjReasonCode)
                    THEN d.AdjReasonCode
                ELSE 'REVERSAL'   -- fallback for unknown codes
            END,
            d.QtyAdjusted,
            d.DispositionCode,
            d.FulfillmentCenterId,
            d.TransactionItemId,
            @ImportId
        FROM @DataTable d
        INNER JOIN dbo.Products p
            ON p.SellerAccountId = @SellerAccountId
           AND p.SKU = d.SKU
        WHERE NOT EXISTS (
            SELECT 1 FROM dbo.InventoryAdjustments ia
            WHERE ia.TransactionItemId = d.TransactionItemId
              AND ia.SellerAccountId = @SellerAccountId
              AND d.TransactionItemId IS NOT NULL
        );

        SET @RowsImported = @@ROWCOUNT;

        -- Fire reimbursement opportunity alerts for loss events
        INSERT INTO dbo.ReimbursementAudit (
            ProductId, SellerAccountId, AuditDate, AuditType,
            QtyExpected, QtyAmazonReported, QtyVariance,
            COGS_PerUnit, ClaimableAmount, Status, DeadlineDate
        )
        SELECT
            p.ProductId,
            @SellerAccountId,
            CAST(d.AdjDate AS DATE),
            CASE d.AdjReasonCode
                WHEN 'LOST'             THEN 'LOST_INVENTORY'
                WHEN 'DAMAGED'          THEN 'DAMAGED_INVENTORY'
                WHEN 'DAMAGED_WAREHOUSE' THEN 'DAMAGED_INVENTORY'
                WHEN 'WAREHOUSE_DAMAGE' THEN 'DAMAGED_INVENTORY'
                ELSE 'LOST_INVENTORY'
            END,
            0,                              -- QtyExpected (unknown at this stage)
            ABS(d.QtyAdjusted),             -- QtyAmazonReported
            ABS(d.QtyAdjusted),             -- Variance
            p.COGS,
            ABS(d.QtyAdjusted) * COALESCE(p.COGS, 0),  -- ClaimableAmount at cost basis
            'OPEN',
            DATEADD(MONTH, 18, CAST(d.AdjDate AS DATE))  -- 18-month deadline
        FROM @DataTable d
        INNER JOIN dbo.Products p
            ON p.SellerAccountId = @SellerAccountId
           AND p.SKU = d.SKU
        INNER JOIN dbo.InventoryAdjustmentReasons r ON r.ReasonCode = d.AdjReasonCode
        WHERE r.IsLossEvent = 1
          AND d.QtyAdjusted < 0      -- negative adjustment = loss
          AND NOT EXISTS (
              SELECT 1 FROM dbo.ReimbursementAudit ra
              WHERE ra.ProductId = p.ProductId
                AND ra.SellerAccountId = @SellerAccountId
                AND ra.AuditDate = CAST(d.AdjDate AS DATE)
                AND ra.QtyVariance = ABS(d.QtyAdjusted)
          );

        -- Alert for new reimbursement opportunities
        INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, ProductId, Message, Severity)
        SELECT DISTINCT
            @SellerAccountId,
            'NEW_REIMBURSEMENT_OPPORTUNITY',
            p.ProductId,
            N'Potential reimbursement: SKU ' + p.SKU + N' — loss event on '
                + CONVERT(NVARCHAR, CAST(d.AdjDate AS DATE), 101)
                + N'. Claimable est: $' + CAST(ABS(d.QtyAdjusted) * COALESCE(p.COGS, 0) AS NVARCHAR(20)),
            'MEDIUM'
        FROM @DataTable d
        INNER JOIN dbo.Products p ON p.SellerAccountId = @SellerAccountId AND p.SKU = d.SKU
        INNER JOIN dbo.InventoryAdjustmentReasons r ON r.ReasonCode = d.AdjReasonCode
        WHERE r.IsLossEvent = 1 AND d.QtyAdjusted < 0
          AND p.COGS IS NOT NULL AND p.COGS > 0;

        UPDATE dbo.CSVImports
        SET RowsImported = @RowsImported, Status = 'COMPLETE',
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        UPDATE dbo.CSVImports SET Status = 'FAILED', ErrorLog = ERROR_MESSAGE(),
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;
        THROW;
    END CATCH;

    SELECT @ImportId AS ImportId, @RowsImported AS RowsImported, 'COMPLETE' AS Status;
END;
GO

-- ============================================================
-- SP: Import Returns
-- ============================================================
CREATE PROCEDURE dbo.usp_ImportCSV_Returns
    @SellerAccountId    INT,
    @UserId             INT,
    @ImportId           INT,
    @DataTable          dbo.TVP_Return READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    DECLARE @RowsImported INT = 0;

    UPDATE dbo.CSVImports SET Status = 'PROCESSING', ProcessingStarted = SYSUTCDATETIME()
    WHERE ImportId = @ImportId;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- UPSERT returns
        MERGE dbo.Returns AS tgt
        USING (
            SELECT
                @SellerAccountId    AS SellerAccountId,
                d.AmazonOrderId,
                p.ProductId,
                d.ASIN,
                d.SKU,
                d.ReturnDate,
                d.CustomerRefundDate,
                d.ReturnReceivedDate,
                d.ReturnStatus,
                d.ReturnReasonCode,
                d.Qty,
                d.RefundAmount,
                d.ReturnlessRefund,
                d.DispositionCode,
                d.FulfillmentCenterId,
                @ImportId           AS ImportId
            FROM @DataTable d
            LEFT JOIN dbo.Products p
                ON p.SellerAccountId = @SellerAccountId
               AND p.SKU = d.SKU
        ) AS src
        ON  tgt.SellerAccountId = src.SellerAccountId
        AND tgt.AmazonOrderId   = src.AmazonOrderId
        AND tgt.ASIN            = src.ASIN
        WHEN MATCHED THEN UPDATE SET
            tgt.ReturnStatus        = src.ReturnStatus,
            tgt.ReturnReceivedDate  = src.ReturnReceivedDate,
            tgt.DispositionCode     = src.DispositionCode
        WHEN NOT MATCHED THEN INSERT (
            SellerAccountId, AmazonOrderId, ProductId, ASIN, SKU,
            ReturnDate, CustomerRefundDate, ReturnReceivedDate,
            ReturnStatus, ReturnReasonCode, Qty, RefundAmount,
            ReturnlessRefund, DispositionCode, FulfillmentCenterId, ImportId
        ) VALUES (
            src.SellerAccountId, src.AmazonOrderId, src.ProductId, src.ASIN, src.SKU,
            src.ReturnDate, src.CustomerRefundDate, src.ReturnReceivedDate,
            src.ReturnStatus, src.ReturnReasonCode, src.Qty, src.RefundAmount,
            src.ReturnlessRefund, src.DispositionCode, src.FulfillmentCenterId, src.ImportId
        );

        SET @RowsImported = @@ROWCOUNT;

        -- Flag returnless refunds where no return was received as audit opportunities
        INSERT INTO dbo.ReimbursementAudit (
            ProductId, SellerAccountId, AuditDate, AuditType,
            QtyExpected, QtyAmazonReported, QtyVariance,
            COGS_PerUnit, ClaimableAmount, Status, DeadlineDate
        )
        SELECT
            r.ProductId,
            @SellerAccountId,
            CAST(SYSUTCDATETIME() AS DATE),
            'RETURNLESS_REFUND',
            0,
            r.Qty,
            r.Qty,
            p.COGS,
            r.RefundAmount,  -- Claimable = refund amount issued
            'OPEN',
            DATEADD(MONTH, 18, CAST(SYSUTCDATETIME() AS DATE))
        FROM dbo.Returns r
        INNER JOIN dbo.Products p ON p.ProductId = r.ProductId
        WHERE r.SellerAccountId = @SellerAccountId
          AND r.ReturnlessRefund = 1
          AND r.ReturnReceivedDate IS NULL
          AND r.RefundAmount > 0
          AND NOT EXISTS (
              SELECT 1 FROM dbo.ReimbursementAudit ra
              WHERE ra.SellerAccountId = @SellerAccountId
                AND ra.AuditType = 'RETURNLESS_REFUND'
                AND ra.ProductId = r.ProductId
                AND ra.Status = 'OPEN'
          );

        UPDATE dbo.CSVImports
        SET RowsImported = @RowsImported, Status = 'COMPLETE',
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        UPDATE dbo.CSVImports SET Status = 'FAILED', ErrorLog = ERROR_MESSAGE(),
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;
        THROW;
    END CATCH;

    SELECT @ImportId AS ImportId, @RowsImported AS RowsImported, 'COMPLETE' AS Status;
END;
GO

-- ============================================================
-- SP: Import PPC Keywords / Search Terms
-- ============================================================
CREATE PROCEDURE dbo.usp_ImportCSV_PPCKeywords
    @SellerAccountId    INT,
    @UserId             INT,
    @ImportId           INT,
    @DataTable          dbo.TVP_PPCKeyword READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    DECLARE @RowsImported INT = 0;

    UPDATE dbo.CSVImports SET Status = 'PROCESSING', ProcessingStarted = SYSUTCDATETIME()
    WHERE ImportId = @ImportId;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Upsert campaigns
        MERGE dbo.PPCCampaigns AS tgt
        USING (
            SELECT DISTINCT
                @SellerAccountId        AS SellerAccountId,
                d.AmazonCampaignId,
                d.CampaignName,
                @ImportId               AS ImportId
            FROM @DataTable d
        ) AS src
        ON  tgt.SellerAccountId = src.SellerAccountId
        AND tgt.AmazonCampaignId = src.AmazonCampaignId
        WHEN NOT MATCHED THEN INSERT (SellerAccountId, AmazonCampaignId, CampaignName, ImportId)
        VALUES (src.SellerAccountId, src.AmazonCampaignId, src.CampaignName, src.ImportId);

        -- Insert keyword performance data (daily granularity — no upsert, append)
        INSERT INTO dbo.PPCKeywords (
            CampaignId, SellerAccountId, AdGroupId, AdGroupName, KeywordText,
            MatchType, ReportDate, Impressions, Clicks, Spend, Sales, Orders,
            ACoS, ROAS, CTR, CVR, IsSearchTerm, ImportId
        )
        SELECT
            c.CampaignId,
            @SellerAccountId,
            d.AdGroupId,
            d.AdGroupName,
            d.KeywordText,
            d.MatchType,
            d.ReportDate,
            d.Impressions,
            d.Clicks,
            d.Spend,
            d.Sales,
            d.Orders,
            CASE WHEN d.Sales > 0 THEN d.Spend / d.Sales ELSE NULL END,
            CASE WHEN d.Spend > 0 THEN d.Sales / d.Spend ELSE NULL END,
            CASE WHEN d.Impressions > 0 THEN CAST(d.Clicks AS DECIMAL) / d.Impressions ELSE NULL END,
            CASE WHEN d.Clicks > 0 THEN CAST(d.Orders AS DECIMAL) / d.Clicks ELSE NULL END,
            d.IsSearchTerm,
            @ImportId
        FROM @DataTable d
        INNER JOIN dbo.PPCCampaigns c
            ON c.SellerAccountId = @SellerAccountId
           AND c.AmazonCampaignId = d.AmazonCampaignId
        WHERE NOT EXISTS (
            SELECT 1 FROM dbo.PPCKeywords k
            WHERE k.CampaignId = c.CampaignId
              AND k.KeywordText = d.KeywordText
              AND k.MatchType = d.MatchType
              AND k.ReportDate = d.ReportDate
              AND k.IsSearchTerm = d.IsSearchTerm
        );

        SET @RowsImported = @@ROWCOUNT;

        UPDATE dbo.CSVImports
        SET RowsImported = @RowsImported, Status = 'COMPLETE',
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        UPDATE dbo.CSVImports SET Status = 'FAILED', ErrorLog = ERROR_MESSAGE(),
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;
        THROW;
    END CATCH;

    SELECT @ImportId AS ImportId, @RowsImported AS RowsImported, 'COMPLETE' AS Status;
END;
GO

-- ============================================================
-- SP: Import Inbound Shipments
-- ============================================================
CREATE PROCEDURE dbo.usp_ImportCSV_InboundShipments
    @SellerAccountId    INT,
    @UserId             INT,
    @ImportId           INT,
    @DataTable          dbo.TVP_InboundShipment READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    DECLARE @RowsImported INT = 0;

    UPDATE dbo.CSVImports SET Status = 'PROCESSING', ProcessingStarted = SYSUTCDATETIME()
    WHERE ImportId = @ImportId;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Upsert shipment headers
        MERGE dbo.InboundShipments AS tgt
        USING (
            SELECT DISTINCT
                @SellerAccountId    AS SellerAccountId,
                d.AmazonShipmentId,
                d.ShipmentName,
                d.ShipmentStatus,
                d.DestinationFC,
                d.ShippedDate,
                d.IsAWD,
                @ImportId           AS ImportId
            FROM @DataTable d
        ) AS src
        ON  tgt.SellerAccountId  = src.SellerAccountId
        AND tgt.AmazonShipmentId = src.AmazonShipmentId
        WHEN MATCHED THEN UPDATE SET
            tgt.ShipmentStatus = src.ShipmentStatus,
            tgt.DestinationFC  = src.DestinationFC
        WHEN NOT MATCHED THEN INSERT (
            SellerAccountId, AmazonShipmentId, ShipmentName,
            ShipmentStatus, DestinationFC, ShippedDate, IsAWD, ImportId
        ) VALUES (
            src.SellerAccountId, src.AmazonShipmentId, src.ShipmentName,
            src.ShipmentStatus, src.DestinationFC, src.ShippedDate, src.IsAWD, src.ImportId
        );

        -- Upsert shipment items
        MERGE dbo.InboundShipmentItems AS tgt
        USING (
            SELECT
                s.ShipmentId,
                p.ProductId,
                d.ASIN,
                d.SKU,
                d.QtyShipped,
                d.QtyReceived
            FROM @DataTable d
            INNER JOIN dbo.InboundShipments s
                ON s.SellerAccountId = @SellerAccountId
               AND s.AmazonShipmentId = d.AmazonShipmentId
            LEFT JOIN dbo.Products p
                ON p.SellerAccountId = @SellerAccountId
               AND p.SKU = d.SKU
        ) AS src
        ON  tgt.ShipmentId = src.ShipmentId
        AND tgt.SKU        = src.SKU
        WHEN MATCHED THEN UPDATE SET
            tgt.QtyShipped  = src.QtyShipped,
            tgt.QtyReceived = src.QtyReceived
        WHEN NOT MATCHED THEN INSERT (
            ShipmentId, ProductId, ASIN, SKU, QtyShipped, QtyReceived
        ) VALUES (
            src.ShipmentId, src.ProductId, src.ASIN, src.SKU, src.QtyShipped, src.QtyReceived
        );

        SET @RowsImported = @@ROWCOUNT;

        -- Create discrepancy alerts for any shipment with variance > 0
        INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, ProductId, Message, Severity)
        SELECT
            @SellerAccountId,
            CASE WHEN s.IsAWD = 1 THEN 'AWD_DISCREPANCY' ELSE 'INBOUND_DISCREPANCY' END,
            si.ProductId,
            N'Shipment ' + s.AmazonShipmentId + N' | SKU: ' + si.SKU
                + N' | Shipped: ' + CAST(si.QtyShipped AS NVARCHAR)
                + N' | Received: ' + CAST(si.QtyReceived AS NVARCHAR)
                + N' | Missing: ' + CAST(si.QtyShipped - si.QtyReceived AS NVARCHAR),
            'HIGH'
        FROM dbo.InboundShipments s
        INNER JOIN dbo.InboundShipmentItems si ON si.ShipmentId = s.ShipmentId
        WHERE s.SellerAccountId = @SellerAccountId
          AND si.QtyShipped > si.QtyReceived
          AND si.QtyReceived >= 0
          AND NOT EXISTS (
              SELECT 1 FROM dbo.Alerts a
              WHERE a.AlertTypeCode IN ('AWD_DISCREPANCY','INBOUND_DISCREPANCY')
                AND a.ProductId = si.ProductId
                AND a.IsRead = 0
                AND a.SellerAccountId = @SellerAccountId
                AND a.Message LIKE N'%' + s.AmazonShipmentId + N'%'
          );

        UPDATE dbo.CSVImports
        SET RowsImported = @RowsImported, Status = 'COMPLETE',
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        UPDATE dbo.CSVImports SET Status = 'FAILED', ErrorLog = ERROR_MESSAGE(),
            ProcessingCompleted = SYSUTCDATETIME()
        WHERE ImportId = @ImportId;
        THROW;
    END CATCH;

    SELECT @ImportId AS ImportId, @RowsImported AS RowsImported, 'COMPLETE' AS Status;
END;
GO

-- ============================================================
-- SP: Get Import History
-- ============================================================
CREATE PROCEDURE dbo.usp_Import_GetHistory
    @SellerAccountId    INT,
    @UserId             INT,
    @PageSize           INT = 50,
    @PageNumber         INT = 1
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    SELECT
        ci.ImportId,
        ci.ReportTypeCode,
        rt.ReportTypeName,
        ci.FileName,
        ci.FileSizeBytes,
        ci.RowsTotal,
        ci.RowsImported,
        ci.RowsSkipped,
        ci.RowsErrored,
        ci.Status,
        ci.ImportDate,
        ci.ProcessingStarted,
        ci.ProcessingCompleted,
        DATEDIFF(SECOND, ci.ProcessingStarted, ci.ProcessingCompleted) AS ProcessingSeconds,
        u.Username AS ImportedBy,
        ci.ErrorLog
    FROM dbo.CSVImports ci
    INNER JOIN dbo.ReportTypes rt ON rt.ReportTypeCode = ci.ReportTypeCode
    INNER JOIN dbo.Users u ON u.UserId = ci.UserId
    WHERE ci.SellerAccountId = @SellerAccountId
    ORDER BY ci.ImportDate DESC
    OFFSET (@PageNumber - 1) * @PageSize ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END;
GO
