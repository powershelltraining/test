-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 12_ErrorLog_Config.sql
-- DESC: Error logging and debug configuration tables
-- SQL Server 2022 / Azure SQL compatible
-- ============================================================
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

USE AmazonFBAManager;
GO

-- ============================================================
-- SECTION 1: APP CONFIG TABLE (Debug Levels & Settings)
-- ============================================================

CREATE TABLE dbo.AppSettings (
    SettingId            INT             IDENTITY(1,1)  NOT NULL,
    SettingKey           VARCHAR(100)    NOT NULL,
    SettingValue         NVARCHAR(MAX)   NULL,
    Description          VARCHAR(500)    NULL,
    Category            VARCHAR(50)     NOT NULL    DEFAULT 'GENERAL',  -- GENERAL, DEBUG, SECURITY, NOTIFICATIONS
    IsActive            BIT             NOT NULL    DEFAULT 1,
    CreatedDate         DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    ModifiedDate        DATETIME2       NULL,
    CreatedBy           VARCHAR(100)    NULL,
    ModifiedBy          VARCHAR(100)    NULL,
    CONSTRAINT PK_AppSettings PRIMARY KEY (SettingId),
    CONSTRAINT UQ_AppSettings_Key UNIQUE (SettingKey)
);
GO

-- ============================================================
-- SECTION 2: ERROR LOGGING TABLE
-- ============================================================

CREATE TABLE dbo.ErrorLogs (
    ErrorLogId           BIGINT          IDENTITY(1,1)  NOT NULL,
    ErrorDate            DATETIME2       NOT NULL    DEFAULT SYSUTCDATETIME(),
    ErrorLevel           VARCHAR(20)     NOT NULL,  -- DEBUG, INFO, WARNING, ERROR, CRITICAL
    ErrorSource          VARCHAR(200)    NULL,  -- Controller/Method name
    ErrorMessage         NVARCHAR(MAX)  NOT NULL,
    StackTrace           NVARCHAR(MAX)  NULL,
    UserId               INT             NULL,
    SellerAccountId      INT             NULL,
    RequestPath          VARCHAR(500)    NULL,
    RequestMethod        VARCHAR(10)     NULL,
    IpAddress            VARCHAR(50)     NULL,
    BrowserInfo          VARCHAR(500)    NULL,
    IsResolved           BIT             NOT NULL    DEFAULT 0,
    ResolvedDate         DATETIME2       NULL,
    ResolvedBy           VARCHAR(100)    NULL,
    Notes                NVARCHAR(MAX)   NULL,
    CONSTRAINT PK_ErrorLogs PRIMARY KEY (ErrorLogId),
    CONSTRAINT CK_ErrorLogs_Level CHECK (ErrorLevel IN ('DEBUG','INFO','WARNING','ERROR','CRITICAL'))
);
GO

-- Indexes for ErrorLogs
CREATE NONCLUSTERED INDEX IX_ErrorLogs_Date ON dbo.ErrorLogs(ErrorDate DESC);
GO
CREATE NONCLUSTERED INDEX IX_ErrorLogs_Level ON dbo.ErrorLogs(ErrorLevel);
GO
CREATE NONCLUSTERED INDEX IX_ErrorLogs_Resolved ON dbo.ErrorLogs(IsResolved);
GO
CREATE NONCLUSTERED INDEX IX_ErrorLogs_User ON dbo.ErrorLogs(UserId);
GO
CREATE NONCLUSTERED INDEX IX_ErrorLogs_Account ON dbo.ErrorLogs(SellerAccountId);
GO

-- ============================================================
-- SECTION 3: SEED DEFAULT CONFIG SETTINGS
-- ============================================================

INSERT INTO dbo.AppSettings (SettingKey, SettingValue, Description, Category, CreatedBy)
VALUES
    -- Debug/Logging Settings
    ('DebugLevel', 'ERROR', 'Minimum log level to record: DEBUG, INFO, WARNING, ERROR, CRITICAL', 'DEBUG', 'SYSTEM'),
    ('EnableFileLogging', 'false', 'Enable logging to file system', 'DEBUG', 'SYSTEM'),
    ('EnableDatabaseLogging', 'true', 'Enable logging to database', 'DEBUG', 'SYSTEM'),
    ('MaxErrorLogDays', '30', 'Days to keep error logs before auto-purge', 'DEBUG', 'SYSTEM'),
    ('EmailOnCriticalErrors', 'true', 'Send email notification on CRITICAL errors', 'NOTIFICATIONS', 'SYSTEM'),
    ('EmailOnHighErrors', 'false', 'Send email notification on ERROR level errors', 'NOTIFICATIONS', 'SYSTEM'),

    -- General Settings
    ('AppVersion', '1.0.0', 'Current application version', 'GENERAL', 'SYSTEM'),
    ('MaintenanceMode', 'false', 'Enable maintenance mode to block users', 'GENERAL', 'SYSTEM'),
    ('MaxLoginAttempts', '5', 'Maximum failed login attempts before lockout', 'SECURITY', 'SYSTEM'),
    ('SessionTimeoutMinutes', '60', 'Session timeout in minutes', 'SECURITY', 'SYSTEM');
GO

PRINT '✓ Error logging and config tables created successfully';
GO