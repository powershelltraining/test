-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 09_Views_COGS_Jobs_Master.sql
-- DESC: Reporting views, COGS onboarding wizard SPs,
--       nightly job SPs, and master install order script
-- ============================================================
SET NOCOUNT ON;
GO

USE AmazonFBAManager;
GO

-- ============================================================
-- VIEWS
-- ============================================================

-- View: Latest inventory snapshot per product
CREATE VIEW dbo.vw_LatestInventory AS
    SELECT
        sn.SellerAccountId,
        sn.ProductId,
        sn.QtyFBA,
        sn.QtyInbound,
        sn.QtyReserved,
        sn.QtyUnfulfillable,
        sn.QtyWarehouseAWD,
        sn.EstStorageCostMTD,
        sn.IPI_Score,
        sn.SnapshotDate
    FROM dbo.InventorySnapshots sn
    WHERE sn.SnapshotDate = (
        SELECT MAX(sn2.SnapshotDate)
        FROM dbo.InventorySnapshots sn2
        WHERE sn2.ProductId = sn.ProductId
          AND sn2.SellerAccountId = sn.SellerAccountId
    );
GO

-- View: Open reimbursement opportunities with product info
CREATE VIEW dbo.vw_OpenReimbursementOpportunities AS
    SELECT
        ra.AuditId,
        ra.SellerAccountId,
        sa.AccountName,
        ra.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        p.COGS,
        ra.AuditType,
        ra.AuditDate,
        ra.QtyVariance,
        ra.COGS_PerUnit,
        ra.ClaimableAmount,
        ra.DeadlineDate,
        DATEDIFF(DAY, SYSUTCDATETIME(), ra.DeadlineDate) AS DaysUntilDeadline,
        CASE
            WHEN DATEDIFF(DAY, SYSUTCDATETIME(), ra.DeadlineDate) < 0    THEN 'EXPIRED'
            WHEN DATEDIFF(DAY, SYSUTCDATETIME(), ra.DeadlineDate) < 30   THEN 'CRITICAL'
            WHEN DATEDIFF(DAY, SYSUTCDATETIME(), ra.DeadlineDate) < 60   THEN 'WARNING'
            ELSE 'OK'
        END AS DeadlineStatus,
        ra.LinkedCaseId
    FROM dbo.ReimbursementAudit ra
    INNER JOIN dbo.SellerAccounts sa ON sa.SellerAccountId = ra.SellerAccountId
    INNER JOIN dbo.Products p ON p.ProductId = ra.ProductId
    WHERE ra.Status = 'OPEN';
GO

-- View: Active cases with SLA status
CREATE VIEW dbo.vw_ActiveCasesWithSLA AS
    SELECT
        c.CaseId,
        c.SellerAccountId,
        sa.AccountName,
        c.CaseTypeCode,
        ct.CaseTypeName,
        c.Status,
        c.Priority,
        c.Subject,
        c.ASIN,
        p.SKU,
        p.ProductTitle,
        c.OpenedDate,
        c.SLADueDate,
        DATEDIFF(DAY, SYSUTCDATETIME(), c.SLADueDate) AS DaysUntilSLA,
        CASE
            WHEN c.SLADueDate < SYSUTCDATETIME()                             THEN 'BREACHED'
            WHEN DATEDIFF(DAY, SYSUTCDATETIME(), c.SLADueDate) = 0           THEN 'DUE_TODAY'
            WHEN DATEDIFF(DAY, SYSUTCDATETIME(), c.SLADueDate) <= 2          THEN 'DUE_SOON'
            ELSE 'ON_TRACK'
        END AS SLAStatus,
        c.EscalationLevel,
        u.Username AS AssignedTo,
        ra.ClaimableAmount AS LinkedClaimAmount
    FROM dbo.Cases c
    INNER JOIN dbo.SellerAccounts sa ON sa.SellerAccountId = c.SellerAccountId
    INNER JOIN dbo.CaseTypes ct ON ct.CaseTypeCode = c.CaseTypeCode
    LEFT JOIN dbo.Products p ON p.ProductId = c.ProductId
    LEFT JOIN dbo.Users u ON u.UserId = c.AssignedUserId
    LEFT JOIN dbo.ReimbursementAudit ra ON ra.AuditId = c.LinkedAuditId
    WHERE c.Status NOT IN ('RESOLVED','CLOSED');
GO

-- View: SKU Economics (latest rolling 30-day P&L per SKU)
CREATE VIEW dbo.vw_SKUEconomics AS
    SELECT
        p.SellerAccountId,
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        p.COGS,
        -- 30-day trailing metrics
        COALESCE(s.UnitsSold30, 0)          AS UnitsSold30Days,
        COALESCE(s.Revenue30, 0)            AS Revenue30Days,
        COALESCE(f.Fees30, 0)               AS TotalFees30Days,
        COALESCE(r.Refunds30, 0)            AS Refunds30Days,
        COALESCE(s.UnitsSold30, 0) * COALESCE(p.COGS, 0) AS COGS30Days,
        -- Net profit 30 days
        COALESCE(s.Revenue30, 0)
            - COALESCE(f.Fees30, 0)
            - COALESCE(s.UnitsSold30, 0) * COALESCE(p.COGS, 0)
            - COALESCE(r.Refunds30, 0)      AS NetProfit30Days,
        ROUND(
            (COALESCE(s.Revenue30, 0)
            - COALESCE(f.Fees30, 0)
            - COALESCE(s.UnitsSold30, 0) * COALESCE(p.COGS, 0)
            - COALESCE(r.Refunds30, 0))
            / NULLIF(COALESCE(s.Revenue30, 0), 0) * 100
        , 2)                                AS NetMarginPct30Days,
        inv.QtyFBA                          AS CurrentFBAQty,
        CASE WHEN p.COGS IS NULL OR p.COGS = 0 THEN 1 ELSE 0 END AS COGSMissing
    FROM dbo.Products p
    LEFT JOIN (
        SELECT soi.ProductId,
               SUM(soi.QtySold) AS UnitsSold30,
               SUM(soi.ItemPrice - soi.PromotionDiscount) AS Revenue30
        FROM dbo.SalesOrderItems soi
        INNER JOIN dbo.SalesOrders so ON so.OrderId = soi.OrderId
        WHERE so.OrderDate >= DATEADD(DAY, -30, SYSUTCDATETIME())
        GROUP BY soi.ProductId
    ) s ON s.ProductId = p.ProductId
    LEFT JOIN (
        SELECT f.ProductId, SUM(ABS(f.FeeAmount)) AS Fees30
        FROM dbo.FBAFees f
        WHERE f.FeeDate >= DATEADD(DAY, -30, CAST(SYSUTCDATETIME() AS DATE))
        GROUP BY f.ProductId
    ) f ON f.ProductId = p.ProductId
    LEFT JOIN (
        SELECT r.ProductId, SUM(r.RefundAmount) AS Refunds30
        FROM dbo.Returns r
        WHERE r.CustomerRefundDate >= DATEADD(DAY, -30, CAST(SYSUTCDATETIME() AS DATE))
        GROUP BY r.ProductId
    ) r ON r.ProductId = p.ProductId
    LEFT JOIN dbo.vw_LatestInventory inv ON inv.ProductId = p.ProductId
    WHERE p.IsActive = 1;
GO

-- ============================================================
-- COGS ONBOARDING WIZARD SPs
-- ============================================================

-- Get all products missing COGS
CREATE PROCEDURE dbo.usp_COGS_GetMissingList
    @SellerAccountId    INT,
    @UserId             INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        p.Brand,
        p.COGS,
        p.COGSEnteredDate,
        CASE WHEN p.COGS IS NULL OR p.COGS = 0 THEN 'MISSING' ELSE 'ENTERED' END AS COGSStatus,
        -- Latest selling price for reference
        (SELECT TOP 1 l.BuyBoxPrice FROM dbo.Listings l
         WHERE l.ProductId = p.ProductId AND l.SellerAccountId = @SellerAccountId
         ORDER BY l.SnapshotDate DESC) AS CurrentBuyBoxPrice,
        -- Open reimbursement exposure with missing COGS
        COALESCE((
            SELECT SUM(ra.QtyVariance)
            FROM dbo.ReimbursementAudit ra
            WHERE ra.ProductId = p.ProductId
              AND ra.SellerAccountId = @SellerAccountId
              AND ra.Status = 'OPEN'
        ), 0) AS UnclaimedQtyAtRisk,
        p.IsActive
    FROM dbo.Products p
    WHERE p.SellerAccountId = @SellerAccountId
      AND (p.COGS IS NULL OR p.COGS = 0)
      AND p.IsActive = 1
    ORDER BY UnclaimedQtyAtRisk DESC, p.SKU;
END;
GO

-- Bulk update COGS for multiple products (TVP)
CREATE TYPE dbo.TVP_COGSUpdate AS TABLE (
    SKU         VARCHAR(100)    NOT NULL,
    COGS        DECIMAL(18,4)   NOT NULL
);
GO

CREATE PROCEDURE dbo.usp_COGS_BulkUpdate
    @SellerAccountId    INT,
    @UserId             INT,
    @Updates            dbo.TVP_COGSUpdate READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF dbo.fn_GetUserPermissionLevel(@UserId, @SellerAccountId) = 'READ'
        RAISERROR('Read-only users cannot update COGS.', 16, 1);

    DECLARE @Updated INT = 0;

    BEGIN TRY
        BEGIN TRANSACTION;

        UPDATE p
        SET
            p.COGS = u.COGS,
            p.COGSEnteredDate = SYSUTCDATETIME(),
            p.ModifiedDate = SYSUTCDATETIME()
        FROM dbo.Products p
        INNER JOIN @Updates u ON u.SKU = p.SKU
        WHERE p.SellerAccountId = @SellerAccountId
          AND u.COGS > 0;

        SET @Updated = @@ROWCOUNT;

        -- Recalculate claimable amounts for open audits now that COGS is known
        UPDATE ra
        SET
            ra.COGS_PerUnit = p.COGS,
            ra.ClaimableAmount = ra.QtyVariance * p.COGS,
            ra.ModifiedDate = SYSUTCDATETIME()
        FROM dbo.ReimbursementAudit ra
        INNER JOIN dbo.Products p ON p.ProductId = ra.ProductId
        INNER JOIN @Updates u ON u.SKU = p.SKU
        WHERE ra.SellerAccountId = @SellerAccountId
          AND ra.Status = 'OPEN'
          AND p.COGS > 0;

        -- Clear COGS_MISSING alerts for updated products
        UPDATE a
        SET a.IsActive = 0, a.ResolvedDate = SYSUTCDATETIME()
        FROM dbo.Alerts a
        INNER JOIN dbo.Products p ON p.ProductId = a.ProductId
        INNER JOIN @Updates u ON u.SKU = p.SKU
        WHERE a.SellerAccountId = @SellerAccountId
          AND a.AlertTypeCode = 'COGS_MISSING';

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;

    SELECT @Updated AS ProductsUpdated;
END;
GO

-- ============================================================
-- HANGFIRE BACKGROUND JOB SPs
-- Called by scheduled workers in AmazonFBAManager.Jobs project
-- ============================================================

-- Nightly Reimbursement Audit (runs 2AM daily)
CREATE PROCEDURE dbo.usp_Job_NightlyReimbursementAudit
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Create/refresh audit records from recent adjustments (last 7 days)
    INSERT INTO dbo.ReimbursementAudit (
        ProductId, SellerAccountId, AuditDate, AuditType,
        QtyExpected, QtyAmazonReported, QtyVariance,
        COGS_PerUnit, ClaimableAmount, Status, DeadlineDate
    )
    SELECT
        ia.ProductId,
        ia.SellerAccountId,
        CAST(ia.AdjDate AS DATE),
        CASE r.ReasonCode
            WHEN 'LOST'             THEN 'LOST_INVENTORY'
            WHEN 'DAMAGED'          THEN 'DAMAGED_INVENTORY'
            WHEN 'DAMAGED_WAREHOUSE' THEN 'DAMAGED_INVENTORY'
            WHEN 'WAREHOUSE_DAMAGE' THEN 'DAMAGED_INVENTORY'
            ELSE 'LOST_INVENTORY'
        END,
        0,
        ABS(ia.QtyAdjusted),
        ABS(ia.QtyAdjusted),
        p.COGS,
        ABS(ia.QtyAdjusted) * COALESCE(p.COGS, 0),
        'OPEN',
        DATEADD(MONTH, 18, CAST(ia.AdjDate AS DATE))
    FROM dbo.InventoryAdjustments ia
    INNER JOIN dbo.InventoryAdjustmentReasons r ON r.ReasonCode = ia.AdjReasonCode
    INNER JOIN dbo.Products p ON p.ProductId = ia.ProductId
    WHERE r.IsLossEvent = 1
      AND ia.QtyAdjusted < 0
      AND CAST(ia.AdjDate AS DATE) >= DATEADD(DAY, -7, CAST(SYSUTCDATETIME() AS DATE))
      AND NOT EXISTS (
          SELECT 1 FROM dbo.ReimbursementAudit ra
          WHERE ra.ProductId = ia.ProductId
            AND ra.SellerAccountId = ia.SellerAccountId
            AND ra.AuditDate = CAST(ia.AdjDate AS DATE)
            AND ra.QtyVariance = ABS(ia.QtyAdjusted)
      );

    -- 2. Alert for claims expiring within 60 days
    INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, ProductId, Message, Severity)
    SELECT
        ra.SellerAccountId,
        'REIMBURSEMENT_DEADLINE',
        ra.ProductId,
        N'Reimbursement claim expires '
            + CONVERT(NVARCHAR, ra.DeadlineDate, 101)
            + N' (' + CAST(DATEDIFF(DAY, SYSUTCDATETIME(), ra.DeadlineDate) AS NVARCHAR)
            + N' days). SKU: ' + p.SKU
            + N'. Claimable: $' + CAST(ROUND(ra.ClaimableAmount, 2) AS NVARCHAR),
        CASE WHEN DATEDIFF(DAY, SYSUTCDATETIME(), ra.DeadlineDate) <= 30
            THEN 'CRITICAL' ELSE 'HIGH' END
    FROM dbo.ReimbursementAudit ra
    INNER JOIN dbo.Products p ON p.ProductId = ra.ProductId
    WHERE ra.Status = 'OPEN'
      AND ra.DeadlineDate IS NOT NULL
      AND DATEDIFF(DAY, SYSUTCDATETIME(), ra.DeadlineDate) BETWEEN 0 AND 60
      AND NOT EXISTS (
          SELECT 1 FROM dbo.Alerts a
          WHERE a.AlertTypeCode = 'REIMBURSEMENT_DEADLINE'
            AND a.ProductId = ra.ProductId
            AND a.SellerAccountId = ra.SellerAccountId
            AND a.AlertDate >= DATEADD(DAY, -3, SYSUTCDATETIME())
      );

    -- 3. Alert for products still missing COGS
    INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, ProductId, Message, Severity)
    SELECT
        p.SellerAccountId,
        'COGS_MISSING',
        p.ProductId,
        N'COGS not entered for SKU: ' + p.SKU + N'. Amazon reimburses at cost basis — your claims are $0 without COGS.',
        'MEDIUM'
    FROM dbo.Products p
    WHERE p.IsActive = 1
      AND (p.COGS IS NULL OR p.COGS = 0)
      AND NOT EXISTS (
          SELECT 1 FROM dbo.Alerts a
          WHERE a.AlertTypeCode = 'COGS_MISSING'
            AND a.ProductId = p.ProductId
            AND a.IsRead = 0
            AND a.AlertDate >= DATEADD(DAY, -7, SYSUTCDATETIME())
      );

    SELECT
        'NightlyReimbursementAudit' AS JobName,
        SYSUTCDATETIME() AS CompletedAt;
END;
GO

-- Inventory Alert Check (every 4 hours)
CREATE PROCEDURE dbo.usp_Job_InventoryAlertCheck
AS
BEGIN
    SET NOCOUNT ON;

    -- Low stock / out of stock
    INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, ProductId, Message, Severity)
    SELECT
        sn.SellerAccountId,
        CASE WHEN sn.QtyFBA = 0 THEN 'OUT_OF_STOCK' ELSE 'LOW_STOCK' END,
        sn.ProductId,
        N'SKU: ' + p.SKU + N' | FBA Qty: ' + CAST(sn.QtyFBA AS NVARCHAR)
            + N' (Reorder Point: ' + CAST(COALESCE(p.ReorderPoint, 0) AS NVARCHAR) + N')',
        CASE WHEN sn.QtyFBA = 0 THEN 'CRITICAL' ELSE 'HIGH' END
    FROM dbo.vw_LatestInventory sn
    INNER JOIN dbo.Products p ON p.ProductId = sn.ProductId
    WHERE p.IsActive = 1
      AND p.ReorderPoint IS NOT NULL
      AND sn.QtyFBA <= p.ReorderPoint
      AND NOT EXISTS (
          SELECT 1 FROM dbo.Alerts a
          WHERE a.ProductId = sn.ProductId
            AND a.AlertTypeCode IN ('LOW_STOCK','OUT_OF_STOCK')
            AND a.IsRead = 0
            AND a.AlertDate >= DATEADD(HOUR, -8, SYSUTCDATETIME())
      );

    -- IPI below threshold
    INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, Message, Severity)
    SELECT DISTINCT
        sn.SellerAccountId,
        'IPI_LOW',
        N'IPI Score is ' + CAST(sn.IPI_Score AS NVARCHAR) + N'. Scores below 400 may result in storage limits.',
        'MEDIUM'
    FROM dbo.vw_LatestInventory sn
    WHERE sn.IPI_Score IS NOT NULL AND sn.IPI_Score < 400
      AND NOT EXISTS (
          SELECT 1 FROM dbo.Alerts a
          WHERE a.SellerAccountId = sn.SellerAccountId
            AND a.AlertTypeCode = 'IPI_LOW'
            AND a.IsRead = 0
            AND a.AlertDate >= DATEADD(DAY, -1, SYSUTCDATETIME())
      );

    SELECT 'InventoryAlertCheck' AS JobName, SYSUTCDATETIME() AS CompletedAt;
END;
GO

-- Weekly PPC Audit Job
CREATE PROCEDURE dbo.usp_Job_PPCAuditWeekly
AS
BEGIN
    SET NOCOUNT ON;

    -- Flag seller accounts with TACoS > 20% (unhealthy PPC spend)
    INSERT INTO dbo.Alerts (SellerAccountId, AlertTypeCode, Message, Severity)
    SELECT
        c.SellerAccountId,
        'FEE_SPIKE',
        N'TACoS alert: PPC spend is '
            + CAST(ROUND(SUM(k.Spend) / NULLIF(
                (SELECT SUM(soi.ItemPrice) FROM dbo.SalesOrderItems soi
                 INNER JOIN dbo.SalesOrders so2 ON so2.OrderId = soi.OrderId
                 WHERE so2.SellerAccountId = c.SellerAccountId
                   AND so2.OrderDate >= DATEADD(DAY, -7, SYSUTCDATETIME()))
            , 0) * 100, 1) AS NVARCHAR) + N'% of total revenue (TACoS). Target < 10%.',
        'MEDIUM'
    FROM dbo.PPCKeywords k
    INNER JOIN dbo.PPCCampaigns c ON c.CampaignId = k.CampaignId
    WHERE k.ReportDate >= DATEADD(DAY, -7, CAST(SYSUTCDATETIME() AS DATE))
    GROUP BY c.SellerAccountId
    HAVING SUM(k.Spend) / NULLIF(
        (SELECT SUM(soi2.ItemPrice) FROM dbo.SalesOrderItems soi2
         INNER JOIN dbo.SalesOrders so3 ON so3.OrderId = soi2.OrderId
         WHERE so3.SellerAccountId = c.SellerAccountId
           AND so3.OrderDate >= DATEADD(DAY, -7, SYSUTCDATETIME()))
    , 0) > 0.20;

    SELECT 'PPCAuditWeekly' AS JobName, SYSUTCDATETIME() AS CompletedAt;
END;
GO

-- ============================================================
-- SELLER ACCOUNT ONBOARDING (seeds default thresholds)
-- ============================================================
CREATE PROCEDURE dbo.usp_SellerAccount_Onboard
    @SellerAccountId    INT,
    @AdminUserId        INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Copy default alert thresholds for this account
        INSERT INTO dbo.AlertThresholds (SellerAccountId, ProductId, AlertTypeCode, ThresholdValue, ThresholdUnit)
        SELECT @SellerAccountId, NULL, AlertTypeCode, DefaultValue, Unit
        FROM dbo.DefaultAlertThresholds
        WHERE NOT EXISTS (
            SELECT 1 FROM dbo.AlertThresholds at2
            WHERE at2.SellerAccountId = @SellerAccountId
              AND at2.AlertTypeCode = DefaultAlertThresholds.AlertTypeCode
              AND at2.ProductId IS NULL
        );

        -- Mark onboarding as complete if COGS wizard can be skipped (do this after COGS entry)
        -- (OnboardingComplete is set to 1 by usp_COGS_BulkUpdate or manually by admin)

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;

    SELECT 'Onboarding thresholds seeded.' AS Result, @SellerAccountId AS SellerAccountId;
END;
GO

-- ============================================================
-- MASTER INSTALL ORDER
-- Run scripts in this exact order on a new database:
-- ============================================================
/*
INSTALL ORDER:
  1. CREATE DATABASE AmazonFBAManager
  2. 01_CoreTables.sql           -- All tables, indexes, FKs
  3. 02_TVPs_And_Security.sql    -- TVPs, fn_UserHasAccountAccess, usp_Auth_*
  4. 03_SeedData.sql             -- Lookup tables, defaults, SOP templates
  5. 04_SP_Import.sql            -- CSV import SPs
  6. 05_SP_Inventory.sql         -- Inventory management SPs
  7. 06_SP_Reimbursement.sql     -- Reimbursement audit SPs
  8. 07_SP_Cases.sql             -- Case management SPs
  9. 08_SP_Reports_PPC_Listings_Research.sql  -- Reporting, PPC, listing, research SPs
  10. 09_Views_COGS_Jobs_Master.sql           -- Views, COGS wizard, job SPs

POST-INSTALL STEPS:
  1. Run usp_SellerAccount_Onboard for each seller account created
  2. Configure ASP.NET Identity to use Users table (or shadow with claims)
  3. Register Hangfire jobs pointing to usp_Job_* SPs:
       - NightlyReimbursementAudit:  Daily @ 02:00 UTC
       - InventoryAlertCheck:        Every 4 hours
       - PPCAuditWeekly:             Every Monday @ 06:00 UTC
       - usp_Case_MonitorSLABreaches: Every 2 hours
  4. Encrypt SPAPIClientSecret and RefreshToken columns using app-layer AES key
  5. Change admin password via Users table on first login
*/
GO
