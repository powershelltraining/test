-- ============================================================
-- Amazon FBA Multi-Seller Management Platform
-- FILE: 06_SP_Reimbursement.sql
-- DESC: All reimbursement audit stored procedures
--       NOTE: As of March 10, 2025 Amazon reimburses at COST
--       BASIS (COGS), not selling price. All ClaimableAmount
--       calculations use Products.COGS per unit.
-- ============================================================
SET NOCOUNT ON;
GO

USE AmazonFBAManager;
GO

-- ============================================================
-- SP: Audit Lost/Damaged Inventory
-- Cross-references: Adjustments vs Reimbursements vs Current Inventory
-- ============================================================
CREATE PROCEDURE dbo.usp_Reimbursement_AuditLostDamagedInventory
    @SellerAccountId    INT,
    @UserId             INT,
    @DateFrom           DATE = NULL,
    @DateTo             DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF @DateFrom IS NULL SET @DateFrom = DATEADD(MONTH, -18, CAST(SYSUTCDATETIME() AS DATE));
    IF @DateTo   IS NULL SET @DateTo   = CAST(SYSUTCDATETIME() AS DATE);

    ;WITH LossEvents AS (
        -- All loss/damage adjustments in the period
        SELECT
            ia.ProductId,
            ia.AdjReasonCode,
            CAST(ia.AdjDate AS DATE)            AS EventDate,
            SUM(ABS(ia.QtyAdjusted))            AS QtyLost
        FROM dbo.InventoryAdjustments ia
        INNER JOIN dbo.InventoryAdjustmentReasons r ON r.ReasonCode = ia.AdjReasonCode
        WHERE ia.SellerAccountId = @SellerAccountId
          AND r.IsLossEvent = 1
          AND ia.QtyAdjusted < 0
          AND CAST(ia.AdjDate AS DATE) BETWEEN @DateFrom AND @DateTo
        GROUP BY ia.ProductId, ia.AdjReasonCode, CAST(ia.AdjDate AS DATE)
    ),
    ReimbReceived AS (
        -- All reimbursements actually paid by Amazon in the period
        SELECT
            r.ProductId,
            SUM(r.QtyReimbursed)                AS QtyReimbursed,
            SUM(r.TotalAmount)                  AS TotalReimbReceived
        FROM dbo.Reimbursements r
        WHERE r.SellerAccountId = @SellerAccountId
          AND r.ReimbDate BETWEEN @DateFrom AND @DateTo
          AND r.ReimbType IN ('LOST_INVENTORY','DAMAGED_INVENTORY','COMPENSATED')
        GROUP BY r.ProductId
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        SUM(le.QtyLost)                                             AS TotalQtyLost,
        COALESCE(rr.QtyReimbursed, 0)                               AS QtyReimbursed,
        SUM(le.QtyLost) - COALESCE(rr.QtyReimbursed, 0)            AS QtyUnclaimed,
        p.COGS                                                      AS COGS_PerUnit,
        -- 2025 policy: Amazon reimburses at COST BASIS
        ROUND(
            (SUM(le.QtyLost) - COALESCE(rr.QtyReimbursed, 0))
            * COALESCE(p.COGS, 0)
        , 2)                                                        AS ClaimableAmountUSD,
        COALESCE(rr.TotalReimbReceived, 0)                          AS AlreadyReceivedUSD,
        CASE WHEN p.COGS IS NULL OR p.COGS = 0
            THEN 'WARNING: COGS not entered — claimable amount is $0. Update COGS to calculate true claim value.'
            ELSE NULL
        END                                                         AS COGSWarning,
        -- 18-month filing deadline: oldest loss event
        DATEADD(MONTH, 18, MIN(le.EventDate))                       AS FilingDeadline,
        CASE
            WHEN DATEDIFF(DAY, SYSUTCDATETIME(), DATEADD(MONTH, 18, MIN(le.EventDate))) < 60
                THEN 'URGENT — deadline within 60 days'
            WHEN DATEDIFF(DAY, SYSUTCDATETIME(), DATEADD(MONTH, 18, MIN(le.EventDate))) < 0
                THEN 'EXPIRED — filing window closed'
            ELSE 'WITHIN WINDOW'
        END                                                         AS DeadlineStatus,
        -- Link to existing audit record if created
        ra.AuditId,
        ra.Status                                                   AS AuditStatus,
        ra.LinkedCaseId
    FROM LossEvents le
    INNER JOIN dbo.Products p ON p.ProductId = le.ProductId
    LEFT JOIN ReimbReceived rr ON rr.ProductId = le.ProductId
    LEFT JOIN dbo.ReimbursementAudit ra
        ON ra.ProductId = le.ProductId
       AND ra.SellerAccountId = @SellerAccountId
       AND ra.AuditType IN ('LOST_INVENTORY','DAMAGED_INVENTORY')
    WHERE p.SellerAccountId = @SellerAccountId
    GROUP BY
        p.ProductId, p.SKU, p.ASIN, p.ProductTitle, p.COGS,
        rr.QtyReimbursed, rr.TotalReimbReceived,
        ra.AuditId, ra.Status, ra.LinkedCaseId
    HAVING
        SUM(le.QtyLost) - COALESCE(rr.QtyReimbursed, 0) > 0  -- Only show unclaimed
    ORDER BY ClaimableAmountUSD DESC;
END;
GO

-- ============================================================
-- SP: Detect Fee Overcharges
-- Compares actual FBA fees vs expected based on product dims/weight
-- ============================================================
CREATE PROCEDURE dbo.usp_Reimbursement_DetectFeeOvercharges
    @SellerAccountId    INT,
    @UserId             INT,
    @DateFrom           DATE = NULL,
    @DateTo             DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF @DateFrom IS NULL SET @DateFrom = DATEADD(MONTH, -3, CAST(SYSUTCDATETIME() AS DATE));
    IF @DateTo   IS NULL SET @DateTo   = CAST(SYSUTCDATETIME() AS DATE);

    -- FBA fee tiers (2024-2025 standard size, US marketplace)
    -- Size tier determined by dimensional weight or actual weight, whichever is greater
    -- Standard sizes (under 20 lbs, under 18"x14"x8"):
    --   Small standard (4 oz or less):   $3.06
    --   Small standard (4-8 oz):         $3.15
    --   Large standard (8-16 oz):        $3.68
    --   Large standard (1-2 lbs):        $4.99
    --   Large standard (2-3 lbs):        $5.91
    --   Large standard (3+ lbs):         $5.91 + $0.16/lb above 3 lbs
    -- Oversize adds significantly more

    ;WITH ActualFees AS (
        SELECT
            f.ProductId,
            SUM(ABS(f.FeeAmount))   AS TotalFeeCharged,
            COUNT(*)                AS FeeTransactionCount,
            AVG(ABS(f.FeeAmount))   AS AvgFeePerUnit
        FROM dbo.FBAFees f
        WHERE f.SellerAccountId = @SellerAccountId
          AND f.FeeTypeCode = 'FBA_FULFILLMENT'
          AND f.FeeDate BETWEEN @DateFrom AND @DateTo
        GROUP BY f.ProductId
    ),
    ExpectedFees AS (
        -- Calculate expected fee from product weight using published 2024-2025 rate card
        SELECT
            p.ProductId,
            p.WeightLbs,
            -- Classify size tier
            CASE
                WHEN p.WeightLbs <= 0.25 THEN 3.06   -- ≤4 oz
                WHEN p.WeightLbs <= 0.5  THEN 3.15   -- 4-8 oz
                WHEN p.WeightLbs <= 1.0  THEN 3.68   -- 8-16 oz
                WHEN p.WeightLbs <= 2.0  THEN 4.99   -- 1-2 lbs
                WHEN p.WeightLbs <= 3.0  THEN 5.91   -- 2-3 lbs
                WHEN p.WeightLbs <= 20.0 THEN 5.91 + (p.WeightLbs - 3.0) * 0.16  -- 3-20 lbs
                ELSE NULL  -- Oversize — cannot estimate without full dims
            END AS ExpectedFeePerUnit
        FROM dbo.Products p
        WHERE p.SellerAccountId = @SellerAccountId
          AND p.WeightLbs IS NOT NULL
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        p.WeightLbs,
        ef.ExpectedFeePerUnit                                       AS ExpectedFeePerUnit,
        af.AvgFeePerUnit                                            AS ActualAvgFeePerUnit,
        ROUND(af.AvgFeePerUnit - COALESCE(ef.ExpectedFeePerUnit, af.AvgFeePerUnit), 4) AS FeeVariancePerUnit,
        af.FeeTransactionCount,
        ROUND(
            (af.AvgFeePerUnit - COALESCE(ef.ExpectedFeePerUnit, af.AvgFeePerUnit))
            * af.FeeTransactionCount
        , 2)                                                        AS TotalOverchargeUSD,
        CASE
            WHEN ef.ExpectedFeePerUnit IS NULL
                THEN 'OVERSIZE — manual review required'
            WHEN af.AvgFeePerUnit > ef.ExpectedFeePerUnit * 1.10
                THEN 'OVERCHARGE DETECTED — fee > 10% above expected'
            WHEN af.AvgFeePerUnit > ef.ExpectedFeePerUnit * 1.05
                THEN 'REVIEW — fee 5-10% above expected'
            ELSE 'WITHIN TOLERANCE'
        END                                                         AS OverchargeType,
        CASE
            WHEN af.AvgFeePerUnit > COALESCE(ef.ExpectedFeePerUnit, 0) * 1.05
                THEN 'File case: FEE_OVERCHARGE. Attach product dimensions and weight documentation.'
            ELSE NULL
        END                                                         AS RecommendedAction
    FROM dbo.Products p
    INNER JOIN ActualFees af ON af.ProductId = p.ProductId
    LEFT JOIN ExpectedFees ef ON ef.ProductId = p.ProductId
    WHERE p.SellerAccountId = @SellerAccountId
    ORDER BY TotalOverchargeUSD DESC;
END;
GO

-- ============================================================
-- SP: Audit Returnless Refunds Not Reimbursed
-- ============================================================
CREATE PROCEDURE dbo.usp_Reimbursement_AuditReturnlessRefunds
    @SellerAccountId    INT,
    @UserId             INT,
    @DateFrom           DATE = NULL,
    @DateTo             DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF @DateFrom IS NULL SET @DateFrom = DATEADD(MONTH, -6, CAST(SYSUTCDATETIME() AS DATE));
    IF @DateTo   IS NULL SET @DateTo   = CAST(SYSUTCDATETIME() AS DATE);

    SELECT
        r.ReturnId,
        r.AmazonOrderId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        r.ReturnDate,
        r.CustomerRefundDate,
        r.ReturnReceivedDate,
        r.RefundAmount,
        r.Qty,
        p.COGS,
        -- Returnless refunds: Amazon refunded buyer, we lost the unit AND the revenue
        -- We can claim the COGS value since we lost inventory without reimbursement
        ROUND(r.Qty * COALESCE(p.COGS, 0), 2)  AS ClaimableAmountUSD,
        CASE WHEN r.ReturnReceivedDate IS NULL THEN 'NOT_RECEIVED' ELSE 'RECEIVED' END AS ReturnReceived,
        -- Check if a reimbursement was already paid for this order
        COALESCE((
            SELECT TOP 1 reimb.TotalAmount
            FROM dbo.Reimbursements reimb
            WHERE reimb.SellerAccountId = @SellerAccountId
              AND reimb.ProductId = r.ProductId
              AND reimb.ReimbDate BETWEEN r.ReturnDate AND DATEADD(DAY, 90, r.ReturnDate)
              AND reimb.ReimbType = 'RETURNLESS_REFUND'
        ), 0)                                   AS ReimbAlreadyReceived,
        DATEADD(MONTH, 18, r.CustomerRefundDate) AS FilingDeadline,
        ra.AuditId,
        ra.Status AS AuditStatus
    FROM dbo.Returns r
    INNER JOIN dbo.Products p ON p.ProductId = r.ProductId
    LEFT JOIN dbo.ReimbursementAudit ra
        ON ra.ProductId = r.ProductId
       AND ra.SellerAccountId = @SellerAccountId
       AND ra.AuditType = 'RETURNLESS_REFUND'
       AND ra.AuditDate = r.ReturnDate
    WHERE r.SellerAccountId = @SellerAccountId
      AND r.ReturnlessRefund = 1
      AND r.ReturnReceivedDate IS NULL  -- No return received
      AND COALESCE(r.CustomerRefundDate, r.ReturnDate) BETWEEN @DateFrom AND @DateTo
      -- Exclude already fully reimbursed
      AND COALESCE((
            SELECT TOP 1 reimb.TotalAmount
            FROM dbo.Reimbursements reimb
            WHERE reimb.SellerAccountId = @SellerAccountId
              AND reimb.ProductId = r.ProductId
              AND reimb.ReimbDate BETWEEN r.ReturnDate AND DATEADD(DAY, 90, r.ReturnDate)
              AND reimb.ReimbType = 'RETURNLESS_REFUND'
      ), 0) < r.RefundAmount
    ORDER BY ClaimableAmountUSD DESC;
END;
GO

-- ============================================================
-- SP: Audit Inbound Shipment Discrepancies
-- ============================================================
CREATE PROCEDURE dbo.usp_Reimbursement_AuditInboundShipments
    @SellerAccountId    INT,
    @UserId             INT,
    @ShipmentId         VARCHAR(50) = NULL   -- NULL = all shipments
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    SELECT
        s.AmazonShipmentId,
        s.ShipmentName,
        s.ShippedDate,
        s.ArrivedDate,
        s.DestinationFC,
        s.IsAWD,
        si.ASIN,
        si.SKU,
        p.ProductTitle,
        si.QtyShipped,
        si.QtyReceived,
        si.QtyShipped - si.QtyReceived          AS QtyMissing,
        p.COGS                                  AS COGS_PerUnit,
        ROUND((si.QtyShipped - si.QtyReceived) * COALESCE(p.COGS, 0), 2) AS ClaimableAmountUSD,
        -- Check if Amazon already reconciled this
        COALESCE((
            SELECT TOP 1 reimb.TotalAmount
            FROM dbo.Reimbursements reimb
            WHERE reimb.SellerAccountId = @SellerAccountId
              AND reimb.ProductId = si.ProductId
              AND reimb.ReimbDate BETWEEN s.ShippedDate AND DATEADD(MONTH, 3, s.ShippedDate)
              AND reimb.ReimbType = 'INBOUND_DISCREPANCY'
        ), 0)                                   AS AlreadyReimbursed,
        -- Existing case for this shipment
        c.CaseId,
        c.Status                                AS CaseStatus,
        c.AmazonCaseId,
        DATEADD(MONTH, 18, s.ShippedDate)       AS FilingDeadline,
        DATEDIFF(DAY, SYSUTCDATETIME(), DATEADD(MONTH, 18, s.ShippedDate)) AS DaysUntilDeadline
    FROM dbo.InboundShipments s
    INNER JOIN dbo.InboundShipmentItems si ON si.ShipmentId = s.ShipmentId
    INNER JOIN dbo.Products p ON p.ProductId = si.ProductId
    LEFT JOIN dbo.Cases c
        ON c.SellerAccountId = @SellerAccountId
       AND c.CaseTypeCode IN ('INBOUND_DISCREPANCY','AWD_LOSS')
       AND c.Subject LIKE '%' + s.AmazonShipmentId + '%'
    WHERE s.SellerAccountId = @SellerAccountId
      AND si.QtyShipped > si.QtyReceived
      AND si.QtyReceived >= 0
      AND (@ShipmentId IS NULL OR s.AmazonShipmentId = @ShipmentId)
    ORDER BY ClaimableAmountUSD DESC;
END;
GO

-- ============================================================
-- SP: Monthly Reimbursement Checklist
-- ============================================================
CREATE PROCEDURE dbo.usp_Reimbursement_MonthlyChecklist
    @SellerAccountId    INT,
    @UserId             INT,
    @Month              TINYINT = NULL,
    @Year               SMALLINT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF @Month IS NULL SET @Month = MONTH(SYSUTCDATETIME());
    IF @Year  IS NULL SET @Year  = YEAR(SYSUTCDATETIME());

    DECLARE
        @PeriodStart    DATE = DATEFROMPARTS(@Year, @Month, 1),
        @PeriodEnd      DATE = EOMONTH(DATEFROMPARTS(@Year, @Month, 1));

    -- Build a checklist of all reimbursement audit categories
    -- Each row: item, status, potential $, action required, deadline

    ;WITH ChecklistItems AS (

        -- 1. Lost Inventory
        SELECT
            1 AS SortOrder,
            'LOST_INVENTORY' AS ChecklistItem,
            'Lost/Damaged Inventory Audit' AS ItemName,
            CAST(COUNT(*) AS NVARCHAR) + ' unclaimed loss events found' AS StatusDetail,
            SUM(ROUND((ia_counts.QtyLost - COALESCE(reimb_counts.QtyReimbursed, 0)) * COALESCE(p.COGS, 0), 2)) AS PotentialAmount,
            CASE WHEN SUM(ia_counts.QtyLost - COALESCE(reimb_counts.QtyReimbursed, 0)) > 0
                THEN 'FILE_CASE' ELSE 'NO_ACTION' END AS ActionRequired,
            DATEADD(MONTH, 18, @PeriodEnd) AS Deadline
        FROM (
            SELECT ia.ProductId, SUM(ABS(ia.QtyAdjusted)) AS QtyLost
            FROM dbo.InventoryAdjustments ia
            INNER JOIN dbo.InventoryAdjustmentReasons r ON r.ReasonCode = ia.AdjReasonCode
            WHERE ia.SellerAccountId = @SellerAccountId
              AND r.IsLossEvent = 1 AND ia.QtyAdjusted < 0
              AND CAST(ia.AdjDate AS DATE) BETWEEN @PeriodStart AND @PeriodEnd
            GROUP BY ia.ProductId
        ) ia_counts
        INNER JOIN dbo.Products p ON p.ProductId = ia_counts.ProductId
        LEFT JOIN (
            SELECT r.ProductId, SUM(r.QtyReimbursed) AS QtyReimbursed
            FROM dbo.Reimbursements r
            WHERE r.SellerAccountId = @SellerAccountId
              AND r.ReimbDate BETWEEN @PeriodStart AND DATEADD(MONTH, 3, @PeriodEnd)
              AND r.ReimbType IN ('LOST_INVENTORY','DAMAGED_INVENTORY','COMPENSATED')
            GROUP BY r.ProductId
        ) reimb_counts ON reimb_counts.ProductId = ia_counts.ProductId
        WHERE (ia_counts.QtyLost - COALESCE(reimb_counts.QtyReimbursed, 0)) > 0

        UNION ALL

        -- 2. Returnless Refunds
        SELECT
            2,
            'RETURNLESS_REFUNDS',
            'Returnless Refunds Not Reimbursed',
            CAST(COUNT(*) AS NVARCHAR) + ' returnless refunds with no return received',
            SUM(ROUND(r.Qty * COALESCE(p.COGS, 0), 2)),
            CASE WHEN COUNT(*) > 0 THEN 'FILE_CASE' ELSE 'NO_ACTION' END,
            DATEADD(MONTH, 18, @PeriodEnd)
        FROM dbo.Returns r
        INNER JOIN dbo.Products p ON p.ProductId = r.ProductId
        WHERE r.SellerAccountId = @SellerAccountId
          AND r.ReturnlessRefund = 1
          AND r.ReturnReceivedDate IS NULL
          AND COALESCE(r.CustomerRefundDate, r.ReturnDate) BETWEEN @PeriodStart AND @PeriodEnd

        UNION ALL

        -- 3. Fee Overcharges
        SELECT
            3,
            'FEE_OVERCHARGES',
            'FBA Fee Overcharge Review',
            'Review fee charges for dimension/weight mismatches',
            -- Rough estimate: flag if average fee > 10% above median
            COALESCE((
                SELECT SUM(ABS(f.FeeAmount)) * 0.10
                FROM dbo.FBAFees f
                WHERE f.SellerAccountId = @SellerAccountId
                  AND f.FeeTypeCode = 'FBA_FULFILLMENT'
                  AND f.FeeDate BETWEEN @PeriodStart AND @PeriodEnd
            ), 0),
            'REVIEW',
            NULL

        UNION ALL

        -- 4. Inbound Shipment Discrepancies
        SELECT
            4,
            'INBOUND_DISCREPANCIES',
            'Inbound Shipment Discrepancies',
            CAST(COUNT(*) AS NVARCHAR) + ' shipments with receiving shortfall',
            SUM(ROUND((si.QtyShipped - si.QtyReceived) * COALESCE(p.COGS, 0), 2)),
            CASE WHEN COUNT(*) > 0 THEN 'FILE_CASE' ELSE 'NO_ACTION' END,
            DATEADD(MONTH, 18, MAX(s.ShippedDate))
        FROM dbo.InboundShipments s
        INNER JOIN dbo.InboundShipmentItems si ON si.ShipmentId = s.ShipmentId
        INNER JOIN dbo.Products p ON p.ProductId = si.ProductId
        WHERE s.SellerAccountId = @SellerAccountId
          AND si.QtyShipped > si.QtyReceived
          AND s.ShippedDate BETWEEN @PeriodStart AND @PeriodEnd

        UNION ALL

        -- 5. COGS Completeness
        SELECT
            5,
            'COGS_COMPLETENESS',
            'COGS Data Completeness Check',
            CAST(COUNT(*) AS NVARCHAR) + ' active ASINs missing COGS — reimbursements will be $0',
            0,
            CASE WHEN COUNT(*) > 0 THEN 'UPDATE_COGS' ELSE 'NO_ACTION' END,
            NULL
        FROM dbo.Products p
        WHERE p.SellerAccountId = @SellerAccountId
          AND p.IsActive = 1
          AND (p.COGS IS NULL OR p.COGS = 0)

        UNION ALL

        -- 6. Upcoming filing deadlines (within 60 days)
        SELECT
            6,
            'UPCOMING_DEADLINES',
            'Reimbursement Filing Deadlines (60-day warning)',
            CAST(COUNT(*) AS NVARCHAR) + ' claims expiring within 60 days',
            SUM(ra.ClaimableAmount),
            CASE WHEN COUNT(*) > 0 THEN 'URGENT_FILE_NOW' ELSE 'NO_ACTION' END,
            MIN(ra.DeadlineDate)
        FROM dbo.ReimbursementAudit ra
        WHERE ra.SellerAccountId = @SellerAccountId
          AND ra.Status = 'OPEN'
          AND ra.DeadlineDate IS NOT NULL
          AND DATEDIFF(DAY, SYSUTCDATETIME(), ra.DeadlineDate) BETWEEN 0 AND 60
    )
    SELECT
        c.SortOrder,
        c.ChecklistItem,
        c.ItemName,
        c.StatusDetail,
        ROUND(COALESCE(c.PotentialAmount, 0), 2)    AS PotentialAmountUSD,
        c.ActionRequired,
        c.Deadline,
        CASE c.ActionRequired
            WHEN 'FILE_CASE'        THEN 'Go to Case Manager > New Case and select the appropriate case type.'
            WHEN 'UPDATE_COGS'      THEN 'Go to Settings > COGS Manager and enter cost for each missing ASIN.'
            WHEN 'REVIEW'           THEN 'Run Fee Overcharge scan under Refund Auditor.'
            WHEN 'URGENT_FILE_NOW'  THEN 'CRITICAL: File case immediately before deadline expires.'
            ELSE 'No action required — all clear for this item.'
        END                                         AS ActionInstructions
    FROM ChecklistItems c
    ORDER BY c.SortOrder;
END;
GO

-- ============================================================
-- SP: COGS Impact Calculator
-- Shows sellers the impact of 2025 cost-basis reimbursement policy
-- ============================================================
CREATE PROCEDURE dbo.usp_Reimbursement_CalculateCOGSImpact
    @SellerAccountId    INT,
    @UserId             INT
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    ;WITH OpenAudits AS (
        SELECT
            ra.ProductId,
            SUM(ra.QtyVariance)         AS TotalQtyUnclaimed,
            SUM(ra.ClaimableAmount)     AS CurrentClaimableAtCOGS
        FROM dbo.ReimbursementAudit ra
        WHERE ra.SellerAccountId = @SellerAccountId
          AND ra.Status = 'OPEN'
        GROUP BY ra.ProductId
    ),
    LatestPrice AS (
        SELECT
            l.ProductId,
            l.BuyBoxPrice,
            ROW_NUMBER() OVER (PARTITION BY l.ProductId ORDER BY l.SnapshotDate DESC) AS rn
        FROM dbo.Listings l
        WHERE l.SellerAccountId = @SellerAccountId
    )
    SELECT
        p.ProductId,
        p.SKU,
        p.ASIN,
        p.ProductTitle,
        p.COGS                                                          AS CurrentCOGS,
        CASE WHEN p.COGS IS NULL OR p.COGS = 0
            THEN 'NOT_ENTERED' ELSE 'ENTERED' END                       AS COGSEntered,
        lp.BuyBoxPrice                                                  AS CurrentBuyBoxPrice,
        -- Under OLD policy: reimbursed at ~selling price
        ROUND(oa.TotalQtyUnclaimed * COALESCE(lp.BuyBoxPrice * 0.85, 0), 2) AS OldPolicyEstimate,
        -- Under NEW policy (2025+): reimbursed at COGS
        ROUND(oa.TotalQtyUnclaimed * COALESCE(p.COGS, 0), 2)           AS NewPolicyAtCOGS,
        -- Revenue impact of the policy change
        ROUND(
            oa.TotalQtyUnclaimed * COALESCE(lp.BuyBoxPrice * 0.85, 0)
            - oa.TotalQtyUnclaimed * COALESCE(p.COGS, 0)
        , 2)                                                            AS PolicyChangeDeltaUSD,
        oa.TotalQtyUnclaimed,
        -- Recommendation
        CASE
            WHEN p.COGS IS NULL OR p.COGS = 0
                THEN 'CRITICAL: Enter COGS immediately — without it, Amazon reimburses at $0 under 2025 policy.'
            WHEN p.COGS < lp.BuyBoxPrice * 0.20
                THEN 'WARNING: COGS appears very low vs selling price. Verify COGS is accurate.'
            ELSE 'COGS entered — reimbursement calculations are accurate.'
        END                                                             AS Recommendation
    FROM dbo.Products p
    LEFT JOIN OpenAudits oa ON oa.ProductId = p.ProductId
    LEFT JOIN LatestPrice lp ON lp.ProductId = p.ProductId AND lp.rn = 1
    WHERE p.SellerAccountId = @SellerAccountId
      AND p.IsActive = 1
    ORDER BY
        CASE WHEN p.COGS IS NULL OR p.COGS = 0 THEN 0 ELSE 1 END,  -- Missing COGS first
        OldPolicyEstimate DESC;
END;
GO

-- ============================================================
-- SP: Reimbursement KPI Dashboard
-- ============================================================
CREATE PROCEDURE dbo.usp_Reimbursement_GetKPIDashboard
    @SellerAccountId    INT,
    @UserId             INT,
    @DateFrom           DATE = NULL,
    @DateTo             DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF dbo.fn_UserHasAccountAccess(@UserId, @SellerAccountId) = 0
        RAISERROR('Access denied.', 16, 1);

    IF @DateFrom IS NULL SET @DateFrom = DATEADD(MONTH, -12, CAST(SYSUTCDATETIME() AS DATE));
    IF @DateTo   IS NULL SET @DateTo   = CAST(SYSUTCDATETIME() AS DATE);

    -- Summary KPIs
    SELECT
        -- Total audit items created
        (SELECT COUNT(*) FROM dbo.ReimbursementAudit ra
         WHERE ra.SellerAccountId = @SellerAccountId
           AND ra.AuditDate BETWEEN @DateFrom AND @DateTo)                      AS TotalAuditItems,

        -- Total cases filed
        (SELECT COUNT(*) FROM dbo.Cases c
         WHERE c.SellerAccountId = @SellerAccountId
           AND c.CaseTypeCode IN ('LOST_INVENTORY','DAMAGED_INVENTORY',
               'FEE_OVERCHARGE','RETURNLESS_REFUND','INBOUND_DISCREPANCY','AWD_LOSS')
           AND CAST(c.OpenedDate AS DATE) BETWEEN @DateFrom AND @DateTo)        AS TotalCasesFiled,

        -- Total reimbursed
        (SELECT ROUND(SUM(r.TotalAmount), 2)
         FROM dbo.Reimbursements r
         WHERE r.SellerAccountId = @SellerAccountId
           AND r.ReimbDate BETWEEN @DateFrom AND @DateTo)                       AS TotalReimbursedUSD,

        -- Total open / pending
        (SELECT ROUND(SUM(ra.ClaimableAmount), 2)
         FROM dbo.ReimbursementAudit ra
         WHERE ra.SellerAccountId = @SellerAccountId
           AND ra.Status = 'OPEN'
           AND ra.AuditDate BETWEEN @DateFrom AND @DateTo)                      AS TotalPendingUSD,

        -- Approval rate
        ROUND(
            CAST((SELECT COUNT(*) FROM dbo.ReimbursementAudit ra
                  WHERE ra.SellerAccountId = @SellerAccountId
                    AND ra.Status = 'REIMBURSED'
                    AND ra.AuditDate BETWEEN @DateFrom AND @DateTo) AS DECIMAL)
            / NULLIF((SELECT COUNT(*) FROM dbo.ReimbursementAudit ra
                      WHERE ra.SellerAccountId = @SellerAccountId
                        AND ra.Status IN ('REIMBURSED','DENIED')
                        AND ra.AuditDate BETWEEN @DateFrom AND @DateTo), 0)
        * 100, 1)                                                               AS ApprovalRatePct,

        -- Avg resolution days (case open to resolve)
        (SELECT ROUND(AVG(CAST(DATEDIFF(DAY, c.OpenedDate, c.ResolvedDate) AS DECIMAL)), 1)
         FROM dbo.Cases c
         WHERE c.SellerAccountId = @SellerAccountId
           AND c.Status = 'RESOLVED'
           AND c.ResolvedDate IS NOT NULL
           AND c.CaseTypeCode IN ('LOST_INVENTORY','DAMAGED_INVENTORY',
               'FEE_OVERCHARGE','RETURNLESS_REFUND','INBOUND_DISCREPANCY','AWD_LOSS')
           AND CAST(c.OpenedDate AS DATE) BETWEEN @DateFrom AND @DateTo)        AS AvgResolutionDays,

        -- Upcoming deadlines: count expiring within 60 days
        (SELECT COUNT(*) FROM dbo.ReimbursementAudit ra
         WHERE ra.SellerAccountId = @SellerAccountId
           AND ra.Status = 'OPEN'
           AND ra.DeadlineDate IS NOT NULL
           AND DATEDIFF(DAY, SYSUTCDATETIME(), ra.DeadlineDate) BETWEEN 0 AND 60) AS DeadlineWarningCount,

        -- Missing COGS count
        (SELECT COUNT(*) FROM dbo.Products p
         WHERE p.SellerAccountId = @SellerAccountId
           AND p.IsActive = 1
           AND (p.COGS IS NULL OR p.COGS = 0))                                  AS MissingCOGSCount,

        -- Monthly trend: last 6 months reimbursed
        @DateFrom AS PeriodFrom,
        @DateTo   AS PeriodTo;

    -- Monthly breakdown
    SELECT
        YEAR(r.ReimbDate)           AS ReimbYear,
        MONTH(r.ReimbDate)          AS ReimbMonth,
        DATENAME(MONTH, r.ReimbDate) + ' ' + CAST(YEAR(r.ReimbDate) AS VARCHAR) AS PeriodLabel,
        COUNT(*)                    AS ReimbCount,
        ROUND(SUM(r.TotalAmount), 2) AS TotalReimbursedUSD
    FROM dbo.Reimbursements r
    WHERE r.SellerAccountId = @SellerAccountId
      AND r.ReimbDate BETWEEN @DateFrom AND @DateTo
    GROUP BY YEAR(r.ReimbDate), MONTH(r.ReimbDate), DATENAME(MONTH, r.ReimbDate)
    ORDER BY ReimbYear, ReimbMonth;
END;
GO
