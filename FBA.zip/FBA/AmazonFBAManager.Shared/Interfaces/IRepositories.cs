// ============================================================
// AmazonFBAManager.Shared/Interfaces/IRepositories.cs
// All repository interfaces — implemented by Data project
// Application layer depends only on these abstractions
// ============================================================
using AmazonFBAManager.Shared.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AmazonFBAManager.Shared.Interfaces
{
    public interface IInventoryRepository
    {
        Task<IEnumerable<ReorderSuggestionDto>> GetReorderSuggestionsAsync(int sellerAccountId, int userId, int leadTimeDays = 30, decimal serviceLevel = 0.95m);
        Task<IEnumerable<OverstockReportDto>> GetOverstockReportAsync(int sellerAccountId, int userId, int daysOfSupplyThreshold = 90);
        Task<IEnumerable<AgedInventoryDto>> GetAgedInventoryFeeRiskAsync(int sellerAccountId, int userId, DateTime? snapshotDate = null);
        Task<IEnumerable<StrandedInventoryDto>> GetStrandedInventoryAsync(int sellerAccountId, int userId);
        Task<IEnumerable<AWDDiscrepancyDto>> GetAWDDiscrepanciesAsync(int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null);
        Task<FBAFBMComparisonDto?> CompareFBAFBMAsync(int productId, int sellerAccountId, int userId, decimal fbmShippingCost = 5.00m, decimal fbmPackagingCost = 1.50m);
    }

    public interface IReimbursementRepository
    {
        Task<IEnumerable<ReimbursementAuditDto>> AuditLostDamagedInventoryAsync(int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null);
        Task<IEnumerable<FeeOverchargeDto>> DetectFeeOverchargesAsync(int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null);
        Task<IEnumerable<ReimbursementAuditDto>> AuditReturnlessRefundsAsync(int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null);
        Task<IEnumerable<MonthlyChecklistItemDto>> GetMonthlyChecklistAsync(int sellerAccountId, int userId, int month, int year);
        Task<ReimbursementKPIDto?> GetKPIDashboardAsync(int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null);
        Task<IEnumerable<ReimbursementMonthlyTrendDto>> GetMonthlyTrendAsync(int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null);
        Task<IEnumerable<COGSProductDto>> GetMissingCOGSAsync(int sellerAccountId, int userId);
        Task<int> BulkUpdateCOGSAsync(int sellerAccountId, int userId, IEnumerable<COGSUpdateDto> updates);
    }

    public interface ICaseRepository
    {
        Task<int> CreateCaseAsync(CreateCaseRequestDto request, int userId);
        Task EscalateCaseAsync(int caseId, int userId, string reason);
        Task ResolveCaseAsync(ResolveCaseRequestDto request, int userId);
        Task<CaseDto?> GetCaseDetailAsync(int caseId, int userId);
        Task<IEnumerable<CaseDto>> GetKanbanBoardAsync(int sellerAccountId, int userId, int? assignedUserId = null);
        Task<IEnumerable<CaseDto>> GetAgingReportAsync(int sellerAccountId, int userId, int sladays = 7);
        Task<HijackReportDto?> BuildHijackReportAsync(int productId, int sellerAccountId, int userId, string? hijackerName = null);
        Task AddCaseNoteAsync(int caseId, int userId, string noteText, bool isInternal = true);
        Task<IEnumerable<CaseNoteDto>> GetCaseNotesAsync(int caseId, int userId);
        Task<IEnumerable<CaseAttachmentDto>> GetCaseAttachmentsAsync(int caseId, int userId);
        Task<int> SaveCaseAttachmentAsync(int caseId, string fileName, string storagePath, long? fileSize, string? mimeType, int userId);
    }

    public interface IReportsRepository
    {
        Task<IEnumerable<ProfitLossDto>> GetProfitLossBySKUAsync(int sellerAccountId, int userId, DateTime dateFrom, DateTime dateTo, string groupBy = "SKU");
        Task<IEnumerable<MultiAccountSummaryDto>> GetMultiAccountSummaryAsync(int userId, DateTime dateFrom, DateTime dateTo);
        Task<IEnumerable<ReturnRateDto>> GetReturnRateAnalysisAsync(int sellerAccountId, int userId, DateTime dateFrom, DateTime dateTo);
        Task<IEnumerable<CashFlowForecastDto>> GetCashFlowForecastAsync(int sellerAccountId, int userId, int forecastDays = 90);
    }

    public interface IPPCRepository
    {
        Task<IEnumerable<PPCAuditItemDto>> AuditCampaignsAsync(int sellerAccountId, int userId, DateTime? dateFrom = null, DateTime? dateTo = null);
        Task<TACosDto?> CalculateTACosAsync(int sellerAccountId, int userId, DateTime dateFrom, DateTime dateTo);
    }

    public interface IListingRepository
    {
        Task<ListingHealthDto?> GetHealthScoreAsync(int productId, int sellerAccountId, int userId);
        Task<IEnumerable<ListingHealthDto>> GetAllHealthScoresAsync(int sellerAccountId, int userId);
    }

    public interface IAlertRepository
    {
        Task<IEnumerable<AlertDto>> GetUnreadAlertsAsync(int sellerAccountId, int userId, int pageSize = 50);
        Task<IEnumerable<AlertDto>> GetAllAlertsAsync(int sellerAccountId, int userId, int pageSize = 100);
        Task MarkAlertReadAsync(long alertId, int userId);
        Task MarkAllReadAsync(int sellerAccountId, int userId);
        Task<int> GetUnreadCountAsync(int sellerAccountId, int userId);
    }

    public interface IImportRepository
    {
        Task<int> CreateImportRecordAsync(int sellerAccountId, int userId, string reportTypeCode, string fileName, long? fileSize);
        Task<ImportResultDto?> GetImportResultAsync(int importId);
        Task<IEnumerable<ImportHistoryDto>> GetImportHistoryAsync(int sellerAccountId, int userId, int pageSize = 50, int page = 1);
    }

    public interface IResearchRepository
    {
        Task<OpportunityScoreDto?> CalculateOpportunityScoreAsync(int sellerAccountId, int userId, string keyword, int? searchVolume, int? competitorCount, decimal? avgRevenue, int? avgReviews, decimal? avgPrice);
    }

    public interface IAuthRepository
    {
        Task<LoginResponseDto> LoginAsync(string username, string password);
        Task<IEnumerable<SellerAccountDto>> GetUserAccountsAsync(int userId);
        Task<bool> HasAccountAccessAsync(int userId, int sellerAccountId);
        Task<string> GetPermissionLevelAsync(int userId, int sellerAccountId);
    }
}
