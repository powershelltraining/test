// ============================================================
// AmazonFBAManager.Shared/DTOs/AllDtos.cs
// All Data Transfer Objects used across the solution
// ============================================================
using System;
using System.Collections.Generic;

namespace AmazonFBAManager.Shared.DTOs
{
    // --------------------------------------------------------
    // AUTH / USER
    // --------------------------------------------------------
    public class UserDto
    {
        public int UserId { get; set; }
        public string Username { get; set; } = "";
        public string Email { get; set; } = "";
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; } = "";
        public bool IsActive { get; set; }
        public DateTime? LastLoginDate { get; set; }
    }

    public class SellerAccountDto
    {
        public int SellerAccountId { get; set; }
        public string AccountName { get; set; } = "";
        public string MarketplaceId { get; set; } = "";
        public string MarketplaceName { get; set; } = "";
        public string Region { get; set; } = "";
        public string DefaultCurrency { get; set; } = "USD";
        public bool IsActive { get; set; }
        public bool OnboardingComplete { get; set; }
        public string PermissionLevel { get; set; } = "";
    }

    public class LoginRequestDto
    {
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
    }

    public class LoginResponseDto
    {
        public bool Success { get; set; }
        public string? Token { get; set; }
        public string? ErrorMessage { get; set; }
        public UserDto? User { get; set; }
        public List<SellerAccountDto> Accounts { get; set; } = new();
    }

    // --------------------------------------------------------
    // INVENTORY
    // --------------------------------------------------------
    public class ReorderSuggestionDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public int CurrentFBAQty { get; set; }
        public int QtyInbound { get; set; }
        public int TotalAvailable { get; set; }
        public decimal DailySalesVelocity { get; set; }
        public int TotalUnitsSold90Days { get; set; }
        public int LeadTimeDays { get; set; }
        public int CalculatedReorderPoint { get; set; }
        public int ActiveReorderPoint { get; set; }
        public int SuggestedOrderQty { get; set; }
        public int DaysOfSupplyRemaining { get; set; }
        public int UrgencyScore { get; set; }
        public decimal? COGS { get; set; }
        public decimal? EstOrderCOGS { get; set; }
    }

    public class OverstockReportDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public int QtyFBA { get; set; }
        public decimal DailySalesVelocity { get; set; }
        public int DaysOfSupply { get; set; }
        public decimal EstStorageCost90Days { get; set; }
        public int ExcessUnits { get; set; }
        public decimal PotentialStorageSavings { get; set; }
        public string? MarkdownSuggestion { get; set; }
    }

    public class AgedInventoryDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public int QtyFBA { get; set; }
        public decimal DailySalesVelocity { get; set; }
        public int EstOldestUnitAgeDays { get; set; }
        public string AgeTier { get; set; } = "";
        public decimal EstMonthlySurchargeUSD { get; set; }
        public decimal EstRemovalCostUSD { get; set; }
        public string RecommendedAction { get; set; } = "";
    }

    public class StrandedInventoryDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public int QtyStranded { get; set; }
        public string ListingStatus { get; set; } = "";
        public string? StrandReason { get; set; }
        public decimal DailySalesVelocity { get; set; }
        public decimal DailyStorageCostEst { get; set; }
        public string RecommendedAction { get; set; } = "";
    }

    public class AWDDiscrepancyDto
    {
        public string AmazonShipmentId { get; set; } = "";
        public string? ShipmentName { get; set; }
        public DateTime? ShippedDate { get; set; }
        public string ASIN { get; set; } = "";
        public string SKU { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public int QtyShipped { get; set; }
        public int QtyReceived { get; set; }
        public int QtyVariance { get; set; }
        public decimal? COGS { get; set; }
        public decimal EstClaimableAmount { get; set; }
        public int? CaseId { get; set; }
        public string? CaseStatus { get; set; }
        public string DispositionStatus { get; set; } = "";
        public DateTime? FilingDeadline { get; set; }
    }

    public class FBAFBMComparisonDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public decimal? BuyBoxPrice { get; set; }
        public decimal? COGS { get; set; }
        public decimal FBA_Revenue { get; set; }
        public decimal FBA_ReferralFee { get; set; }
        public decimal FBA_FulfillmentFee { get; set; }
        public decimal FBA_COGS { get; set; }
        public decimal FBA_NetProfit { get; set; }
        public decimal FBA_MarginPct { get; set; }
        public decimal FBM_Revenue { get; set; }
        public decimal FBM_ReferralFee { get; set; }
        public decimal FBM_ShippingCost { get; set; }
        public decimal FBM_PackagingCost { get; set; }
        public decimal FBM_COGS { get; set; }
        public decimal FBM_NetProfit { get; set; }
        public decimal FBM_MarginPct { get; set; }
        public string RecommendedChannel { get; set; } = "";
        public string BreakevenNote { get; set; } = "";
    }

    // --------------------------------------------------------
    // REIMBURSEMENT
    // --------------------------------------------------------
    public class ReimbursementAuditDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public int TotalQtyLost { get; set; }
        public int QtyReimbursed { get; set; }
        public int QtyUnclaimed { get; set; }
        public decimal? COGS_PerUnit { get; set; }
        public decimal ClaimableAmountUSD { get; set; }
        public decimal AlreadyReceivedUSD { get; set; }
        public string? COGSWarning { get; set; }
        public DateTime? FilingDeadline { get; set; }
        public string DeadlineStatus { get; set; } = "";
        public int? AuditId { get; set; }
        public string? AuditStatus { get; set; }
        public int? LinkedCaseId { get; set; }
    }

    public class FeeOverchargeDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public decimal? WeightLbs { get; set; }
        public decimal? ExpectedFeePerUnit { get; set; }
        public decimal ActualAvgFeePerUnit { get; set; }
        public decimal FeeVariancePerUnit { get; set; }
        public int FeeTransactionCount { get; set; }
        public decimal TotalOverchargeUSD { get; set; }
        public string OverchargeType { get; set; } = "";
        public string? RecommendedAction { get; set; }
    }

    public class MonthlyChecklistItemDto
    {
        public int SortOrder { get; set; }
        public string ChecklistItem { get; set; } = "";
        public string ItemName { get; set; } = "";
        public string StatusDetail { get; set; } = "";
        public decimal PotentialAmountUSD { get; set; }
        public string ActionRequired { get; set; } = "";
        public DateTime? Deadline { get; set; }
        public string ActionInstructions { get; set; } = "";
    }

    public class ReimbursementKPIDto
    {
        public int TotalAuditItems { get; set; }
        public int TotalCasesFiled { get; set; }
        public decimal TotalReimbursedUSD { get; set; }
        public decimal TotalPendingUSD { get; set; }
        public decimal ApprovalRatePct { get; set; }
        public decimal? AvgResolutionDays { get; set; }
        public int DeadlineWarningCount { get; set; }
        public int MissingCOGSCount { get; set; }
        public DateTime PeriodFrom { get; set; }
        public DateTime PeriodTo { get; set; }
    }

    public class ReimbursementMonthlyTrendDto
    {
        public int ReimbYear { get; set; }
        public int ReimbMonth { get; set; }
        public string PeriodLabel { get; set; } = "";
        public int ReimbCount { get; set; }
        public decimal TotalReimbursedUSD { get; set; }
    }

    public class COGSProductDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public decimal? COGS { get; set; }
        public string COGSStatus { get; set; } = "";
        public DateTime? COGSEnteredDate { get; set; }
        public decimal? CurrentBuyBoxPrice { get; set; }
        public int UnclaimedQtyAtRisk { get; set; }
    }

    public class COGSUpdateDto
    {
        public string SKU { get; set; } = "";
        public decimal COGS { get; set; }
    }

    // --------------------------------------------------------
    // CASES
    // --------------------------------------------------------
    public class CaseDto
    {
        public int CaseId { get; set; }
        public int SellerAccountId { get; set; }
        public string AccountName { get; set; } = "";
        public string? AmazonCaseId { get; set; }
        public string CaseTypeCode { get; set; } = "";
        public string CaseTypeName { get; set; } = "";
        public string Status { get; set; } = "";
        public string Priority { get; set; } = "";
        public string Subject { get; set; } = "";
        public string? Description { get; set; }
        public string? ASIN { get; set; }
        public string? SKU { get; set; }
        public string? ProductTitle { get; set; }
        public DateTime OpenedDate { get; set; }
        public DateTime? SLADueDate { get; set; }
        public int? DaysUntilSLA { get; set; }
        public string SLAStatus { get; set; } = "";
        public DateTime? ResolvedDate { get; set; }
        public decimal? ResolvedAmount { get; set; }
        public int EscalationLevel { get; set; }
        public bool POARequired { get; set; }
        public int? LinkedAuditId { get; set; }
        public decimal? LinkedClaimAmount { get; set; }
        public string? AssignedTo { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    public class CaseNoteDto
    {
        public int NoteId { get; set; }
        public DateTime NoteDate { get; set; }
        public string Username { get; set; } = "";
        public string NoteText { get; set; } = "";
        public bool IsInternal { get; set; }
    }

    public class CaseAttachmentDto
    {
        public int AttachmentId { get; set; }
        public string FileName { get; set; } = "";
        public long? FileSizeBytes { get; set; }
        public string? MimeType { get; set; }
        public DateTime UploadDate { get; set; }
        public string? UploadedBy { get; set; }
    }

    public class CreateCaseRequestDto
    {
        public int SellerAccountId { get; set; }
        public string CaseTypeCode { get; set; } = "";
        public string Subject { get; set; } = "";
        public string? Description { get; set; }
        public string? ASIN { get; set; }
        public string Priority { get; set; } = "MEDIUM";
        public int? LinkedAuditId { get; set; }
    }

    public class EscalateCaseRequestDto
    {
        public int CaseId { get; set; }
        public string EscalationReason { get; set; } = "";
    }

    public class ResolveCaseRequestDto
    {
        public int CaseId { get; set; }
        public decimal? ResolvedAmount { get; set; }
        public string? ResolutionNote { get; set; }
    }

    public class HijackReportDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public string? Brand { get; set; }
        public decimal? OurListingPrice { get; set; }
        public int ReviewCount { get; set; }
        public decimal? StarRating { get; set; }
        public int? BSR { get; set; }
        public decimal? HijackerPrice { get; set; }
        public int? TotalOffersOnListing { get; set; }
        public bool? BuyBoxOwnedByUs { get; set; }
        public string? BuyBoxOwner { get; set; }
        public decimal? AvgDailySales { get; set; }
        public decimal? EstRevenueLostIf30Days { get; set; }
        public string? HijackerSellerName { get; set; }
        public string Evidence1 { get; set; } = "";
        public string Evidence2 { get; set; } = "";
        public string Evidence3 { get; set; } = "";
        public string Evidence4 { get; set; } = "";
        public string DraftReportText { get; set; } = "";
    }

    // --------------------------------------------------------
    // REPORTS / P&L
    // --------------------------------------------------------
    public class ProfitLossDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public string? Brand { get; set; }
        public string? Category { get; set; }
        public decimal Revenue { get; set; }
        public int UnitsSold { get; set; }
        public decimal AvgSellingPrice { get; set; }
        public decimal COGS_Total { get; set; }
        public decimal FBAFulfillmentFees { get; set; }
        public decimal ReferralFees { get; set; }
        public decimal StorageFees { get; set; }
        public decimal PPC_Spend_AccountLevel { get; set; }
        public decimal RefundsIssued { get; set; }
        public decimal ReimbReceived { get; set; }
        public decimal NetProfit { get; set; }
        public decimal NetMarginPct { get; set; }
        public decimal COGSPct { get; set; }
        public decimal? COGSPerUnit { get; set; }
        public string? DataWarning { get; set; }
    }

    public class MultiAccountSummaryDto
    {
        public int SellerAccountId { get; set; }
        public string AccountName { get; set; } = "";
        public string MarketplaceName { get; set; } = "";
        public decimal TotalRevenue { get; set; }
        public int TotalUnitsSold { get; set; }
        public int OpenCaseCount { get; set; }
        public decimal OpenReimbursementOpportunity { get; set; }
        public int UnreadCriticalAlerts { get; set; }
        public decimal? LatestIPIScore { get; set; }
        public int MissingCOGSCount { get; set; }
    }

    public class ReturnRateDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string ProductTitle { get; set; } = "";
        public int UnitsSold { get; set; }
        public int QtyReturned { get; set; }
        public decimal ReturnRatePct { get; set; }
        public decimal TotalRefundedUSD { get; set; }
        public int ReturnlessRefundCount { get; set; }
        public decimal ReturnlessRefundPct { get; set; }
        public string? TopReturnReason { get; set; }
        public string? TopReturnReasonDescription { get; set; }
        public string ReturnRateFlag { get; set; } = "";
    }

    public class CashFlowForecastDto
    {
        public DateTime ForecastDate { get; set; }
        public int DayNumber { get; set; }
        public decimal ProjectedRevenue { get; set; }
        public decimal ProjectedCOGS { get; set; }
        public decimal ProjectedFees { get; set; }
        public decimal ProjectedPPCSpend { get; set; }
        public decimal ProjectedRefunds { get; set; }
        public decimal ProjectedReimb { get; set; }
        public decimal ProjectedNetCash { get; set; }
        public decimal CumulativeNetCash { get; set; }
    }

    // --------------------------------------------------------
    // PPC
    // --------------------------------------------------------
    public class PPCAuditItemDto
    {
        public string AuditCategory { get; set; } = "";
        public string CampaignName { get; set; } = "";
        public string? AdGroupName { get; set; }
        public string KeywordText { get; set; } = "";
        public string MatchType { get; set; } = "";
        public decimal TotalSpend { get; set; }
        public long TotalClicks { get; set; }
        public int TotalOrders { get; set; }
        public decimal TotalSales { get; set; }
        public decimal? CostPerClick { get; set; }
        public string Recommendation { get; set; } = "";
    }

    public class TACosDto
    {
        public decimal TotalRevenue { get; set; }
        public decimal PPCAttributedSales { get; set; }
        public decimal OrganicRevenue { get; set; }
        public decimal TotalPPCSpend { get; set; }
        public decimal ACoS_Pct { get; set; }
        public decimal TACoS_Pct { get; set; }
        public decimal PPCSalesSharePct { get; set; }
        public decimal OrganicSalesSharePct { get; set; }
        public string Benchmark { get; set; } = "";
    }

    // --------------------------------------------------------
    // LISTINGS
    // --------------------------------------------------------
    public class ListingHealthDto
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = "";
        public string ASIN { get; set; } = "";
        public string? ProductTitle { get; set; }
        public string ListingStatus { get; set; } = "";
        public int TitleScore { get; set; }
        public int BulletsScore { get; set; }
        public int ImagesScore { get; set; }
        public int APlusScore { get; set; }
        public int KeywordsScore { get; set; }
        public int OverallScore { get; set; }
        public string? TitleRec { get; set; }
        public string? BulletsRec { get; set; }
        public string? ImagesRec { get; set; }
        public string? APlusRec { get; set; }
        public string? KeywordsRec { get; set; }
        public int ReviewCount { get; set; }
        public decimal? StarRating { get; set; }
        public int? BSR { get; set; }
        public decimal? BuyBoxPrice { get; set; }
    }

    // --------------------------------------------------------
    // ALERTS
    // --------------------------------------------------------
    public class AlertDto
    {
        public long AlertId { get; set; }
        public int SellerAccountId { get; set; }
        public string AccountName { get; set; } = "";
        public string AlertTypeCode { get; set; } = "";
        public string AlertTypeName { get; set; } = "";
        public int? ProductId { get; set; }
        public string? SKU { get; set; }
        public int? CaseId { get; set; }
        public DateTime AlertDate { get; set; }
        public string Message { get; set; } = "";
        public string Severity { get; set; } = "";
        public bool IsRead { get; set; }
    }

    // --------------------------------------------------------
    // IMPORT
    // --------------------------------------------------------
    public class ImportHistoryDto
    {
        public int ImportId { get; set; }
        public string ReportTypeCode { get; set; } = "";
        public string ReportTypeName { get; set; } = "";
        public string FileName { get; set; } = "";
        public long? FileSizeBytes { get; set; }
        public int RowsTotal { get; set; }
        public int RowsImported { get; set; }
        public int RowsSkipped { get; set; }
        public int RowsErrored { get; set; }
        public string Status { get; set; } = "";
        public DateTime ImportDate { get; set; }
        public int? ProcessingSeconds { get; set; }
        public string ImportedBy { get; set; } = "";
        public string? ErrorLog { get; set; }
    }

    public class ImportResultDto
    {
        public int ImportId { get; set; }
        public int RowsImported { get; set; }
        public int RowsSkipped { get; set; }
        public int RowsErrored { get; set; }
        public string Status { get; set; } = "";
        public string? ErrorLog { get; set; }
    }

    // --------------------------------------------------------
    // EXPORT
    // --------------------------------------------------------
    public class ExportRequestDto
    {
        public string ReportType { get; set; } = "";
        public string Format { get; set; } = "EXCEL";
        public DateTime DateFrom { get; set; } = DateTime.UtcNow.AddDays(-30).Date;
        public DateTime DateTo { get; set; } = DateTime.UtcNow.Date;
        public string? GroupBy { get; set; }
        public int SellerAccountId { get; set; }
    }

    // --------------------------------------------------------
    // SP-API
    // --------------------------------------------------------
    public class SPAPIConnectionTestResult
    {
        public bool Success { get; set; }
        public string Message { get; set; } = "";
        public string? MarketplaceName { get; set; }
        public string? SellerId { get; set; }
        public DateTime TestedAt { get; set; } = DateTime.UtcNow;
    }

    // --------------------------------------------------------
    // NICHE RESEARCH
    // --------------------------------------------------------
    public class OpportunityScoreDto
    {
        public int NicheId { get; set; }
        public string Keyword { get; set; } = "";
        public int? EstMonthlySearchVolume { get; set; }
        public int? CompetitorCount { get; set; }
        public decimal? AvgMonthlyRevenue { get; set; }
        public int? AvgReviewCount { get; set; }
        public decimal? AvgPrice { get; set; }
        public decimal SearchVolumeScore { get; set; }
        public decimal CompetitionScore { get; set; }
        public decimal RevenueScore { get; set; }
        public decimal BarrierToEntryScore { get; set; }
        public decimal OpportunityScore { get; set; }
        public string OpportunityRating { get; set; } = "";
    }

    // --------------------------------------------------------
    // HELP / GUIDE
    // --------------------------------------------------------
    public class HelpTopicDto
    {
        public int TopicId { get; set; }
        public int SectionNumber { get; set; }
        public string SectionName { get; set; } = "";
        public string TopicCode { get; set; } = "";
        public string TopicName { get; set; } = "";
        public string WhatItDoes { get; set; } = "";
        public string? WhenToUseIt { get; set; }
        public string? StepByStep { get; set; }
        public string? ProTip { get; set; }
        public string? CommonMistake { get; set; }
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
    }

    public class HelpSectionDto
    {
        public int SectionNumber { get; set; }
        public string SectionName { get; set; } = "";
        public List<HelpTopicDto> Topics { get; set; } = new();
    }

    public class HelpIndexViewModel
    {
        public List<HelpSectionDto> Sections { get; set; } = new();
        public string? SearchQuery { get; set; }
    }

    // --------------------------------------------------------
    // ERROR LOGGING
    // --------------------------------------------------------
    public class ErrorLogDto
    {
        public long ErrorLogId { get; set; }
        public DateTime ErrorDate { get; set; }
        public string ErrorLevel { get; set; } = "";  // DEBUG, INFO, WARNING, ERROR, CRITICAL
        public string? ErrorSource { get; set; }
        public string ErrorMessage { get; set; } = "";
        public string? StackTrace { get; set; }
        public int? UserId { get; set; }
        public int? SellerAccountId { get; set; }
        public string? RequestPath { get; set; }
        public string? RequestMethod { get; set; }
        public string? IpAddress { get; set; }
        public string? BrowserInfo { get; set; }
        public bool IsResolved { get; set; }
        public DateTime? ResolvedDate { get; set; }
        public string? ResolvedBy { get; set; }
        public string? Notes { get; set; }
    }

    public class AppSettingDto
    {
        public int SettingId { get; set; }
        public string SettingKey { get; set; } = "";
        public string? SettingValue { get; set; }
        public string? Description { get; set; }
        public string Category { get; set; } = "GENERAL";
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string? CreatedBy { get; set; }
        public string? ModifiedBy { get; set; }
    }

    public class LogErrorRequestDto
    {
        public string ErrorLevel { get; set; } = "ERROR";
        public string? ErrorSource { get; set; }
        public string ErrorMessage { get; set; } = "";
        public string? StackTrace { get; set; }
        public int? UserId { get; set; }
        public int? SellerAccountId { get; set; }
        public string? RequestPath { get; set; }
        public string? RequestMethod { get; set; }
        public string? IpAddress { get; set; }
        public string? BrowserInfo { get; set; }
    }

    public class DebugConfigDto
    {
        public string DebugLevel { get; set; } = "ERROR";
        public bool EnableFileLogging { get; set; }
        public bool EnableDatabaseLogging { get; set; }
        public int MaxErrorLogDays { get; set; } = 30;
        public bool EmailOnCriticalErrors { get; set; }
        public bool EmailOnHighErrors { get; set; }
    }
}
