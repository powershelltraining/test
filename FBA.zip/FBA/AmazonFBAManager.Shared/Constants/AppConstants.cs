// ============================================================
// AmazonFBAManager.Shared/Constants/AppConstants.cs
// ============================================================
namespace AmazonFBAManager.Shared.Constants
{
    public static class StoredProcedures
    {
        // Auth
        public const string Auth_ValidateAccess = "dbo.usp_Auth_ValidateUserAccountAccess";
        public const string Auth_GetUserAccounts = "dbo.usp_Auth_GetUserAccounts";

        // Import
        public const string Import_InventorySnapshot = "dbo.usp_ImportCSV_InventorySnapshot";
        public const string Import_SalesOrders = "dbo.usp_ImportCSV_SalesOrders";
        public const string Import_Reimbursements = "dbo.usp_ImportCSV_Reimbursements";
        public const string Import_Adjustments = "dbo.usp_ImportCSV_InventoryAdjustments";
        public const string Import_Returns = "dbo.usp_ImportCSV_Returns";
        public const string Import_PPCKeywords = "dbo.usp_ImportCSV_PPCKeywords";
        public const string Import_InboundShipments = "dbo.usp_ImportCSV_InboundShipments";
        public const string Import_GetHistory = "dbo.usp_Import_GetHistory";

        // Inventory
        public const string Inventory_ReorderSuggestions = "dbo.usp_Inventory_GetReorderSuggestions";
        public const string Inventory_OverstockReport = "dbo.usp_Inventory_GetOverstockReport";
        public const string Inventory_AgedInventory = "dbo.usp_Inventory_GetAgedInventoryFeeRisk";
        public const string Inventory_StrandedInventory = "dbo.usp_Inventory_GetStrandedInventory";
        public const string Inventory_AWDDiscrepancies = "dbo.usp_Inventory_GetAWDDiscrepancies";
        public const string Inventory_CompareFBAFBM = "dbo.usp_Inventory_CompareFBAFBM";
        public const string Inventory_IPIActions = "dbo.usp_Inventory_GetIPIImprovementActions";

        // Reimbursement
        public const string Reimb_AuditLostDamaged = "dbo.usp_Reimbursement_AuditLostDamagedInventory";
        public const string Reimb_FeeOvercharges = "dbo.usp_Reimbursement_DetectFeeOvercharges";
        public const string Reimb_ReturnlessRefunds = "dbo.usp_Reimbursement_AuditReturnlessRefunds";
        public const string Reimb_InboundShipments = "dbo.usp_Reimbursement_AuditInboundShipments";
        public const string Reimb_MonthlyChecklist = "dbo.usp_Reimbursement_MonthlyChecklist";
        public const string Reimb_COGSImpact = "dbo.usp_Reimbursement_CalculateCOGSImpact";
        public const string Reimb_KPIDashboard = "dbo.usp_Reimbursement_GetKPIDashboard";
        public const string COGS_GetMissing = "dbo.usp_COGS_GetMissingList";
        public const string COGS_BulkUpdate = "dbo.usp_COGS_BulkUpdate";

        // Cases
        public const string Case_Create = "dbo.usp_Case_Create";
        public const string Case_Escalate = "dbo.usp_Case_Escalate";
        public const string Case_Resolve = "dbo.usp_Case_Resolve";
        public const string Case_GetDetail = "dbo.usp_Case_GetDetail";
        public const string Case_KanbanBoard = "dbo.usp_Case_GetKanbanBoard";
        public const string Case_AgingReport = "dbo.usp_Case_GetAgingReport";
        public const string Case_HijackReport = "dbo.usp_Case_BuildHijackReport";
        public const string Case_SuspensionPOA = "dbo.usp_Case_GetSuspensionPOAData";

        // Reports
        public const string Reports_PLBySKU = "dbo.usp_Reports_ProfitLossBySKU";
        public const string Reports_SalesVelocity = "dbo.usp_Reports_SalesVelocity";
        public const string Reports_FeeBreakdown = "dbo.usp_Reports_FeeBreakdownByASIN";
        public const string Reports_MultiAccount = "dbo.usp_Reports_MultiAccountSummary";
        public const string Reports_ReturnRate = "dbo.usp_Reports_ReturnRateAnalysis";
        public const string Reports_CashFlow = "dbo.usp_Reports_CashFlowForecast";

        // PPC
        public const string PPC_AuditCampaigns = "dbo.usp_PPC_AuditCampaigns";
        public const string PPC_TACoS = "dbo.usp_PPC_CalculateTACoS";

        // Listings
        public const string Listing_HealthScore = "dbo.usp_Listing_GetHealthScore";

        // Research
        public const string Research_OpportunityScore = "dbo.usp_Research_CalculateOpportunityScore";

        // Jobs
        public const string Job_NightlyAudit = "dbo.usp_Job_NightlyReimbursementAudit";
        public const string Job_InventoryAlerts = "dbo.usp_Job_InventoryAlertCheck";
        public const string Job_PPCAudit = "dbo.usp_Job_PPCAuditWeekly";
        public const string Job_SLAMonitor = "dbo.usp_Case_MonitorSLABreaches";
    }

    public static class ReportTypes
    {
        public const string InventorySnapshot = "INVENTORY_SNAPSHOT";
        public const string SalesOrders = "ORDER_REPORT";
        public const string Reimbursements = "REIMBURSEMENTS";
        public const string InventoryAdjustments = "INVENTORY_ADJUSTMENTS";
        public const string CustomerReturns = "CUSTOMER_RETURNS";
        public const string PPCSearchTerm = "PPC_SEARCH_TERM";
        public const string InboundShipments = "INBOUND_SHIPMENTS";
        public const string AgedInventory = "AGED_INVENTORY";
        public const string StrandedInventory = "STRANDED_INVENTORY";
        public const string Settlement = "SETTLEMENT";
        public const string RemovalOrders = "REMOVAL_ORDERS";
        public const string AWDInventory = "AWD_INVENTORY";
        public const string FBAFeePreview = "FBA_FEE_PREVIEW";
    }

    public static class Roles
    {
        public const string Admin = "Admin";
        public const string AccountManager = "AccountManager";
        public const string Analyst = "Analyst";
        public const string VAReadOnly = "VAReadOnly";
    }

    public static class CasePriorities
    {
        public const string Low = "LOW";
        public const string Medium = "MEDIUM";
        public const string High = "HIGH";
        public const string Critical = "CRITICAL";
    }

    public static class ImportStatuses
    {
        public const string Pending = "PENDING";
        public const string Processing = "PROCESSING";
        public const string Complete = "COMPLETE";
        public const string Failed = "FAILED";
        public const string Partial = "PARTIAL";
    }

    public static class AlertSeverities
    {
        public const string Low = "LOW";
        public const string Medium = "MEDIUM";
        public const string High = "HIGH";
        public const string Critical = "CRITICAL";
    }

    public static class SignalRHubs
    {
        public const string ImportProgress = "/hubs/import";
        public const string Alerts = "/hubs/alerts";
    }
}
