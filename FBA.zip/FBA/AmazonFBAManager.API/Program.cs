// ============================================================
// AmazonFBAManager.API/Program.cs
// ============================================================
using AmazonFBAManager.Data.Connections;
using AmazonFBAManager.Data.Repositories;
using AmazonFBAManager.Data.Services;
using AmazonFBAManager.Shared.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
var connStr = builder.Configuration.GetConnectionString("DefaultConnection")!;
var jwtKey = builder.Configuration["Jwt:Key"] ?? "CHANGE-THIS-SECRET-KEY-IN-PRODUCTION-MIN-32-CHARS";

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Amazon FBA Manager API", Version = "v1" });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization. Enter 'Bearer {token}'",
        Name = "Authorization", In = ParameterLocation.Header, Type = SecuritySchemeType.ApiKey
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement {
        { new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }, new string[] { } }
    });
});

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
            ValidateIssuer = false,
            ValidateAudience = false,
            ClockSkew = TimeSpan.Zero
        };
    });

builder.Services.AddAuthorization();
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

// Data Layer
builder.Services.AddSingleton<ISqlConnectionFactory>(_ => new SqlConnectionFactory(connStr));
builder.Services.AddScoped<IAuthRepository, AuthRepository>();
builder.Services.AddScoped<IInventoryRepository, InventoryRepository>();
builder.Services.AddScoped<IReimbursementRepository, ReimbursementRepository>();
builder.Services.AddScoped<ICaseRepository, CaseRepository>();
builder.Services.AddScoped<IReportsRepository, ReportsRepository>();
builder.Services.AddScoped<IPPCRepository, PPCRepository>();
builder.Services.AddScoped<IListingRepository, ListingRepository>();
builder.Services.AddScoped<IAlertRepository, AlertRepository>();
builder.Services.AddScoped<IImportRepository, ImportRepository>();
builder.Services.AddScoped<IResearchRepository, ResearchRepository>();
builder.Services.AddScoped<ICsvParsingService, CsvParsingService>();
builder.Services.AddScoped<IImportOrchestrationService, ImportOrchestrationService>();

var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();
app.UseCors();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();


// ============================================================
// AmazonFBAManager.Web/Views/_ViewImports.cshtml
// ============================================================
/*
@using AmazonFBAManager.Web
@using AmazonFBAManager.Web.Controllers
@using AmazonFBAManager.Shared.DTOs
@using AmazonFBAManager.Shared.Constants
@addTagHelper *, Microsoft.AspNetCore.Mvc.TagHelpers
*/


// ============================================================
// AmazonFBAManager.Web/Views/_ViewStart.cshtml
// ============================================================
/*
@{
    Layout = "_Layout";
}
*/


// ============================================================
// AmazonFBAManager.Web/Views/Shared/Error.cshtml
// ============================================================
/*
@{
    Layout = "_Layout";
    ViewData["Title"] = "Error";
}
<div class="text-center py-5">
    <i class="fa fa-circle-xmark fa-4x text-danger mb-3"></i>
    <h3>Something went wrong</h3>
    <p class="text-muted">An unexpected error occurred. Please try again.</p>
    <a href="/Dashboard" class="btn btn-primary">Return to Dashboard</a>
</div>
*/


// ============================================================
// DEPLOYMENT CHECKLIST (IIS / On-Premise)
// ============================================================
/*
PRE-DEPLOYMENT:
  1. Run all 11 SQL scripts in order on SQL Server 2022
  2. Update appsettings.json connection string for production DB
  3. Generate a strong JWT key (32+ chars) and set in appsettings
  4. Set a strong Hangfire storage connection string
  5. Create wwwroot/uploads directory with write permissions for IIS AppPool user
  6. Ensure app pool uses .NET CLR v4 / No Managed Code (Kestrel handles it)

IIS SETUP:
  1. Install .NET 8 Windows Hosting Bundle on the server
  2. Create IIS Application Pool: No Managed Code
  3. Create IIS Site pointing to AmazonFBAManager.Web publish output
  4. Bind to your domain/IP with SSL certificate
  5. Enable Windows Authentication if using Windows Auth for desktop app

PUBLISH COMMANDS:
  dotnet publish AmazonFBAManager.Web -c Release -o ./publish/web
  dotnet publish AmazonFBAManager.API -c Release -o ./publish/api

WEB.CONFIG (auto-generated by dotnet publish):
  No manual web.config needed — SDK generates it.

POST-DEPLOYMENT:
  1. Login as admin (default: admin / CHANGE_ON_FIRST_LOGIN_PLACEHOLDER)
  2. Change admin password immediately
  3. Add first Seller Account via Settings > Seller Accounts
  4. Run usp_SellerAccount_Onboard for each account
  5. Upload initial CSV reports (FBA Inventory, last 18 months of Reimbursements)
  6. Enter COGS for all active ASINs via Settings > COGS Manager
  7. Verify Hangfire jobs are running via /admin/jobs dashboard
*/
