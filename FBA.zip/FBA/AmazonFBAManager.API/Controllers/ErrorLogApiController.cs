// ============================================================
// AmazonFBAManager.API/Controllers/ErrorLogApiController.cs
// API endpoints for error logging and debug configuration
// ============================================================
using AmazonFBAManager.Data.Services;
using AmazonFBAManager.Shared.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AmazonFBAManager.API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class ErrorLogApiController : ControllerBase
    {
        private readonly IErrorLogService _errorLog;

        public ErrorLogApiController(IErrorLogService errorLog)
        {
            _errorLog = errorLog;
        }

        /// <summary>
        /// Get recent error logs
        /// </summary>
        [HttpGet("recent")]
        public async Task<IActionResult> GetRecentErrors([FromQuery] int count = 50, [FromQuery] string? level = null)
        {
            var errors = await _errorLog.GetRecentErrors(count, level);
            return Ok(errors);
        }

        /// <summary>
        /// Get all unresolved errors
        /// </summary>
        [HttpGet("unresolved")]
        public async Task<IActionResult> GetUnresolvedErrors()
        {
            var errors = await _errorLog.GetUnresolvedErrors();
            return Ok(errors);
        }

        /// <summary>
        /// Mark an error as resolved
        /// </summary>
        [HttpPost("resolve")]
        public async Task<IActionResult> ResolveError([FromBody] ResolveErrorRequest request)
        {
            await _errorLog.ResolveErrorAsync(request.ErrorLogId, request.ResolvedBy, request.Notes);
            return Ok(new { success = true });
        }

        /// <summary>
        /// Get debug configuration
        /// </summary>
        [HttpGet("config")]
        public async Task<IActionResult> GetDebugConfig()
        {
            var config = await _errorLog.GetDebugConfigAsync();
            return Ok(config);
        }

        /// <summary>
        /// Update debug configuration (Admin only)
        /// </summary>
        [HttpPost("config")]
        public async Task<IActionResult> UpdateDebugConfig([FromBody] DebugConfigDto config)
        {
            if (!User.IsInRole("Admin"))
                return Forbid();

            await _errorLog.UpdateDebugConfigAsync(config);
            return Ok(new { success = true });
        }

        /// <summary>
        /// Purge old error logs
        /// </summary>
        [HttpPost("purge")]
        public async Task<IActionResult> PurgeOldLogs([FromQuery] int daysToKeep = 30)
        {
            if (!User.IsInRole("Admin"))
                return Forbid();

            await _errorLog.PurgeOldLogsAsync(daysToKeep);
            return Ok(new { success = true, message = $"Purged logs older than {daysToKeep} days" });
        }
    }

    public class ResolveErrorRequest
    {
        public long ErrorLogId { get; set; }
        public string ResolvedBy { get; set; } = "";
        public string? Notes { get; set; }
    }
}