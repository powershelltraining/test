// ============================================================
// AmazonFBAManager.API/Controllers/ApiControllers.cs
// RESTful API — used by desktop app and external integrations
// All endpoints call repositories (same Dapper layer as Web)
// ============================================================
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AmazonFBAManager.API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class InventoryApiController : ControllerBase
    {
        private readonly IInventoryRepository _inv;
        public InventoryApiController(IInventoryRepository inv) => _inv = inv;

        [HttpGet("reorder/{sellerAccountId}")]
        public async Task<IActionResult> ReorderSuggestions(int sellerAccountId, [FromQuery] int leadTimeDays = 30)
        {
            var userId = GetUserId();
            var data = await _inv.GetReorderSuggestionsAsync(sellerAccountId, userId, leadTimeDays);
            return Ok(data);
        }

        [HttpGet("overstock/{sellerAccountId}")]
        public async Task<IActionResult> Overstock(int sellerAccountId, [FromQuery] int threshold = 90)
        {
            var data = await _inv.GetOverstockReportAsync(sellerAccountId, GetUserId(), threshold);
            return Ok(data);
        }

        [HttpGet("aged/{sellerAccountId}")]
        public async Task<IActionResult> AgedInventory(int sellerAccountId)
        {
            var data = await _inv.GetAgedInventoryFeeRiskAsync(sellerAccountId, GetUserId());
            return Ok(data);
        }

        [HttpGet("stranded/{sellerAccountId}")]
        public async Task<IActionResult> StrandedInventory(int sellerAccountId)
        {
            var data = await _inv.GetStrandedInventoryAsync(sellerAccountId, GetUserId());
            return Ok(data);
        }

        [HttpGet("awd/{sellerAccountId}")]
        public async Task<IActionResult> AWDDiscrepancies(int sellerAccountId,
            [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo)
        {
            var data = await _inv.GetAWDDiscrepanciesAsync(sellerAccountId, GetUserId(), dateFrom, dateTo);
            return Ok(data);
        }

        [HttpGet("compare/{productId}/{sellerAccountId}")]
        public async Task<IActionResult> CompareFBAFBM(int productId, int sellerAccountId,
            [FromQuery] decimal fbmShipping = 5.00m, [FromQuery] decimal fbmPackaging = 1.50m)
        {
            var data = await _inv.CompareFBAFBMAsync(productId, sellerAccountId, GetUserId(), fbmShipping, fbmPackaging);
            return data == null ? NotFound() : Ok(data);
        }

        private int GetUserId() => int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value ?? "0");
    }

    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class ReimbursementApiController : ControllerBase
    {
        private readonly IReimbursementRepository _reimb;
        public ReimbursementApiController(IReimbursementRepository reimb) => _reimb = reimb;

        [HttpGet("checklist/{sellerAccountId}")]
        public async Task<IActionResult> Checklist(int sellerAccountId,
            [FromQuery] int? month, [FromQuery] int? year)
        {
            var m = month ?? DateTime.UtcNow.Month;
            var y = year ?? DateTime.UtcNow.Year;
            var data = await _reimb.GetMonthlyChecklistAsync(sellerAccountId, GetUserId(), m, y);
            return Ok(data);
        }

        [HttpGet("kpi/{sellerAccountId}")]
        public async Task<IActionResult> KPI(int sellerAccountId,
            [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo)
        {
            var data = await _reimb.GetKPIDashboardAsync(sellerAccountId, GetUserId(), dateFrom, dateTo);
            return Ok(data);
        }

        [HttpGet("lost-damaged/{sellerAccountId}")]
        public async Task<IActionResult> LostDamaged(int sellerAccountId,
            [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo)
        {
            var data = await _reimb.AuditLostDamagedInventoryAsync(sellerAccountId, GetUserId(), dateFrom, dateTo);
            return Ok(data);
        }

        [HttpGet("fee-overcharges/{sellerAccountId}")]
        public async Task<IActionResult> FeeOvercharges(int sellerAccountId,
            [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo)
        {
            var data = await _reimb.DetectFeeOverchargesAsync(sellerAccountId, GetUserId(), dateFrom, dateTo);
            return Ok(data);
        }

        [HttpGet("returnless/{sellerAccountId}")]
        public async Task<IActionResult> ReturnlessRefunds(int sellerAccountId,
            [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo)
        {
            var data = await _reimb.AuditReturnlessRefundsAsync(sellerAccountId, GetUserId(), dateFrom, dateTo);
            return Ok(data);
        }

        [HttpGet("cogs-missing/{sellerAccountId}")]
        public async Task<IActionResult> MissingCOGS(int sellerAccountId)
        {
            var data = await _reimb.GetMissingCOGSAsync(sellerAccountId, GetUserId());
            return Ok(data);
        }

        [HttpPost("cogs/{sellerAccountId}")]
        public async Task<IActionResult> UpdateCOGS(int sellerAccountId, [FromBody] List<COGSUpdateDto> updates)
        {
            var count = await _reimb.BulkUpdateCOGSAsync(sellerAccountId, GetUserId(), updates);
            return Ok(new { Updated = count });
        }

        private int GetUserId() => int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value ?? "0");
    }

    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class CasesApiController : ControllerBase
    {
        private readonly ICaseRepository _cases;
        public CasesApiController(ICaseRepository cases) => _cases = cases;

        [HttpGet("kanban/{sellerAccountId}")]
        public async Task<IActionResult> Kanban(int sellerAccountId)
        {
            var data = await _cases.GetKanbanBoardAsync(sellerAccountId, GetUserId());
            return Ok(data);
        }

        [HttpGet("{caseId}")]
        public async Task<IActionResult> Detail(int caseId)
        {
            var data = await _cases.GetCaseDetailAsync(caseId, GetUserId());
            return data == null ? NotFound() : Ok(data);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateCaseRequestDto request)
        {
            var caseId = await _cases.CreateCaseAsync(request, GetUserId());
            return CreatedAtAction(nameof(Detail), new { caseId }, new { CaseId = caseId });
        }

        [HttpPost("{caseId}/escalate")]
        public async Task<IActionResult> Escalate(int caseId, [FromBody] string reason)
        {
            await _cases.EscalateCaseAsync(caseId, GetUserId(), reason);
            return Ok();
        }

        [HttpPost("{caseId}/resolve")]
        public async Task<IActionResult> Resolve(int caseId, [FromBody] ResolveCaseRequestDto request)
        {
            request.CaseId = caseId;
            await _cases.ResolveCaseAsync(request, GetUserId());
            return Ok();
        }

        [HttpGet("{caseId}/notes")]
        public async Task<IActionResult> Notes(int caseId)
        {
            var data = await _cases.GetCaseNotesAsync(caseId, GetUserId());
            return Ok(data);
        }

        [HttpPost("{caseId}/notes")]
        public async Task<IActionResult> AddNote(int caseId, [FromBody] string noteText)
        {
            await _cases.AddCaseNoteAsync(caseId, GetUserId(), noteText);
            return Ok();
        }

        [HttpGet("aging/{sellerAccountId}")]
        public async Task<IActionResult> Aging(int sellerAccountId, [FromQuery] int slaDays = 7)
        {
            var data = await _cases.GetAgingReportAsync(sellerAccountId, GetUserId(), slaDays);
            return Ok(data);
        }

        private int GetUserId() => int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value ?? "0");
    }

    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class ReportsApiController : ControllerBase
    {
        private readonly IReportsRepository _reports;
        public ReportsApiController(IReportsRepository reports) => _reports = reports;

        [HttpGet("pl/{sellerAccountId}")]
        public async Task<IActionResult> ProfitLoss(int sellerAccountId,
            [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo, [FromQuery] string groupBy = "SKU")
        {
            var df = dateFrom ?? DateTime.UtcNow.AddDays(-30).Date;
            var dt = dateTo ?? DateTime.UtcNow.Date;
            var data = await _reports.GetProfitLossBySKUAsync(sellerAccountId, GetUserId(), df, dt, groupBy);
            return Ok(data);
        }

        [HttpGet("multi-account")]
        public async Task<IActionResult> MultiAccount([FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo)
        {
            var df = dateFrom ?? DateTime.UtcNow.AddDays(-30).Date;
            var dt = dateTo ?? DateTime.UtcNow.Date;
            var data = await _reports.GetMultiAccountSummaryAsync(GetUserId(), df, dt);
            return Ok(data);
        }

        [HttpGet("return-rate/{sellerAccountId}")]
        public async Task<IActionResult> ReturnRate(int sellerAccountId,
            [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo)
        {
            var df = dateFrom ?? DateTime.UtcNow.AddDays(-90).Date;
            var dt = dateTo ?? DateTime.UtcNow.Date;
            var data = await _reports.GetReturnRateAnalysisAsync(sellerAccountId, GetUserId(), df, dt);
            return Ok(data);
        }

        [HttpGet("cash-flow/{sellerAccountId}")]
        public async Task<IActionResult> CashFlow(int sellerAccountId, [FromQuery] int forecastDays = 90)
        {
            var data = await _reports.GetCashFlowForecastAsync(sellerAccountId, GetUserId(), forecastDays);
            return Ok(data);
        }

        private int GetUserId() => int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value ?? "0");
    }

    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class AlertsApiController : ControllerBase
    {
        private readonly IAlertRepository _alerts;
        public AlertsApiController(IAlertRepository alerts) => _alerts = alerts;

        [HttpGet("{sellerAccountId}")]
        public async Task<IActionResult> GetAlerts(int sellerAccountId, [FromQuery] bool unreadOnly = false)
        {
            var data = unreadOnly
                ? await _alerts.GetUnreadAlertsAsync(sellerAccountId, GetUserId())
                : await _alerts.GetAllAlertsAsync(sellerAccountId, GetUserId());
            return Ok(data);
        }

        [HttpGet("{sellerAccountId}/count")]
        public async Task<IActionResult> UnreadCount(int sellerAccountId)
        {
            var count = await _alerts.GetUnreadCountAsync(sellerAccountId, GetUserId());
            return Ok(new { count });
        }

        [HttpPost("{alertId}/read")]
        public async Task<IActionResult> MarkRead(long alertId)
        {
            await _alerts.MarkAlertReadAsync(alertId, GetUserId());
            return Ok();
        }

        private int GetUserId() => int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value ?? "0");
    }

    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class PPCApiController : ControllerBase
    {
        private readonly IPPCRepository _ppc;
        public PPCApiController(IPPCRepository ppc) => _ppc = ppc;

        [HttpGet("audit/{sellerAccountId}")]
        public async Task<IActionResult> Audit(int sellerAccountId,
            [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo)
        {
            var data = await _ppc.AuditCampaignsAsync(sellerAccountId, GetUserId(), dateFrom, dateTo);
            return Ok(data);
        }

        [HttpGet("tacos/{sellerAccountId}")]
        public async Task<IActionResult> TACoS(int sellerAccountId,
            [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo)
        {
            var df = dateFrom ?? DateTime.UtcNow.AddDays(-30).Date;
            var dt = dateTo ?? DateTime.UtcNow.Date;
            var data = await _ppc.CalculateTACosAsync(sellerAccountId, GetUserId(), df, dt);
            return Ok(data);
        }

        private int GetUserId() => int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value ?? "0");
    }
}
