// ============================================================
// AmazonFBAManager.Web/Controllers/SettingsAndMoreControllers.cs
// Settings, User Management, Email Templates, SOP, Help
// ============================================================
using AmazonFBAManager.Data.Connections;
using AmazonFBAManager.Data.Services;
using AmazonFBAManager.Shared.Constants;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Web.ViewModels;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AmazonFBAManager.Web.Controllers
{
    // ============================================================
    // SETTINGS CONTROLLER
    // ============================================================
    [Authorize]
    public class SettingsController : BaseController
    {
        private readonly ISqlConnectionFactory _cf;
        private readonly ISpApiService _spApi;

        public SettingsController(ISqlConnectionFactory cf, ISpApiService spApi)
        {
            _cf = cf; _spApi = spApi;
        }

        // ── Seller Accounts ──────────────────────────────────
        public async Task<IActionResult> Accounts()
        {
            if (!IsAdmin) return Forbid();
            using var conn = _cf.Create();
            var accounts = await conn.QueryAsync<SellerAccountDto>(
                "SELECT sa.SellerAccountId, sa.AccountName, sa.MarketplaceId, m.MarketplaceName, " +
                "sa.Region, sa.DefaultCurrency, sa.IsActive, sa.OnboardingComplete " +
                "FROM dbo.SellerAccounts sa INNER JOIN dbo.Marketplaces m ON m.MarketplaceId = sa.MarketplaceId " +
                "ORDER BY sa.AccountName");
            return View(accounts);
        }

        [HttpGet]
        public async Task<IActionResult> AccountCreate()
        {
            if (!IsAdmin) return Forbid();
            var model = new SellerAccountFormViewModel
            {
                Marketplaces = await GetMarketplacesAsync()
            };
            return View("AccountForm", model);
        }

        [HttpGet]
        public async Task<IActionResult> AccountEdit(int id)
        {
            if (!IsAdmin) return Forbid();
            using var conn = _cf.Create();
            var acct = await conn.QueryFirstOrDefaultAsync(
                "SELECT * FROM dbo.SellerAccounts WHERE SellerAccountId = @Id", new { Id = id });
            if (acct == null) return NotFound();

            var model = new SellerAccountFormViewModel
            {
                SellerAccountId = acct.SellerAccountId,
                AccountName = acct.AccountName,
                MarketplaceId = acct.MarketplaceId,
                MerchantToken = acct.MerchantToken,
                SPAPIClientId = acct.SPAPIClientId,
                Region = acct.Region,
                IsActive = acct.IsActive,
                Notes = acct.Notes,
                Marketplaces = await GetMarketplacesAsync()
            };
            return View("AccountForm", model);
        }

        [HttpPost]
        public async Task<IActionResult> AccountSave(SellerAccountFormViewModel model)
        {
            if (!IsAdmin) return Forbid();
            if (!ModelState.IsValid) { model.Marketplaces = await GetMarketplacesAsync(); return View("AccountForm", model); }

            using var conn = _cf.Create();

            if (model.SellerAccountId == 0)
            {
                // Encrypt secrets before storing
                var encSecret = model.SPAPIClientSecret != null ? EncryptValue(model.SPAPIClientSecret) : null;
                var encToken  = model.RefreshToken != null ? EncryptValue(model.RefreshToken) : null;

                var newId = await conn.QuerySingleAsync<int>(
                    "INSERT INTO dbo.SellerAccounts (AccountName, MarketplaceId, MerchantToken, SPAPIClientId, " +
                    "SPAPIClientSecret_Enc, RefreshToken_Enc, Region, IsActive, Notes) " +
                    "OUTPUT INSERTED.SellerAccountId " +
                    "VALUES (@AccountName, @MarketplaceId, @MerchantToken, @SPAPIClientId, @Secret, @Token, @Region, @IsActive, @Notes)",
                    new { model.AccountName, model.MarketplaceId, model.MerchantToken, model.SPAPIClientId,
                          Secret = encSecret, Token = encToken, model.Region, model.IsActive, model.Notes });

                // Seed default thresholds
                await conn.ExecuteAsync("dbo.usp_SellerAccount_Onboard",
                    new { SellerAccountId = newId, AdminUserId = CurrentUserId },
                    commandType: CommandType.StoredProcedure);

                SetSuccess($"Seller account '{model.AccountName}' created.");
            }
            else
            {
                await conn.ExecuteAsync(
                    "UPDATE dbo.SellerAccounts SET AccountName=@AccountName, MarketplaceId=@MarketplaceId, " +
                    "MerchantToken=@MerchantToken, SPAPIClientId=@SPAPIClientId, Region=@Region, " +
                    "IsActive=@IsActive, Notes=@Notes, ModifiedDate=SYSUTCDATETIME() " +
                    "WHERE SellerAccountId=@SellerAccountId",
                    new { model.AccountName, model.MarketplaceId, model.MerchantToken,
                          model.SPAPIClientId, model.Region, model.IsActive, model.Notes, model.SellerAccountId });

                // Only update encrypted secrets if new values provided
                if (!string.IsNullOrEmpty(model.SPAPIClientSecret))
                    await conn.ExecuteAsync(
                        "UPDATE dbo.SellerAccounts SET SPAPIClientSecret_Enc=@V WHERE SellerAccountId=@Id",
                        new { V = EncryptValue(model.SPAPIClientSecret), Id = model.SellerAccountId });
                if (!string.IsNullOrEmpty(model.RefreshToken))
                    await conn.ExecuteAsync(
                        "UPDATE dbo.SellerAccounts SET RefreshToken_Enc=@V WHERE SellerAccountId=@Id",
                        new { V = EncryptValue(model.RefreshToken), Id = model.SellerAccountId });

                SetSuccess($"Account '{model.AccountName}' updated.");
            }
            return RedirectToAction("Accounts");
        }

        [HttpPost]
        public async Task<IActionResult> TestSPAPIConnection(int sellerAccountId)
        {
            var result = await _spApi.TestConnectionAsync(sellerAccountId, CurrentUserId);
            return Json(result);
        }

        // ── Alert Thresholds ─────────────────────────────────
        public async Task<IActionResult> AlertThresholds()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            using var conn = _cf.Create();

            var thresholds = await conn.QueryAsync<AlertThresholdRowDto>(
                "SELECT at.ThresholdId, at.AlertTypeCode, aty.AlertTypeName, p.SKU, at.ProductId, " +
                "at.ThresholdValue, at.ThresholdUnit, aty.Description, at.IsActive " +
                "FROM dbo.AlertThresholds at " +
                "INNER JOIN dbo.AlertTypes aty ON aty.AlertTypeCode = at.AlertTypeCode " +
                "LEFT JOIN dbo.Products p ON p.ProductId = at.ProductId " +
                "WHERE at.SellerAccountId = @AccountId ORDER BY at.ProductId, aty.AlertTypeName",
                new { AccountId = CurrentSellerAccountId });

            using var conn2 = _cf.Create();
            var accountName = await conn2.QueryFirstOrDefaultAsync<string>(
                "SELECT AccountName FROM dbo.SellerAccounts WHERE SellerAccountId=@Id",
                new { Id = CurrentSellerAccountId });

            return View(new AlertThresholdViewModel
            {
                SellerAccountId = CurrentSellerAccountId,
                AccountName = accountName ?? "",
                Thresholds = thresholds.ToList()
            });
        }

        [HttpPost]
        public async Task<IActionResult> SaveAlertThresholds([FromBody] List<AlertThresholdRowDto> updates)
        {
            if (!CanWrite) return Json(new { success = false, message = "Insufficient permissions." });
            using var conn = _cf.Create();
            foreach (var t in updates)
            {
                await conn.ExecuteAsync(
                    "UPDATE dbo.AlertThresholds SET ThresholdValue=@ThresholdValue, IsActive=@IsActive " +
                    "WHERE ThresholdId=@ThresholdId AND SellerAccountId=@AccountId",
                    new { t.ThresholdValue, t.IsActive, t.ThresholdId, AccountId = CurrentSellerAccountId });
            }
            return Json(new { success = true, updated = updates.Count });
        }

        // ── SP-API Sync ───────────────────────────────────────
        public IActionResult SPAPISync()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var model = new SPAPISyncViewModel
            {
                SellerAccountId = CurrentSellerAccountId,
                AccountName = CurrentAccountName,
                AvailableJobs = new List<SPAPISyncJobDto>
                {
                    new() { JobCode = "INVENTORY", JobName = "Inventory Levels", Description = "Pull current FBA quantities from SP-API" },
                    new() { JobCode = "ORDERS", JobName = "Recent Orders", Description = "Pull orders from last 48 hours" },
                    new() { JobCode = "LISTINGS", JobName = "Listing Status", Description = "Pull listing status, BSR, Buy Box ownership" },
                    new() { JobCode = "REIMBURSEMENTS", JobName = "Reimbursements", Description = "Pull reimbursements from last 30 days" },
                    new() { JobCode = "FBA_FEES", JobName = "FBA Fee Estimates", Description = "Pull per-ASIN fee estimates" }
                }
            };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> RunSPAPISync(string jobCode)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var result = await _spApi.RunSyncJobAsync(CurrentSellerAccountId, CurrentUserId, jobCode);
            return Json(result);
        }

        // ── Helpers ───────────────────────────────────────────
        private async Task<List<MarketplaceOptionDto>> GetMarketplacesAsync()
        {
            using var conn = _cf.Create();
            var rows = await conn.QueryAsync<MarketplaceOptionDto>(
                "SELECT MarketplaceId, MarketplaceName, Region, CurrencyCode FROM dbo.Marketplaces WHERE IsActive=1 ORDER BY Region, MarketplaceName");
            return rows.ToList();
        }

        private static byte[] EncryptValue(string value)
        {
            // AES-256 encryption. Key should come from config in production.
            var key = Encoding.UTF8.GetBytes("FBAManager-AES256-Key-32CharsPad!");
            using var aes = Aes.Create();
            aes.Key = key[..32];
            aes.GenerateIV();
            using var enc = aes.CreateEncryptor();
            var bytes = Encoding.UTF8.GetBytes(value);
            var encrypted = enc.TransformFinalBlock(bytes, 0, bytes.Length);
            // Prepend IV
            var result = new byte[aes.IV.Length + encrypted.Length];
            Array.Copy(aes.IV, result, aes.IV.Length);
            Array.Copy(encrypted, 0, result, aes.IV.Length, encrypted.Length);
            return result;
        }
    }

    // ============================================================
    // USER MANAGEMENT CONTROLLER
    // ============================================================
    [Authorize]
    public class UsersController : BaseController
    {
        private readonly ISqlConnectionFactory _cf;
        public UsersController(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<IActionResult> Index()
        {
            if (!IsAdmin) return Forbid();
            using var conn = _cf.Create();
            var users = await conn.QueryAsync<UserDto>(
                "SELECT u.UserId, u.Username, u.Email, u.FirstName, u.LastName, u.RoleId, r.RoleName, u.IsActive, u.LastLoginDate " +
                "FROM dbo.Users u INNER JOIN dbo.Roles r ON r.RoleId = u.RoleId ORDER BY u.Username");
            var accounts = await conn.QueryAsync<SellerAccountDto>(
                "SELECT SellerAccountId, AccountName FROM dbo.SellerAccounts WHERE IsActive=1 ORDER BY AccountName");
            return View(new UserManagementViewModel { Users = users.ToList(), AllAccounts = accounts.ToList() });
        }

        [HttpGet]
        public async Task<IActionResult> CreateUser()
        {
            if (!IsAdmin) return Forbid();
            using var conn = _cf.Create();
            var accounts = await conn.QueryAsync<SellerAccountDto>(
                "SELECT SellerAccountId, AccountName FROM dbo.SellerAccounts WHERE IsActive=1 ORDER BY AccountName");
            return View("UserForm", new UserFormViewModel { AllAccounts = accounts.ToList() });
        }

        [HttpGet]
        public async Task<IActionResult> EditUser(int id)
        {
            if (!IsAdmin) return Forbid();
            using var conn = _cf.Create();
            var user = await conn.QueryFirstOrDefaultAsync<UserDto>(
                "SELECT u.UserId, u.Username, u.Email, u.FirstName, u.LastName, u.RoleId, r.RoleName, u.IsActive " +
                "FROM dbo.Users u INNER JOIN dbo.Roles r ON r.RoleId=u.RoleId WHERE u.UserId=@Id", new { Id = id });
            if (user == null) return NotFound();

            var assigned = await conn.QueryAsync<int>(
                "SELECT SellerAccountId FROM dbo.UserSellerAccounts WHERE UserId=@Id", new { Id = id });
            var accounts = await conn.QueryAsync<SellerAccountDto>(
                "SELECT SellerAccountId, AccountName FROM dbo.SellerAccounts WHERE IsActive=1 ORDER BY AccountName");

            return View("UserForm", new UserFormViewModel
            {
                UserId = user.UserId, Username = user.Username, Email = user.Email,
                FirstName = user.FirstName, LastName = user.LastName, RoleId = user.RoleId,
                IsActive = user.IsActive, AssignedAccountIds = assigned.ToList(),
                AllAccounts = accounts.ToList()
            });
        }

        [HttpPost]
        public async Task<IActionResult> SaveUser(UserFormViewModel model)
        {
            if (!IsAdmin) return Forbid();
            if (!ModelState.IsValid) return View("UserForm", model);
            using var conn = _cf.Create();

            if (model.UserId == 0)
            {
                if (string.IsNullOrEmpty(model.NewPassword))
                { ModelState.AddModelError("NewPassword", "Password required for new users."); return View("UserForm", model); }
                var hash = HashPassword(model.NewPassword);
                model.UserId = await conn.QuerySingleAsync<int>(
                    "INSERT INTO dbo.Users (Username,Email,PasswordHash,RoleId,FirstName,LastName,IsActive) " +
                    "OUTPUT INSERTED.UserId VALUES (@Username,@Email,@Hash,@RoleId,@First,@Last,@Active)",
                    new { model.Username, model.Email, Hash = hash, model.RoleId,
                          First = model.FirstName, Last = model.LastName, Active = model.IsActive });
                SetSuccess($"User '{model.Username}' created.");
            }
            else
            {
                await conn.ExecuteAsync(
                    "UPDATE dbo.Users SET Username=@Username, Email=@Email, RoleId=@RoleId, " +
                    "FirstName=@First, LastName=@Last, IsActive=@Active, ModifiedDate=SYSUTCDATETIME() WHERE UserId=@Id",
                    new { model.Username, model.Email, model.RoleId,
                          First = model.FirstName, Last = model.LastName, Active = model.IsActive, Id = model.UserId });
                if (!string.IsNullOrEmpty(model.NewPassword))
                    await conn.ExecuteAsync("UPDATE dbo.Users SET PasswordHash=@Hash WHERE UserId=@Id",
                        new { Hash = HashPassword(model.NewPassword), Id = model.UserId });
                SetSuccess($"User '{model.Username}' updated.");
            }

            // Sync account assignments
            await conn.ExecuteAsync("DELETE FROM dbo.UserSellerAccounts WHERE UserId=@Id", new { Id = model.UserId });
            foreach (var accountId in model.AssignedAccountIds)
                await conn.ExecuteAsync(
                    "INSERT INTO dbo.UserSellerAccounts (UserId,SellerAccountId,PermissionLevel) VALUES (@Uid,@Aid,'WRITE')",
                    new { Uid = model.UserId, Aid = accountId });

            return RedirectToAction("Index");
        }

        private static string HashPassword(string password)
        {
            using var sha = SHA256.Create();
            return Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(password)));
        }
    }

    // ============================================================
    // EMAIL TEMPLATES CONTROLLER
    // ============================================================
    [Authorize]
    public class EmailTemplatesController : BaseController
    {
        private readonly ISqlConnectionFactory _cf;
        public EmailTemplatesController(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<IActionResult> Index(string? category = null)
        {
            using var conn = _cf.Create();
            var sql = "SELECT TemplateId, TemplateCode, TemplateName, Category, SubCategory, SubjectLine, Tags " +
                      "FROM dbo.EmailTemplates WHERE IsActive=1 " +
                      (category != null ? "AND Category=@Category " : "") +
                      "ORDER BY Category, TemplateName";
            var templates = await conn.QueryAsync<EmailTemplateDto>(sql,
                category != null ? new { Category = category } : null);
            ViewBag.Categories = new[] { "CASE_MANAGEMENT", "BUYER_MESSAGE", "BRAND_IP", "INTERNAL_OPS" };
            ViewBag.ActiveCategory = category;
            return View(templates);
        }

        public async Task<IActionResult> Detail(string code)
        {
            using var conn = _cf.Create();
            var template = await conn.QueryFirstOrDefaultAsync<EmailTemplateDto>(
                "SELECT * FROM dbo.EmailTemplates WHERE TemplateCode=@Code AND IsActive=1", new { Code = code });
            if (template == null) return NotFound();

            // Extract merge fields from body (everything in [BRACKETS])
            var mergeFields = System.Text.RegularExpressions.Regex
                .Matches(template.BodyText, @"\[([A-Z_]+)\]")
                .Select(m => m.Groups[1].Value)
                .Distinct()
                .ToDictionary(k => k, _ => "");

            return View(new EmailTemplateDetailViewModel
            {
                TemplateId = template.TemplateId, TemplateCode = template.TemplateCode,
                TemplateName = template.TemplateName, Category = template.Category,
                SubjectLine = template.SubjectLine, BodyText = template.BodyText,
                MergeFields = mergeFields,
                RenderedSubject = template.SubjectLine,
                RenderedBody = template.BodyText
            });
        }

        [HttpPost]
        public async Task<IActionResult> Render([FromBody] EmailTemplateDetailViewModel model)
        {
            using var conn = _cf.Create();
            var template = await conn.QueryFirstOrDefaultAsync<EmailTemplateDto>(
                "SELECT SubjectLine, BodyText FROM dbo.EmailTemplates WHERE TemplateId=@Id", new { Id = model.TemplateId });
            if (template == null) return NotFound();

            var subject = template.SubjectLine;
            var body = template.BodyText;
            foreach (var kv in model.MergeFields)
            {
                subject = subject.Replace($"[{kv.Key}]", kv.Value);
                body = body.Replace($"[{kv.Key}]", kv.Value);
            }
            return Json(new { subject, body });
        }
    }

    // ============================================================
    // SOP BUILDER CONTROLLER
    // ============================================================
    [Authorize]
    public class SOPController : BaseController
    {
        private readonly ISqlConnectionFactory _cf;
        public SOPController(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<IActionResult> Index()
        {
            using var conn = _cf.Create();
            var templates = await conn.QueryAsync<SOPTemplateDto>(
                "SELECT TemplateId, TemplateCode, TemplateName, Category, Body, IsActive " +
                "FROM dbo.SOPTemplates WHERE IsActive=1 ORDER BY Category, TemplateName");

            var assignments = await conn.QueryAsync<SOPAssignmentDto>(
                "SELECT sa.AssignmentId, st.TemplateName, u.Username AS AssignedToUsername, " +
                "sa.AssignedDate, sa.DueDate, sa.CompletedDate, sa.Status, sa.Notes " +
                "FROM dbo.SOPAssignments sa " +
                "INNER JOIN dbo.SOPTemplates st ON st.TemplateId = sa.TemplateId " +
                "INNER JOIN dbo.Users u ON u.UserId = sa.AssignedToUserId " +
                "WHERE sa.SellerAccountId = @AccountId " +
                "ORDER BY sa.AssignedDate DESC",
                new { AccountId = CurrentSellerAccountId });

            return View(new SOPTemplateListViewModel
            {
                Templates = templates.ToList(),
                RecentAssignments = assignments.Take(20).ToList()
            });
        }

        public async Task<IActionResult> View(int id)
        {
            using var conn = _cf.Create();
            var template = await conn.QueryFirstOrDefaultAsync<SOPTemplateDto>(
                "SELECT * FROM dbo.SOPTemplates WHERE TemplateId=@Id", new { Id = id });
            return template == null ? NotFound() : View("SOPView", template);
        }

        [HttpGet]
        public async Task<IActionResult> Assign(int templateId)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            if (!CanWrite) return Forbid();
            using var conn = _cf.Create();
            var users = await conn.QueryAsync<UserDto>(
                "SELECT u.UserId, u.Username, r.RoleName FROM dbo.Users u " +
                "INNER JOIN dbo.Roles r ON r.RoleId=u.RoleId " +
                "INNER JOIN dbo.UserSellerAccounts usa ON usa.UserId=u.UserId " +
                "WHERE usa.SellerAccountId=@AccountId AND u.IsActive=1 ORDER BY u.Username",
                new { AccountId = CurrentSellerAccountId });
            ViewBag.Users = users;
            ViewBag.TemplateId = templateId;
            return View(new SOPAssignRequestViewModel { TemplateId = templateId, SellerAccountId = CurrentSellerAccountId });
        }

        [HttpPost]
        public async Task<IActionResult> Assign(SOPAssignRequestViewModel model)
        {
            if (!CanWrite) return Forbid();
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                "INSERT INTO dbo.SOPAssignments (TemplateId,AssignedToUserId,SellerAccountId,DueDate,Notes) " +
                "VALUES (@TemplateId,@UserId,@AccountId,@Due,@Notes)",
                new { model.TemplateId, UserId = model.AssignedToUserId, AccountId = model.SellerAccountId,
                      Due = model.DueDate, Notes = model.Notes });
            SetSuccess("SOP assigned successfully.");
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> MarkComplete(int assignmentId)
        {
            using var conn = _cf.Create();
            await conn.ExecuteAsync(
                "UPDATE dbo.SOPAssignments SET Status='COMPLETE', CompletedDate=SYSUTCDATETIME() WHERE AssignmentId=@Id",
                new { Id = assignmentId });
            return Json(new { success = true });
        }
    }

    // ============================================================
    // HELP CONTROLLER
    // ============================================================
    [Authorize]
    public class HelpController : BaseController
    {
        private readonly ISqlConnectionFactory _cf;
        public HelpController(ISqlConnectionFactory cf) => _cf = cf;

        public async Task<IActionResult> Index(string? q = null)
        {
            using var conn = _cf.Create();
            IEnumerable<HelpTopicDto> topics;

            if (!string.IsNullOrWhiteSpace(q))
            {
                topics = await conn.QueryAsync<HelpTopicDto>(
                    "SELECT * FROM dbo.HelpTopics WHERE IsActive=1 AND " +
                    "(TopicName LIKE @Q OR WhatItDoes LIKE @Q OR StepByStep LIKE @Q) " +
                    "ORDER BY SectionNumber, SortOrder",
                    new { Q = $"%{q}%" });
            }
            else
            {
                topics = await conn.QueryAsync<HelpTopicDto>(
                    "SELECT * FROM dbo.HelpTopics WHERE IsActive=1 ORDER BY SectionNumber, SortOrder");
            }

            var sections = topics
                .GroupBy(t => new { t.SectionNumber, t.SectionName })
                .OrderBy(g => g.Key.SectionNumber)
                .Select(g => new HelpSectionDto
                {
                    SectionNumber = g.Key.SectionNumber,
                    SectionName = g.Key.SectionName,
                    Topics = g.ToList()
                }).ToList();

            return View(new HelpIndexViewModel { Sections = sections, SearchQuery = q });
        }

        public async Task<IActionResult> Topic(string code)
        {
            using var conn = _cf.Create();
            var topic = await conn.QueryFirstOrDefaultAsync<HelpTopicDto>(
                "SELECT * FROM dbo.HelpTopics WHERE TopicCode=@Code AND IsActive=1", new { Code = code });
            return topic == null ? NotFound() : View(topic);
        }
    }

    // ============================================================
    // EXPORT CONTROLLER
    // ============================================================
    [Authorize]
    public class ExportController : BaseController
    {
        private readonly IExportService _exportService;
        public ExportController(IExportService exportService) => _exportService = exportService;

        [HttpPost]
        public async Task<IActionResult> Download(ExportRequestViewModel model)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            model.SellerAccountId = CurrentSellerAccountId;

            var dto = new ExportRequestDto
            {
                ReportType = model.ReportType,
                Format = model.Format,
                DateFrom = model.DateFrom,
                DateTo = model.DateTo,
                GroupBy = model.GroupBy,
                SellerAccountId = model.SellerAccountId
            };
            var (data, mimeType, fileName) = await _exportService.GenerateAsync(dto, CurrentUserId);
            return File(data, mimeType, fileName);
        }

        // Quick export endpoints used by report pages
        [HttpGet]
        public async Task<IActionResult> ProfitLoss(DateTime dateFrom, DateTime dateTo, string format = "EXCEL")
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var dto = new ExportRequestDto
            {
                ReportType = "PL", Format = format,
                DateFrom = dateFrom, DateTo = dateTo,
                SellerAccountId = CurrentSellerAccountId
            };
            var (data, mime, name) = await _exportService.GenerateAsync(dto, CurrentUserId);
            return File(data, mime, name);
        }

        [HttpGet]
        public async Task<IActionResult> ReimbursementAudit(DateTime dateFrom, DateTime dateTo, string format = "EXCEL")
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var dto = new ExportRequestDto
            {
                ReportType = "REIMBURSEMENT", Format = format,
                DateFrom = dateFrom, DateTo = dateTo,
                SellerAccountId = CurrentSellerAccountId
            };
            var (data, mime, name) = await _exportService.GenerateAsync(dto, CurrentUserId);
            return File(data, mime, name);
        }
    }
}
