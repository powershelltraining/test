// ============================================================
// AmazonFBAManager.Web/Controllers/HomeController.cs
// Minimal Home controller — catches unhandled routes + errors
// ============================================================
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AmazonFBAManager.Web.Controllers
{
    public class HomeController : Controller
    {
        [Authorize]
        public IActionResult Index() => RedirectToAction("Index", "Dashboard");

        [AllowAnonymous]
        public IActionResult Error()
        {
            ViewData["Title"] = "Error";
            return View("~/Views/Shared/Error.cshtml");
        }

        [AllowAnonymous]
        [Route("Health")]
        public IActionResult Health() => Ok(new { status = "healthy", utc = DateTime.UtcNow });
    }
}
