// ============================================================
// AmazonFBAManager.Web/Controllers/AuthController.cs
// ============================================================
using AmazonFBAManager.Data.Services;
using AmazonFBAManager.Shared.DTOs;
using AmazonFBAManager.Shared.Interfaces;
using AmazonFBAManager.Web.Controllers;
using AmazonFBAManager.Web.Hubs;
using Microsoft.AspNetCore.SignalR;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AmazonFBAManager.Web.Controllers
{
    [AllowAnonymous]
    public class AuthController : Controller
    {
        private readonly IAuthRepository _auth;
        public AuthController(IAuthRepository auth) => _auth = auth;

        [HttpGet] public IActionResult Login(string? returnUrl = null)
        {
            if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Dashboard");
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginRequestDto model, string? returnUrl = null)
        {
            if (!ModelState.IsValid) return View(model);

            var result = await _auth.LoginAsync(model.Username, model.Password);
            if (!result.Success)
            {
                ModelState.AddModelError("", result.ErrorMessage ?? "Invalid credentials.");
                return View(model);
            }

            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, result.User!.UserId.ToString()),
                new(ClaimTypes.Name, result.User.Username),
                new(ClaimTypes.Email, result.User.Email),
                new(ClaimTypes.Role, result.User.RoleName),
                new("RoleId", result.User.RoleId.ToString())
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal,
                new AuthenticationProperties { IsPersistent = true, ExpiresUtc = DateTimeOffset.UtcNow.AddHours(10) });

            // Auto-select first account
            if (result.Accounts.Count > 0)
            {
                HttpContext.Session.SetString("SelectedAccountId", result.Accounts[0].SellerAccountId.ToString());
                HttpContext.Session.SetString("SelectedAccountName", result.Accounts[0].AccountName);
            }

            HttpContext.Session.SetString("UserAccounts", System.Text.Json.JsonSerializer.Serialize(result.Accounts));

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("Index", "Dashboard");
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        [Authorize]
        [HttpPost]
        public IActionResult SwitchAccount(int accountId, string accountName)
        {
            HttpContext.Session.SetString("SelectedAccountId", accountId.ToString());
            HttpContext.Session.SetString("SelectedAccountName", accountName);
            return Json(new { success = true });
        }

        public IActionResult AccessDenied() => View();
    }
}

// ============================================================
// AmazonFBAManager.Web/Controllers/DashboardController.cs
// ============================================================
namespace AmazonFBAManager.Web.Controllers
{
    public class DashboardController : BaseController
    {
        private readonly IReportsRepository _reports;
        private readonly IAlertRepository _alerts;

        public DashboardController(IReportsRepository reports, IAlertRepository alerts)
        {
            _reports = reports; _alerts = alerts;
        }

        public async Task<IActionResult> Index()
        {
            var dateFrom = DateTime.UtcNow.AddDays(-30).Date;
            var dateTo = DateTime.UtcNow.Date;

            var summary = await _reports.GetMultiAccountSummaryAsync(CurrentUserId, dateFrom, dateTo);
            var unreadAlerts = CurrentSellerAccountId > 0
                ? await _alerts.GetUnreadAlertsAsync(CurrentSellerAccountId, CurrentUserId, 10)
                : Enumerable.Empty<AlertDto>();

            ViewBag.Summary = summary;
            ViewBag.UnreadAlerts = unreadAlerts;
            ViewBag.DateFrom = dateFrom;
            ViewBag.DateTo = dateTo;
            return View();
        }
    }
}

// ============================================================
// AmazonFBAManager.Web/Controllers/InventoryController.cs
// ============================================================
namespace AmazonFBAManager.Web.Controllers
{
    public class InventoryController : BaseController
    {
        private readonly IInventoryRepository _inv;
        public InventoryController(IInventoryRepository inv) => _inv = inv;

        public async Task<IActionResult> Index()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var suggestions = await _inv.GetReorderSuggestionsAsync(CurrentSellerAccountId, CurrentUserId);
            return View(suggestions);
        }

        public async Task<IActionResult> ReorderSuggestions()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _inv.GetReorderSuggestionsAsync(CurrentSellerAccountId, CurrentUserId);
            return View(data);
        }

        public async Task<IActionResult> Overstock()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _inv.GetOverstockReportAsync(CurrentSellerAccountId, CurrentUserId);
            return View(data);
        }

        public async Task<IActionResult> AgedInventory()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _inv.GetAgedInventoryFeeRiskAsync(CurrentSellerAccountId, CurrentUserId);
            return View(data);
        }

        public async Task<IActionResult> Stranded()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _inv.GetStrandedInventoryAsync(CurrentSellerAccountId, CurrentUserId);
            return View(data);
        }

        public async Task<IActionResult> AWDDiscrepancies()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _inv.GetAWDDiscrepanciesAsync(CurrentSellerAccountId, CurrentUserId);
            return View(data);
        }

        public async Task<IActionResult> FBAFBMCompare(int productId)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _inv.CompareFBAFBMAsync(productId, CurrentSellerAccountId, CurrentUserId);
            return View(data);
        }

        [HttpGet]
        public async Task<IActionResult> GetReorderJson()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _inv.GetReorderSuggestionsAsync(CurrentSellerAccountId, CurrentUserId);
            return Json(data);
        }
    }
}

// ============================================================
// AmazonFBAManager.Web/Controllers/CasesController.cs
// ============================================================
namespace AmazonFBAManager.Web.Controllers
{
    public class CasesController : BaseController
    {
        private readonly ICaseRepository _cases;
        public CasesController(ICaseRepository cases) => _cases = cases;

        public async Task<IActionResult> Index()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var cases = await _cases.GetKanbanBoardAsync(CurrentSellerAccountId, CurrentUserId);
            return View(cases);
        }

        public async Task<IActionResult> Detail(int id)
        {
            var caseDetail = await _cases.GetCaseDetailAsync(id, CurrentUserId);
            if (caseDetail == null) return NotFound();
            var notes = await _cases.GetCaseNotesAsync(id, CurrentUserId);
            var attachments = await _cases.GetCaseAttachmentsAsync(id, CurrentUserId);
            ViewBag.Notes = notes;
            ViewBag.Attachments = attachments;
            return View(caseDetail);
        }

        [HttpGet]
        public IActionResult Create()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            return View(new CreateCaseRequestDto { SellerAccountId = CurrentSellerAccountId });
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateCaseRequestDto model)
        {
            if (!CanWrite) { SetError("Insufficient permissions."); return RedirectToAction("Index"); }
            if (!ModelState.IsValid) return View(model);
            var caseId = await _cases.CreateCaseAsync(model, CurrentUserId);
            SetSuccess($"Case #{caseId} created successfully.");
            return RedirectToAction("Detail", new { id = caseId });
        }

        [HttpPost]
        public async Task<IActionResult> Escalate(int caseId, string reason)
        {
            await _cases.EscalateCaseAsync(caseId, CurrentUserId, reason);
            SetSuccess("Case escalated.");
            return RedirectToAction("Detail", new { id = caseId });
        }

        [HttpPost]
        public async Task<IActionResult> Resolve(ResolveCaseRequestDto model)
        {
            if (!CanWrite) return Json(new { success = false, message = "Insufficient permissions." });
            await _cases.ResolveCaseAsync(model, CurrentUserId);
            SetSuccess($"Case #{model.CaseId} resolved.");
            return RedirectToAction("Detail", new { id = model.CaseId });
        }

        [HttpPost]
        public async Task<IActionResult> AddNote(int caseId, string noteText, bool isInternal = true)
        {
            await _cases.AddCaseNoteAsync(caseId, CurrentUserId, noteText, isInternal);
            return RedirectToAction("Detail", new { id = caseId });
        }

        [HttpPost]
        public async Task<IActionResult> UploadAttachment(int caseId, IFormFile file)
        {
            if (file == null || file.Length == 0) { SetError("No file selected."); return RedirectToAction("Detail", new { id = caseId }); }

            var uploadPath = Path.Combine("wwwroot", "uploads", "cases", caseId.ToString());
            Directory.CreateDirectory(uploadPath);
            var fileName = Path.GetFileName(file.FileName);
            var filePath = Path.Combine(uploadPath, $"{Guid.NewGuid()}_{fileName}");
            using var stream = new FileStream(filePath, FileMode.Create);
            await file.CopyToAsync(stream);

            await _cases.SaveCaseAttachmentAsync(caseId, fileName, filePath, file.Length, file.ContentType, CurrentUserId);
            SetSuccess("Attachment uploaded.");
            return RedirectToAction("Detail", new { id = caseId });
        }

        public async Task<IActionResult> Aging()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _cases.GetAgingReportAsync(CurrentSellerAccountId, CurrentUserId);
            return View(data);
        }

        public async Task<IActionResult> HijackReport(int productId, string? hijackerName = null)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _cases.BuildHijackReportAsync(productId, CurrentSellerAccountId, CurrentUserId, hijackerName);
            return View(data);
        }
    }
}

// ============================================================
// AmazonFBAManager.Web/Controllers/ReimbursementController.cs
// ============================================================
namespace AmazonFBAManager.Web.Controllers
{
    public class ReimbursementController : BaseController
    {
        private readonly IReimbursementRepository _reimb;
        public ReimbursementController(IReimbursementRepository reimb) => _reimb = reimb;

        public async Task<IActionResult> Index()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var kpi = await _reimb.GetKPIDashboardAsync(CurrentSellerAccountId, CurrentUserId);
            var trend = await _reimb.GetMonthlyTrendAsync(CurrentSellerAccountId, CurrentUserId);
            ViewBag.KPI = kpi;
            ViewBag.Trend = trend;
            return View();
        }

        public async Task<IActionResult> Checklist(int? month, int? year)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var m = month ?? DateTime.UtcNow.Month;
            var y = year ?? DateTime.UtcNow.Year;
            var data = await _reimb.GetMonthlyChecklistAsync(CurrentSellerAccountId, CurrentUserId, m, y);
            ViewBag.Month = m; ViewBag.Year = y;
            return View(data);
        }

        public async Task<IActionResult> LostDamaged(DateTime? dateFrom, DateTime? dateTo)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _reimb.AuditLostDamagedInventoryAsync(CurrentSellerAccountId, CurrentUserId, dateFrom, dateTo);
            ViewBag.DateFrom = dateFrom; ViewBag.DateTo = dateTo;
            return View(data);
        }

        public async Task<IActionResult> FeeOvercharges(DateTime? dateFrom, DateTime? dateTo)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _reimb.DetectFeeOverchargesAsync(CurrentSellerAccountId, CurrentUserId, dateFrom, dateTo);
            return View(data);
        }

        public async Task<IActionResult> ReturnlessRefunds(DateTime? dateFrom, DateTime? dateTo)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _reimb.AuditReturnlessRefundsAsync(CurrentSellerAccountId, CurrentUserId, dateFrom, dateTo);
            return View(data);
        }

        public async Task<IActionResult> COGSManager()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _reimb.GetMissingCOGSAsync(CurrentSellerAccountId, CurrentUserId);
            return View(data);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateCOGS([FromBody] List<COGSUpdateDto> updates)
        {
            if (!CanWrite) return Json(new { success = false, message = "Insufficient permissions." });
            var count = await _reimb.BulkUpdateCOGSAsync(CurrentSellerAccountId, CurrentUserId, updates);
            return Json(new { success = true, updated = count });
        }
    }
}

// ============================================================
// AmazonFBAManager.Web/Controllers/ReportsController.cs
// ============================================================
namespace AmazonFBAManager.Web.Controllers
{
    public class ReportsController : BaseController
    {
        private readonly IReportsRepository _reports;
        public ReportsController(IReportsRepository reports) => _reports = reports;

        public async Task<IActionResult> ProfitLoss(DateTime? dateFrom, DateTime? dateTo, string groupBy = "SKU")
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var df = dateFrom ?? DateTime.UtcNow.AddDays(-30).Date;
            var dt = dateTo ?? DateTime.UtcNow.Date;
            var data = await _reports.GetProfitLossBySKUAsync(CurrentSellerAccountId, CurrentUserId, df, dt, groupBy);
            ViewBag.DateFrom = df; ViewBag.DateTo = dt; ViewBag.GroupBy = groupBy;
            return View(data);
        }

        public async Task<IActionResult> MultiAccount(DateTime? dateFrom, DateTime? dateTo)
        {
            var df = dateFrom ?? DateTime.UtcNow.AddDays(-30).Date;
            var dt = dateTo ?? DateTime.UtcNow.Date;
            var data = await _reports.GetMultiAccountSummaryAsync(CurrentUserId, df, dt);
            ViewBag.DateFrom = df; ViewBag.DateTo = dt;
            return View(data);
        }

        public async Task<IActionResult> ReturnRate(DateTime? dateFrom, DateTime? dateTo)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var df = dateFrom ?? DateTime.UtcNow.AddDays(-90).Date;
            var dt = dateTo ?? DateTime.UtcNow.Date;
            var data = await _reports.GetReturnRateAnalysisAsync(CurrentSellerAccountId, CurrentUserId, df, dt);
            ViewBag.DateFrom = df; ViewBag.DateTo = dt;
            return View(data);
        }

        public async Task<IActionResult> CashFlowForecast(int forecastDays = 90)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _reports.GetCashFlowForecastAsync(CurrentSellerAccountId, CurrentUserId, forecastDays);
            ViewBag.ForecastDays = forecastDays;
            return View(data);
        }
    }
}

// ============================================================
// AmazonFBAManager.Web/Controllers/PPCController.cs
// ============================================================
namespace AmazonFBAManager.Web.Controllers
{
    public class PPCController : BaseController
    {
        private readonly IPPCRepository _ppc;
        public PPCController(IPPCRepository ppc) => _ppc = ppc;

        public async Task<IActionResult> Index(DateTime? dateFrom, DateTime? dateTo)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var df = dateFrom ?? DateTime.UtcNow.AddDays(-30).Date;
            var dt = dateTo ?? DateTime.UtcNow.Date;
            var audit = await _ppc.AuditCampaignsAsync(CurrentSellerAccountId, CurrentUserId, df, dt);
            var tacos = await _ppc.CalculateTACosAsync(CurrentSellerAccountId, CurrentUserId, df, dt);
            ViewBag.Audit = audit; ViewBag.TACoS = tacos;
            ViewBag.DateFrom = df; ViewBag.DateTo = dt;
            return View();
        }

        public async Task<IActionResult> TACoS(DateTime? dateFrom, DateTime? dateTo)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var df = dateFrom ?? DateTime.UtcNow.AddDays(-30).Date;
            var dt = dateTo ?? DateTime.UtcNow.Date;
            var data = await _ppc.CalculateTACosAsync(CurrentSellerAccountId, CurrentUserId, df, dt);
            return View(data);
        }
    }
}

// ============================================================
// AmazonFBAManager.Web/Controllers/ListingsController.cs
// ============================================================
namespace AmazonFBAManager.Web.Controllers
{
    public class ListingsController : BaseController
    {
        private readonly IListingRepository _listings;
        public ListingsController(IListingRepository listings) => _listings = listings;

        public async Task<IActionResult> Index()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _listings.GetAllHealthScoresAsync(CurrentSellerAccountId, CurrentUserId);
            return View(data);
        }

        public async Task<IActionResult> Detail(int productId)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _listings.GetHealthScoreAsync(productId, CurrentSellerAccountId, CurrentUserId);
            return data == null ? NotFound() : View(data);
        }
    }
}

// ============================================================
// AmazonFBAManager.Web/Controllers/ImportController.cs
// ============================================================
namespace AmazonFBAManager.Web.Controllers
{
    public class ImportController : BaseController
    {
        private readonly IImportRepository _importRepo;
        private readonly IImportOrchestrationService _importService;
        private readonly IHubContext<ImportProgressHub> _hub;

        public ImportController(
            IImportRepository importRepo,
            IImportOrchestrationService importService,
            IHubContext<ImportProgressHub> hub)
        {
            _importRepo = importRepo; _importService = importService; _hub = hub;
        }

        public async Task<IActionResult> Index()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var history = await _importRepo.GetImportHistoryAsync(CurrentSellerAccountId, CurrentUserId);
            return View(history);
        }

        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file, string reportTypeCode)
        {
            var acct = RequireAccount(); if (acct != null) return acct;

            if (file == null || file.Length == 0)
                return Json(new { success = false, message = "No file received." });

            // Create import record
            var importId = await _importRepo.CreateImportRecordAsync(
                CurrentSellerAccountId, CurrentUserId, reportTypeCode, file.FileName, file.Length);

            // Process asynchronously — fire and forget, push progress via SignalR
            _ = Task.Run(async () =>
            {
                using var stream = file.OpenReadStream();
                var progress = new Progress<string>(async msg =>
                    await _hub.Clients.Group($"import_{importId}").SendAsync("ImportUpdate",
                        new { ImportId = importId, Message = msg, Status = "PROCESSING" }));

                var result = await _importService.ProcessImportAsync(
                    importId, CurrentSellerAccountId, CurrentUserId,
                    reportTypeCode, stream, file.FileName, progress);

                // Final push
                await _hub.Clients.Group($"import_{importId}").SendAsync("ImportComplete", new
                {
                    ImportId = importId,
                    Status = result.Status,
                    RowsImported = result.RowsImported,
                    RowsErrored = result.RowsErrored,
                    ErrorLog = result.ErrorLog
                });
            });

            return Json(new { success = true, importId });
        }

        [HttpGet]
        public async Task<IActionResult> Status(int importId)
        {
            var result = await _importRepo.GetImportResultAsync(importId);
            return Json(result);
        }

        [HttpGet]
        public async Task<IActionResult> History()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _importRepo.GetImportHistoryAsync(CurrentSellerAccountId, CurrentUserId);
            return Json(data);
        }
    }
}

// ============================================================
// AmazonFBAManager.Web/Controllers/AlertsController.cs
// ============================================================
namespace AmazonFBAManager.Web.Controllers
{
    public class AlertsController : BaseController
    {
        private readonly IAlertRepository _alerts;
        public AlertsController(IAlertRepository alerts) => _alerts = alerts;

        public async Task<IActionResult> Index()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _alerts.GetAllAlertsAsync(CurrentSellerAccountId, CurrentUserId, 200);
            return View(data);
        }

        [HttpPost]
        public async Task<IActionResult> MarkRead(long alertId)
        {
            await _alerts.MarkAlertReadAsync(alertId, CurrentUserId);
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> MarkAllRead()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            await _alerts.MarkAllReadAsync(CurrentSellerAccountId, CurrentUserId);
            return Json(new { success = true });
        }

        [HttpGet]
        public async Task<IActionResult> UnreadCount()
        {
            if (CurrentSellerAccountId == 0) return Json(new { count = 0 });
            var count = await _alerts.GetUnreadCountAsync(CurrentSellerAccountId, CurrentUserId);
            return Json(new { count });
        }

        [HttpGet]
        public async Task<IActionResult> GetUnread()
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var data = await _alerts.GetUnreadAlertsAsync(CurrentSellerAccountId, CurrentUserId, 20);
            return Json(data);
        }
    }
}

// ============================================================
// AmazonFBAManager.Web/Controllers/ResearchController.cs
// ============================================================
namespace AmazonFBAManager.Web.Controllers
{
    public class ResearchController : BaseController
    {
        private readonly IResearchRepository _research;
        public ResearchController(IResearchRepository research) => _research = research;

        public IActionResult Index() => View();

        [HttpPost]
        public async Task<IActionResult> CalculateScore(
            string keyword, int? searchVolume, int? competitorCount,
            decimal? avgRevenue, int? avgReviews, decimal? avgPrice)
        {
            var acct = RequireAccount(); if (acct != null) return acct;
            var result = await _research.CalculateOpportunityScoreAsync(
                CurrentSellerAccountId, CurrentUserId,
                keyword, searchVolume, competitorCount, avgRevenue, avgReviews, avgPrice);
            return View("ScoreResult", result);
        }
    }
}
