// ============================================================
// AmazonFBAManager.Web/ViewModels/AllViewModels.cs
// View-specific models that aggregate DTOs or add UI state
// ============================================================
using AmazonFBAManager.Shared.DTOs;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AmazonFBAManager.Web.ViewModels
{
    // ── SETTINGS ─────────────────────────────────────────────
    public class SellerAccountFormViewModel
    {
        public int SellerAccountId { get; set; }

        [Required, StringLength(200)]
        [Display(Name = "Account Name")]
        public string AccountName { get; set; } = "";

        [Required]
        [Display(Name = "Marketplace")]
        public string MarketplaceId { get; set; } = "ATVPDKIKX0DER";

        [Display(Name = "Merchant Token")]
        public string? MerchantToken { get; set; }

        [Display(Name = "SP-API Client ID")]
        public string? SPAPIClientId { get; set; }

        [Display(Name = "SP-API Client Secret")]
        public string? SPAPIClientSecret { get; set; }

        [Display(Name = "SP-API Refresh Token")]
        public string? RefreshToken { get; set; }

        [Required]
        public string Region { get; set; } = "NA";

        public bool IsActive { get; set; } = true;
        public string? Notes { get; set; }

        // Available marketplaces (populated by controller)
        public List<MarketplaceOptionDto> Marketplaces { get; set; } = new();
    }

    public class MarketplaceOptionDto
    {
        public string MarketplaceId { get; set; } = "";
        public string MarketplaceName { get; set; } = "";
        public string Region { get; set; } = "";
        public string CurrencyCode { get; set; } = "";
    }

    public class AlertThresholdViewModel
    {
        public int SellerAccountId { get; set; }
        public string AccountName { get; set; } = "";
        public List<AlertThresholdRowDto> Thresholds { get; set; } = new();
    }

    public class AlertThresholdRowDto
    {
        public int ThresholdId { get; set; }
        public string AlertTypeCode { get; set; } = "";
        public string AlertTypeName { get; set; } = "";
        public string? SKU { get; set; }
        public int? ProductId { get; set; }
        public decimal ThresholdValue { get; set; }
        public string? ThresholdUnit { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
    }

    public class UserManagementViewModel
    {
        public List<UserDto> Users { get; set; } = new();
        public List<SellerAccountDto> AllAccounts { get; set; } = new();
    }

    public class UserFormViewModel
    {
        public int UserId { get; set; }

        [Required, StringLength(100)]
        public string Username { get; set; } = "";

        [Required, EmailAddress, StringLength(255)]
        public string Email { get; set; } = "";

        [StringLength(100)]
        [Display(Name = "First Name")]
        public string? FirstName { get; set; }

        [StringLength(100)]
        [Display(Name = "Last Name")]
        public string? LastName { get; set; }

        [Required]
        [Display(Name = "Role")]
        public int RoleId { get; set; }

        public bool IsActive { get; set; } = true;

        [StringLength(200, MinimumLength = 8)]
        [Display(Name = "Password (leave blank to keep current)")]
        public string? NewPassword { get; set; }

        // Assigned accounts (multi-select)
        public List<int> AssignedAccountIds { get; set; } = new();
        public List<SellerAccountDto> AllAccounts { get; set; } = new();
    }

    // ── SP-API ────────────────────────────────────────────────
    public class SPAPIConnectionTestResult
    {
        public bool Success { get; set; }
        public string? Message { get; set; }
        public string? MarketplaceName { get; set; }
        public string? SellerId { get; set; }
        public DateTime TestedAt { get; set; } = DateTime.UtcNow;
    }

    public class SPAPISyncViewModel
    {
        public int SellerAccountId { get; set; }
        public string AccountName { get; set; } = "";
        public List<SPAPISyncJobDto> AvailableJobs { get; set; } = new();
        public List<SPAPISyncHistoryDto> RecentHistory { get; set; } = new();
    }

    public class SPAPISyncJobDto
    {
        public string JobCode { get; set; } = "";
        public string JobName { get; set; } = "";
        public string Description { get; set; } = "";
        public string LastRunAt { get; set; } = "Never";
        public string Status { get; set; } = "IDLE";
    }

    public class SPAPISyncHistoryDto
    {
        public DateTime RunAt { get; set; }
        public string JobCode { get; set; } = "";
        public string Status { get; set; } = "";
        public int RecordsProcessed { get; set; }
        public string? ErrorMessage { get; set; }
    }

    // ── EXPORT ────────────────────────────────────────────────
    public class ExportRequestViewModel
    {
        [Required]
        public string ReportType { get; set; } = "";    // PL, CASES, REIMBURSEMENT, INVENTORY, etc.

        [Required]
        public string Format { get; set; } = "EXCEL";   // EXCEL, CSV, PDF

        public DateTime DateFrom { get; set; } = DateTime.UtcNow.AddDays(-30).Date;
        public DateTime DateTo { get; set; } = DateTime.UtcNow.Date;
        public string? GroupBy { get; set; }
        public int SellerAccountId { get; set; }
    }

    // ── EMAIL TEMPLATES ───────────────────────────────────────
    public class EmailTemplateListViewModel
    {
        public string Category { get; set; } = "";
        public List<EmailTemplateDto> Templates { get; set; } = new();
    }

    public class EmailTemplateDto
    {
        public int TemplateId { get; set; }
        public string TemplateCode { get; set; } = "";
        public string TemplateName { get; set; } = "";
        public string Category { get; set; } = "";
        public string? SubCategory { get; set; }
        public string SubjectLine { get; set; } = "";
        public string BodyText { get; set; } = "";
        public string? Tags { get; set; }
    }

    public class EmailTemplateDetailViewModel : EmailTemplateDto
    {
        // Merge field values supplied by user
        public Dictionary<string, string> MergeFields { get; set; } = new();
        public string RenderedSubject { get; set; } = "";
        public string RenderedBody { get; set; } = "";
    }

    // ── SOP BUILDER ───────────────────────────────────────────
    public class SOPTemplateListViewModel
    {
        public List<SOPTemplateDto> Templates { get; set; } = new();
        public List<SOPAssignmentDto> RecentAssignments { get; set; } = new();
    }

    public class SOPTemplateDto
    {
        public int TemplateId { get; set; }
        public string TemplateCode { get; set; } = "";
        public string TemplateName { get; set; } = "";
        public string Category { get; set; } = "";
        public string Body { get; set; } = "";
        public bool IsActive { get; set; }
    }

    public class SOPAssignmentDto
    {
        public int AssignmentId { get; set; }
        public string TemplateName { get; set; } = "";
        public string AssignedToUsername { get; set; } = "";
        public DateTime AssignedDate { get; set; }
        public DateTime? DueDate { get; set; }
        public DateTime? CompletedDate { get; set; }
        public string Status { get; set; } = "";
        public string? Notes { get; set; }
    }

    public class SOPAssignRequestViewModel
    {
        [Required]
        public int TemplateId { get; set; }

        [Required]
        public int AssignedToUserId { get; set; }

        [Required]
        public int SellerAccountId { get; set; }

        public DateTime? DueDate { get; set; }
        public string? Notes { get; set; }
    }

    // ── HELP TOPICS ───────────────────────────────────────────
    public class HelpTopicDto
    {
        public int TopicId { get; set; }
        public int SectionNumber { get; set; }
        public string SectionName { get; set; } = "";
        public string TopicCode { get; set; } = "";
        public string TopicName { get; set; } = "";
        public string WhatItDoes { get; set; } = "";
        public string WhenToUseIt { get; set; } = "";
        public string StepByStep { get; set; } = "";
        public string? ProTip { get; set; }
        public string? CommonMistake { get; set; }
    }

    public class HelpIndexViewModel
    {
        public List<HelpSectionDto> Sections { get; set; } = new();
        public string? SearchQuery { get; set; }
    }

    public class HelpSectionDto
    {
        public int SectionNumber { get; set; }
        public string SectionName { get; set; } = "";
        public List<HelpTopicDto> Topics { get; set; } = new();
    }
}
