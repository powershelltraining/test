// ============================================================
// AmazonFBAManager.Web/Infrastructure/Infrastructure.cs
// Hangfire auth filter, SignalR hubs, BaseController
// ============================================================
using AmazonFBAManager.Shared.Constants;
using Hangfire.Dashboard;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.SignalR;
using System.Security.Claims;

namespace AmazonFBAManager.Web.Hubs
{
    // ── SignalR: Import Progress ─────────────────────────────
    public class ImportProgressHub : Hub
    {
        public async Task JoinImportGroup(string importId) =>
            await Groups.AddToGroupAsync(Context.ConnectionId, $"import_{importId}");

        public async Task LeaveImportGroup(string importId) =>
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, $"import_{importId}");
    }

    // ── SignalR: Real-time Alerts ────────────────────────────
    public class AlertHub : Hub
    {
        public async Task JoinAccountGroup(string sellerAccountId) =>
            await Groups.AddToGroupAsync(Context.ConnectionId, $"account_{sellerAccountId}");
    }

    // ── SignalR Notifier Service ─────────────────────────────
    public interface ISignalRNotifier
    {
        Task NotifyImportProgressAsync(int importId, string message, string status, int rowsImported = 0);
        Task NotifyNewAlertAsync(int sellerAccountId, string severity, string message);
    }

    public class SignalRNotifier : ISignalRNotifier
    {
        private readonly IHubContext<ImportProgressHub> _importHub;
        private readonly IHubContext<AlertHub> _alertHub;

        public SignalRNotifier(IHubContext<ImportProgressHub> importHub, IHubContext<AlertHub> alertHub)
        {
            _importHub = importHub;
            _alertHub = alertHub;
        }

        public async Task NotifyImportProgressAsync(int importId, string message, string status, int rowsImported = 0)
        {
            await _importHub.Clients.Group($"import_{importId}").SendAsync("ImportUpdate", new
            {
                ImportId = importId,
                Message = message,
                Status = status,
                RowsImported = rowsImported
            });
        }

        public async Task NotifyNewAlertAsync(int sellerAccountId, string severity, string message)
        {
            await _alertHub.Clients.Group($"account_{sellerAccountId}").SendAsync("NewAlert", new
            {
                SellerAccountId = sellerAccountId,
                Severity = severity,
                Message = message,
                Timestamp = DateTime.UtcNow
            });
        }
    }
}

namespace AmazonFBAManager.Web
{
    // ── Hangfire Dashboard Auth (Admin only) ─────────────────
    public class HangfireAdminAuthFilter : IDashboardAuthorizationFilter
    {
        public bool Authorize(DashboardContext context)
        {
            var httpContext = context.GetHttpContext();
            return httpContext.User.Identity?.IsAuthenticated == true &&
                   httpContext.User.IsInRole(Roles.Admin);
        }
    }
}

namespace AmazonFBAManager.Web.Controllers
{
    // ── Base Controller ───────────────────────────────────────
    [Authorize]
    public abstract class BaseController : Controller
    {
        protected int CurrentUserId =>
            int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");

        protected string CurrentUsername =>
            User.FindFirstValue(ClaimTypes.Name) ?? "";

        protected string CurrentUserRole =>
            User.FindFirstValue(ClaimTypes.Role) ?? "";

        protected int CurrentSellerAccountId
        {
            get
            {
                var val = HttpContext.Session.GetString("SelectedAccountId");
                return int.TryParse(val, out var id) ? id : 0;
            }
        }

        protected string CurrentAccountName =>
            HttpContext.Session.GetString("SelectedAccountName") ?? "No Account Selected";

        protected void SetSelectedAccount(int accountId, string accountName)
        {
            HttpContext.Session.SetString("SelectedAccountId", accountId.ToString());
            HttpContext.Session.SetString("SelectedAccountName", accountName);
        }

        protected bool IsAdmin => CurrentUserRole == Roles.Admin;
        protected bool CanWrite => CurrentUserRole is Roles.Admin or Roles.AccountManager;

        protected void SetSuccess(string message) => TempData["Success"] = message;
        protected void SetError(string message) => TempData["Error"] = message;
        protected void SetWarning(string message) => TempData["Warning"] = message;

        protected IActionResult RequireAccount()
        {
            if (CurrentSellerAccountId == 0)
            {
                SetWarning("Please select a seller account first.");
                return RedirectToAction("Index", "Dashboard");
            }
            return null!;
        }
    }
}
