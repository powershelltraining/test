// ============================================================
// AmazonFBAManager.Web/Program.cs
// Full application bootstrap: DI, auth, SignalR, Hangfire, CSV
// ============================================================
using AmazonFBAManager.Data.Connections;
using AmazonFBAManager.Data.Repositories;
using AmazonFBAManager.Data.Services;
using AmazonFBAManager.Jobs;
using AmazonFBAManager.Shared.Interfaces;
using AmazonFBAManager.Web;
using AmazonFBAManager.Web.Hubs;
using Hangfire;
using Hangfire.SqlServer;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.Extensions.Http;

var builder = WebApplication.CreateBuilder(args);

// ── Connection string ────────────────────────────────────────
var connStr = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

// ── MVC + Razor Views ────────────────────────────────────────
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

// ── Cookie Authentication ────────────────────────────────────
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Auth/Login";
        options.LogoutPath = "/Auth/Logout";
        options.AccessDeniedPath = "/Auth/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromHours(10);
        options.SlidingExpiration = true;
        options.Cookie.Name = "FBAManager.Auth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    });

builder.Services.AddAuthorization();

// ── Session (for selected seller account) ───────────────────
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(8);
    options.Cookie.HttpOnly = true;
    options.Cookie.Name = "FBAManager.Session";
});

// ── SignalR ──────────────────────────────────────────────────
builder.Services.AddSignalR();

// ── Hangfire ─────────────────────────────────────────────────
builder.Services.AddHangfire(config => config
    .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
    .UseSimpleAssemblyNameTypeSerializer()
    .UseRecommendedSerializerSettings()
    .UseSqlServerStorage(connStr, new SqlServerStorageOptions
    {
        CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
        SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
        QueuePollInterval = TimeSpan.Zero,
        UseRecommendedIsolationLevel = true,
        DisableGlobalLocks = true
    }));
builder.Services.AddHangfireServer();

// ── Data Layer (Dapper repositories) ────────────────────────
builder.Services.AddSingleton<ISqlConnectionFactory>(_ => new SqlConnectionFactory(connStr));
builder.Services.AddScoped<IAuthRepository, AuthRepository>();
builder.Services.AddScoped<IInventoryRepository, InventoryRepository>();
builder.Services.AddScoped<IReimbursementRepository, ReimbursementRepository>();
builder.Services.AddScoped<ICaseRepository, CaseRepository>();
builder.Services.AddScoped<IReportsRepository, ReportsRepository>();
builder.Services.AddScoped<IPPCRepository, PPCRepository>();
builder.Services.AddScoped<IListingRepository, ListingRepository>();
builder.Services.AddScoped<IAlertRepository, AlertRepository>();
builder.Services.AddScoped<IImportRepository, ImportRepository>();
builder.Services.AddScoped<IResearchRepository, ResearchRepository>();

// ── Services ─────────────────────────────────────────────────
builder.Services.AddHttpClient();  // Required for IHttpClientFactory
builder.Services.AddScoped<ICsvParsingService, CsvParsingService>();
builder.Services.AddScoped<IImportOrchestrationService, ImportOrchestrationService>();
builder.Services.AddScoped<ISpApiService, SpApiService>();
builder.Services.AddScoped<IExportService, ExportService>();
builder.Services.AddScoped<IErrorLogService, ErrorLogService>();
builder.Services.AddScoped<IFbaJobService, FbaJobService>();

// ── HTTP Context for controllers ─────────────────────────────
builder.Services.AddHttpContextAccessor();

var app = builder.Build();

// ── Middleware pipeline ───────────────────────────────────────
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

// ── Hangfire Dashboard (admin only) ──────────────────────────
app.UseHangfireDashboard("/admin/jobs", new DashboardOptions
{
    Authorization = new[] { new HangfireAdminAuthFilter() }
});

// ── SignalR Hubs ─────────────────────────────────────────────
app.MapHub<ImportProgressHub>("/hubs/import");
app.MapHub<AlertHub>("/hubs/alerts");

// ── MVC Routes ───────────────────────────────────────────────
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Dashboard}/{action=Index}/{id?}");

// ── Razor Pages Routes ───────────────────────────────────────
app.MapRazorPages();

// ── Register Hangfire recurring jobs ─────────────────────────
RegisterHangfireJobs(app);

app.Run("http://localhost:5005");

static void RegisterHangfireJobs(WebApplication app)
{
    using var scope = app.Services.CreateScope();
    var jobService = scope.ServiceProvider.GetRequiredService<IFbaJobService>();

    RecurringJob.AddOrUpdate("nightly-reimb-audit",
        () => jobService.RunNightlyReimbursementAuditAsync(),
        "0 2 * * *",   // 2:00 AM UTC daily
        new RecurringJobOptions { TimeZone = TimeZoneInfo.Utc });

    RecurringJob.AddOrUpdate("inventory-alert-check",
        () => jobService.RunInventoryAlertCheckAsync(),
        "0 */4 * * *", // Every 4 hours
        new RecurringJobOptions { TimeZone = TimeZoneInfo.Utc });

    RecurringJob.AddOrUpdate("ppc-audit-weekly",
        () => jobService.RunPPCAuditWeeklyAsync(),
        "0 6 * * 1",   // Monday 6:00 AM UTC
        new RecurringJobOptions { TimeZone = TimeZoneInfo.Utc });

    RecurringJob.AddOrUpdate("case-sla-monitor",
        () => jobService.RunCaseSLAMonitorAsync(),
        "0 */2 * * *", // Every 2 hours
        new RecurringJobOptions { TimeZone = TimeZoneInfo.Utc });
}
