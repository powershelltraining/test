/* ============================================================
   AmazonFBAManager.Web/wwwroot/js/app.js
   Global JS: account switcher, alert badge, SignalR, sidebar
   ============================================================ */

(function () {
    'use strict';

    // ── DOM READY ────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', () => {
        initAccountSwitcher();
        initAlertBadge();
        initAlertSignalR();
        initSidebarToggle();
        initAutoHideAlerts();
        initConfirmButtons();
    });

    // ── ACCOUNT SWITCHER ─────────────────────────────────────
    function initAccountSwitcher() {
        const menuEl = document.getElementById('accountDropdownMenu');
        const nameEl = document.getElementById('activeAccountName');
        if (!menuEl) return;

        const raw = sessionStorage.getItem('UserAccounts') || '[]';
        let accounts = [];
        try { accounts = JSON.parse(raw); } catch { }

        // If not in sessionStorage, try fetching from server
        if (!accounts.length) {
            fetch('/Auth/GetAccounts')
                .then(r => r.json())
                .then(data => {
                    sessionStorage.setItem('UserAccounts', JSON.stringify(data));
                    renderAccountMenu(data, menuEl, nameEl);
                })
                .catch(() => {});
            return;
        }
        renderAccountMenu(accounts, menuEl, nameEl);
    }

    function renderAccountMenu(accounts, menuEl, nameEl) {
        const frag = document.createDocumentFragment();
        accounts.forEach(acct => {
            const li = document.createElement('li');
            const a = document.createElement('a');
            a.className = 'dropdown-item d-flex justify-content-between';
            a.href = '#';
            a.innerHTML = `<span>${escHtml(acct.accountName)}</span><small class="text-muted">${escHtml(acct.marketplaceName)}</small>`;
            a.addEventListener('click', e => {
                e.preventDefault();
                switchAccount(acct.sellerAccountId, acct.accountName, nameEl);
            });
            li.appendChild(a);
            frag.appendChild(li);
        });
        menuEl.appendChild(frag);
    }

    function switchAccount(accountId, accountName, nameEl) {
        fetch('/Auth/SwitchAccount', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'RequestVerificationToken': getAntiForgeryToken() },
            body: `accountId=${accountId}&accountName=${encodeURIComponent(accountName)}`
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                if (nameEl) nameEl.textContent = accountName;
                window.location.reload();
            }
        });
    }

    // ── ALERT BADGE ──────────────────────────────────────────
    function initAlertBadge() {
        const badge = document.getElementById('alertBadge');
        const topBadge = document.getElementById('topBarAlertBadge');
        if (!badge && !topBadge) return;

        function updateBadge() {
            fetch('/Alerts/UnreadCount')
                .then(r => r.json())
                .then(data => {
                    const count = data.count || 0;
                    [badge, topBadge].forEach(el => {
                        if (!el) return;
                        el.textContent = count > 99 ? '99+' : count;
                        el.style.display = count > 0 ? '' : 'none';
                    });
                })
                .catch(() => {});
        }

        updateBadge();
        setInterval(updateBadge, 60_000); // refresh every minute
    }

    // ── SIGNALR ALERT FEED ───────────────────────────────────
    function initAlertSignalR() {
        if (typeof signalR === 'undefined') return;

        const accountIdEl = document.querySelector('[data-account-id]');
        const accountId = accountIdEl?.dataset.accountId || getMetaContent('account-id');
        if (!accountId) return;

        const conn = new signalR.HubConnectionBuilder()
            .withUrl('/hubs/alerts')
            .withAutomaticReconnect()
            .build();

        conn.on('NewAlert', data => {
            showToast(data.message, data.severity?.toLowerCase() || 'info');
            // Refresh badge
            setTimeout(() => {
                fetch('/Alerts/UnreadCount')
                    .then(r => r.json())
                    .then(d => {
                        const count = d.count || 0;
                        ['alertBadge', 'topBarAlertBadge'].forEach(id => {
                            const el = document.getElementById(id);
                            if (el) { el.textContent = count; el.style.display = count > 0 ? '' : 'none'; }
                        });
                    });
            }, 500);
        });

        conn.start()
            .then(() => conn.invoke('JoinAccountGroup', String(accountId)))
            .catch(console.error);
    }

    // ── SIDEBAR TOGGLE (mobile) ───────────────────────────────
    function initSidebarToggle() {
        const toggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        if (!toggle || !sidebar) return;

        toggle.addEventListener('click', () => sidebar.classList.toggle('open'));

        // Close on outside click
        document.addEventListener('click', e => {
            if (!sidebar.contains(e.target) && !toggle.contains(e.target))
                sidebar.classList.remove('open');
        });
    }

    // ── AUTO-HIDE FLASH ALERTS ───────────────────────────────
    function initAutoHideAlerts() {
        document.querySelectorAll('.alert.alert-success, .alert.alert-info').forEach(el => {
            setTimeout(() => {
                el.style.transition = 'opacity .5s';
                el.style.opacity = '0';
                setTimeout(() => el.remove(), 500);
            }, 5000);
        });
    }

    // ── CONFIRM BUTTONS ──────────────────────────────────────
    function initConfirmButtons() {
        document.querySelectorAll('[data-confirm]').forEach(btn => {
            btn.addEventListener('click', e => {
                if (!confirm(btn.dataset.confirm)) e.preventDefault();
            });
        });
    }

    // ── TOAST NOTIFICATION ───────────────────────────────────
    function showToast(message, type = 'info') {
        let container = document.getElementById('toastContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toastContainer';
            container.className = 'position-fixed bottom-0 end-0 p-3';
            container.style.zIndex = '9999';
            document.body.appendChild(container);
        }

        const colorMap = { critical: 'danger', high: 'warning', medium: 'info', low: 'secondary', info: 'info', success: 'success' };
        const bsColor = colorMap[type] || 'secondary';

        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-bg-${bsColor} border-0 show mb-2`;
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body" style="font-size:.84rem">${escHtml(message)}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>`;
        container.prepend(toast);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }

    // ── UTILITIES ────────────────────────────────────────────
    function escHtml(str) {
        return String(str).replace(/[&<>"']/g, c =>
            ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    function getAntiForgeryToken() {
        return document.querySelector('input[name="__RequestVerificationToken"]')?.value || '';
    }

    function getMetaContent(name) {
        return document.querySelector(`meta[name="${name}"]`)?.content || '';
    }

    // ── EXPORT HELPERS (called from views) ───────────────────
    window.FBAApp = {
        exportTableToCSV(tableId, filename) {
            const table = document.getElementById(tableId);
            if (!table) return;
            const rows = Array.from(table.querySelectorAll('tr'));
            const csv = rows.map(r =>
                Array.from(r.querySelectorAll('th,td'))
                    .map(c => `"${c.innerText.replace(/"/g, '""').trim()}"`)
                    .join(',')
            ).join('\n');
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = filename || 'export.csv';
            a.click();
        },

        markAlertRead(alertId, rowEl) {
            fetch('/Alerts/MarkRead', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'RequestVerificationToken': getAntiForgeryToken() },
                body: `alertId=${alertId}`
            }).then(() => { if (rowEl) rowEl.style.opacity = '0.5'; });
        },

        showToast,
        escHtml
    };
})();
