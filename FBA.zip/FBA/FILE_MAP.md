# FILE MAP — Amazon FBA Manager Platform
## Complete guide to every file in this project

---

## DATABASE (run in order)

| File | Tables/Objects Created | Notes |
|---|---|---|
| `Database/Tables/01_CoreTables.sql` | 21 tables, all indexes, foreign keys, computed columns | Run first |
| `Database/TVPs/02_TVPs_And_Security.sql` | 8 TVPs, `fn_UserHasAccountAccess`, `fn_GetUserPermissionLevel`, `usp_Auth_*` | Row-level security |
| `Database/Seed/03_SeedData.sql` | 10 marketplaces, 4 roles, 19 alert types, 14 case types, 15 fee types, report types, SOP templates, default thresholds, admin user | Reference data |
| `Database/StoredProcedures/Import/04_SP_Import.sql` | 6 import SPs + import history SP | All CSV imports |
| `Database/StoredProcedures/Inventory/05_SP_Inventory.sql` | 6 inventory SPs (reorder, overstock, aged, stranded, AWD, FBA/FBM) | All inventory logic |
| `Database/StoredProcedures/Reimbursement/06_SP_Reimbursement.sql` | 7 reimbursement SPs (audit, fee scan, returnless, checklist, COGS, KPI) | 2025 policy aware |
| `Database/StoredProcedures/Cases/07_SP_Cases.sql` | 8 case SPs (create, escalate, resolve, kanban, aging, hijack, POA, SLA monitor) | Full case lifecycle |
| `Database/StoredProcedures/Reports/08_SP_Reports_PPC_Listings_Research.sql` | P&L, velocity, fees, multi-account, return rate, cash flow, PPC audit, TACoS, listing health, opportunity score | All reports |
| `Database/Views/09_Views_COGS_Jobs_Master.sql` | 4 views, COGS wizard SPs, 3 Hangfire job SPs, seller onboarding SP | Jobs + views |
| `Database/Seed/10_SeedData_EmailTemplates.sql` | 20 email templates across 4 categories | `dbo.EmailTemplates` |
| `Database/Seed/11_SeedData_HelpGuide.sql` | `dbo.HelpTopics` table + 11-section help guide | In-app help system |

---

## APPLICATION

### AmazonFBAManager.Shared (no external deps)

| File | Contents |
|---|---|
| `DTOs/AllDtos.cs` | 35+ DTOs: Auth, Inventory, Reimbursement, Cases, Reports, PPC, Listings, Alerts, Import, Research, COGS |
| `Interfaces/IRepositories.cs` | 10 repository interfaces (IAuthRepository through IResearchRepository) |
| `Constants/AppConstants.cs` | All 40+ SP names, report type codes, roles, priorities, statuses, SignalR hub paths |

### AmazonFBAManager.Data (Dapper + CsvHelper + ClosedXML)

| File | Contents |
|---|---|
| `Connections/SqlConnectionFactory.cs` | `ISqlConnectionFactory` + implementation — creates SqlConnection |
| `Repositories/Repositories.cs` | All 10 repository classes — pure Dapper SP calls, TVP passing, multi-result-set handling |
| `Services/CsvParsingService.cs` | Parses 7 Amazon report types → DataTable with header normalization, error collection |
| `Services/ImportOrchestrationService.cs` | Routes CSV → correct TVP → correct SP → SignalR push |
| `Services/SpApiService.cs` | Full SP-API: token refresh, inventory sync, orders sync, listings sync, reimbursements sync, FBA fee sync |
| `Services/ExportService.cs` | Generates Excel/CSV/PDF for P&L, reimbursement audit, inventory, cases, return rate |
| `Services/ExcelBuilder.cs` | ClosedXML Excel builder with formatted headers, alternating rows, auto-width, totals row |
| `ServiceExtensions.cs` | `AddFBAManagerDataLayer()` — single call registers all repos + services |
| `AmazonFBAManager.Data.csproj` | Dapper 2.1.28, SqlClient 5.2.1, CsvHelper 33.0.1, ClosedXML 0.102.3 |

### AmazonFBAManager.Jobs (Hangfire)

| File | Contents |
|---|---|
| `FbaJobService.cs` | 4 jobs: NightlyReimbAudit, InventoryAlertCheck, PPCAuditWeekly, CaseSLAMonitor |
| `AmazonFBAManager.Jobs.csproj` | Hangfire.Core 1.8.14 |

### AmazonFBAManager.Web (MVC frontend)

| File | Contents |
|---|---|
| `Program.cs` | Bootstrap: DI, cookie auth, SignalR, Hangfire SQL storage, static files, routing, job registration |
| `Program_Updated.cs` | Notes on additions needed (HttpClient, IExportService, ISignalRNotifier) |
| `appsettings.json` | Development connection string + app settings |
| `appsettings.Production.json` | Production overrides template |
| `web.config` | IIS hosting, max upload 50MB, static file cache, compression |
| **Controllers** | |
| `Controllers/AllControllers.cs` | Auth, Dashboard, Inventory, Cases, Reimbursement, Reports, PPC, Listings, Import, Alerts, Research |
| `Controllers/SettingsAndMoreControllers.cs` | Settings (accounts, thresholds, SP-API sync), Users, EmailTemplates, SOP, Help, Export |
| `Controllers/HomeController.cs` | Error handler, /Health endpoint, root redirect |
| **Infrastructure** | |
| `Infrastructure/Infrastructure.cs` | ImportProgressHub, AlertHub, SignalRNotifier, BaseController (userId/accountId helpers), HangfireAdminAuthFilter |
| **ViewModels** | |
| `ViewModels/AllViewModels.cs` | SellerAccountFormViewModel, AlertThresholdViewModel, UserManagement/Form, SPAPISync, ExportRequest, EmailTemplate, SOP, Help |
| **Views** | |
| `Views/_ViewImports.cshtml` | `@using`, `@addTagHelper` for all projects |
| `Views/_ViewStart.cshtml` | Sets `_Layout` as default |
| `Views/Shared/_Layout.cshtml` | Sidebar nav, account switcher, topbar, alert badge, flash messages, SignalR init |
| `Views/Shared/Error.cshtml` | Friendly error page |
| `Views/Dashboard/Index.cshtml` | Multi-account KPI cards, alert feed |
| `Views/AllViews.cshtml` | Inventory (reorder grid), Cases (kanban + detail + create), Reimbursement (KPI + import center) |
| `Views/AdditionalViews.cshtml` | Login, P&L report, PPC analyzer, Listing health index, Alerts center, Research scorer |
| `Views/RemainingViews.cshtml` | Checklist, COGS Manager, Aged Inventory, Stranded, Cases/Create, Research result, SOP |
| `Views/SettingsAndMoreViews.cshtml` | Account list, account form, alert thresholds, SP-API sync, user list, user form, email templates (list + detail), SOP (index + assign), Help (index + topic) |
| `Views/MoreViews.cshtml` | Alert banner partial, COGS warning, Lost/Damaged audit, Fee overcharges, Returnless refunds, Overstock, Cash flow forecast |
| `Views/FinalViews.cshtml` | Case aging, AWD discrepancies, Return rate, Multi-account dashboard, FBA/FBM compare |
| `Views/FinalViews2.cshtml` | SOP view, SOP assign, Listing detail, Home error |
| `wwwroot/css/app.css` | Complete stylesheet: sidebar, KPIs, kanban, drop zone, score bars, severity badges, auth page |
| `wwwroot/js/app.js` | Account switcher, alert badge polling, SignalR alert feed, toast notifications, CSV export, confirm buttons |
| `AmazonFBAManager.Web.csproj` | Auth cookies, SignalR, Hangfire AspNetCore + SqlServer, CsvHelper, Razor runtime compilation |

### AmazonFBAManager.API (REST API for desktop)

| File | Contents |
|---|---|
| `Controllers/ApiControllers.cs` | 6 API controllers: Inventory, Reimbursement, Cases, Reports, Alerts, PPC — all endpoints |
| `Program.cs` | JWT auth, Swagger/OpenAPI, CORS, same data layer registration |
| `AmazonFBAManager.API.csproj` | JwtBearer 8.0.8, Swashbuckle 6.7.3, IdentityModel |

### Root

| File | Contents |
|---|---|
| `AmazonFBAManager.sln` | Solution file wiring all 5 projects |
| `README.md` | Architecture overview, stack, DB setup, local dev, first login, jobs, roles, CSV types, SignalR events |
| `DEPLOYMENT_GUIDE.md` | Full IIS deployment: SQL setup, publish commands, IIS config, SSL, SP-API registration, backup strategy, troubleshooting |

---

## QUICK REFERENCE: View → Controller → Repository → SP

| URL | Controller | Repository Method | SP Called |
|---|---|---|---|
| `/Dashboard` | DashboardController.Index | GetMultiAccountSummaryAsync | usp_Reports_MultiAccountSummary |
| `/Inventory` | InventoryController.Index | GetReorderSuggestionsAsync | usp_Inventory_GetReorderSuggestions |
| `/Inventory/Overstock` | InventoryController.Overstock | GetOverstockReportAsync | usp_Inventory_GetOverstockReport |
| `/Inventory/AgedInventory` | InventoryController.AgedInventory | GetAgedInventoryFeeRiskAsync | usp_Inventory_GetAgedInventoryFeeRisk |
| `/Inventory/Stranded` | InventoryController.Stranded | GetStrandedInventoryAsync | usp_Inventory_GetStrandedInventory |
| `/Inventory/AWDDiscrepancies` | InventoryController.AWDDiscrepancies | GetAWDDiscrepanciesAsync | usp_Inventory_GetAWDDiscrepancies |
| `/Cases` | CasesController.Index | GetKanbanBoardAsync | usp_Case_GetKanbanBoard |
| `/Cases/Detail/{id}` | CasesController.Detail | GetCaseDetailAsync | usp_Case_GetDetail |
| `/Cases/Create` | CasesController.Create | CreateCaseAsync | usp_Case_Create |
| `/Cases/Aging` | CasesController.Aging | GetAgingReportAsync | usp_Case_GetAgingReport |
| `/Reimbursement` | ReimbursementController.Index | GetKPIDashboardAsync | usp_Reimbursement_GetKPIDashboard |
| `/Reimbursement/Checklist` | ReimbursementController.Checklist | GetMonthlyChecklistAsync | usp_Reimbursement_MonthlyChecklist |
| `/Reimbursement/LostDamaged` | ReimbursementController.LostDamaged | AuditLostDamagedInventoryAsync | usp_Reimbursement_AuditLostDamagedInventory |
| `/Reimbursement/FeeOvercharges` | ReimbursementController.FeeOvercharges | DetectFeeOverchargesAsync | usp_Reimbursement_DetectFeeOvercharges |
| `/Reimbursement/ReturnlessRefunds` | ReimbursementController.ReturnlessRefunds | AuditReturnlessRefundsAsync | usp_Reimbursement_AuditReturnlessRefunds |
| `/Reimbursement/COGSManager` | ReimbursementController.COGSManager | GetMissingCOGSAsync | usp_COGS_GetMissingList |
| `/Reports/ProfitLoss` | ReportsController.ProfitLoss | GetProfitLossBySKUAsync | usp_Reports_ProfitLossBySKU |
| `/Reports/MultiAccount` | ReportsController.MultiAccount | GetMultiAccountSummaryAsync | usp_Reports_MultiAccountSummary |
| `/Reports/ReturnRate` | ReportsController.ReturnRate | GetReturnRateAnalysisAsync | usp_Reports_ReturnRateAnalysis |
| `/Reports/CashFlowForecast` | ReportsController.CashFlowForecast | GetCashFlowForecastAsync | usp_Reports_CashFlowForecast |
| `/PPC` | PPCController.Index | AuditCampaignsAsync + CalculateTACosAsync | usp_PPC_AuditCampaigns + usp_PPC_CalculateTACoS |
| `/Listings` | ListingsController.Index | GetAllHealthScoresAsync | Direct SQL query |
| `/Listings/Detail/{id}` | ListingsController.Detail | GetHealthScoreAsync | usp_Listing_GetHealthScore |
| `/Import` | ImportController.Index | GetImportHistoryAsync | usp_Import_GetHistory |
| `/Import/Upload` | ImportController.Upload | CreateImportRecordAsync + ProcessImportAsync | TVP → per-type SP |
| `/Alerts` | AlertsController.Index | GetAllAlertsAsync | Direct SQL |
| `/Research` | ResearchController.Index | — | — |
| `/Research/CalculateScore` | ResearchController.CalculateScore | CalculateOpportunityScoreAsync | usp_Research_CalculateOpportunityScore |
| `/Settings/Accounts` | SettingsController.Accounts | Direct SQL | — |
| `/Settings/SPAPISync` | SettingsController.SPAPISync | SpApiService.RunSyncJobAsync | Amazon SP-API |
| `/Settings/AlertThresholds` | SettingsController.AlertThresholds | Direct SQL | — |
| `/Users` | UsersController.Index | Direct SQL | — |
| `/EmailTemplates` | EmailTemplatesController.Index | Direct SQL | — |
| `/SOP` | SOPController.Index | Direct SQL | — |
| `/Help` | HelpController.Index | Direct SQL from HelpTopics | — |
